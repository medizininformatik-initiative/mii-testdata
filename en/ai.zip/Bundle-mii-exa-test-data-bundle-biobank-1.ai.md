# mii-exa-test-data-bundle-biobank-1 - MII KDS Test Data v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-test-data-bundle-biobank-1**

## Example Bundle: mii-exa-test-data-bundle-biobank-1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-test-data-bundle-biobank-1",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2025-06-18T13:51:00+02:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-1",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-1</b></p><a name=\"mii-exa-test-data-biobank-patient-1\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Sabine Musterfrau  Female, DoB: 1975-11-03 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-001)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-001"
      }],
      "name" : [{
        "family" : "Musterfrau",
        "given" : ["Sabine"]
      }],
      "gender" : "female",
      "birthDate" : "1975-11-03"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-biobank-encounter-1",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-biobank-encounter-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-biobank-encounter-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-biobank-encounter-1</b></p><a name=\"mii-exa-test-data-biobank-encounter-1\"> </a><a name=\"hcmii-exa-test-data-biobank-encounter-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-1.html\">Sabine Musterfrau  Female, DoB: 1975-11-03 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-001)</a></p><p><b>period</b>: 2024-03-01 --&gt; 2024-03-01</p></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB",
        "display" : "ambulatory"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-1"
      },
      "period" : {
        "start" : "2024-03-01",
        "end" : "2024-03-01"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-biobank-encounter-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-biobank-charite",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-biobank-charite",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Organization"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-biobank-charite\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-biobank-charite</b></p><a name=\"mii-exa-test-data-organization-biobank-charite\"> </a><a name=\"hcmii-exa-test-data-organization-biobank-charite\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Organization\">MII PR Biobank Organization Sammlung Biobank</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Description extension</b>: Zentrale Biobank der Charité</p><p><b>identifier</b>: <code>http://www.bbmri-eric.eu/</code>/de-12345</p><p><b>name</b>: Zentrale Biobank der Charité</p><p><b>alias</b>: ZeBanC</p><p><b>partOf</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Purpose</b></td><td><b>Name</b></td><td><b>Telecom</b></td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/ContactType RESEARCH}\">Research</span></td><td>Koch Robert </td><td><a href=\"mailto:robert.koch@charite.de\">robert.koch@charite.de</a></td><td>Südring 7 Berlin 13353 </td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://fhir.bbmri-eric.eu/StructureDefinition/miabis-organization-description-extension",
        "valueString" : "Zentrale Biobank der Charité"
      }],
      "identifier" : [{
        "system" : "http://www.bbmri-eric.eu/",
        "value" : "de-12345"
      }],
      "name" : "Zentrale Biobank der Charité",
      "alias" : ["ZeBanC"],
      "partOf" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "contact" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/KontaktRolle",
          "valueString" : "Direktor"
        }],
        "purpose" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/ContactType",
            "code" : "RESEARCH"
          }]
        },
        "name" : {
          "family" : "Robert",
          "given" : ["Koch"],
          "prefix" : ["Prof."]
        },
        "telecom" : [{
          "system" : "email",
          "value" : "robert.koch@charite.de"
        }],
        "address" : {
          "line" : ["Südring 7"],
          "city" : "Berlin",
          "postalCode" : "13353"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-biobank-charite"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Substance/mii-exa-test-data-patient-1-substance-1",
    "resource" : {
      "resourceType" : "Substance",
      "id" : "mii-exa-test-data-patient-1-substance-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Substance_mii-exa-test-data-patient-1-substance-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Substance mii-exa-test-data-patient-1-substance-1</b></p><a name=\"mii-exa-test-data-patient-1-substance-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-substance-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Substance\">MII PR Biobank Substance Additiv</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/substance-category chemical}\">Chemical</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 69519002}\">Edetic acid (substance)</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Quantity</b></td><td><b>Substance[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1.8 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td><span title=\"Codes:{http://snomed.info/sct 69519002}\">Edetic acid (substance)</span></td></tr></table></div>"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/substance-category",
          "code" : "chemical",
          "display" : "Chemical"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "69519002",
          "display" : "Edetic acid (substance)"
        }]
      },
      "ingredient" : [{
        "quantity" : {
          "numerator" : {
            "value" : 1.8,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "mL",
            "system" : "http://unitsofmeasure.org",
            "code" : "mL"
          }
        },
        "substanceCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "69519002",
            "display" : "Edetic acid (substance)"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Substance/mii-exa-test-data-patient-1-substance-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-1-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-1-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-1-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-1-specimen-1</b></p><a name=\"mii-exa-test-data-patient-1-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>MII EX Biobank Ebene</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene#mii-cs-biobank-probenebene-PRIM.196RPROBE\">MII CS Biobank Probenebene: PRIMÄRPROBE</a> (Primärprobe)</p><p><b>MII EX Biobank Infektiositätsstatus</b>: <span title=\"Codes:{http://snomed.info/sct 409603009}\">Biosafety level 2 (qualifier value)</span></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000001</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 122555007}\">Venous blood specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-1.html\">Sabine Musterfrau  Female, DoB: 1975-11-03 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-001)</a></p><p><b>request</b>: Laborauftrag kleines Blutbild (Identifier: <code>https://www.charite.de/fhir/sid/Laboranforderungen</code>/LA_000001)</p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>Quantity</b></td><td><b>Method</b></td><td><b>BodySite</b></td><td><b>FastingStatus[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-02-15 11:05:00+0100</td><td>10 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td><span title=\"Codes:{http://snomed.info/sct 129300006}\">Puncture - action</span></td><td><span title=\"Codes:{http://snomed.info/sct 789218009}\">Structure of dorsum of left hand (body structure)</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0916 F}\">Patient was fasting prior to the procedure.</span></td></tr></table><h3>Processings</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Procedure</b></td><td><b>Additive</b></td><td><b>Time[x]</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Codes:{http://snomed.info/sct 1186936003}\">Storage of specimen (procedure)</span></td><td><a href=\"Substance-mii-exa-test-data-patient-1-substance-1.html\">Substance Edetic acid (substance)</a></td><td>2024-02-15 11:05:00+0100 --&gt; 2024-02-15 11:35:00+0100</td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td><td><b>Additive[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>10 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>10 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td><a href=\"Substance-mii-exa-test-data-patient-1-substance-1.html\">Substance Edetic acid (substance)</a></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Probe innerhalb von 30 Minuten nach Entnahme eingelagert.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-ebene",
        "valueCoding" : {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene",
          "code" : "PRIMÄRPROBE",
          "display" : "Primärprobe"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-infektiositaetsstatus",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "409603009",
            "display" : "Biosafety level 2 (qualifier value)"
          }]
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000001"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "122555007",
          "display" : "Venous blood specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-1"
      },
      "request" : [{
        "identifier" : {
          "system" : "https://www.charite.de/fhir/sid/Laboranforderungen",
          "value" : "LA_000001"
        },
        "display" : "Laborauftrag kleines Blutbild"
      }],
      "collection" : {
        "collectedDateTime" : "2024-02-15T11:05:00+01:00",
        "quantity" : {
          "value" : 10,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "method" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "129300006"
          }]
        },
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "789218009",
            "display" : "Structure of dorsum of left hand (body structure)"
          }]
        },
        "fastingStatusCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0916",
            "code" : "F",
            "display" : "Patient was fasting prior to the procedure."
          }]
        }
      },
      "processing" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Temperaturbedingungen",
          "valueRange" : {
            "low" : {
              "value" : 15,
              "unit" : "°C",
              "system" : "http://unitsofmeasure.org",
              "code" : "Cel"
            },
            "high" : {
              "value" : 25,
              "unit" : "°C",
              "system" : "http://unitsofmeasure.org",
              "code" : "Cel"
            }
          }
        }],
        "procedure" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1186936003",
            "display" : "Storage of specimen (procedure)"
          }]
        },
        "additive" : [{
          "reference" : "Substance/mii-exa-test-data-patient-1-substance-1"
        }],
        "timePeriod" : {
          "start" : "2024-02-15T11:05:00+01:00",
          "end" : "2024-02-15T11:35:00+01:00"
        }
      }],
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 10,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 10,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "additiveReference" : {
          "reference" : "Substance/mii-exa-test-data-patient-1-substance-1"
        }
      }],
      "note" : [{
        "text" : "Probe innerhalb von 30 Minuten nach Entnahme eingelagert."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-1-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-3",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-3</b></p><a name=\"mii-exa-test-data-biobank-patient-3\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Claudia Spender  Female, DoB: 1962-05-22 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-003)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-003"
      }],
      "name" : [{
        "family" : "Spender",
        "given" : ["Claudia"]
      }],
      "gender" : "female",
      "birthDate" : "1962-05-22"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-3-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-3-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-3-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-3-specimen-1</b></p><a name=\"mii-exa-test-data-patient-3-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-3-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000002</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 128159001}\">Tissue specimen from colon (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-3.html\">Claudia Spender  Female, DoB: 1962-05-22 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-003)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td/><td>2022-03-24 12:44:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 71854001}, {http://terminology.hl7.org/CodeSystem/icd-o-3 C18.9}\">Colon structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000002"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "128159001",
          "display" : "Tissue specimen from colon (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-3"
      },
      "collection" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/EinstellungBlutversorgung",
          "valueDateTime" : "2022-03-24T12:30:00+01:00"
        }],
        "collectedDateTime" : "2022-03-24T12:44:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "71854001",
            "display" : "Colon structure (body structure)"
          },
          {
            "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
            "code" : "C18.9",
            "display" : "Colon, NOS"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-3-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-3-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-3-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-3-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-3-specimen-2</b></p><a name=\"mii-exa-test-data-patient-3-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-3-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000004</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-3.html\">Claudia Spender  Female, DoB: 1962-05-22 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-003)</a></p><p><b>parent</b>: <a href=\"Specimen-mii-exa-test-data-patient-3-specimen-3.html\">Specimen: extension = -&gt;Organization Zentrale Biobank der Charité,-&gt;Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet; identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000005; status = available; type = Blood specimen with edetic acid (specimen)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-04-05 07:15:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000004"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-3"
      },
      "parent" : [{
        "reference" : "Specimen/mii-exa-test-data-patient-3-specimen-3"
      }],
      "collection" : {
        "collectedDateTime" : "2022-04-05T07:15:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-3-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-3-specimen-3",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-3-specimen-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-3-specimen-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-3-specimen-3</b></p><a name=\"mii-exa-test-data-patient-3-specimen-3\"> </a><a name=\"hcmii-exa-test-data-patient-3-specimen-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000005</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-3.html\">Claudia Spender  Female, DoB: 1962-05-22 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-003)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-04-05 07:15:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000005"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-3"
      },
      "collection" : {
        "collectedDateTime" : "2022-04-05T07:15:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-3-specimen-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-4",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-4",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-4</b></p><a name=\"mii-exa-test-data-biobank-patient-4\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Dirk Probenspender  Male, DoB: 1978-09-11 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-004)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-004"
      }],
      "name" : [{
        "family" : "Probenspender",
        "given" : ["Dirk"]
      }],
      "gender" : "male",
      "birthDate" : "1978-09-11"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-4"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-4-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-4-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-4-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-4-specimen-1</b></p><a name=\"mii-exa-test-data-patient-4-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-4-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/bioproben</code>/BP_00070024</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-4.html\">Dirk Probenspender  Male, DoB: 1978-09-11 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-004)</a></p><p><b>receivedTime</b>: 2022-11-30</p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-11-30</td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/bioproben",
        "value" : "BP_00070024"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-4"
      },
      "receivedTime" : "2022-11-30",
      "collection" : {
        "collectedDateTime" : "2022-11-30"
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-4-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-4-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-4-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-4-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-4-specimen-2</b></p><a name=\"mii-exa-test-data-patient-4-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-4-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/bioproben</code>/BP_00070025</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-4.html\">Dirk Probenspender  Male, DoB: 1978-09-11 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-004)</a></p><p><b>receivedTime</b>: 2022-11-30</p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-11-30</td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/bioproben",
        "value" : "BP_00070025"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-4"
      },
      "receivedTime" : "2022-11-30",
      "collection" : {
        "collectedDateTime" : "2022-11-30"
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-4-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-4-specimen-3",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-4-specimen-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-4-specimen-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-4-specimen-3</b></p><a name=\"mii-exa-test-data-patient-4-specimen-3\"> </a><a name=\"hcmii-exa-test-data-patient-4-specimen-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000006</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-4.html\">Dirk Probenspender  Male, DoB: 1978-09-11 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-004)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2020-09-17 06:30:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000006"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-4"
      },
      "collection" : {
        "collectedDateTime" : "2020-09-17T06:30:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-4-specimen-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-4-specimen-4",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-4-specimen-4",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-4-specimen-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-4-specimen-4</b></p><a name=\"mii-exa-test-data-patient-4-specimen-4\"> </a><a name=\"hcmii-exa-test-data-patient-4-specimen-4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000007</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-4.html\">Dirk Probenspender  Male, DoB: 1978-09-11 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-004)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2020-09-17 06:30:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000007"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-4"
      },
      "collection" : {
        "collectedDateTime" : "2020-09-17T06:30:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-4-specimen-4"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-5",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-5",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-5</b></p><a name=\"mii-exa-test-data-biobank-patient-5\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Eva Gewebe  Female, DoB: 1991-01-30 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-005)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-005"
      }],
      "name" : [{
        "family" : "Gewebe",
        "given" : ["Eva"]
      }],
      "gender" : "female",
      "birthDate" : "1991-01-30"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-5"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-5-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-5-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-5-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-5-specimen-1</b></p><a name=\"mii-exa-test-data-patient-5-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-5-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000008</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-5.html\">Eva Gewebe  Female, DoB: 1991-01-30 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-005)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2023-07-12 06:00:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000008"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-5"
      },
      "collection" : {
        "collectedDateTime" : "2023-07-12T06:00:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-5-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-5-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-5-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-5-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-5-specimen-2</b></p><a name=\"mii-exa-test-data-patient-5-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-5-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000009</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-5.html\">Eva Gewebe  Female, DoB: 1991-01-30 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-005)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td><td><b>FastingStatus[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2023-07-12 06:00:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0916 F}\">Patient was fasting prior to the procedure.</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000009"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-5"
      },
      "collection" : {
        "collectedDateTime" : "2023-07-12T06:00:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        },
        "fastingStatusCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0916",
            "code" : "F",
            "display" : "Patient was fasting prior to the procedure."
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-5-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-6",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-6",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-6\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-6</b></p><a name=\"mii-exa-test-data-biobank-patient-6\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-6\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Frank Blutprobe  Male, DoB: 1955-12-07 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-006)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-006"
      }],
      "name" : [{
        "family" : "Blutprobe",
        "given" : ["Frank"]
      }],
      "gender" : "male",
      "birthDate" : "1955-12-07"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-6"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-6-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-6-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-6-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-6-specimen-1</b></p><a name=\"mii-exa-test-data-patient-6-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-6-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000010</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-6.html\">Frank Blutprobe  Male, DoB: 1955-12-07 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-006)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-03-14 06:15:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000010"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-6"
      },
      "collection" : {
        "collectedDateTime" : "2022-03-14T06:15:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-6-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-6-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-6-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-6-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-6-specimen-2</b></p><a name=\"mii-exa-test-data-patient-6-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-6-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000011</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-6.html\">Frank Blutprobe  Male, DoB: 1955-12-07 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-006)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-03-14 06:15:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000011"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-6"
      },
      "collection" : {
        "collectedDateTime" : "2022-03-14T06:15:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-6-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-7",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-7",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-7</b></p><a name=\"mii-exa-test-data-biobank-patient-7\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-7\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Greta Serum  Female, DoB: 1987-03-15 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-007)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-007"
      }],
      "name" : [{
        "family" : "Serum",
        "given" : ["Greta"]
      }],
      "gender" : "female",
      "birthDate" : "1987-03-15"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-7"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-7-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-7-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-7-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-7-specimen-1</b></p><a name=\"mii-exa-test-data-patient-7-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-7-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000012</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-7.html\">Greta Serum  Female, DoB: 1987-03-15 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-007)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-01-10 07:30:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000012"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-7"
      },
      "collection" : {
        "collectedDateTime" : "2024-01-10T07:30:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-7-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-7-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-7-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-7-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-7-specimen-2</b></p><a name=\"mii-exa-test-data-patient-7-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-7-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000013</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-7.html\">Greta Serum  Female, DoB: 1987-03-15 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-007)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-01-10 07:30:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000013"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-7"
      },
      "collection" : {
        "collectedDateTime" : "2024-01-10T07:30:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-7-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-8",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-8",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-8</b></p><a name=\"mii-exa-test-data-biobank-patient-8\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Heinrich Plasma  Male, DoB: 1969-07-28 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-008)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-008"
      }],
      "name" : [{
        "family" : "Plasma",
        "given" : ["Heinrich"]
      }],
      "gender" : "male",
      "birthDate" : "1969-07-28"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-8"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-8-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-8-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-8-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-8-specimen-1</b></p><a name=\"mii-exa-test-data-patient-8-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-8-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000014</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-8.html\">Heinrich Plasma  Male, DoB: 1969-07-28 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-008)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2023-11-12 05:45:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000014"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-8"
      },
      "collection" : {
        "collectedDateTime" : "2023-11-12T05:45:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-8-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-8-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-8-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-8-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-8-specimen-2</b></p><a name=\"mii-exa-test-data-patient-8-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-8-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000015</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-8.html\">Heinrich Plasma  Male, DoB: 1969-07-28 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-008)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2023-11-12 05:45:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000015"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-8"
      },
      "collection" : {
        "collectedDateTime" : "2023-11-12T05:45:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-8-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-9",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-9",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-9</b></p><a name=\"mii-exa-test-data-biobank-patient-9\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Ingrid Biopsie  Female, DoB: 1983-10-04 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-009)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-009"
      }],
      "name" : [{
        "family" : "Biopsie",
        "given" : ["Ingrid"]
      }],
      "gender" : "female",
      "birthDate" : "1983-10-04"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-9"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-9-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-9-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-9-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-9-specimen-1</b></p><a name=\"mii-exa-test-data-patient-9-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-9-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000016</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-9.html\">Ingrid Biopsie  Female, DoB: 1983-10-04 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-009)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-02-22 06:30:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000016"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-9"
      },
      "collection" : {
        "collectedDateTime" : "2024-02-22T06:30:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-9-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-9-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-9-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-9-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-9-specimen-2</b></p><a name=\"mii-exa-test-data-patient-9-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-9-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000017</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-9.html\">Ingrid Biopsie  Female, DoB: 1983-10-04 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-009)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-02-22 06:30:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000017"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-9"
      },
      "collection" : {
        "collectedDateTime" : "2024-02-22T06:30:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-9-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-biobank-patient-2",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-biobank-patient-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-biobank-patient-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-biobank-patient-2</b></p><a name=\"mii-exa-test-data-biobank-patient-2\"> </a><a name=\"hcmii-exa-test-data-biobank-patient-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Martin Testfall  Male, DoB: 1980-04-18 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-002)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "BIO-TEST-002"
      }],
      "name" : [{
        "family" : "Testfall",
        "given" : ["Martin"]
      }],
      "gender" : "male",
      "birthDate" : "1980-04-18"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-biobank-patient-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-10-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-10-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-10-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-10-specimen-1</b></p><a name=\"mii-exa-test-data-patient-10-specimen-1\"> </a><a name=\"hcmii-exa-test-data-patient-10-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000018</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 445295009}\">Blood specimen with edetic acid (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-2.html\">Martin Testfall  Male, DoB: 1980-04-18 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-002)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2019-05-16 07:45:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000018"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445295009",
          "display" : "Blood specimen with edetic acid (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-2"
      },
      "collection" : {
        "collectedDateTime" : "2019-05-16T07:45:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368208006",
            "display" : "Left upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-10-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-10-specimen-2",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-10-specimen-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-10-specimen-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-10-specimen-2</b></p><a name=\"mii-exa-test-data-patient-10-specimen-2\"> </a><a name=\"hcmii-exa-test-data-patient-10-specimen-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Specimen\">MII PR Biobank Specimen Bioprobe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-1.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000019</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119364003}\">Serum specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-2.html\">Martin Testfall  Male, DoB: 1980-04-18 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-002)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2019-05-16 07:45:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 368209003}\">Right upper arm structure (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td>7 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000019"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119364003",
          "display" : "Serum specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-2"
      },
      "collection" : {
        "collectedDateTime" : "2019-05-16T07:45:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368209003",
            "display" : "Right upper arm structure (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "specimenQuantity" : {
          "value" : 7,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-10-specimen-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-biobank-organoid-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-biobank-organoid-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-zellinie-organoid"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-biobank-organoid-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-biobank-organoid-1</b></p><a name=\"mii-exa-test-data-biobank-organoid-1\"> </a><a name=\"hcmii-exa-test-data-biobank-organoid-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-zellinie-organoid\">MII PR Biobank Specimen Zellinie Organoid</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Kulturprotokoll</b>: <a href=\"DocumentReference-mii-exa-test-data-biobank-kulturprotokoll-1.html\">DocumentReference: status = current; date = 2022-03-20 09:00:00+0100; description = Standardprotokoll zur Kultivierung von Kolon-Tumor-Organoiden</a></p><blockquote><p><b>MII EX Biobank Zelllinien-Modifikation</b></p><ul><li>artDerModifikation: <span title=\"Codes:{http://purl.obolibrary.org/obo/clo.owl CLO:0037375}\">derives from cell with knockout gene</span></li><li>zielGen: <a href=\"http://terminology.hl7.org/6.5.0/CodeSystem-v3-hgnc.html#v3-hgnc-TP53\">HUGO Gene Nomenclature Committee Genes: TP53</a> (tumor protein p53)</li><li>protokoll: <a href=\"DocumentReference-mii-exa-test-data-biobank-crispr-protokoll-1.html\">DocumentReference: status = current; date = 2022-03-19 09:00:00+0100; description = CRISPR Knockout-Protokoll fuer TP53 in Kolon-Tumor-Organoiden</a></li></ul></blockquote><p><b>MII EX Biobank Anzahl Passagen</b>: 3</p><p><b>MII EX Biobank Verwaltende Organisation</b>: <a href=\"Organization-mii-exa-test-data-organization-biobank-charite.html\">Organization Zentrale Biobank der Charité</a></p><p><b>MII EX Biobank Diagnose</b>: <a href=\"Condition-mii-exa-test-data-biobank-diagnose-3.html\">Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet</a></p><p><b>MII EX Biobank Ebene</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene#mii-cs-biobank-probenebene-ALIQUOT\">MII CS Biobank Probenebene: ALIQUOT</a> (Aliquot)</p><p><b>MII EX Biobank Infektiositätsstatus</b>: <span title=\"Codes:{http://snomed.info/sct 409603009}\">Biosafety level 2 (qualifier value)</span></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000020</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 123038009}, {https://fhir.bbmri-eric.eu/CodeSystem/miabis-detailed-samply-type-cs Organoid}\">Specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-3.html\">Claudia Spender  Female, DoB: 1962-05-22 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-003)</a></p><p><b>receivedTime</b>: 2022-03-24 14:00:00+0100</p><p><b>parent</b>: <a href=\"Specimen-mii-exa-test-data-patient-3-specimen-1.html\">Specimen: identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000002; status = available; type = Tissue specimen from colon (specimen)</a></p><p><b>request</b>: Anforderung Organoid-Kultur (Identifier: <code>https://www.charite.de/fhir/sid/Bioproben-Anforderungen</code>/BPA_000001)</p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Collected[x]</b></td><td><b>Quantity</b></td><td><b>Method</b></td><td><b>BodySite</b></td><td><b>FastingStatus[x]</b></td></tr><tr><td style=\"display: none\">*</td><td/><td>2022-03-24 12:44:00+0100</td><td>1 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td><span title=\"Codes:{http://snomed.info/sct 86273004}\">Biopsy (procedure)</span></td><td><span title=\"Codes:{http://snomed.info/sct 71854001}\">Colon structure (body structure)</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0916 NF}\">The patient indicated they did not fast prior to the procedure.</span></td></tr></table><h3>Processings</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Procedure</b></td><td><b>Additive</b></td><td><b>Time[x]</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Codes:{http://snomed.info/sct 1186936003}\">Storage of specimen (procedure)</span></td><td><a href=\"Substance-mii-exa-test-data-patient-1-substance-1.html\">Substance Edetic acid (substance)</a></td><td>2022-04-01 10:00:00+0200 --&gt; 2022-04-12 10:00:00+0200</td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td><td><b>Additive[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>2 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td>1 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td><td><span title=\"Codes:{http://snomed.info/sct 105590001}\">Organoid-Kulturmedium mit Matrigel</span></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Kolon-Tumor-Organoid, Passage 3, aus der Gewebeprobe etabliert.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-kulturprotokoll",
        "valueReference" : {
          "reference" : "DocumentReference/mii-exa-test-data-biobank-kulturprotokoll-1"
        }
      },
      {
        "extension" : [{
          "url" : "artDerModifikation",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://purl.obolibrary.org/obo/clo.owl",
              "code" : "CLO:0037375",
              "display" : "derives from cell with knockout gene"
            }]
          }
        },
        {
          "url" : "zielGen",
          "valueCoding" : {
            "system" : "http://www.genenames.org",
            "code" : "TP53",
            "display" : "tumor protein p53"
          }
        },
        {
          "url" : "protokoll",
          "valueReference" : {
            "reference" : "DocumentReference/mii-exa-test-data-biobank-crispr-protokoll-1"
          }
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-modifikationen"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-anzahl-passagen",
        "valueInteger" : 3
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/VerwaltendeOrganisation",
        "valueReference" : {
          "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Diagnose",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-biobank-diagnose-3"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-ebene",
        "valueCoding" : {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene",
          "code" : "ALIQUOT",
          "display" : "Aliquot"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-infektiositaetsstatus",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "409603009",
            "display" : "Biosafety level 2 (qualifier value)"
          }]
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000020"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "123038009",
          "display" : "Specimen (specimen)"
        },
        {
          "system" : "https://fhir.bbmri-eric.eu/CodeSystem/miabis-detailed-samply-type-cs",
          "code" : "Organoid",
          "display" : "Organoids"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-3"
      },
      "receivedTime" : "2022-03-24T14:00:00+01:00",
      "parent" : [{
        "reference" : "Specimen/mii-exa-test-data-patient-3-specimen-1"
      }],
      "request" : [{
        "identifier" : {
          "system" : "https://www.charite.de/fhir/sid/Bioproben-Anforderungen",
          "value" : "BPA_000001"
        },
        "display" : "Anforderung Organoid-Kultur"
      }],
      "collection" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/EinstellungBlutversorgung",
          "valueDateTime" : "2022-03-24T12:30:00+01:00"
        }],
        "collectedDateTime" : "2022-03-24T12:44:00+01:00",
        "quantity" : {
          "value" : 1,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "method" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "86273004",
            "display" : "Biopsy (procedure)"
          }]
        },
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "71854001",
            "display" : "Colon structure (body structure)"
          }]
        },
        "fastingStatusCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0916",
            "code" : "NF",
            "display" : "The patient indicated they did not fast prior to the procedure."
          }]
        }
      },
      "processing" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/Temperaturbedingungen",
          "valueRange" : {
            "low" : {
              "value" : 37,
              "unit" : "°C",
              "system" : "http://unitsofmeasure.org",
              "code" : "Cel"
            },
            "high" : {
              "value" : 37,
              "unit" : "°C",
              "system" : "http://unitsofmeasure.org",
              "code" : "Cel"
            }
          }
        }],
        "procedure" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1186936003",
            "display" : "Storage of specimen (procedure)"
          }]
        },
        "additive" : [{
          "reference" : "Substance/mii-exa-test-data-patient-1-substance-1"
        }],
        "timePeriod" : {
          "start" : "2022-04-01T10:00:00+02:00",
          "end" : "2022-04-12T10:00:00+02:00"
        }
      }],
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 2,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "specimenQuantity" : {
          "value" : 1,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        },
        "additiveCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "105590001",
            "display" : "Substance (substance)"
          }],
          "text" : "Organoid-Kulturmedium mit Matrigel"
        }
      }],
      "note" : [{
        "text" : "Kolon-Tumor-Organoid, Passage 3, aus der Gewebeprobe etabliert."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-biobank-organoid-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-biobank-specimen-dna-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-biobank-specimen-dna-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/SpecimenCore"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-biobank-specimen-dna-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-biobank-specimen-dna-1</b></p><a name=\"mii-exa-test-data-biobank-specimen-dna-1\"> </a><a name=\"hcmii-exa-test-data-biobank-specimen-dna-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/SpecimenCore\">MII PR Biobank Specimen Bioprobe Core</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Ebene</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene#mii-cs-biobank-probenebene-ALIQUOT\">MII CS Biobank Probenebene: ALIQUOT</a> (Aliquot)</p><p><b>MII EX Biobank Infektiositätsstatus</b>: <span title=\"Codes:{http://snomed.info/sct 409603009}\">Biosafety level 2 (qualifier value)</span></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Bioproben</code>/BP_000021</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 258566005}\">Deoxyribonucleic acid specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-1.html\">Sabine Musterfrau  Female, DoB: 1975-11-03 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-001)</a></p><p><b>receivedTime</b>: 2024-02-15 13:30:00+0100</p><p><b>parent</b>: <a href=\"Specimen-mii-exa-test-data-patient-1-specimen-1.html\">Specimen: extension = -&gt;Organization Zentrale Biobank der Charité,-&gt;Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet,Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000001; status = available; type = Venous blood specimen (specimen); note = Probe innerhalb von 30 Minuten nach Entnahme eingelagert.</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Collected[x]</b></td><td><b>Quantity</b></td><td><b>FastingStatus[x]</b></td></tr><tr><td style=\"display: none\">*</td><td/><td>2024-02-15 11:05:00+0100</td><td>10 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0916 F}\">Patient was fasting prior to the procedure.</span></td></tr></table><h3>Processings</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Description</b></td><td><b>Procedure</b></td><td><b>Additive</b></td><td><b>Time[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>DNA-Extraktion aus EDTA-Vollblut</td><td><span title=\"Codes:{http://snomed.info/sct 73373003}\">Specimen centrifugation (procedure)</span></td><td><a href=\"Substance-mii-exa-test-data-patient-1-substance-1.html\">Substance Edetic acid (substance)</a></td><td>2024-02-15 13:45:00+0100 --&gt; 2024-02-15 14:30:00+0100</td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td><td>0.5 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td>0.2 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></td></tr></table><p><b>note</b>: </p><blockquote><div><p>DNA-Extraktion aus dem EDTA-Vollblut, Konzentration 50 ng/uL.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-ebene",
        "valueCoding" : {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene",
          "code" : "ALIQUOT",
          "display" : "Aliquot"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-infektiositaetsstatus",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "409603009",
            "display" : "Biosafety level 2 (qualifier value)"
          }]
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Bioproben",
        "value" : "BP_000021"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258566005",
          "display" : "Deoxyribonucleic acid specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-1"
      },
      "receivedTime" : "2024-02-15T13:30:00+01:00",
      "parent" : [{
        "reference" : "Specimen/mii-exa-test-data-patient-1-specimen-1"
      }],
      "collection" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/EinstellungBlutversorgung",
          "valueDateTime" : "2024-02-15T11:05:00+01:00"
        }],
        "collectedDateTime" : "2024-02-15T11:05:00+01:00",
        "quantity" : {
          "value" : 10,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "fastingStatusCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0916",
            "code" : "F",
            "display" : "Patient was fasting prior to the procedure."
          }]
        }
      },
      "processing" : [{
        "description" : "DNA-Extraktion aus EDTA-Vollblut",
        "procedure" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "73373003",
            "display" : "Specimen centrifugation (procedure)"
          }]
        },
        "additive" : [{
          "reference" : "Substance/mii-exa-test-data-patient-1-substance-1"
        }],
        "timePeriod" : {
          "start" : "2024-02-15T13:45:00+01:00",
          "end" : "2024-02-15T14:30:00+01:00"
        }
      }],
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        },
        "capacity" : {
          "value" : 0.5,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "specimenQuantity" : {
          "value" : 0.2,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "ml"
        }
      }],
      "note" : [{
        "text" : "DNA-Extraktion aus dem EDTA-Vollblut, Konzentration 50 ng/uL."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-biobank-specimen-dna-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DocumentReference/mii-exa-test-data-biobank-kulturprotokoll-1",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "mii-exa-test-data-biobank-kulturprotokoll-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_mii-exa-test-data-biobank-kulturprotokoll-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference mii-exa-test-data-biobank-kulturprotokoll-1</b></p><a name=\"mii-exa-test-data-biobank-kulturprotokoll-1\"> </a><a name=\"hcmii-exa-test-data-biobank-kulturprotokoll-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Current</p><p><b>date</b>: 2022-03-20 09:00:00+0100</p><p><b>description</b>: Standardprotokoll zur Kultivierung von Kolon-Tumor-Organoiden</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>PDF</td><td><a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/biobank/protocols/KolonOrganoidKultur_v1.pdf\">https://www.charite.de/biobank/protocols/KolonOrganoidKultur_v1.pdf</a></td><td>Kolon-Organoid Kulturprotokoll v1</td></tr></table></blockquote></div>"
      },
      "status" : "current",
      "date" : "2022-03-20T09:00:00+01:00",
      "description" : "Standardprotokoll zur Kultivierung von Kolon-Tumor-Organoiden",
      "content" : [{
        "attachment" : {
          "contentType" : "application/pdf",
          "url" : "https://www.charite.de/biobank/protocols/KolonOrganoidKultur_v1.pdf",
          "title" : "Kolon-Organoid Kulturprotokoll v1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "DocumentReference/mii-exa-test-data-biobank-kulturprotokoll-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DocumentReference/mii-exa-test-data-biobank-crispr-protokoll-1",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "mii-exa-test-data-biobank-crispr-protokoll-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_mii-exa-test-data-biobank-crispr-protokoll-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference mii-exa-test-data-biobank-crispr-protokoll-1</b></p><a name=\"mii-exa-test-data-biobank-crispr-protokoll-1\"> </a><a name=\"hcmii-exa-test-data-biobank-crispr-protokoll-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Current</p><p><b>date</b>: 2022-03-19 09:00:00+0100</p><p><b>description</b>: CRISPR Knockout-Protokoll fuer TP53 in Kolon-Tumor-Organoiden</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>PDF</td><td><a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/biobank/protocols/CRISPR_TP53_KO_v1.pdf\">https://www.charite.de/biobank/protocols/CRISPR_TP53_KO_v1.pdf</a></td><td>CRISPR TP53 Knockout Protokoll v1</td></tr></table></blockquote></div>"
      },
      "status" : "current",
      "date" : "2022-03-19T09:00:00+01:00",
      "description" : "CRISPR Knockout-Protokoll fuer TP53 in Kolon-Tumor-Organoiden",
      "content" : [{
        "attachment" : {
          "contentType" : "application/pdf",
          "url" : "https://www.charite.de/biobank/protocols/CRISPR_TP53_KO_v1.pdf",
          "title" : "CRISPR TP53 Knockout Protokoll v1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "DocumentReference/mii-exa-test-data-biobank-crispr-protokoll-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-biobank-dna-konzentration-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-biobank-dna-konzentration-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-dna-konzentration"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-biobank-dna-konzentration-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-biobank-dna-konzentration-1</b></p><a name=\"mii-exa-test-data-biobank-dna-konzentration-1\"> </a><a name=\"hcmii-exa-test-data-biobank-dna-konzentration-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-dna-konzentration\">MII PR Biobank Observation DNA Konzentration</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 72496-3}\">DNA double strand [Mass/volume] in Specimen</span></p><p><b>focus</b>: <a href=\"Specimen-mii-exa-test-data-biobank-specimen-dna-1.html\">Specimen: extension = Aliquot (MII CS Biobank Probenebene#ALIQUOT),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000021; status = available; type = Deoxyribonucleic acid specimen (specimen); receivedTime = 2024-02-15 13:30:00+0100; note = DNA-Extraktion aus dem EDTA-Vollblut, Konzentration 50 ng/uL.</a></p><p><b>effective</b>: 2024-02-16 09:30:00+0100</p><p><b>value</b>: 40 ng/µL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/uL = 'ng/uL')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "72496-3",
          "display" : "DNA double strand [Mass/volume] in Specimen"
        }]
      },
      "focus" : [{
        "reference" : "Specimen/mii-exa-test-data-biobank-specimen-dna-1"
      }],
      "effectiveDateTime" : "2024-02-16T09:30:00+01:00",
      "valueQuantity" : {
        "value" : 40,
        "unit" : "ng/µL",
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/uL"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-biobank-dna-konzentration-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-biobank-karyotyp-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-biobank-karyotyp-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-karyotyp"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-biobank-karyotyp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-biobank-karyotyp-1</b></p><a name=\"mii-exa-test-data-biobank-karyotyp-1\"> </a><a name=\"hcmii-exa-test-data-biobank-karyotyp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-karyotyp\">MII PR Biobank Observation Karyotyp</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 734840008}\">Karyotype (cell structure)</span></p><p><b>focus</b>: <a href=\"Specimen-mii-exa-test-data-biobank-organoid-1.html\">Specimen: extension = -&gt;DocumentReference: status = current; date = 2022-03-20 09:00:00+0100; description = Standardprotokoll zur Kultivierung von Kolon-Tumor-Organoiden,,3,-&gt;Organization Zentrale Biobank der Charité,-&gt;Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet,Aliquot (MII CS Biobank Probenebene#ALIQUOT),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000020; status = available; type = Specimen (specimen); receivedTime = 2022-03-24 14:00:00+0100; note = Kolon-Tumor-Organoid, Passage 3, aus der Gewebeprobe etabliert.</a></p><p><b>effective</b>: 2022-04-12 10:00:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 734875008}\">Karyotype 46, XX</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "734840008",
          "display" : "Karyotype (cell structure)"
        }]
      },
      "focus" : [{
        "reference" : "Specimen/mii-exa-test-data-biobank-organoid-1"
      }],
      "effectiveDateTime" : "2022-04-12T10:00:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "734875008",
          "display" : "Karyotype 46, XX"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-biobank-karyotyp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-biobank-morphologie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-biobank-morphologie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-morphologie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-biobank-morphologie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-biobank-morphologie-1</b></p><a name=\"mii-exa-test-data-biobank-morphologie-1\"> </a><a name=\"hcmii-exa-test-data-biobank-morphologie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-morphologie\">MII PR Biobank Observation Morphologie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://purl.obolibrary.org/obo/pato.owl PATO:0010006}\">cell morphology</span></p><p><b>focus</b>: <a href=\"Specimen-mii-exa-test-data-biobank-organoid-1.html\">Specimen: extension = -&gt;DocumentReference: status = current; date = 2022-03-20 09:00:00+0100; description = Standardprotokoll zur Kultivierung von Kolon-Tumor-Organoiden,,3,-&gt;Organization Zentrale Biobank der Charité,-&gt;Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet,Aliquot (MII CS Biobank Probenebene#ALIQUOT),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000020; status = available; type = Specimen (specimen); receivedTime = 2022-03-24 14:00:00+0100; note = Kolon-Tumor-Organoid, Passage 3, aus der Gewebeprobe etabliert.</a></p><p><b>effective</b>: 2022-04-14 10:00:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 125393006}\">Cell structure alteration (morphologic abnormality)</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://purl.obolibrary.org/obo/pato.owl",
          "code" : "PATO:0010006",
          "display" : "cell morphology"
        }]
      },
      "focus" : [{
        "reference" : "Specimen/mii-exa-test-data-biobank-organoid-1"
      }],
      "effectiveDateTime" : "2022-04-14T10:00:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "125393006",
          "display" : "Cell structure alteration (morphologic abnormality)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-biobank-morphologie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-biobank-proliferation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-biobank-proliferation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-proliferation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-biobank-proliferation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-biobank-proliferation-1</b></p><a name=\"mii-exa-test-data-biobank-proliferation-1\"> </a><a name=\"hcmii-exa-test-data-biobank-proliferation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-proliferation\">MII PR Biobank Observation Proliferation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://purl.obolibrary.org/obo/go.owl GO:0008283}\">cell population proliferation</span></p><p><b>focus</b>: <a href=\"Specimen-mii-exa-test-data-biobank-organoid-1.html\">Specimen: extension = -&gt;DocumentReference: status = current; date = 2022-03-20 09:00:00+0100; description = Standardprotokoll zur Kultivierung von Kolon-Tumor-Organoiden,,3,-&gt;Organization Zentrale Biobank der Charité,-&gt;Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet,Aliquot (MII CS Biobank Probenebene#ALIQUOT),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000020; status = available; type = Specimen (specimen); receivedTime = 2022-03-24 14:00:00+0100; note = Kolon-Tumor-Organoid, Passage 3, aus der Gewebeprobe etabliert.</a></p><p><b>effective</b>: 2022-04-13 10:00:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://purl.obolibrary.org/obo/pato.owl PATO:0000719}\">viable</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://purl.obolibrary.org/obo/go.owl",
          "code" : "GO:0008283",
          "display" : "cell population proliferation"
        }]
      },
      "focus" : [{
        "reference" : "Specimen/mii-exa-test-data-biobank-organoid-1"
      }],
      "effectiveDateTime" : "2022-04-13T10:00:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://purl.obolibrary.org/obo/pato.owl",
          "code" : "PATO:0000719",
          "display" : "viable"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-biobank-proliferation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-biobank-wachstumstyp-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-biobank-wachstumstyp-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-wachstumstyp"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-biobank-wachstumstyp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-biobank-wachstumstyp-1</b></p><a name=\"mii-exa-test-data-biobank-wachstumstyp-1\"> </a><a name=\"hcmii-exa-test-data-biobank-wachstumstyp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-wachstumstyp\">MII PR Biobank Observation Wachstumstyp</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://purl.obolibrary.org/obo/clo.owl CLO:0000030}\">cell culture growth mode</span></p><p><b>focus</b>: <a href=\"Specimen-mii-exa-test-data-biobank-organoid-1.html\">Specimen: extension = -&gt;DocumentReference: status = current; date = 2022-03-20 09:00:00+0100; description = Standardprotokoll zur Kultivierung von Kolon-Tumor-Organoiden,,3,-&gt;Organization Zentrale Biobank der Charité,-&gt;Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet,Aliquot (MII CS Biobank Probenebene#ALIQUOT),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000020; status = available; type = Specimen (specimen); receivedTime = 2022-03-24 14:00:00+0100; note = Kolon-Tumor-Organoid, Passage 3, aus der Gewebeprobe etabliert.</a></p><p><b>effective</b>: 2022-04-13 10:00:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://purl.obolibrary.org/obo/clo.owl CLO:0000028}\">adherent cell culture growth mode</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://purl.obolibrary.org/obo/clo.owl",
          "code" : "CLO:0000030",
          "display" : "cell culture growth mode"
        }]
      },
      "focus" : [{
        "reference" : "Specimen/mii-exa-test-data-biobank-organoid-1"
      }],
      "effectiveDateTime" : "2022-04-13T10:00:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://purl.obolibrary.org/obo/clo.owl",
          "code" : "CLO:0000028",
          "display" : "adherent cell culture growth mode"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-biobank-wachstumstyp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-biobank-qualitaetspruefung-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-biobank-qualitaetspruefung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-qualitaetspruefung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-biobank-qualitaetspruefung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-biobank-qualitaetspruefung-1</b></p><a name=\"mii-exa-test-data-biobank-qualitaetspruefung-1\"> </a><a name=\"hcmii-exa-test-data-biobank-qualitaetspruefung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-pr-biobank-observation-qualitaetspruefung\">MII PR Biobank Observation Qualitätsprüfung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 386404008}\">Quality monitoring (procedure)</span></p><p><b>focus</b>: <a href=\"Specimen-mii-exa-test-data-patient-3-specimen-2.html\">Specimen: extension = -&gt;Organization Zentrale Biobank der Charité,-&gt;Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet; identifier = https://www.charite.de/fhir/sid/Bioproben#BP_000004; status = available; type = Serum specimen (specimen)</a></p><p><b>effective</b>: 2022-04-05 09:00:00+0200</p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 246423001}\">Test protocol used (attribute)</span></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 401297005}\">Hemolysis screening test (procedure)</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 79409006}\">Resulting in (attribute)</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA10392-1}\">Pass</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "386404008",
          "display" : "Quality monitoring (procedure)"
        }]
      },
      "focus" : [{
        "reference" : "Specimen/mii-exa-test-data-patient-3-specimen-2"
      }],
      "effectiveDateTime" : "2022-04-05T09:00:00+02:00",
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "246423001",
            "display" : "Test protocol used (attribute)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "401297005",
            "display" : "Hemolysis screening test (procedure)"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "79409006",
            "display" : "Resulting in (attribute)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA10392-1",
            "display" : "Pass"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-biobank-qualitaetspruefung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-charite",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-charite",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-charite\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-charite</b></p><a name=\"mii-exa-test-data-organization-charite\"> </a><a name=\"hcmii-exa-test-data-organization-charite\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Charité – Universitätsmedizin Berlin</p></div>"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Charité – Universitätsmedizin Berlin"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-charite"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-biobank-diagnose-1",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-biobank-diagnose-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-biobank-diagnose-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-biobank-diagnose-1</b></p><a name=\"mii-exa-test-data-biobank-diagnose-1\"> </a><a name=\"hcmii-exa-test-data-biobank-diagnose-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose\">MII PR Diagnose Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C18.9}, {http://fhir.de/CodeSystem/bfarm/alpha-id I29723}, {http://snomed.info/sct 363406005}\">Bösartige Neubildung: Kolon, nicht näher bezeichnet</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 71854001}\">Colon structure (body structure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-1.html\">Sabine Musterfrau  Female, DoB: 1975-11-03 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-001)</a></p><p><b>recordedDate</b>: 2024-08-15</p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "C18.9",
          "display" : "Bösartige Neubildung: Kolon, nicht näher bezeichnet"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/alpha-id",
          "version" : "2024",
          "code" : "I29723",
          "display" : "Bösartige Neubildung des Kolons o.n.A."
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "363406005",
          "display" : "Malignant tumor of colon (disorder)"
        }]
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "71854001",
          "display" : "Colon structure (body structure)"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-1"
      },
      "recordedDate" : "2024-08-15"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-biobank-diagnose-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-biobank-diagnose-3",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-biobank-diagnose-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-biobank-diagnose-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-biobank-diagnose-3</b></p><a name=\"mii-exa-test-data-biobank-diagnose-3\"> </a><a name=\"hcmii-exa-test-data-biobank-diagnose-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose\">MII PR Diagnose Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C18.9}, {http://fhir.de/CodeSystem/bfarm/alpha-id I29723}, {http://snomed.info/sct 363406005}\">Bösartige Neubildung: Kolon, nicht näher bezeichnet</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 71854001}\">Colon structure (body structure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-biobank-patient-3.html\">Claudia Spender  Female, DoB: 1962-05-22 ( https://www.charite.de/fhir/sid/patientenidentifikation#BIO-TEST-003)</a></p><p><b>recordedDate</b>: 2022-03-20</p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "C18.9",
          "display" : "Bösartige Neubildung: Kolon, nicht näher bezeichnet"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/alpha-id",
          "version" : "2024",
          "code" : "I29723",
          "display" : "Bösartige Neubildung des Kolons o.n.A."
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "363406005",
          "display" : "Malignant tumor of colon (disorder)"
        }]
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "71854001",
          "display" : "Colon structure (body structure)"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-3"
      },
      "recordedDate" : "2022-03-20"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-biobank-diagnose-3"
    }
  }]
}

```
