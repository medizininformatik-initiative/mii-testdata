# mii-exa-test-data-bundle-pat-12 - MII KDS Test Data v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-test-data-bundle-pat-12**

## Example Bundle: mii-exa-test-data-bundle-pat-12



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-test-data-bundle-pat-12",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2025-03-25T12:00:00+01:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-patient-12",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-patient-12",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/Patient",
        "http://fhir.de/ConsentManagement/StructureDefinition/Patient"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-patient-12\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-patient-12</b></p><a name=\"mii-exa-test-data-patient-12\"> </a><a name=\"hcmii-exa-test-data-patient-12\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/Patient\">MII PR Person Patient</a>, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.consent@2027.0.0-ballot&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Patient\">Consent Management: Patient</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\">Krankenversichertennummer/G345678901 (use: official, )</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">Gubener Straße 31 Berlin 10243 DE </td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
            "code" : "KVZ10"
          }]
        },
        "system" : "http://fhir.de/sid/gkv/kvid-10",
        "value" : "G345678901",
        "assigner" : {
          "identifier" : {
            "use" : "official",
            "system" : "http://fhir.de/sid/arge-ik/iknr",
            "value" : "109519005"
          }
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "733815094",
        "assigner" : {
          "identifier" : {
            "type" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "XX"
              }]
            },
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "name" : [{
        "use" : "official",
        "family" : "Woltmann",
        "given" : ["Gerhard"]
      }],
      "gender" : "male",
      "birthDate" : "1953-04-22",
      "address" : [{
        "type" : "both",
        "line" : ["Gubener Straße 31"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Gubener Straße"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "31"
          }]
        }],
        "city" : "Berlin",
        "_city" : {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/destatis/ags",
            "valueCoding" : {
              "system" : "http://fhir.de/sid/destatis/ags",
              "code" : "11000000"
            }
          }]
        },
        "postalCode" : "10243",
        "country" : "DE"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-patient-12"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-patient-12-encounter-1",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-patient-12-encounter-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-patient-12-encounter-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-patient-12-encounter-1</b></p><a name=\"mii-exa-test-data-patient-12-encounter-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-encounter-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung\">MII PR Fall Kontakt mit einer Gesundheitseinrichtung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Visit number/MII_0000016</p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>type</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/Kontaktebene einrichtungskontakt}\">Einrichtungskontakt</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/kontaktart-de normalstationaer}\">Normalstationär</span></p><p><b>serviceType</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel 0100}\">Innere Medizin</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>period</b>: 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</p><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Condition-mii-exa-test-data-patient-12-diagnose-1.html\">Condition Pneumonia caused by Klebsiella pneumoniae</a></p><p><b>use</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/KontaktDiagnoseProzedur hospital-main-diagnosis}, {http://terminology.hl7.org/CodeSystem/diagnosis-role DD}\">Krankenhaus Hauptdiagnose</span></p><p><b>rank</b>: 1</p></blockquote><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Condition-mii-exa-test-data-patient-12-diagnose-2.html\">Condition Sepsis: Sonstige gramnegative Erreger</a></p><p><b>use</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/KontaktDiagnoseProzedur secondary-DRG}\">DRG-Nebendiagnose</span></p><p><b>rank</b>: 2</p></blockquote><h3>Hospitalizations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>AdmitSource</b></td><td><b>DischargeDisposition</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.de/CodeSystem/dgkev/Aufnahmeanlass N}\">Notfall</span></td><td><span title=\"Codes:\"></span></td></tr></table><p><b>serviceProvider</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Charité - Universitätsmedizin Berlin</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "VN"
          }]
        },
        "system" : "https://www.charite.de/fhir/NamingSystem/Aufnahmenummern",
        "value" : "MII_0000016"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/Kontaktebene",
          "code" : "einrichtungskontakt"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/kontaktart-de",
          "code" : "normalstationaer"
        }]
      }],
      "serviceType" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel",
          "code" : "0100"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "period" : {
        "start" : "2025-03-08T14:20:00+01:00",
        "end" : "2025-03-25T11:00:00+01:00"
      },
      "diagnosis" : [{
        "condition" : {
          "reference" : "Condition/mii-exa-test-data-patient-12-diagnose-1"
        },
        "use" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/KontaktDiagnoseProzedur",
            "code" : "hospital-main-diagnosis",
            "display" : "Krankenhaus Hauptdiagnose"
          },
          {
            "system" : "http://terminology.hl7.org/CodeSystem/diagnosis-role",
            "code" : "DD",
            "display" : "Discharge diagnosis"
          }]
        },
        "rank" : 1
      },
      {
        "condition" : {
          "reference" : "Condition/mii-exa-test-data-patient-12-diagnose-2"
        },
        "use" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/KontaktDiagnoseProzedur",
            "code" : "secondary-DRG",
            "display" : "DRG-Nebendiagnose"
          }]
        },
        "rank" : 2
      }],
      "hospitalization" : {
        "admitSource" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/dgkev/Aufnahmeanlass",
            "code" : "N",
            "display" : "Notfall"
          }]
        },
        "dischargeDisposition" : {
          "extension" : [{
            "extension" : [{
              "url" : "ErsteUndZweiteStelle",
              "valueCoding" : {
                "system" : "http://fhir.de/CodeSystem/dkgev/EntlassungsgrundErsteUndZweiteStelle",
                "code" : "01",
                "display" : "Behandlung regulär beendet"
              }
            },
            {
              "url" : "DritteStelle",
              "valueCoding" : {
                "system" : "http://fhir.de/CodeSystem/dkgev/EntlassungsgrundDritteStelle",
                "code" : "2",
                "display" : "arbeitsunfähig entlassen"
              }
            }],
            "url" : "http://fhir.de/StructureDefinition/Entlassungsgrund"
          }]
        }
      },
      "serviceProvider" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite",
        "display" : "Charité - Universitätsmedizin Berlin"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-patient-12-encounter-2",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-patient-12-encounter-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-patient-12-encounter-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-patient-12-encounter-2</b></p><a name=\"mii-exa-test-data-patient-12-encounter-2\"> </a><a name=\"hcmii-exa-test-data-patient-12-encounter-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung\">MII PR Fall Kontakt mit einer Gesundheitseinrichtung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Visit number/MII_0000017</p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>type</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/Kontaktebene abteilungskontakt}\">Abteilungskontakt</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/kontaktart-de intensivstationaer}\">Intensivstationär</span></p><p><b>serviceType</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel 3600}\">Intensivmedizin</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>period</b>: 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</p><p><b>serviceProvider</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Charité - Universitätsmedizin Berlin</a></p><p><b>partOf</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "VN"
          }]
        },
        "system" : "https://www.charite.de/fhir/NamingSystem/Aufnahmenummern",
        "value" : "MII_0000017"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/Kontaktebene",
          "code" : "abteilungskontakt"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/kontaktart-de",
          "code" : "intensivstationaer"
        }]
      }],
      "serviceType" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel",
          "code" : "3600"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "period" : {
        "start" : "2025-03-08T18:00:00+01:00",
        "end" : "2025-03-18T10:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite",
        "display" : "Charité - Universitätsmedizin Berlin"
      },
      "partOf" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-patient-12-diagnose-1",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-patient-12-diagnose-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-patient-12-diagnose-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-patient-12-diagnose-1</b></p><a name=\"mii-exa-test-data-patient-12-diagnose-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-diagnose-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose\">MII PR Diagnose Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm J15.0}, {http://snomed.info/sct 64479007}\">Klebsiellen-Pneumonie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p><p><b>onset</b>: 2025-03-06</p><p><b>recordedDate</b>: 2025-03-10</p><p><b>note</b>: </p><blockquote><div><p>Pneumonie durch Klebsiella pneumoniae - erregergesichert am 10.03.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "J15.0"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "64479007",
          "display" : "Pneumonia caused by Klebsiella pneumoniae"
        }],
        "text" : "Klebsiellen-Pneumonie"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "onsetDateTime" : "2025-03-06",
      "recordedDate" : "2025-03-10",
      "note" : [{
        "text" : "Pneumonie durch Klebsiella pneumoniae - erregergesichert am 10.03."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-patient-12-diagnose-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-patient-12-diagnose-2",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-patient-12-diagnose-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-patient-12-diagnose-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-patient-12-diagnose-2</b></p><a name=\"mii-exa-test-data-patient-12-diagnose-2\"> </a><a name=\"hcmii-exa-test-data-patient-12-diagnose-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose\">MII PR Diagnose Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm A41.58}\">Gramnegative Sepsis mit septischem Schock</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p><p><b>onset</b>: 2025-03-08</p><p><b>recordedDate</b>: 2025-03-08</p><p><b>note</b>: </p><blockquote><div><p>Sepsis durch sonstige gramnegative Erreger - septischer Schock bei Aufnahme</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "A41.58"
        }],
        "text" : "Gramnegative Sepsis mit septischem Schock"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "onsetDateTime" : "2025-03-08",
      "recordedDate" : "2025-03-08",
      "note" : [{
        "text" : "Sepsis durch sonstige gramnegative Erreger - septischer Schock bei Aufnahme"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-patient-12-diagnose-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-patient-12-prozedur-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-patient-12-prozedur-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Procedure"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-patient-12-prozedur-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-patient-12-prozedur-1</b></p><a name=\"mii-exa-test-data-patient-12-prozedur-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-prozedur-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Procedure\">MII PR Prozedur Procedure</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>ExtensionProzedurDokumentationsdatum</b>: 2025-03-08 19:30:00+0100</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 112798008}, {http://fhir.de/CodeSystem/bfarm/ops 8-701}\">Insertion of endotracheal tube</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>performed</b>: 2025-03-08 17:52:00+0100</p><p><b>recorder</b>: <a href=\"PractitionerRole-mii-exa-test-data-practitioner-role-physician-1.html\">PractitionerRole Physician (occupation)</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 44567001}\">Tracheal structure</span></p><p><b>note</b>: </p><blockquote><div><p>Endotracheale Intubation bei respiratorischer Erschoepfung</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2025-03-08T19:30:00+01:00"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "112798008"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2024",
          "code" : "8-701"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "performedDateTime" : "2025-03-08T17:52:00+01:00",
      "recorder" : {
        "reference" : "PractitionerRole/mii-exa-test-data-practitioner-role-physician-1"
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "44567001"
        }]
      }],
      "note" : [{
        "text" : "Endotracheale Intubation bei respiratorischer Erschoepfung"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-patient-12-prozedur-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Consent/mii-exa-test-data-patient-12-consent-1",
    "resource" : {
      "resourceType" : "Consent",
      "id" : "mii-exa-test-data-patient-12-consent-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-einwilligung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_mii-exa-test-data-patient-12-consent-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent mii-exa-test-data-patient-12-consent-1</b></p><a name=\"mii-exa-test-data-patient-12-consent-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-consent-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-einwilligung\">Profile - MI-I - Consent - Einwilligung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2>Participants</h2><table class=\"grid\"><tr><td><b>Role</b></td><td><b>Details</b></td></tr><tr><td title=\"Who the consent applies to\">Patient</td><td><a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></td></tr><tr><td title=\"Who manages the consent through its lifecycle.\">Manager</td><td><a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></td></tr></table><p>This consent is made under the regulation <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ActCode OPTIN}\">MII Broad Consent Opt-in</span> and the policy <code>urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791</code> .</p><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: 1px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top;\"><tr style=\"border: 2px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top\"><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Applicable Rule\">Rule</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Applicable Period\">Time Period</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Applicable Data\">What</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Other Applicable Rules\">Rules</a><span style=\"float: right\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Legend for this format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/></a></span></th></tr><tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck1.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: #F7F7F7\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck01.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin_end.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon-qi-hidden.png\" alt=\".\" style=\"background-color: #F7F7F7; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> deny</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2025-03-19 --&gt; 2055-03-18</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck010.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_blank.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2025-03-19 --&gt; 2055-03-18</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Code: <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.6}\">MDAT erheben</span></li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: #F7F7F7\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck010.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_blank.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: #F7F7F7; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2025-03-19 --&gt; 2055-03-18</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Code: <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.7}\">MDAT speichern, verarbeiten</span></li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck000.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_blank.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin_end.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2025-03-19 --&gt; 2055-03-18</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Code: <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.8}\">MDAT wissenschaftlich nutzen</span></li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr><td colspan=\"4\" class=\"hierarchy\"><br/><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Legend for this format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/> Documentation for this format</a></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "domain",
          "valueReference" : {
            "reference" : "Organization/mii-exa-test-data-organization-charite",
            "display" : "MII Broad Consent Domäne Charité"
          }
        }],
        "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
      }],
      "status" : "active",
      "scope" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
          "code" : "research"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "57016-8"
        }]
      },
      {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/modul-consent/CodeSystem/mii-cs-consent-version-modules",
          "code" : "2.16.840.1.113883.3.1937.777.24.2.184"
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-patient-12",
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "G345678901"
        }
      },
      "dateTime" : "2025-03-19T11:00:00+01:00",
      "organization" : [{
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      }],
      "policy" : [{
        "uri" : "urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791"
      }],
      "policyRule" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          "code" : "OPTIN",
          "display" : "opt-in"
        }],
        "text" : "MII Broad Consent Opt-in"
      },
      "provision" : {
        "type" : "deny",
        "period" : {
          "start" : "2025-03-19",
          "end" : "2055-03-18"
        },
        "provision" : [{
          "type" : "permit",
          "period" : {
            "start" : "2025-03-19",
            "end" : "2055-03-18"
          },
          "code" : [{
            "coding" : [{
              "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
              "code" : "2.16.840.1.113883.3.1937.777.24.5.3.6",
              "display" : "MDAT erheben"
            }]
          }]
        },
        {
          "type" : "permit",
          "period" : {
            "start" : "2025-03-19",
            "end" : "2055-03-18"
          },
          "code" : [{
            "coding" : [{
              "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
              "code" : "2.16.840.1.113883.3.1937.777.24.5.3.7",
              "display" : "MDAT speichern, verarbeiten"
            }]
          }]
        },
        {
          "type" : "permit",
          "period" : {
            "start" : "2025-03-19",
            "end" : "2055-03-18"
          },
          "code" : [{
            "coding" : [{
              "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
              "code" : "2.16.840.1.113883.3.1937.777.24.5.3.8",
              "display" : "MDAT wissenschaftlich nutzen"
            }]
          }]
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Consent/mii-exa-test-data-patient-12-consent-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-patient-12-labrequest-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-patient-12-labrequest-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ServiceRequestLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-patient-12-labrequest-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-patient-12-labrequest-1</b></p><a name=\"mii-exa-test-data-patient-12-labrequest-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-labrequest-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ServiceRequestLab\">MII PR Labor Laboranforderung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Placer Identifier/LA_000012</p><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>priority</b>: STAT</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 2524-7}\">Sepsis-Basislabor (Laktat, CRP, Procalcitonin, Leukozyten)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p><p><b>authoredOn</b>: 2025-03-08 14:35:00+0100</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PLAC"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/Laboranforderungen",
        "value" : "LA_000012",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "status" : "completed",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "priority" : "stat",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "2524-7",
          "display" : "Lactate [Moles/volume] in Serum or Plasma"
        }],
        "text" : "Sepsis-Basislabor (Laktat, CRP, Procalcitonin, Leukozyten)"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "authoredOn" : "2025-03-08T14:35:00+01:00",
      "requester" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-patient-12-labrequest-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DiagnosticReport/mii-exa-test-data-patient-12-labreport-1",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-test-data-patient-12-labreport-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/DiagnosticReportLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_mii-exa-test-data-patient-12-labreport-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-test-data-patient-12-labreport-1</b></p><a name=\"mii-exa-test-data-patient-12-labreport-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-labreport-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/DiagnosticReportLab\">MII PR Labor Laborbefund</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2><span title=\"Codes:{http://loinc.org 11502-2}\">Laboratory report</span> (<span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 LAB}, {http://loinc.org 26436-6}\">Laboratory studies (set)</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</td></tr><tr><td>Relevant Time</td><td>2025-03-08 14:45:00+0100</td></tr><tr><td>Reported</td><td>2025-03-08 15:20:00+0100</td></tr><tr><td>Performer</td><td> <a href=\"Organization-mii-exa-test-data-organization-labor-berlin.html\">Organization Labor Berlin – Charité Vivantes GmbH</a></td></tr><tr><td>Identifier</td><td> Filler Identifier/LDR_000012</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Reference Range</b></td><td><b>Flags</b></td><td><b>Note</b></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-labobs-1.html\"><span title=\"Codes:{http://loinc.org 2524-7}\">Lactate [Moles/volume] in Serum or Plasma</span></a></td><td>4.8 millimole per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemmol/L = 'mmol/L')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span>: 0.5 millimole per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemmol/L = 'mmol/L')</span> - 1.6 millimole per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemmol/L = 'mmol/L')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation HH}\">Critical high</span></td><td><blockquote><div><p>Laktat &gt; 2 mmol/L trotz Volumengabe — Kriterium des septischen Schocks (Sepsis-3).</p>\n</div></blockquote></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-labobs-2.html\"><span title=\"Codes:{http://loinc.org 33959-8}\">Procalcitonin [Mass/volume] in Serum or Plasma</span></a></td><td>28.4 nanogram per milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/mL = 'ng/mL')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span>: &lt;0.5 nanogram per milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/mL = 'ng/mL')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation HH}\">Critical high</span></td><td><blockquote><div><p>PCT-Verlauf steuert die Therapiedauer im Stewardship-Protokoll.</p>\n</div></blockquote></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-labobs-3.html\"><span title=\"Codes:{http://loinc.org 1988-5}\">C reactive protein [Mass/volume] in Serum or Plasma</span></a></td><td>312 milligram per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span>: &lt;5 milligram per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></td><td/></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-labobs-4.html\"><span title=\"Codes:{http://loinc.org 26464-8}\">Leukocytes [#/volume] in Blood</span></a></td><td>23.4 /nanoliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/nL = '/nL')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span>: 3.9 /nanoliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/nL = '/nL')</span> - 10.5 /nanoliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/nL = '/nL')</span> for <span title=\"Codes:{http://snomed.info/sct 248153007}\">Male (finding)</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></td><td/></tr></table><p>Laktat 4.8 mmol/L, Procalcitonin 28 ng/mL, CRP 312 mg/L, Leukozytose 23.4/nL — Konstellation eines septischen Schocks.</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "FILL"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LDR_000012",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "LAB"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "effectiveDateTime" : "2025-03-08T14:45:00+01:00",
      "issued" : "2025-03-08T15:20:00+01:00",
      "performer" : [{
        "reference" : "Organization/mii-exa-test-data-organization-labor-berlin"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-test-data-patient-12-labobs-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-labobs-2"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-labobs-3"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-labobs-4"
      }],
      "conclusion" : "Laktat 4.8 mmol/L, Procalcitonin 28 ng/mL, CRP 312 mg/L, Leukozytose 23.4/nL — Konstellation eines septischen Schocks."
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-test-data-patient-12-labreport-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-labobs-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-labobs-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-labobs-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-labobs-1</b></p><a name=\"mii-exa-test-data-patient-12-labobs-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-labobs-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab\">MII PR Labor Laboruntersuchung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/LO_000041</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-labrequest-1.html\">ServiceRequest Lactate [Moles/volume] in Serum or Plasma</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}, {http://loinc.org 26436-6}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 2524-7}\">Lactate [Moles/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p><p><b>effective</b>: 2025-03-08 14:45:00+0100</p><p><b>issued</b>: 2025-03-08 15:20:00+0100</p><p><b>value</b>: 4.8 millimole per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemmol/L = 'mmol/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation HH}\">Critical high</span></p><p><b>note</b>: </p><blockquote><div><p>Laktat &gt; 2 mmol/L trotz Volumengabe — Kriterium des septischen Schocks (Sepsis-3).</p>\n</div></blockquote><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>0.5 millimole per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemmol/L = 'mmol/L')</span></td><td>1.6 millimole per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemmol/L = 'mmol/L')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LO_000041",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "version" : "2.78",
          "code" : "2524-7",
          "display" : "Lactate [Moles/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "effectiveDateTime" : "2025-03-08T14:45:00+01:00",
      "issued" : "2025-03-08T15:20:00+01:00",
      "valueQuantity" : {
        "value" : 4.8,
        "unit" : "millimole per liter",
        "system" : "http://unitsofmeasure.org",
        "code" : "mmol/L"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "HH",
          "display" : "Critical high"
        }]
      }],
      "note" : [{
        "text" : "Laktat > 2 mmol/L trotz Volumengabe — Kriterium des septischen Schocks (Sepsis-3)."
      }],
      "referenceRange" : [{
        "low" : {
          "value" : 0.5,
          "unit" : "millimole per liter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mmol/L"
        },
        "high" : {
          "value" : 1.6,
          "unit" : "millimole per liter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mmol/L"
        },
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
            "code" : "normal",
            "display" : "Normal Range"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-labobs-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-labobs-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-labobs-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-labobs-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-labobs-2</b></p><a name=\"mii-exa-test-data-patient-12-labobs-2\"> </a><a name=\"hcmii-exa-test-data-patient-12-labobs-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab\">MII PR Labor Laboruntersuchung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/LO_000042</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-labrequest-1.html\">ServiceRequest Lactate [Moles/volume] in Serum or Plasma</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}, {http://loinc.org 26436-6}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33959-8}\">Procalcitonin [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p><p><b>effective</b>: 2025-03-08 14:45:00+0100</p><p><b>issued</b>: 2025-03-08 15:20:00+0100</p><p><b>value</b>: 28.4 nanogram per milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/mL = 'ng/mL')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation HH}\">Critical high</span></p><p><b>note</b>: </p><blockquote><div><p>PCT-Verlauf steuert die Therapiedauer im Stewardship-Protokoll.</p>\n</div></blockquote><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>High</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>0.5 nanogram per milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/mL = 'ng/mL')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LO_000042",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "version" : "2.78",
          "code" : "33959-8",
          "display" : "Procalcitonin [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "effectiveDateTime" : "2025-03-08T14:45:00+01:00",
      "issued" : "2025-03-08T15:20:00+01:00",
      "valueQuantity" : {
        "value" : 28.4,
        "unit" : "nanogram per milliliter",
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/mL"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "HH",
          "display" : "Critical high"
        }]
      }],
      "note" : [{
        "text" : "PCT-Verlauf steuert die Therapiedauer im Stewardship-Protokoll."
      }],
      "referenceRange" : [{
        "high" : {
          "value" : 0.5,
          "unit" : "nanogram per milliliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "ng/mL"
        },
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
            "code" : "normal",
            "display" : "Normal Range"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-labobs-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-labobs-3",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-labobs-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-labobs-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-labobs-3</b></p><a name=\"mii-exa-test-data-patient-12-labobs-3\"> </a><a name=\"hcmii-exa-test-data-patient-12-labobs-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab\">MII PR Labor Laboruntersuchung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/LO_000043</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-labrequest-1.html\">ServiceRequest Lactate [Moles/volume] in Serum or Plasma</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}, {http://loinc.org 26436-6}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 1988-5}\">C reactive protein [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p><p><b>effective</b>: 2025-03-08 14:45:00+0100</p><p><b>issued</b>: 2025-03-08 15:20:00+0100</p><p><b>value</b>: 312 milligram per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>High</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>5 milligram per liter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LO_000043",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "version" : "2.78",
          "code" : "1988-5",
          "display" : "C reactive protein [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "effectiveDateTime" : "2025-03-08T14:45:00+01:00",
      "issued" : "2025-03-08T15:20:00+01:00",
      "valueQuantity" : {
        "value" : 312,
        "unit" : "milligram per liter",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/L"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "referenceRange" : [{
        "high" : {
          "value" : 5,
          "unit" : "milligram per liter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/L"
        },
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
            "code" : "normal",
            "display" : "Normal Range"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-labobs-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-labobs-4",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-labobs-4",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-labobs-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-labobs-4</b></p><a name=\"mii-exa-test-data-patient-12-labobs-4\"> </a><a name=\"hcmii-exa-test-data-patient-12-labobs-4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab\">MII PR Labor Laboruntersuchung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/LO_000044</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-labrequest-1.html\">ServiceRequest Lactate [Moles/volume] in Serum or Plasma</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}, {http://loinc.org 26436-6}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 26464-8}\">Leukocytes [#/volume] in Blood</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Einrichtungskontakt,Normalstationär; serviceType = Innere Medizin; period = 2025-03-08 14:20:00+0100 --&gt; 2025-03-25 11:00:00+0100</a></p><p><b>effective</b>: 2025-03-08 14:45:00+0100</p><p><b>issued</b>: 2025-03-08 15:20:00+0100</p><p><b>value</b>: 23.4 /nanoliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/nL = '/nL')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td><td><b>Type</b></td><td><b>AppliesTo</b></td></tr><tr><td style=\"display: none\">*</td><td>3.9 /nanoliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/nL = '/nL')</span></td><td>10.5 /nanoliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/nL = '/nL')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span></td><td><span title=\"Codes:{http://snomed.info/sct 248153007}\">Male (finding)</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LO_000044",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "version" : "2.78",
          "code" : "26464-8",
          "display" : "Leukocytes [#/volume] in Blood"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-1"
      },
      "effectiveDateTime" : "2025-03-08T14:45:00+01:00",
      "issued" : "2025-03-08T15:20:00+01:00",
      "valueQuantity" : {
        "value" : 23.4,
        "unit" : "/nanoliter",
        "system" : "http://unitsofmeasure.org",
        "code" : "/nL"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "referenceRange" : [{
        "low" : {
          "value" : 3.9,
          "unit" : "/nanoliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "/nL"
        },
        "high" : {
          "value" : 10.5,
          "unit" : "/nanoliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "/nL"
        },
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
            "code" : "normal",
            "display" : "Normal Range"
          }]
        },
        "appliesTo" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "248153007",
            "display" : "Male (finding)"
          }]
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-labobs-4"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Medication/mii-exa-test-data-medication-piperacillin-tazobactam",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "mii-exa-test-data-medication-piperacillin-tazobactam",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_mii-exa-test-data-medication-piperacillin-tazobactam\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication mii-exa-test-data-medication-piperacillin-tazobactam</b></p><a name=\"mii-exa-test-data-medication-piperacillin-tazobactam\"> </a><a name=\"hcmii-exa-test-data-medication-piperacillin-tazobactam\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication\">MII PR Medikation Medication</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc J01CR05}\">Piperacillin/Tazobactam 4 g/0,5 g</span></p><p><b>form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 50043000}\">Powder for concentrate for solution for infusion</span></p><blockquote><p><b>ingredient</b></p><p><b>item</b>: <span title=\"Codes:{http://snomed.info/sct 372836004}\">Piperacillin</span></p><p><b>strength</b>: 4 gram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span>/1 Powder for concentrate for solution for infusion<span style=\"background: LightGoldenRodYellow\"> (Details: standardterms.edqm.eu  code50043000 = 'Powder for concentrate for solution for infusion')</span></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>item</b>: <span title=\"Codes:{http://snomed.info/sct 96007008}\">Tazobactam</span></p><p><b>strength</b>: 500 milligram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Powder for concentrate for solution for infusion<span style=\"background: LightGoldenRodYellow\"> (Details: standardterms.edqm.eu  code50043000 = 'Powder for concentrate for solution for infusion')</span></p></blockquote></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2023",
          "code" : "J01CR05",
          "display" : "Piperacillin und Beta-Lactamase-Inhibitoren"
        }],
        "text" : "Piperacillin/Tazobactam 4 g/0,5 g"
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "50043000",
          "display" : "Powder for concentrate for solution for infusion"
        }]
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "372836004",
            "display" : "Piperacillin (substance)"
          }],
          "text" : "Piperacillin"
        },
        "strength" : {
          "numerator" : {
            "value" : 4,
            "unit" : "gram",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Powder for concentrate for solution for infusion",
            "system" : "http://standardterms.edqm.eu",
            "code" : "50043000"
          }
        }
      },
      {
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "96007008",
            "display" : "Tazobactam (substance)"
          }],
          "text" : "Tazobactam"
        },
        "strength" : {
          "numerator" : {
            "value" : 500,
            "unit" : "milligram",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Powder for concentrate for solution for infusion",
            "system" : "http://standardterms.edqm.eu",
            "code" : "50043000"
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Medication/mii-exa-test-data-medication-piperacillin-tazobactam"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Medication/mii-exa-test-data-medication-meropenem",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "mii-exa-test-data-medication-meropenem",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_mii-exa-test-data-medication-meropenem\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication mii-exa-test-data-medication-meropenem</b></p><a name=\"mii-exa-test-data-medication-meropenem\"> </a><a name=\"hcmii-exa-test-data-medication-meropenem\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication\">MII PR Medikation Medication</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc J01DH02}\">Meropenem 1 g</span></p><p><b>form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 50043000}\">Powder for concentrate for solution for infusion</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 387540000}\">Meropenem</span></td><td>1 gram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span>/1 Powder for concentrate for solution for infusion<span style=\"background: LightGoldenRodYellow\"> (Details: standardterms.edqm.eu  code50043000 = 'Powder for concentrate for solution for infusion')</span></td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2023",
          "code" : "J01DH02",
          "display" : "Meropenem"
        }],
        "text" : "Meropenem 1 g"
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "50043000",
          "display" : "Powder for concentrate for solution for infusion"
        }]
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "387540000",
            "display" : "Meropenem (substance)"
          }],
          "text" : "Meropenem"
        },
        "strength" : {
          "numerator" : {
            "value" : 1,
            "unit" : "gram",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Powder for concentrate for solution for infusion",
            "system" : "http://standardterms.edqm.eu",
            "code" : "50043000"
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Medication/mii-exa-test-data-medication-meropenem"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Medication/mii-exa-test-data-medication-noradrenalin",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "mii-exa-test-data-medication-noradrenalin",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_mii-exa-test-data-medication-noradrenalin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication mii-exa-test-data-medication-noradrenalin</b></p><a name=\"mii-exa-test-data-medication-noradrenalin\"> </a><a name=\"hcmii-exa-test-data-medication-noradrenalin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication\">MII PR Medikation Medication</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc C01CA03}\">Noradrenalin 1 mg/mL</span></p><p><b>form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 50060000}\">Concentrate for solution for infusion</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 45555007}\">Noradrenalin</span></td><td>1 milligram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2023",
          "code" : "C01CA03",
          "display" : "Norepinephrin"
        }],
        "text" : "Noradrenalin 1 mg/mL"
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "50060000",
          "display" : "Concentrate for solution for infusion"
        }]
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "45555007",
            "display" : "Norepinephrine (substance)"
          }],
          "text" : "Noradrenalin"
        },
        "strength" : {
          "numerator" : {
            "value" : 1,
            "unit" : "milligram",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "milliliter",
            "system" : "http://unitsofmeasure.org",
            "code" : "mL"
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Medication/mii-exa-test-data-medication-noradrenalin"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-patient-12-medrequest-1",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-patient-12-medrequest-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-patient-12-medrequest-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-patient-12-medrequest-1</b></p><a name=\"mii-exa-test-data-patient-12-medrequest-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-medrequest-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest\">MII PR Medikation MedicationRequest</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/MedicationOrders</code>/MO_0000031</p><p><b>status</b>: Stopped</p><p><b>statusReason</b>: <span title=\"Codes:{http://snomed.info/sct 182840001}\">Drug treatment stopped - medical advice</span></p><p><b>intent</b>: Order</p><p><b>medication</b>: <a href=\"Medication-mii-exa-test-data-medication-piperacillin-tazobactam.html\">Medication Piperacillin und Beta-Lactamase-Inhibitoren</a></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>authoredOn</b>: 2025-03-08 18:55:00+0100</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-patient-12-diagnose-2.html\">Condition Sepsis: Sonstige gramnegative Erreger</a></p><p><b>note</b>: </p><blockquote><div><p>Kalkulierte Initialtherapie nach hausinternem Sepsis-Standard, begonnen 19:00 nach Abnahme der Blutkulturen. Beendet am 11.03. 11:00 nach Vorliegen des Antibiogramms (Erreger resistent).</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: 3 per 1 day</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20045000}\">Intravenous use</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>4.5 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></td></tr></table></blockquote><h3>Substitutions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Allowed[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>false</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/MedicationOrders",
        "value" : "MO_0000031"
      }],
      "status" : "stopped",
      "statusReason" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182840001",
          "display" : "Drug treatment stopped - medical advice"
        }]
      },
      "intent" : "order",
      "medicationReference" : {
        "reference" : "Medication/mii-exa-test-data-medication-piperacillin-tazobactam"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "authoredOn" : "2025-03-08T18:55:00+01:00",
      "requester" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-patient-12-diagnose-2"
      }],
      "note" : [{
        "text" : "Kalkulierte Initialtherapie nach hausinternem Sepsis-Standard, begonnen 19:00 nach Abnahme der Blutkulturen. Beendet am 11.03. 11:00 nach Vorliegen des Antibiogramms (Erreger resistent)."
      }],
      "dosageInstruction" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2025-03-08T19:00:00+01:00",
              "end" : "2025-03-11T11:00:00+01:00"
            },
            "frequency" : 3,
            "period" : 1,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Intravenous use"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 4.5,
            "unit" : "g",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          }
        }]
      }],
      "substitution" : {
        "allowedBoolean" : false
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-patient-12-medrequest-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-patient-12-medrequest-2",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-patient-12-medrequest-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-patient-12-medrequest-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-patient-12-medrequest-2</b></p><a name=\"mii-exa-test-data-patient-12-medrequest-2\"> </a><a name=\"hcmii-exa-test-data-patient-12-medrequest-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest\">MII PR Medikation MedicationRequest</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/MedicationOrders</code>/MO_0000032</p><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>priority</b>: Urgent</p><p><b>medication</b>: <a href=\"Medication-mii-exa-test-data-medication-meropenem.html\">Medication Meropenem</a></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>authoredOn</b>: 2025-03-11 10:45:00+0100</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>reasonReference</b>: </p><ul><li><a href=\"Condition-mii-exa-test-data-patient-12-diagnose-2.html\">Condition Sepsis: Sonstige gramnegative Erreger</a></li><li><a href=\"Observation-mii-exa-test-data-patient-12-mibi-mrgn-1.html\">Observation Multidrug resistant gram-negative organism classification [Type]</a></li><li><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-meropenem.html\">Observation Meropenem [Susceptibility]</a></li></ul><p><b>note</b>: </p><blockquote><div><p>Umstellung 1 h 45 min nach Freigabe des Antibiogramms (09:00 befundet, 11:00 erste Gabe). Dauer 7 Tage bis 18.03., gesteuert ueber den Procalcitonin-Verlauf.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: Duration 180days , 3 per 1 day</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20045000}\">Intravenous use</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></td></tr></table><p><b>maxDosePerAdministration</b>: 2 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></p></blockquote><h3>Substitutions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Allowed[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>false</td></tr></table><p><b>priorPrescription</b>: <a href=\"MedicationRequest-mii-exa-test-data-patient-12-medrequest-1.html\">MedicationRequest: identifier = https://www.charite.de/fhir/sid/MedicationOrders#MO_0000031; status = stopped; statusReason = Drug treatment stopped - medical advice; intent = order; medication[x] = -&gt;Medication Piperacillin und Beta-Lactamase-Inhibitoren; authoredOn = 2025-03-08 18:55:00+0100; note = Kalkulierte Initialtherapie nach hausinternem Sepsis-Standard, begonnen 19:00 nach Abnahme der Blutkulturen. Beendet am 11.03. 11:00 nach Vorliegen des Antibiogramms (Erreger resistent).</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/MedicationOrders",
        "value" : "MO_0000032"
      }],
      "status" : "completed",
      "intent" : "order",
      "priority" : "urgent",
      "medicationReference" : {
        "reference" : "Medication/mii-exa-test-data-medication-meropenem"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "authoredOn" : "2025-03-11T10:45:00+01:00",
      "requester" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-patient-12-diagnose-2"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-mrgn-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-meropenem"
      }],
      "note" : [{
        "text" : "Umstellung 1 h 45 min nach Freigabe des Antibiogramms (09:00 befundet, 11:00 erste Gabe). Dauer 7 Tage bis 18.03., gesteuert ueber den Procalcitonin-Verlauf."
      }],
      "dosageInstruction" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2025-03-11T11:00:00+01:00",
              "end" : "2025-03-18T11:00:00+01:00"
            },
            "duration" : 180,
            "durationUnit" : "min",
            "frequency" : 3,
            "period" : 1,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Intravenous use"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "g",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          }
        }],
        "maxDosePerAdministration" : {
          "value" : 2,
          "unit" : "g",
          "system" : "http://unitsofmeasure.org",
          "code" : "g"
        }
      }],
      "substitution" : {
        "allowedBoolean" : false
      },
      "priorPrescription" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-12-medrequest-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-patient-12-medrequest-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationAdministration/mii-exa-test-data-patient-12-medadmin-1",
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "mii-exa-test-data-patient-12-medadmin-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationAdministration_mii-exa-test-data-patient-12-medadmin-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationAdministration mii-exa-test-data-patient-12-medadmin-1</b></p><a name=\"mii-exa-test-data-patient-12-medadmin-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-medadmin-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration\">MII PR Medikation MedicationAdministration</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/MedicationAdministrations</code>/MA_0000031</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/medication-admin-category inpatient}\">Inpatient</span></p><p><b>medication</b>: <a href=\"Medication-mii-exa-test-data-medication-meropenem.html\">Medication Meropenem</a></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>context</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 11:00:00+0100 --&gt; 2025-03-11 14:00:00+0100</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></td></tr></table><p><b>reasonReference</b>: <a href=\"Observation-mii-exa-test-data-patient-12-mibi-mrgn-1.html\">Observation Multidrug resistant gram-negative organism classification [Type]</a></p><p><b>request</b>: <a href=\"MedicationRequest-mii-exa-test-data-patient-12-medrequest-2.html\">MedicationRequest: identifier = https://www.charite.de/fhir/sid/MedicationOrders#MO_0000032; status = completed; intent = order; priority = urgent; medication[x] = -&gt;Medication Meropenem; authoredOn = 2025-03-11 10:45:00+0100; note = Umstellung 1 h 45 min nach Freigabe des Antibiogramms (09:00 befundet, 11:00 erste Gabe). Dauer 7 Tage bis 18.03., gesteuert ueber den Procalcitonin-Verlauf.</a></p><p><b>note</b>: </p><blockquote><div><p>Verlaengerte Infusion ueber 3 h (pharmakokinetisch optimiert bei septischem Patienten).</p>\n</div></blockquote><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Route</b></td><td><b>Dose</b></td><td><b>Rate[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20045000}\">Intravenous use</span></td><td>1 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></td><td>1 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span>/3 Stunden<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeh = 'h')</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/MedicationAdministrations",
        "value" : "MA_0000031"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medication-admin-category",
          "code" : "inpatient"
        }]
      },
      "medicationReference" : {
        "reference" : "Medication/mii-exa-test-data-medication-meropenem"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "context" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectivePeriod" : {
        "start" : "2025-03-11T11:00:00+01:00",
        "end" : "2025-03-11T14:00:00+01:00"
      },
      "performer" : [{
        "actor" : {
          "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
        }
      }],
      "reasonReference" : [{
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-mrgn-1"
      }],
      "request" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-12-medrequest-2"
      },
      "note" : [{
        "text" : "Verlaengerte Infusion ueber 3 h (pharmakokinetisch optimiert bei septischem Patienten)."
      }],
      "dosage" : {
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Intravenous use"
          }]
        },
        "dose" : {
          "value" : 1,
          "unit" : "g",
          "system" : "http://unitsofmeasure.org",
          "code" : "g"
        },
        "rateRatio" : {
          "numerator" : {
            "value" : 1,
            "unit" : "g",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          },
          "denominator" : {
            "value" : 3,
            "unit" : "Stunden",
            "system" : "http://unitsofmeasure.org",
            "code" : "h"
          }
        }
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationAdministration/mii-exa-test-data-patient-12-medadmin-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationAdministration/mii-exa-test-data-patient-12-medadmin-2",
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "mii-exa-test-data-patient-12-medadmin-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationAdministration_mii-exa-test-data-patient-12-medadmin-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationAdministration mii-exa-test-data-patient-12-medadmin-2</b></p><a name=\"mii-exa-test-data-patient-12-medadmin-2\"> </a><a name=\"hcmii-exa-test-data-patient-12-medadmin-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration\">MII PR Medikation MedicationAdministration</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/MedicationAdministrations</code>/MA_0000032</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/medication-admin-category inpatient}\">Inpatient</span></p><p><b>medication</b>: <a href=\"Medication-mii-exa-test-data-medication-noradrenalin.html\">Medication Norepinephrin</a></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>context</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-08 18:10:00+0100 --&gt; 2025-03-14 06:00:00+0100</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></td></tr></table><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-patient-12-diagnose-2.html\">Condition Sepsis: Sonstige gramnegative Erreger</a></p><p><b>note</b>: </p><blockquote><div><p>Spitzendosis 0,35 µg/kg/min am 09.03.; ausgeschlichen bis 14.03. — begruendet den Kreislauf-Teilscore im SOFA-Verlauf.</p>\n</div></blockquote><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Route</b></td><td><b>Rate[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20045000}\">Intravenous use</span></td><td>0.35 µg/kg/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeug/kg/min = 'ug/kg/min')</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/MedicationAdministrations",
        "value" : "MA_0000032"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medication-admin-category",
          "code" : "inpatient"
        }]
      },
      "medicationReference" : {
        "reference" : "Medication/mii-exa-test-data-medication-noradrenalin"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "context" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectivePeriod" : {
        "start" : "2025-03-08T18:10:00+01:00",
        "end" : "2025-03-14T06:00:00+01:00"
      },
      "performer" : [{
        "actor" : {
          "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
        }
      }],
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-patient-12-diagnose-2"
      }],
      "note" : [{
        "text" : "Spitzendosis 0,35 µg/kg/min am 09.03.; ausgeschlichen bis 14.03. — begruendet den Kreislauf-Teilscore im SOFA-Verlauf."
      }],
      "dosage" : {
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Intravenous use"
          }]
        },
        "rateQuantity" : {
          "value" : 0.35,
          "unit" : "µg/kg/min",
          "system" : "http://unitsofmeasure.org",
          "code" : "ug/kg/min"
        }
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationAdministration/mii-exa-test-data-patient-12-medadmin-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationStatement/mii-exa-test-data-patient-12-medstatement-1",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "mii-exa-test-data-patient-12-medstatement-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_mii-exa-test-data-patient-12-medstatement-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement mii-exa-test-data-patient-12-medstatement-1</b></p><a name=\"mii-exa-test-data-patient-12-medstatement-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-medstatement-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement\">MII PR Medikation MedicationStatement</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/MedicationStatements</code>/MS_0000031</p><p><b>basedOn</b>: <a href=\"MedicationRequest-mii-exa-test-data-patient-12-medrequest-2.html\">MedicationRequest: identifier = https://www.charite.de/fhir/sid/MedicationOrders#MO_0000032; status = completed; intent = order; priority = urgent; medication[x] = -&gt;Medication Meropenem; authoredOn = 2025-03-11 10:45:00+0100; note = Umstellung 1 h 45 min nach Freigabe des Antibiogramms (09:00 befundet, 11:00 erste Gabe). Dauer 7 Tage bis 18.03., gesteuert ueber den Procalcitonin-Verlauf.</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/medication-statement-category inpatient}, {http://ihe-d.de/CodeSystems/FallkontextBeiDokumentenerstellung E200}\">stationärer Aufenthalt</span></p><p><b>medication</b>: <a href=\"Medication-mii-exa-test-data-medication-meropenem.html\">Medication Meropenem</a></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>context</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 --&gt; 2025-03-18</p><p><b>dateAsserted</b>: 2025-03-18</p><p><b>informationSource</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-patient-12-diagnose-1.html\">Condition Pneumonia caused by Klebsiella pneumoniae</a></p><blockquote><p><b>dosage</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: 3 per 1 day</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20045000}\">Intravenous use</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/MedicationStatements",
        "value" : "MS_0000031"
      }],
      "basedOn" : [{
        "reference" : "MedicationRequest/mii-exa-test-data-patient-12-medrequest-2"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medication-statement-category",
          "code" : "inpatient"
        },
        {
          "system" : "http://ihe-d.de/CodeSystems/FallkontextBeiDokumentenerstellung",
          "code" : "E200",
          "display" : "stationärer Aufenthalt"
        }]
      },
      "medicationReference" : {
        "reference" : "Medication/mii-exa-test-data-medication-meropenem"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "context" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectivePeriod" : {
        "start" : "2025-03-11",
        "end" : "2025-03-18"
      },
      "dateAsserted" : "2025-03-18",
      "informationSource" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-patient-12-diagnose-1"
      }],
      "dosage" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "frequency" : 3,
            "period" : 1,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Intravenous use"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "g",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          }
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationStatement/mii-exa-test-data-patient-12-medstatement-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/List/mii-exa-test-data-patient-12-list-stat-aufenthalt",
    "resource" : {
      "resourceType" : "List",
      "id" : "mii-exa-test-data-patient-12-list-stat-aufenthalt",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/medikationsliste"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_mii-exa-test-data-patient-12-list-stat-aufenthalt\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List mii-exa-test-data-patient-12-list-stat-aufenthalt</b></p><a name=\"mii-exa-test-data-patient-12-list-stat-aufenthalt\"> </a><a name=\"hcmii-exa-test-data-patient-12-list-stat-aufenthalt\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/medikationsliste\">MII PR Medikation Medikationsliste</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2>Antiinfektive Therapie Intensivaufenthalt</h2><table class=\"clstu\"><tr><td>Date: 2025-03-18 12:00:00+0100 </td><td>Mode: Working List </td><td>Status: Current </td><td>Code: stationärer Aufenthalt </td></tr><tr><td>Subject: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a>Encounter: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td></tr><tr><td><a href=\"MedicationStatement-mii-exa-test-data-patient-12-medstatement-1.html\">MedicationStatement: identifier = https://www.charite.de/fhir/sid/MedicationStatements#MS_0000031; status = completed; category = stationärer Aufenthalt; medication[x] = -&gt;Medication Meropenem; effective[x] = 2025-03-11 --&gt; 2025-03-18; dateAsserted = 2025-03-18</a></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Medikationslisten",
        "value" : "ML_0000031"
      }],
      "status" : "current",
      "mode" : "working",
      "title" : "Antiinfektive Therapie Intensivaufenthalt",
      "code" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/list-example-use-codes",
          "code" : "medications"
        },
        {
          "system" : "http://ihe-d.de/CodeSystems/FallkontextBeiDokumentenerstellung",
          "code" : "E200",
          "display" : "stationärer Aufenthalt"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "date" : "2025-03-18T12:00:00+01:00",
      "entry" : [{
        "item" : {
          "reference" : "MedicationStatement/mii-exa-test-data-patient-12-medstatement-1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "List/mii-exa-test-data-patient-12-list-stat-aufenthalt"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-charite",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-charite",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-charite\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-charite</b></p><a name=\"mii-exa-test-data-organization-charite\"> </a><a name=\"hcmii-exa-test-data-organization-charite\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Charité – Universitätsmedizin Berlin</p></div>"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Charité – Universitätsmedizin Berlin"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-charite"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-labor-berlin",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-labor-berlin",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-labor-berlin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-labor-berlin</b></p><a name=\"mii-exa-test-data-organization-labor-berlin\"> </a><a name=\"hcmii-exa-test-data-organization-labor-berlin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Labor Berlin – Charité Vivantes GmbH</p></div>"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Labor Berlin – Charité Vivantes GmbH"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-labor-berlin"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Practitioner/mii-exa-test-data-practitioner-physician-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-test-data-practitioner-physician-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_mii-exa-test-data-practitioner-physician-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-test-data-practitioner-physician-1</b></p><a name=\"mii-exa-test-data-practitioner-physician-1\"> </a><a name=\"hcmii-exa-test-data-practitioner-physician-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>active</b>: true</p><p><b>name</b>: Rahel Hirsch </p></div>"
      },
      "active" : true,
      "name" : [{
        "family" : "Hirsch",
        "given" : ["Rahel"]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/PractitionerRole/mii-exa-test-data-practitioner-role-physician-1",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "mii-exa-test-data-practitioner-role-physician-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-beteiligte-person"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_mii-exa-test-data-practitioner-role-physician-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole mii-exa-test-data-practitioner-role-physician-1</b></p><a name=\"mii-exa-test-data-practitioner-role-physician-1\"> </a><a name=\"hcmii-exa-test-data-practitioner-role-physician-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-beteiligte-person\">MII PR Studie Beteiligte Person</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>organization</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 309343006}\">Physician (occupation)</span></p><p><b>telecom</b>: <a href=\"mailto:studienteam@charite.de\">studienteam@charite.de</a></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "organization" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "309343006",
          "display" : "Physician (occupation)"
        }]
      }],
      "telecom" : [{
        "system" : "email",
        "value" : "studienteam@charite.de",
        "use" : "work"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "PractitionerRole/mii-exa-test-data-practitioner-role-physician-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-mikrobio-organization-lab-1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-mikrobio-organization-lab-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-mikrobio-organization-lab-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-mikrobio-organization-lab-1</b></p><a name=\"mii-exa-test-data-mikrobio-organization-lab-1\"> </a><a name=\"hcmii-exa-test-data-mikrobio-organization-lab-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier</code>/DIZ-CHA</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Mikrobiologisches Labor Charité</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
        "value" : "DIZ-CHA"
      }],
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Mikrobiologisches Labor Charité"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-mikrobio-organization-lab-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-mikrobio-device-bactec-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-mikrobio-device-bactec-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-mikrobio-device-bactec-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-mikrobio-device-bactec-1</b></p><a name=\"mii-exa-test-data-mikrobio-device-bactec-1\"> </a><a name=\"hcmii-exa-test-data-mikrobio-device-bactec-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/BACTEC-001</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Blutkultur-Automat</td><td>User Friendly name</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "BACTEC-001"
      }],
      "deviceName" : [{
        "name" : "Blutkultur-Automat",
        "type" : "user-friendly-name"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-mikrobio-device-bactec-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-mikrobio-device-maldi-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-mikrobio-device-maldi-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-mikrobio-device-maldi-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-mikrobio-device-maldi-1</b></p><a name=\"mii-exa-test-data-mikrobio-device-maldi-1\"> </a><a name=\"hcmii-exa-test-data-mikrobio-device-maldi-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/MALDI-TOF-001</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>MALDI Biotyper</td><td>Model name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 469318003}\">Bacterial identification device (physical object)</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "MALDI-TOF-001"
      }],
      "deviceName" : [{
        "name" : "MALDI Biotyper",
        "type" : "model-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "469318003",
          "display" : "Bacterial identification device (physical object)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-mikrobio-device-maldi-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-mikrobio-device-vitek-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-mikrobio-device-vitek-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-mikrobio-device-vitek-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-mikrobio-device-vitek-1</b></p><a name=\"mii-exa-test-data-mikrobio-device-vitek-1\"> </a><a name=\"hcmii-exa-test-data-mikrobio-device-vitek-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/VITEK-001</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>VITEK 2</td><td>Model name</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "VITEK-001"
      }],
      "deviceName" : [{
        "name" : "VITEK 2",
        "type" : "model-name"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-mikrobio-device-mikroskop-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-mikrobio-device-mikroskop-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-mikrobio-device-mikroskop-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-mikrobio-device-mikroskop-1</b></p><a name=\"mii-exa-test-data-mikrobio-device-mikroskop-1\"> </a><a name=\"hcmii-exa-test-data-mikrobio-device-mikroskop-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/MIKROSKOP-001</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Lichtmikroskop Labor 2</td><td>User Friendly name</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "MIKROSKOP-001"
      }],
      "deviceName" : [{
        "name" : "Lichtmikroskop Labor 2",
        "type" : "user-friendly-name"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-mikrobio-device-mikroskop-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-patient-12-icu-device-vent",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-patient-12-icu-device-vent",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-patient-12-icu-device-vent\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-patient-12-icu-device-vent</b></p><a name=\"mii-exa-test-data-patient-12-icu-device-vent\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-device-vent\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device\">MII PR ICU Device</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/ICU-VENT-012</p><p><b>status</b>: Active</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Draeger Evita V500</td><td>Manufacturer name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 706172005}\">Ventilator (physical object)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>SW 2.64</td></tr></table><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "ICU-VENT-012"
      }],
      "status" : "active",
      "deviceName" : [{
        "name" : "Draeger Evita V500",
        "type" : "manufacturer-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "706172005",
          "display" : "Ventilator (physical object)"
        }]
      },
      "version" : [{
        "value" : "SW 2.64"
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-patient-12-icu-device-vent"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DeviceMetric/mii-exa-test-data-patient-12-icu-dm-vent",
    "resource" : {
      "resourceType" : "DeviceMetric",
      "id" : "mii-exa-test-data-patient-12-icu-dm-vent",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-dm-eingestellte-gemessene-parameter-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DeviceMetric_mii-exa-test-data-patient-12-icu-dm-vent\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DeviceMetric mii-exa-test-data-patient-12-icu-dm-vent</b></p><a name=\"mii-exa-test-data-patient-12-icu-dm-vent\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-dm-vent\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-dm-eingestellte-gemessene-parameter-beatmung\">MII PR ICU DeviceMetric Eingestellte Gemessene Parameter Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>source</b>: <a href=\"Device-mii-exa-test-data-patient-12-icu-device-vent.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-VENT-012; status = active; type = Ventilator (physical object)</a></p><p><b>category</b>: Measurement</p></div>"
      },
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      },
      "source" : {
        "reference" : "Device/mii-exa-test-data-patient-12-icu-device-vent"
      },
      "category" : "measurement"
    },
    "request" : {
      "method" : "PUT",
      "url" : "DeviceMetric/mii-exa-test-data-patient-12-icu-dm-vent"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-patient-12-icu-beatmung-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-patient-12-icu-beatmung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-patient-12-icu-beatmung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-patient-12-icu-beatmung-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-beatmung-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-beatmung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-beatmung\">MII PR ICU Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>ExtensionProzedurDokumentationsdatum</b>: 2025-03-16 14:00:00+0100</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 243147009}, {http://fhir.de/CodeSystem/bfarm/ops 8-718.72}\">Controlled ventilation (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>performed</b>: 2025-03-08 18:00:00+0100 --&gt; 2025-03-16 13:00:00+0100</p><p><b>recorder</b>: <a href=\"PractitionerRole-mii-exa-test-data-practitioner-role-physician-1.html\">PractitionerRole Physician (occupation)</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 44567001}\">Tracheal structure</span></p><p><b>note</b>: </p><blockquote><div><p>Lungenprotektive Beatmung (6 mL/kg ideales Koerpergewicht), taegliche Spontanatmungsversuche ab 13.03., Extubation am 16.03.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2025-03-16T14:00:00+01:00"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "243147009",
          "display" : "Controlled ventilation (procedure)"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2024",
          "code" : "8-718.72",
          "display" : "Mindestens 6 bis höchstens 10 Behandlungstage"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "performedPeriod" : {
        "start" : "2025-03-08T18:00:00+01:00",
        "end" : "2025-03-16T13:00:00+01:00"
      },
      "recorder" : {
        "reference" : "PractitionerRole/mii-exa-test-data-practitioner-role-physician-1"
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "44567001",
          "display" : "Tracheal structure"
        }]
      }],
      "note" : [{
        "text" : "Lungenprotektive Beatmung (6 mL/kg ideales Koerpergewicht), taegliche Spontanatmungsversuche ab 13.03., Extubation am 16.03."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-patient-12-icu-beatmung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-vent-peep-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-vent-peep-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-positiv-endexpiratorischer-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-vent-peep-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-vent-peep-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-vent-peep-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-vent-peep-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-positiv-endexpiratorischer-druck\">MII PR ICU Positiv Endexpiratorischer Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-peep-12-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-12-icu-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250854009}, {http://loinc.org 76248-4}, {urn:iso:std:iso:11073:10101 151976}\">Positive end expiratory pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-09 06:00:00+0100</p><p><b>issued</b>: 2025-03-09 06:05:00+0100</p><p><b>value</b>: 12 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-12-icu-dm-vent.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-peep-12-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-12-icu-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250854009",
          "display" : "Positive end expiratory pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76248-4",
          "display" : "PEEP Respiratory system --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151976",
          "display" : "Positive end expiratory pressure applied to the airway."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-09T06:00:00+01:00",
      "issued" : "2025-03-09T06:05:00+01:00",
      "valueQuantity" : {
        "value" : 12,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-12-icu-dm-vent"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-vent-peep-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-vent-fio2-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-vent-fio2-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-vent-fio2-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-vent-fio2-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-vent-fio2-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-vent-fio2-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion\">MII PR ICU Inspiratorische Sauerstofffraktion</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-fio2-12-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-12-icu-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250774007}\">Inspired oxygen concentration (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-09 06:00:00+0100</p><p><b>issued</b>: 2025-03-09 06:05:00+0100</p><p><b>value</b>: 0.6 percent<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-12-icu-dm-vent.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-fio2-12-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-12-icu-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250774007",
          "display" : "Inspired oxygen concentration (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-09T06:00:00+01:00",
      "issued" : "2025-03-09T06:05:00+01:00",
      "valueQuantity" : {
        "value" : 0.6,
        "unit" : "percent",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-12-icu-dm-vent"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-vent-fio2-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-vent-vt-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-vent-vt-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-einstellung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-vent-vt-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-vent-vt-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-vent-vt-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-vent-vt-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-einstellung\">MII PR ICU Atemzugvolumen Einstellung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-12-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-12-icu-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 416811008}, {http://loinc.org 20112-9}, {urn:iso:std:iso:11073:10101 16929196}\">Tidal volume setting (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-09 06:00:00+0100</p><p><b>issued</b>: 2025-03-09 06:05:00+0100</p><p><b>value</b>: 430 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></p><p><b>note</b>: </p><blockquote><div><p>6 mL/kg ideales Koerpergewicht (72 kg IBW bei 178 cm).</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-12-icu-dm-vent.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-12-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-12-icu-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "416811008",
          "display" : "Tidal volume setting (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "20112-9",
          "display" : "Tidal volume setting Ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929196",
          "display" : "MDC_VENT_VOL_TIDAL_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-09T06:00:00+01:00",
      "issued" : "2025-03-09T06:05:00+01:00",
      "valueQuantity" : {
        "value" : 430,
        "unit" : "mL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL"
      },
      "note" : [{
        "text" : "6 mL/kg ideales Koerpergewicht (72 kg IBW bei 178 cm)."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-12-icu-dm-vent"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-vent-vt-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-sofa-t1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-sofa-t1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-sofa-t1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-sofa-t1</b></p><a name=\"mii-exa-test-data-patient-12-icu-sofa-t1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-sofa-t1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa\">MII PR ICU Score SOFA</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96789-3}, {http://snomed.info/sct 1187491009}\">Sequential Organ Failure Assessment SOFA</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-09 09:00:00+0100</p><p><b>issued</b>: 2025-03-09 09:30:00+0100</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>value</b>: 12</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>note</b>: </p><blockquote><div><p>Kreislauf 4 Punkte unter hochdosiertem Noradrenalin; Respiration 4 bei Horovitz &lt; 100 unter Beatmung.</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96823-0}, {http://snomed.info/sct xxxx}\">Respiration [Score] SOFA</span></p><p><b>value</b>: 4</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96824-8}, {http://snomed.info/sct xxx}\">Coagulation [Score] SOFA</span></p><p><b>value</b>: 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96825-5}, {http://snomed.info/sct xxx}\">Liver [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96826-3}, {http://snomed.info/sct xxx}\">Cardiovascular [Score] SOFA</span></p><p><b>value</b>: 4</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96827-1}, {http://snomed.info/sct xxxx}\">Central nervous system [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96828-9}, {http://snomed.info/sct xxx}\">Renal [Score] SOFA</span></p><p><b>value</b>: 0</p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "96789-3",
          "display" : "Sequential Organ Failure Assessment SOFA"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1187491009",
          "display" : "Sequential Organ Failure Assessment score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-09T09:00:00+01:00",
      "issued" : "2025-03-09T09:30:00+01:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      }],
      "valueInteger" : 12,
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "note" : [{
        "text" : "Kreislauf 4 Punkte unter hochdosiertem Noradrenalin; Respiration 4 bei Horovitz < 100 unter Beatmung."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96823-0",
            "display" : "Respiration [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Respiratory"
          }]
        },
        "valueInteger" : 4
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96824-8",
            "display" : "Coagulation [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Coagulation"
          }]
        },
        "valueInteger" : 2
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96825-5",
            "display" : "Liver [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Hepatic"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96826-3",
            "display" : "Cardiovascular [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Cardiovascular"
          }]
        },
        "valueInteger" : 4
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96827-1",
            "display" : "Central nervous system [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Neurological"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96828-9",
            "display" : "Renal [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Renal"
          }]
        },
        "valueInteger" : 0
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-sofa-t1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-sofa-t5",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-sofa-t5",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-sofa-t5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-sofa-t5</b></p><a name=\"mii-exa-test-data-patient-12-icu-sofa-t5\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-sofa-t5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa\">MII PR ICU Score SOFA</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96789-3}, {http://snomed.info/sct 1187491009}\">Sequential Organ Failure Assessment SOFA</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-13 09:00:00+0100</p><p><b>issued</b>: 2025-03-13 09:30:00+0100</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>value</b>: 9</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>note</b>: </p><blockquote><div><p>Rueckgang um 3 Punkte nach Umstellung auf Meropenem am 11.03.</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96823-0}, {http://snomed.info/sct xxxx}\">Respiration [Score] SOFA</span></p><p><b>value</b>: 3</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96824-8}, {http://snomed.info/sct xxx}\">Coagulation [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96825-5}, {http://snomed.info/sct xxx}\">Liver [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96826-3}, {http://snomed.info/sct xxx}\">Cardiovascular [Score] SOFA</span></p><p><b>value</b>: 3</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96827-1}, {http://snomed.info/sct xxxx}\">Central nervous system [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96828-9}, {http://snomed.info/sct xxx}\">Renal [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "96789-3",
          "display" : "Sequential Organ Failure Assessment SOFA"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1187491009",
          "display" : "Sequential Organ Failure Assessment score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-13T09:00:00+01:00",
      "issued" : "2025-03-13T09:30:00+01:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      }],
      "valueInteger" : 9,
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "note" : [{
        "text" : "Rueckgang um 3 Punkte nach Umstellung auf Meropenem am 11.03."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96823-0",
            "display" : "Respiration [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Respiratory"
          }]
        },
        "valueInteger" : 3
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96824-8",
            "display" : "Coagulation [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Coagulation"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96825-5",
            "display" : "Liver [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Hepatic"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96826-3",
            "display" : "Cardiovascular [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Cardiovascular"
          }]
        },
        "valueInteger" : 3
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96827-1",
            "display" : "Central nervous system [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Neurological"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96828-9",
            "display" : "Renal [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Renal"
          }]
        },
        "valueInteger" : 1
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-sofa-t5"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-sofa-t8",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-sofa-t8",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-sofa-t8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-sofa-t8</b></p><a name=\"mii-exa-test-data-patient-12-icu-sofa-t8\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-sofa-t8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa\">MII PR ICU Score SOFA</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96789-3}, {http://snomed.info/sct 1187491009}\">Sequential Organ Failure Assessment SOFA</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-16 09:00:00+0100</p><p><b>issued</b>: 2025-03-16 09:30:00+0100</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>value</b>: 4</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><p><b>note</b>: </p><blockquote><div><p>Katecholaminfrei seit 14.03.; Extubation am selben Tag um 13:00.</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96823-0}, {http://snomed.info/sct xxxx}\">Respiration [Score] SOFA</span></p><p><b>value</b>: 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96824-8}, {http://snomed.info/sct xxx}\">Coagulation [Score] SOFA</span></p><p><b>value</b>: 0</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96825-5}, {http://snomed.info/sct xxx}\">Liver [Score] SOFA</span></p><p><b>value</b>: 0</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96826-3}, {http://snomed.info/sct xxx}\">Cardiovascular [Score] SOFA</span></p><p><b>value</b>: 0</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96827-1}, {http://snomed.info/sct xxxx}\">Central nervous system [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96828-9}, {http://snomed.info/sct xxx}\">Renal [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "96789-3",
          "display" : "Sequential Organ Failure Assessment SOFA"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1187491009",
          "display" : "Sequential Organ Failure Assessment score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-16T09:00:00+01:00",
      "issued" : "2025-03-16T09:30:00+01:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      }],
      "valueInteger" : 4,
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "note" : [{
        "text" : "Katecholaminfrei seit 14.03.; Extubation am selben Tag um 13:00."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96823-0",
            "display" : "Respiration [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Respiratory"
          }]
        },
        "valueInteger" : 2
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96824-8",
            "display" : "Coagulation [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Coagulation"
          }]
        },
        "valueInteger" : 0
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96825-5",
            "display" : "Liver [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Hepatic"
          }]
        },
        "valueInteger" : 0
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96826-3",
            "display" : "Cardiovascular [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Cardiovascular"
          }]
        },
        "valueInteger" : 0
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96827-1",
            "display" : "Central nervous system [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Neurological"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96828-9",
            "display" : "Renal [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Renal"
          }]
        },
        "valueInteger" : 1
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-sofa-t8"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-gcs-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-gcs-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-gcs"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-gcs-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-gcs-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-gcs-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-gcs-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-gcs\">MII PR ICU Score GCS</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9269-2}, {http://snomed.info/sct 248241002}, {urn:iso:std:iso:11073:10101 153728}\">Glasgow coma score total</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-09 08:00:00+0100</p><p><b>issued</b>: 2025-03-09 08:15:00+0100</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>value</b>: 10 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9267-6}\">Glasgow coma score eye opening</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6555-2}\">Eye opening to verbal command</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9270-0}\">Glasgow coma score verbal</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6558-6}\">Incomprehensible sounds</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9268-4}\">Glasgow coma score motor</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6566-9}\">Localizing pain</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9269-2",
          "display" : "Glasgow coma score total"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "248241002"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "153728"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-09T08:00:00+01:00",
      "issued" : "2025-03-09T08:15:00+01:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      }],
      "valueQuantity" : {
        "value" : 10,
        "unit" : "{score}",
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9267-6",
            "display" : "Glasgow coma score eye opening"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6555-2",
            "display" : "Eye opening to verbal command"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9270-0",
            "display" : "Glasgow coma score verbal"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6558-6",
            "display" : "Incomprehensible sounds"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9268-4",
            "display" : "Glasgow coma score motor"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6566-9",
            "display" : "Localizing pain"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-gcs-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-rass-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-rass-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-rass"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-rass-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-rass-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-rass-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-rass-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-rass\">MII PR ICU Score RASS</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1345050000}\">Richmond Agitation Sedation Scale score (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-15 08:00:00+0100</p><p><b>issued</b>: 2025-03-15 08:10:00+0100</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA33964-0}\">Light sedation -2</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><p><b>note</b>: </p><blockquote><div><p>Sedierungsreduktion im Rahmen der Beatmungsentwoehnung.</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1345050000",
          "display" : "Richmond Agitation Sedation Scale score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-15T08:00:00+01:00",
      "issued" : "2025-03-15T08:10:00+01:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA33964-0",
          "display" : "Light sedation -2"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "note" : [{
        "text" : "Sedierungsreduktion im Rahmen der Beatmungsentwoehnung."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-rass-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-bilanz-urin-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-bilanz-urin-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-urin"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-bilanz-urin-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-bilanz-urin-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-bilanz-urin-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-bilanz-urin-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-urin\">MII PR ICU Bilanz Ausfuhr Urin</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-urin-12-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9187-6}, {http://snomed.info/sct 364201005}\">Urine output</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-09 06:00:00+0100</p><p><b>issued</b>: 2025-03-09 06:10:00+0100</p><p><b>value</b>: 620 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation L}\">Low</span></p><p><b>note</b>: </p><blockquote><div><p>Oligurie (&lt; 0.5 mL/kg/h) bei septischer Kreislaufsituation.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 89837001}\">Urinary bladder structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-urin-12-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9187-6",
          "display" : "Urine output"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364201005",
          "display" : "Urine output observable (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-09T06:00:00+01:00",
      "issued" : "2025-03-09T06:10:00+01:00",
      "valueQuantity" : {
        "value" : 620,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "L",
          "display" : "Low"
        }]
      }],
      "note" : [{
        "text" : "Oligurie (< 0.5 mL/kg/h) bei septischer Kreislaufsituation."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "89837001",
          "display" : "Urinary bladder structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-bilanz-urin-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-icu-bilanz-tages-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-icu-bilanz-tages-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-tagesbilanz-fluessigkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-icu-bilanz-tages-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-icu-bilanz-tages-1</b></p><a name=\"mii-exa-test-data-patient-12-icu-bilanz-tages-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-icu-bilanz-tages-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-tagesbilanz-fluessigkeit\">MII PR ICU Bilanz Tagesbilanz Fluessigkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-tages-12-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251856003}, {http://loinc.org 9097-7}\">Fluid balance status (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-09 06:00:00+0100</p><p><b>issued</b>: 2025-03-09 06:10:00+0100</p><p><b>value</b>: 3250 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>note</b>: </p><blockquote><div><p>Deutlich positive Bilanz nach initialer Volumentherapie des septischen Schocks.</p>\n</div></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-tages-12-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251856003",
          "display" : "Fluid balance status (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9097-7",
          "display" : "Fluid balance 24 hour"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-09T06:00:00+01:00",
      "issued" : "2025-03-09T06:10:00+01:00",
      "valueQuantity" : {
        "value" : 3250,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "note" : [{
        "text" : "Deutlich positive Bilanz nach initialer Volumentherapie des septischen Schocks."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-icu-bilanz-tages-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-patient-12-mibi-anforderung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ServiceRequestLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-patient-12-mibi-anforderung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-patient-12-mibi-anforderung-1</b></p><a name=\"mii-exa-test-data-patient-12-mibi-anforderung-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-anforderung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ServiceRequestLab\">MII PR Labor Laboranforderung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Placer Identifier/MIKROBIO-SR-012</p><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>priority</b>: Urgent</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 252418007}\">Blutkultur und Trachealsekret, Erregerdiagnostik mit Antibiogramm</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>authoredOn</b>: 2025-03-08 18:25:00+0100</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-patient-12-diagnose-2.html\">Condition Sepsis: Sonstige gramnegative Erreger</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PLAC"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/service-request",
        "value" : "MIKROBIO-SR-012",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "status" : "completed",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "priority" : "urgent",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "252418007",
          "display" : "Microbiology procedure (procedure)"
        }],
        "text" : "Blutkultur und Trachealsekret, Erregerdiagnostik mit Antibiogramm"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "authoredOn" : "2025-03-08T18:25:00+01:00",
      "requester" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-patient-12-diagnose-2"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-12-mibi-specimen-bk",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-probe"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-12-mibi-specimen-bk\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-12-mibi-specimen-bk</b></p><a name=\"mii-exa-test-data-patient-12-mibi-specimen-bk\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-specimen-bk\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-probe\">MII PR Mikrobio Probe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Ebene</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene#mii-cs-biobank-probenebene-PRIM.196RPROBE\">MII CS Biobank Probenebene: PRIMÄRPROBE</a> (Primärprobe)</p><p><b>MII EX Biobank Infektiositätsstatus</b>: <span title=\"Codes:{http://snomed.info/sct 409603009}\">Biosafety level 2 (qualifier value)</span></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Probennummer</code>/BK-012-001</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119297000}\">Blood specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>receivedTime</b>: 2025-03-08 19:05:00+0100</p><p><b>request</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2025-03-08 18:30:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 28273000}\">Bilateral antecubital fossae (body structure)</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-ebene",
        "valueCoding" : {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene",
          "code" : "PRIMÄRPROBE",
          "display" : "Primärprobe"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-infektiositaetsstatus",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "409603009",
            "display" : "Biosafety level 2 (qualifier value)"
          }]
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Probennummer",
        "value" : "BK-012-001"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119297000",
          "display" : "Blood specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "receivedTime" : "2025-03-08T19:05:00+01:00",
      "request" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "collection" : {
        "collectedDateTime" : "2025-03-08T18:30:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "28273000",
            "display" : "Bilateral antecubital fossae (body structure)"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        }
      }],
      "note" : [{
        "text" : "Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-patient-12-mibi-specimen-ts",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-patient-12-mibi-specimen-ts",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-probe"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-patient-12-mibi-specimen-ts\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-patient-12-mibi-specimen-ts</b></p><a name=\"mii-exa-test-data-patient-12-mibi-specimen-ts\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-specimen-ts\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-probe\">MII PR Mikrobio Probe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Biobank Ebene</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene#mii-cs-biobank-probenebene-PRIM.196RPROBE\">MII CS Biobank Probenebene: PRIMÄRPROBE</a> (Primärprobe)</p><p><b>MII EX Biobank Infektiositätsstatus</b>: <span title=\"Codes:{http://snomed.info/sct 409603009}\">Biosafety level 2 (qualifier value)</span></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/Probennummer</code>/TS-012-001</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 57741000052105}\">Tracheal secretion specimen (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>receivedTime</b>: 2025-03-08 19:05:00+0100</p><p><b>request</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>Quantity</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2025-03-08 18:35:00+0100</td><td>3 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td><span title=\"Codes:{http://snomed.info/sct 44567001}\">Tracheal structure</span></td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 83059008}\">Tube, device (physical object)</span></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Direkt nach Intubation ueber den Tubus gewonnen.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-ebene",
        "valueCoding" : {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/CodeSystem/mii-cs-biobank-probenebene",
          "code" : "PRIMÄRPROBE",
          "display" : "Primärprobe"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/mii-ex-biobank-infektiositaetsstatus",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "409603009",
            "display" : "Biosafety level 2 (qualifier value)"
          }]
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/Probennummer",
        "value" : "TS-012-001"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "57741000052105",
          "display" : "Tracheal secretion specimen (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "receivedTime" : "2025-03-08T19:05:00+01:00",
      "request" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "collection" : {
        "collectedDateTime" : "2025-03-08T18:35:00+01:00",
        "quantity" : {
          "value" : 3,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "44567001",
            "display" : "Tracheal structure"
          }]
        }
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "83059008",
            "display" : "Tube, device (physical object)"
          }]
        }
      }],
      "note" : [{
        "text" : "Direkt nach Intubation ueber den Tubus gewonnen."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-ts"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-kultur-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-kultur-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-allgemeine-kultur"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-kultur-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-kultur-1</b></p><a name=\"mii-exa-test-data-patient-12-mibi-kultur-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-kultur-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-allgemeine-kultur\">MII PR Mikrobio Allgemeine Kultur</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/pat12-kultur-1</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 11475-1}\">Microorganism identified in Specimen by Culture</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-08 18:30:00+0100</p><p><b>issued</b>: 2025-03-10 08:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 10828004}\">Positive (qualifier value)</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>note</b>: </p><blockquote><div><p>Wachstumssignal nach 14 h in beiden aeroben Flaschen.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 703750006}\">Aerobic culture technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-bactec-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#BACTEC-001</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-kultur-1",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11475-1",
          "display" : "Microorganism identified in Specimen by Culture"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-08T18:30:00+01:00",
      "_effectiveDateTime" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/QuelleKlinischesBezugsdatum",
          "valueCoding" : {
            "system" : "http://snomed.info/sct",
            "code" : "399445004",
            "display" : "Specimen collection date (observable entity)"
          }
        }]
      },
      "issued" : "2025-03-10T08:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "10828004",
          "display" : "Positive (qualifier value)"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "note" : [{
        "text" : "Wachstumssignal nach 14 h in beiden aeroben Flaschen."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "703750006",
          "display" : "Aerobic culture technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-bactec-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-kultur-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-mikroskopie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-mikroskopie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-mikroskopie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-mikroskopie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-mikroskopie-1</b></p><a name=\"mii-exa-test-data-patient-12-mibi-mikroskopie-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-mikroskopie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-mikroskopie\">MII PR Mikrobio Allgemeine Mikroskopie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/pat12-mikroskopie-1</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 664-3}\">Microscopic observation [Identifier] in Specimen by Gram stain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-10 08:15:00+0100</p><p><b>issued</b>: 2025-03-10 08:40:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 87172008}\">Gram-negative bacillus (organism)</span></p><p><b>note</b>: </p><blockquote><div><p>Befund sofort telefonisch an die Intensivstation uebermittelt.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 62777006}\">Gram stain method (procedure)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-mikroskop-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#MIKROSKOP-001</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-mikroskopie-1",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "664-3",
          "display" : "Microscopic observation [Identifier] in Specimen by Gram stain"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-10T08:15:00+01:00",
      "issued" : "2025-03-10T08:40:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "87172008",
          "display" : "Gram-negative bacillus (organism)"
        }]
      },
      "note" : [{
        "text" : "Befund sofort telefonisch an die Intensivstation uebermittelt."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "62777006",
          "display" : "Gram stain method (procedure)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-mikroskop-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-mikroskopie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-erreger-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-erreger-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-spezifische-bestimmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-erreger-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-erreger-1</b></p><a name=\"mii-exa-test-data-patient-12-mibi-erreger-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-erreger-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-spezifische-bestimmung\">MII PR Mikrobio Spezifische Bestimmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>R5: Triggering observation(s) (new)</b></p><ul><li>observation: <a href=\"Observation-mii-exa-test-data-patient-12-mibi-kultur-1.html\">Observation Microorganism identified in Specimen by Culture</a></li><li>type: reflex</li></ul></blockquote><p><b>identifier</b>: Observation Instance Identifier/pat12-erreger-1</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 11475-1}\">Microorganism identified in Specimen by Culture</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-10 16:00:00+0100</p><p><b>issued</b>: 2025-03-10 16:30:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 56415008}\">Klebsiella pneumoniae (organism)</span></p><p><b>note</b>: </p><blockquote><div><p>Identifikation per MALDI-TOF am Kulturisolat.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 703752003}\">Organism specific culture technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-maldi-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#MALDI-TOF-001; type = Bacterial identification device (physical object)</a></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "observation",
          "valueReference" : {
            "reference" : "Observation/mii-exa-test-data-patient-12-mibi-kultur-1"
          }
        },
        {
          "url" : "type",
          "valueCode" : "reflex"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Observation.triggeredBy"
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-erreger-1",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11475-1",
          "display" : "Microorganism identified in Specimen by Culture"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-10T16:00:00+01:00",
      "issued" : "2025-03-10T16:30:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "56415008",
          "display" : "Klebsiella pneumoniae (organism)"
        }]
      },
      "note" : [{
        "text" : "Identifikation per MALDI-TOF am Kulturisolat."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "703752003",
          "display" : "Organism specific culture technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-maldi-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-erreger-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-ast-piptazo",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-ast-piptazo",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-ast-piptazo\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-ast-piptazo</b></p><a name=\"mii-exa-test-data-patient-12-mibi-ast-piptazo\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-ast-piptazo\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit\">MII PR Mikrobio Empfindlichkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>R5: Triggering observation(s) (new)</b></p><ul><li>observation: <a href=\"Observation-mii-exa-test-data-patient-12-mibi-erreger-1.html\">Observation Microorganism identified in Specimen by Culture</a></li><li>type: reflex</li></ul></blockquote><p><b>identifier</b>: Observation Instance Identifier/pat12-ast-piptazo</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 18970-4}\">Piperacillin+Tazobactam [Susceptibility]</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 09:00:00+0100</p><p><b>issued</b>: 2025-03-11 09:30:00+0100</p><p><b>value</b>: &gt;64 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></p><p><b>note</b>: </p><blockquote><div><p>Die laufende empirische Therapie ist damit unwirksam.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 708073008}\">Minimum inhibitory concentration susceptibility test technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-vitek-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#VITEK-001</a></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "observation",
          "valueReference" : {
            "reference" : "Observation/mii-exa-test-data-patient-12-mibi-erreger-1"
          }
        },
        {
          "url" : "type",
          "valueCode" : "reflex"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Observation.triggeredBy"
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-ast-piptazo",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18970-4",
          "display" : "Piperacillin+Tazobactam [Susceptibility]"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-11T09:00:00+01:00",
      "issued" : "2025-03-11T09:30:00+01:00",
      "valueQuantity" : {
        "value" : 64,
        "comparator" : ">",
        "unit" : "mg/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/L"
      },
      "interpretation" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-ex-mikrobio-empfindlichkeit-norm",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/CodeSystem/mii-cs-mikrobio-susceptibility-norm",
              "code" : "EUCAST",
              "display" : "EUCAST"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "R",
          "display" : "Resistant"
        }]
      }],
      "note" : [{
        "text" : "Die laufende empirische Therapie ist damit unwirksam."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "708073008",
          "display" : "Minimum inhibitory concentration susceptibility test technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-ast-piptazo"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-ast-ceftazidim",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-ast-ceftazidim",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-ast-ceftazidim\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-ast-ceftazidim</b></p><a name=\"mii-exa-test-data-patient-12-mibi-ast-ceftazidim\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-ast-ceftazidim\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit\">MII PR Mikrobio Empfindlichkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>R5: Triggering observation(s) (new)</b></p><ul><li>observation: <a href=\"Observation-mii-exa-test-data-patient-12-mibi-erreger-1.html\">Observation Microorganism identified in Specimen by Culture</a></li><li>type: reflex</li></ul></blockquote><p><b>identifier</b>: Observation Instance Identifier/pat12-ast-ceftazidim</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 18893-8}\">cefTAZidime [Susceptibility]</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 09:00:00+0100</p><p><b>issued</b>: 2025-03-11 09:30:00+0100</p><p><b>value</b>: 32 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 708073008}\">Minimum inhibitory concentration susceptibility test technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-vitek-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#VITEK-001</a></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "observation",
          "valueReference" : {
            "reference" : "Observation/mii-exa-test-data-patient-12-mibi-erreger-1"
          }
        },
        {
          "url" : "type",
          "valueCode" : "reflex"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Observation.triggeredBy"
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-ast-ceftazidim",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18893-8",
          "display" : "cefTAZidime [Susceptibility]"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-11T09:00:00+01:00",
      "issued" : "2025-03-11T09:30:00+01:00",
      "valueQuantity" : {
        "value" : 32,
        "unit" : "mg/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/L"
      },
      "interpretation" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-ex-mikrobio-empfindlichkeit-norm",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/CodeSystem/mii-cs-mikrobio-susceptibility-norm",
              "code" : "EUCAST",
              "display" : "EUCAST"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "R",
          "display" : "Resistant"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "708073008",
          "display" : "Minimum inhibitory concentration susceptibility test technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-ast-ceftazidim"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-ast-cipro",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-ast-cipro",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-ast-cipro\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-ast-cipro</b></p><a name=\"mii-exa-test-data-patient-12-mibi-ast-cipro\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-ast-cipro\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit\">MII PR Mikrobio Empfindlichkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>R5: Triggering observation(s) (new)</b></p><ul><li>observation: <a href=\"Observation-mii-exa-test-data-patient-12-mibi-erreger-1.html\">Observation Microorganism identified in Specimen by Culture</a></li><li>type: reflex</li></ul></blockquote><p><b>identifier</b>: Observation Instance Identifier/pat12-ast-cipro</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 18906-8}\">Ciprofloxacin [Susceptibility]</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 09:00:00+0100</p><p><b>issued</b>: 2025-03-11 09:30:00+0100</p><p><b>value</b>: 4 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 708073008}\">Minimum inhibitory concentration susceptibility test technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-vitek-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#VITEK-001</a></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "observation",
          "valueReference" : {
            "reference" : "Observation/mii-exa-test-data-patient-12-mibi-erreger-1"
          }
        },
        {
          "url" : "type",
          "valueCode" : "reflex"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Observation.triggeredBy"
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-ast-cipro",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18906-8",
          "display" : "Ciprofloxacin [Susceptibility]"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-11T09:00:00+01:00",
      "issued" : "2025-03-11T09:30:00+01:00",
      "valueQuantity" : {
        "value" : 4,
        "unit" : "mg/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/L"
      },
      "interpretation" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-ex-mikrobio-empfindlichkeit-norm",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/CodeSystem/mii-cs-mikrobio-susceptibility-norm",
              "code" : "EUCAST",
              "display" : "EUCAST"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "R",
          "display" : "Resistant"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "708073008",
          "display" : "Minimum inhibitory concentration susceptibility test technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-ast-cipro"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-ast-meropenem",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-ast-meropenem",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-ast-meropenem\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-ast-meropenem</b></p><a name=\"mii-exa-test-data-patient-12-mibi-ast-meropenem\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-ast-meropenem\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-empfindlichkeit\">MII PR Mikrobio Empfindlichkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>R5: Triggering observation(s) (new)</b></p><ul><li>observation: <a href=\"Observation-mii-exa-test-data-patient-12-mibi-erreger-1.html\">Observation Microorganism identified in Specimen by Culture</a></li><li>type: reflex</li></ul></blockquote><p><b>identifier</b>: Observation Instance Identifier/pat12-ast-meropenem</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 18943-1}\">Meropenem [Susceptibility]</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 09:00:00+0100</p><p><b>issued</b>: 2025-03-11 09:30:00+0100</p><p><b>value</b>: &lt;=0.25 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation S}\">Susceptible</span></p><p><b>note</b>: </p><blockquote><div><p>Carbapenem bleibt wirksam — Grundlage der Therapieumstellung am 11.03.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 708073008}\">Minimum inhibitory concentration susceptibility test technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-vitek-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#VITEK-001</a></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>2 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "observation",
          "valueReference" : {
            "reference" : "Observation/mii-exa-test-data-patient-12-mibi-erreger-1"
          }
        },
        {
          "url" : "type",
          "valueCode" : "reflex"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Observation.triggeredBy"
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-ast-meropenem",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18943-1",
          "display" : "Meropenem [Susceptibility]"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-11T09:00:00+01:00",
      "issued" : "2025-03-11T09:30:00+01:00",
      "valueQuantity" : {
        "value" : 0.25,
        "comparator" : "<=",
        "unit" : "mg/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/L"
      },
      "interpretation" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-ex-mikrobio-empfindlichkeit-norm",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/CodeSystem/mii-cs-mikrobio-susceptibility-norm",
              "code" : "EUCAST",
              "display" : "EUCAST"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "S",
          "display" : "Susceptible"
        }]
      }],
      "note" : [{
        "text" : "Carbapenem bleibt wirksam — Grundlage der Therapieumstellung am 11.03."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "708073008",
          "display" : "Minimum inhibitory concentration susceptibility test technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
      },
      "referenceRange" : [{
        "high" : {
          "value" : 2,
          "unit" : "mg/L",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/L"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-ast-meropenem"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-mrgn-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-mrgn-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-mrgn-klasse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-mrgn-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-mrgn-1</b></p><a name=\"mii-exa-test-data-patient-12-mibi-mrgn-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-mrgn-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-mrgn-klasse\">MII PR Mikrobio MRGN Klasse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/pat12-mrgn-1</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 99780-9}\">Multidrug resistant gram-negative organism classification [Type]</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 09:15:00+0100</p><p><b>issued</b>: 2025-03-11 09:30:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA33215-7}\">3MRGN</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></p><p><b>note</b>: </p><blockquote><div><p>3MRGN nach KRINKO 2012: Resistenz gegen Acylureidopenicilline, Cephalosporine der 3./4. Generation und Fluorchinolone; Carbapeneme wirksam. Isolierungsmassnahmen eingeleitet.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 14788002}\">Antimicrobial susceptibility test (procedure)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-vitek-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#VITEK-001</a></p><p><b>derivedFrom</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-piptazo.html\">Observation Piperacillin+Tazobactam [Susceptibility]</a></li><li><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-ceftazidim.html\">Observation cefTAZidime [Susceptibility]</a></li><li><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-cipro.html\">Observation Ciprofloxacin [Susceptibility]</a></li></ul></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-mrgn-1",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "99780-9",
          "display" : "Multidrug resistant gram-negative organism classification [Type]"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-11T09:15:00+01:00",
      "issued" : "2025-03-11T09:30:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA33215-7",
          "display" : "3MRGN"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "R",
          "display" : "Resistant"
        }]
      }],
      "note" : [{
        "text" : "3MRGN nach KRINKO 2012: Resistenz gegen Acylureidopenicilline, Cephalosporine der 3./4. Generation und Fluorchinolone; Carbapeneme wirksam. Isolierungsmassnahmen eingeleitet."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "14788002",
          "display" : "Antimicrobial susceptibility test (procedure)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-piptazo"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-ceftazidim"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-cipro"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-mrgn-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-12-mibi-esbl-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-12-mibi-esbl-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-resistenzmechanismen-determinanten"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-12-mibi-esbl-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-12-mibi-esbl-1</b></p><a name=\"mii-exa-test-data-patient-12-mibi-esbl-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-esbl-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-resistenzmechanismen-determinanten\">MII PR Mikrobio Resistenzmechanismen Determinanten</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/pat12-esbl-1</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-12-mibi-anforderung-1.html\">ServiceRequest Microbiology procedure (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 105277-8}\">Beta lactamase [Presence] in Isolate</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-12.html\">Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-12-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Intensivstationär; serviceType = Intensivmedizin; period = 2025-03-08 18:00:00+0100 --&gt; 2025-03-18 10:00:00+0100</a></p><p><b>effective</b>: 2025-03-11 09:10:00+0100</p><p><b>issued</b>: 2025-03-11 09:30:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 260373001}\">Detected (qualifier value)</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>note</b>: </p><blockquote><div><p>ESBL-Phaenotyp im EUCAST-Bestaetigungstest (Synergie mit Clavulansaeure). Fuer den ESBL-Phaenotyp existiert in LOINC 2.83 kein eigener Observable-Code, daher der generische Beta-Laktamase-Code.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 1303975003}\">Disk diffusion technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-patient-12-mibi-specimen-bk.html\">Specimen: extension = Primärprobe (MII CS Biobank Probenebene#PRIMÄRPROBE),Biosafety level 2 (qualifier value); identifier = https://www.charite.de/fhir/sid/Probennummer#BK-012-001; status = available; type = Blood specimen (specimen); receivedTime = 2025-03-08 19:05:00+0100; note = Zwei Paerchen vor Beginn der empirischen Antibiose abgenommen.</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mikrobio-device-vitek-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#VITEK-001</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/test-lab-results",
        "value" : "pat12-esbl-1",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "105277-8",
          "display" : "Beta lactamase [Presence] in Isolate"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-11T09:10:00+01:00",
      "issued" : "2025-03-11T09:30:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "260373001",
          "display" : "Detected (qualifier value)"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "note" : [{
        "text" : "ESBL-Phaenotyp im EUCAST-Bestaetigungstest (Synergie mit Clavulansaeure). Fuer den ESBL-Phaenotyp existiert in LOINC 2.83 kein eigener Observable-Code, daher der generische Beta-Laktamase-Code."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1303975003",
          "display" : "Disk diffusion technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-12-mibi-esbl-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DiagnosticReport/mii-exa-test-data-patient-12-mibi-report-1",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-test-data-patient-12-mibi-report-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-diagnostic-report"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_mii-exa-test-data-patient-12-mibi-report-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-test-data-patient-12-mibi-report-1</b></p><a name=\"mii-exa-test-data-patient-12-mibi-report-1\"> </a><a name=\"hcmii-exa-test-data-patient-12-mibi-report-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-mikrobio/StructureDefinition/mii-pr-mikrobio-diagnostic-report\">MII PR Mikrobio Diagnostic Report</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2><span title=\"Codes:{http://loinc.org 11502-2}, {http://loinc.org 11475-1}\">Microorganism identified in Specimen by Culture</span> (<span title=\"Codes:{http://loinc.org 18725-2}\">Microbiology studies (set)</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 LAB}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Gerhard Woltmann (official) Male, DoB: 1953-04-22 ( Medical record number)</td></tr><tr><td>Relevant Time</td><td>2025-03-08 18:30:00+0100</td></tr><tr><td>Reported</td><td>2025-03-11 09:45:00+0100</td></tr><tr><td>Performer</td><td> <a href=\"Organization-mii-exa-test-data-mikrobio-organization-lab-1.html\">Organization Mikrobiologisches Labor Charité</a></td></tr><tr><td>Identifier</td><td> Filler Identifier/MIKROBIO-DR-012</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Reference Range</b></td><td><b>Flags</b></td><td><b>Note</b></td><td><b>Relevant Time</b></td><td><b>Reported</b></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-kultur-1.html\"><span title=\"Codes:{http://loinc.org 11475-1}\">Microorganism identified in Specimen by Culture</span></a></td><td><span title=\"Codes:{http://snomed.info/sct 10828004}\">Positive (qualifier value)</span></td><td/><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></td><td><blockquote><div><p>Wachstumssignal nach 14 h in beiden aeroben Flaschen.</p>\n</div></blockquote></td><td/><td>2025-03-10 08:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-mikroskopie-1.html\"><span title=\"Codes:{http://loinc.org 664-3}\">Microscopic observation [Identifier] in Specimen by Gram stain</span></a></td><td><span title=\"Codes:{http://snomed.info/sct 87172008}\">Gram-negative bacillus (organism)</span></td><td/><td>Final</td><td><blockquote><div><p>Befund sofort telefonisch an die Intensivstation uebermittelt.</p>\n</div></blockquote></td><td>2025-03-10 08:15:00+0100</td><td>2025-03-10 08:40:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-erreger-1.html\"><span title=\"Codes:{http://loinc.org 11475-1}\">Microorganism identified in Specimen by Culture</span></a></td><td><span title=\"Codes:{http://snomed.info/sct 56415008}\">Klebsiella pneumoniae (organism)</span></td><td/><td>Final</td><td><blockquote><div><p>Identifikation per MALDI-TOF am Kulturisolat.</p>\n</div></blockquote></td><td>2025-03-10 16:00:00+0100</td><td>2025-03-10 16:30:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-piptazo.html\"><span title=\"Codes:{http://loinc.org 18970-4}\">Piperacillin+Tazobactam [Susceptibility]</span></a></td><td>&gt;64 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td/><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></td><td><blockquote><div><p>Die laufende empirische Therapie ist damit unwirksam.</p>\n</div></blockquote></td><td>2025-03-11 09:00:00+0100</td><td>2025-03-11 09:30:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-ceftazidim.html\"><span title=\"Codes:{http://loinc.org 18893-8}\">cefTAZidime [Susceptibility]</span></a></td><td>32 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td/><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></td><td/><td>2025-03-11 09:00:00+0100</td><td>2025-03-11 09:30:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-cipro.html\"><span title=\"Codes:{http://loinc.org 18906-8}\">Ciprofloxacin [Susceptibility]</span></a></td><td>4 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td/><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></td><td/><td>2025-03-11 09:00:00+0100</td><td>2025-03-11 09:30:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-ast-meropenem.html\"><span title=\"Codes:{http://loinc.org 18943-1}\">Meropenem [Susceptibility]</span></a></td><td>&lt;=0.25 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td>&lt;2 mg/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/L = 'mg/L')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation S}\">Susceptible</span></td><td><blockquote><div><p>Carbapenem bleibt wirksam — Grundlage der Therapieumstellung am 11.03.</p>\n</div></blockquote></td><td>2025-03-11 09:00:00+0100</td><td>2025-03-11 09:30:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-mrgn-1.html\"><span title=\"Codes:{http://loinc.org 99780-9}\">Multidrug resistant gram-negative organism classification [Type]</span></a></td><td><span title=\"Codes:{http://loinc.org LA33215-7}\">3MRGN</span></td><td/><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation R}\">Resistant</span></td><td><blockquote><div><p>3MRGN nach KRINKO 2012: Resistenz gegen Acylureidopenicilline, Cephalosporine der 3./4. Generation und Fluorchinolone; Carbapeneme wirksam. Isolierungsmassnahmen eingeleitet.</p>\n</div></blockquote></td><td>2025-03-11 09:15:00+0100</td><td>2025-03-11 09:30:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-12-mibi-esbl-1.html\"><span title=\"Codes:{http://loinc.org 105277-8}\">Beta lactamase [Presence] in Isolate</span></a></td><td><span title=\"Codes:{http://snomed.info/sct 260373001}\">Detected (qualifier value)</span></td><td/><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></td><td><blockquote><div><p>ESBL-Phaenotyp im EUCAST-Bestaetigungstest (Synergie mit Clavulansaeure). Fuer den ESBL-Phaenotyp existiert in LOINC 2.83 kein eigener Observable-Code, daher der generische Beta-Laktamase-Code.</p>\n</div></blockquote></td><td>2025-03-11 09:10:00+0100</td><td>2025-03-11 09:30:00+0100</td></tr></table><p>Klebsiella pneumoniae, 3MRGN, ESBL-Phaenotyp. Piperacillin/Tazobactam resistent — laufende empirische Therapie unwirksam. Meropenem empfindlich, Umstellung dringend empfohlen. Isolierung nach KRINKO.</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "FILL"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/diagnostic-report",
        "value" : "MIKROBIO-DR-012",
        "assigner" : {
          "reference" : "Organization/mii-exa-test-data-mikrobio-organization-lab-1",
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "DIZ-CHA"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-12-mibi-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18725-2",
          "display" : "Microbiology studies (set)"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "LAB"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2"
        },
        {
          "system" : "http://loinc.org",
          "code" : "11475-1",
          "display" : "Microorganism identified in Specimen by Culture"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-12"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-12-encounter-2"
      },
      "effectiveDateTime" : "2025-03-08T18:30:00+01:00",
      "_effectiveDateTime" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/QuelleKlinischesBezugsdatum",
          "valueCoding" : {
            "system" : "http://snomed.info/sct",
            "code" : "399445004",
            "display" : "Specimen collection date (observable entity)"
          }
        }]
      },
      "issued" : "2025-03-11T09:45:00+01:00",
      "performer" : [{
        "reference" : "Organization/mii-exa-test-data-mikrobio-organization-lab-1"
      }],
      "resultsInterpreter" : [{
        "reference" : "Organization/mii-exa-test-data-mikrobio-organization-lab-1"
      }],
      "specimen" : [{
        "reference" : "Specimen/mii-exa-test-data-patient-12-mibi-specimen-bk"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-kultur-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-mikroskopie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-erreger-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-piptazo"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-ceftazidim"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-cipro"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-ast-meropenem"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-mrgn-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-12-mibi-esbl-1"
      }],
      "conclusion" : "Klebsiella pneumoniae, 3MRGN, ESBL-Phaenotyp. Piperacillin/Tazobactam resistent — laufende empirische Therapie unwirksam. Meropenem empfindlich, Umstellung dringend empfohlen. Isolierung nach KRINKO."
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-test-data-patient-12-mibi-report-1"
    }
  }]
}

```
