# ERN ReCONNET Registry - Katalogeintrag - MII KDS Test Data v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ERN ReCONNET Registry - Katalogeintrag**

## Library: ERN ReCONNET Registry - Katalogeintrag 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/testdata/Library/mii-exa-test-data-seltene-register-katalog-1 | *Version*:2027.0.0-ballot |
| Active as of 2026-09-25 | *Computable Name*:ERNReCONNETRegistry |
| *Other Identifiers:*https://reconnet.ern-net.eu/fhir/sid/registry#RECONNET-REG | |

**Exception parsing generated Narrative (see /tmp/liquid-afbcce14-6082-4567-b568-0011040a17b8.html): unexpected non-end of element null::a at line 135 column 50**



## Resource Content

```json
{
  "resourceType" : "Library",
  "id" : "mii-exa-test-data-seltene-register-katalog-1",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "url" : "https://www.medizininformatik-initiative.de/fhir/testdata/Library/mii-exa-test-data-seltene-register-katalog-1",
  "identifier" : [{
    "system" : "https://reconnet.ern-net.eu/fhir/sid/registry",
    "value" : "RECONNET-REG"
  }],
  "version" : "2027.0.0-ballot",
  "name" : "ERNReCONNETRegistry",
  "title" : "ERN ReCONNET Registry - Katalogeintrag",
  "status" : "active",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/library-type",
      "code" : "asset-collection"
    }]
  },
  "date" : "2026-09-25T07:02:09+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Deutschland"
    }]
  }],
  "relatedArtifact" : [{
    "type" : "documentation",
    "url" : "https://reconnet.ern-net.eu/",
    "document" : {
      "url" : "https://reconnet.ern-net.eu/"
    }
  }]
}

```
