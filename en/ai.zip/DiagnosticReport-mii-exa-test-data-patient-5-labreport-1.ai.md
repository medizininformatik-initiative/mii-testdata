# mii-exa-test-data-patient-5-labreport-1 - MII KDS Test Data v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-test-data-patient-5-labreport-1**

## Example DiagnosticReport: mii-exa-test-data-patient-5-labreport-1

Information Source: [https://www.charite.de/fhir/kds-testdata](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&canonical=https://www.charite.de/fhir/kds-testdata)

Profile: [MII PR Labor Laborbefund](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/DiagnosticReportLab)

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html)

## Laboratory report (Laboratory studies (set)) 

| | |
| :--- | :--- |
| Subject | Sabine Maria Weber (official) Female, DoB: 1985-03-12 ( Medical record number (use: usual, )) |
| Relevant Time | 2023-07-12 06:45:00+0200 |
| Reported | 2023-07-12 10:15:00+0200 |
| Performer | [Organization Labor Berlin – Charité Vivantes GmbH](Organization-mii-exa-test-data-organization-labor-berlin.md) |
| Identifier | Filler Identifier/LDR_000005 |

**Report Details**

* **Code**: [Leukocytes [#/volume] in Blood](Observation-mii-exa-test-data-patient-5-labobs-1.md)
  * **Value**: 7.8 /nanoliter (Details: UCUM code/nL = '/nL')
  * **Flags**: Final,Normal
  * **Reported**: 2023-07-12 08:30:00+0200
* **Code**: [Hemoglobin [Mass/volume] in Blood](Observation-mii-exa-test-data-patient-5-labobs-2.md)
  * **Value**: 11.8 gram per deciliter (Details: UCUM codeg/dL = 'g/dL')
  * **Flags**: Final,Low
  * **Reported**: 2023-07-12 08:30:00+0200
* **Code**: [Fasting glucose [Mass/volume] in Serum or Plasma](Observation-mii-exa-test-data-patient-5-labobs-3.md)
  * **Value**: 92 milligram per deciliter (Details: UCUM codemg/dL = 'mg/dL')
  * **Flags**: Final,Normal
  * **Reported**: 2023-07-12 08:30:00+0200

Leichte Anämie (Hb 11,8 g/dL) bei normoglykämischen Nüchternwerten (92 mg/dL). Eisenmangel-Anämie bei Endometriose-Patientin wahrscheinlich.



## Resource Content

```json
{
  "resourceType" : "DiagnosticReport",
  "id" : "mii-exa-test-data-patient-5-labreport-1",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/DiagnosticReportLab"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "FILL"
      }]
    },
    "system" : "https://www.charite.de/fhir/sid/lab-results",
    "value" : "LDR_000005",
    "assigner" : {
      "identifier" : {
        "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
        "value" : "Charité"
      }
    }
  }],
  "basedOn" : [{
    "reference" : "ServiceRequest/mii-exa-test-data-patient-5-labrequest-1"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
      "code" : "LAB"
    },
    {
      "system" : "http://loinc.org",
      "code" : "26436-6",
      "display" : "Laboratory studies (set)"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11502-2",
      "display" : "Laboratory report"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-test-data-patient-5"
  },
  "encounter" : {
    "reference" : "Encounter/mii-exa-test-data-patient-5-encounter-1"
  },
  "effectiveDateTime" : "2023-07-12T06:45:00+02:00",
  "issued" : "2023-07-12T10:15:00+02:00",
  "performer" : [{
    "reference" : "Organization/mii-exa-test-data-organization-labor-berlin"
  }],
  "result" : [{
    "reference" : "Observation/mii-exa-test-data-patient-5-labobs-1"
  },
  {
    "reference" : "Observation/mii-exa-test-data-patient-5-labobs-2"
  },
  {
    "reference" : "Observation/mii-exa-test-data-patient-5-labobs-3"
  }],
  "conclusion" : "Leichte Anämie (Hb 11,8 g/dL) bei normoglykämischen Nüchternwerten (92 mg/dL). Eisenmangel-Anämie bei Endometriose-Patientin wahrscheinlich."
}

```
