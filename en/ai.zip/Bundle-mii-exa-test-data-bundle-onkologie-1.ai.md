# MII Onkologie Test Data Bundle - MII KDS Test Data v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII Onkologie Test Data Bundle**

## Example Bundle: MII Onkologie Test Data Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-test-data-bundle-onkologie-1",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2025-01-03T10:00:00+01:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-onko-patient-1",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-onko-patient-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-onko-patient-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-onko-patient-1</b></p><a name=\"mii-exa-test-data-onko-patient-1\"> </a><a name=\"hcmii-exa-test-data-onko-patient-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "ONKO-TEST-001"
      }],
      "name" : [{
        "family" : "Musterperson",
        "given" : ["Kim"]
      }],
      "gender" : "female",
      "birthDate" : "1956-03-14"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-onko-patient-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-onko-encounter-1",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-onko-encounter-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-onko-encounter-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-onko-encounter-1</b></p><a name=\"mii-exa-test-data-onko-encounter-1\"> </a><a name=\"hcmii-exa-test-data-onko-encounter-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>period</b>: 2021-06-10 --&gt; 2021-10-15</p></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP",
        "display" : "inpatient encounter"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "period" : {
        "start" : "2021-06-10",
        "end" : "2021-10-15"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-onko-encounter-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-onko-diagnose-1",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-onko-diagnose-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-onko-diagnose-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-onko-diagnose-1</b></p><a name=\"mii-exa-test-data-onko-diagnose-1\"> </a><a name=\"hcmii-exa-test-data-onko-diagnose-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor\">MII PR Onkologie Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2021-06-10</p><p><b>Condition Occurred Following</b>: <a href=\"Condition-mii-exa-test-data-onko-fruehere-tumorerkrankung-1.html\">Condition Bösartige Neubildung: Oberer äußerer Quadrant der Brustdrüse</a></p><p><b>MII EX Onko Histology Morphology Behavior ICDO3</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 8461/3}\">High-grade seröses Karzinom</span></p><p><b>Condition Due To</b>: <span title=\"Codes:{http://snomed.info/sct 726019003}\">Hereditary breast and ovarian cancer syndrome (disorder)</span></p><p><b>Condition Related</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-2.html\">Condition Bösartige Neubildung: Oberer äußerer Quadrant der Brustdrüse</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/onko-diagnose</code>/ONKO-DIAG-2021-001</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung 7}\">histologische Untersuchung eines Primärtumors</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 55342001}\">Neoplastic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C56}\">Bösartige Neubildung des Ovars</span></p><p><b>bodySite</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-seitenlokalisation L}, {http://terminology.hl7.org/CodeSystem/icd-o-3 C56.9}, {http://snomed.info/sct 15497006}\">Links</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>recordedDate</b>: 2021-06-15</p><h3>Evidences</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Detail</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 21522001}\">Abdominal pain (finding)</span></td><td><a href=\"List-mii-exa-test-data-onko-liste-evidenz-1.html\">List for 'Unspecified List Type' for '-&gt;Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)'</a></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2021-06-10"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-occurredFollowing",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-onko-fruehere-tumorerkrankung-1"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-histology-morphology-behavior-icdo3",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
            "code" : "8461/3",
            "display" : "Seröses Oberflächenpapillom"
          }],
          "text" : "High-grade seröses Karzinom"
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-dueTo",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "726019003",
            "display" : "Hereditary breast and ovarian cancer syndrome (disorder)"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-related",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-onko-diagnose-2"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/onko-diagnose",
        "value" : "ONKO-DIAG-2021-001"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
          "code" : "7",
          "display" : "histologische Untersuchung eines Primärtumors"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55342001",
          "display" : "Neoplastic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_DIAGNOSESICHERHEIT",
              "code" : "G",
              "display" : "Gesicherte Diagnose"
            }
          },
          {
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "L",
              "display" : "links"
            }
          },
          {
            "url" : "http://fhir.de/StructureDefinition/icd-10-gm-mehrfachcodierungs-kennzeichen",
            "valueCoding" : {
              "system" : "http://fhir.de/CodeSystem/icd-10-gm-mehrfachcodierungs-kennzeichen",
              "code" : "!"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "C56",
          "display" : "Bösartige Neubildung des Ovars"
        }]
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-seitenlokalisation",
          "code" : "L",
          "display" : "Links"
        },
        {
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "C56.9",
          "display" : "Ovar"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "15497006",
          "display" : "Ovarian structure (body structure)"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "recordedDate" : "2021-06-15",
      "evidence" : [{
        "code" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "21522001",
            "display" : "Abdominal pain (finding)"
          }]
        }],
        "detail" : [{
          "reference" : "List/mii-exa-test-data-onko-liste-evidenz-1"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-onko-diagnose-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-onko-diagnose-2",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-onko-diagnose-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-onko-diagnose-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-onko-diagnose-2</b></p><a name=\"mii-exa-test-data-onko-diagnose-2\"> </a><a name=\"hcmii-exa-test-data-onko-diagnose-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor\">MII PR Onkologie Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2015-03-01</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical resolved}\">Resolved</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung 7}\">histologische Untersuchung eines Primärtumors</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 55342001}\">Neoplastic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C50.4}\">Bösartige Neubildung: Oberer äußerer Quadrant der Brustdrüse</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>onset</b>: 52 Jahre<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></p><p><b>abatement</b>: 2016-06-30</p><p><b>recordedDate</b>: 2015-03-01</p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2015-03-01"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "resolved"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
          "code" : "7",
          "display" : "histologische Untersuchung eines Primärtumors"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55342001",
          "display" : "Neoplastic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2015",
          "code" : "C50.4",
          "display" : "Bösartige Neubildung: Oberer äußerer Quadrant der Brustdrüse"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "onsetAge" : {
        "extension" : [{
          "url" : "http://fhir.de/StructureDefinition/lebensphase",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "41847000",
              "display" : "Adulthood (qualifier value)"
            }]
          }
        }],
        "value" : 52,
        "unit" : "Jahre",
        "system" : "http://unitsofmeasure.org",
        "code" : "a"
      },
      "abatementDateTime" : "2016-06-30",
      "recordedDate" : "2015-03-01"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-onko-diagnose-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-onko-diagnose-3",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-onko-diagnose-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-onko-diagnose-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-onko-diagnose-3</b></p><a name=\"mii-exa-test-data-onko-diagnose-3\"> </a><a name=\"hcmii-exa-test-data-onko-diagnose-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor\">MII PR Onkologie Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2010-05-01</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical resolved}\">Resolved</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung 7}\">histologische Untersuchung eines Primärtumors</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 55342001}\">Neoplastic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C44.3}\">Sonstige bösartige Neubildungen: Haut sonstiger und nicht näher bezeichneter Teile des Gesichtes</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>abatement</b>: 48 Jahre<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></p><p><b>recordedDate</b>: 2010-05-01</p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2010-05-01"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "resolved"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
          "code" : "7",
          "display" : "histologische Untersuchung eines Primärtumors"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55342001",
          "display" : "Neoplastic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2010",
          "code" : "C44.3",
          "display" : "Sonstige bösartige Neubildungen: Haut sonstiger und nicht näher bezeichneter Teile des Gesichtes"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "abatementAge" : {
        "extension" : [{
          "url" : "http://fhir.de/StructureDefinition/lebensphase",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "41847000",
              "display" : "Adulthood (qualifier value)"
            }]
          }
        }],
        "value" : 48,
        "unit" : "Jahre",
        "system" : "http://unitsofmeasure.org",
        "code" : "a"
      },
      "recordedDate" : "2010-05-01"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-onko-diagnose-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-onko-fruehere-tumorerkrankung-1",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-onko-fruehere-tumorerkrankung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fruehere-tumorerkrankung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-onko-fruehere-tumorerkrankung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-onko-fruehere-tumorerkrankung-1</b></p><a name=\"mii-exa-test-data-onko-fruehere-tumorerkrankung-1\"> </a><a name=\"hcmii-exa-test-data-onko-fruehere-tumorerkrankung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fruehere-tumorerkrankung\">MII PR Onkologie Frühere Tumorerkrankung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2015-03-01</p><p><b>MII EX Onko Histology Morphology Behavior ICDO3</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 8500/3}\">Invasiv-duktales Mammakarzinom</span></p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical remission}\">Remission</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category encounter-diagnosis}\">Encounter Diagnosis</span>, <span title=\"Codes:{http://snomed.info/sct 394593009}\">Medical oncology (qualifier value)</span>, <span title=\"Codes:{http://snomed.info/sct 55342001}\">Neoplastic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C50.4}\">Mammakarzinom 2015, in Remission</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 C50.4}\">Oberer äußerer Quadrant der Brust</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>recordedDate</b>: 2015-03-15</p><p><b>note</b>: </p><blockquote><div><p>Zustand nach brusterhaltender OP und adjuvanter Therapie 2015</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2015-03-01"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-histology-morphology-behavior-icdo3",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
            "code" : "8500/3",
            "display" : "Invasives duktales Karzinom o.n.A."
          }],
          "text" : "Invasiv-duktales Mammakarzinom"
        }
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "remission"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "394593009",
          "display" : "Medical oncology (qualifier value)"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55342001",
          "display" : "Neoplastic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2015",
          "code" : "C50.4",
          "display" : "Bösartige Neubildung: Oberer äußerer Quadrant der Brustdrüse"
        }],
        "text" : "Mammakarzinom 2015, in Remission"
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "C50.4",
          "display" : "Oberer äußerer Quadrant der Brust"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "recordedDate" : "2015-03-15",
      "note" : [{
        "text" : "Zustand nach brusterhaltender OP und adjuvanter Therapie 2015"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-onko-fruehere-tumorerkrankung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/List/mii-exa-test-data-onko-liste-evidenz-1",
    "resource" : {
      "resourceType" : "List",
      "id" : "mii-exa-test-data-onko-liste-evidenz-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-liste-evidenz-erstdiagnose"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_mii-exa-test-data-onko-liste-evidenz-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List mii-exa-test-data-onko-liste-evidenz-1</b></p><a name=\"mii-exa-test-data-onko-liste-evidenz-1\"> </a><a name=\"hcmii-exa-test-data-onko-liste-evidenz-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-liste-evidenz-erstdiagnose\">MII PR Onkologie Evidenz Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2>Liste der Evidenz zum Erstdiagnosezeitpunkt</h2><table class=\"clstu\"><tr><td>Mode: Snapshot List </td><td>Status: Current </td></tr><tr><td>Subject: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a>Encounter: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td><td>Flag</td></tr><tr><td><a href=\"DiagnosticReport-mii-exa-test-data-onko-befund-1.html\">Diagnostic Report for 'Pathology report Cancer Narrative' for '-&gt;Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)'</a></td><td>Imaging (procedure)</td></tr></table></div>"
      },
      "status" : "current",
      "mode" : "snapshot",
      "title" : "Liste der Evidenz zum Erstdiagnosezeitpunkt",
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "entry" : [{
        "flag" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "363679005",
            "display" : "Imaging (procedure)"
          }]
        },
        "item" : {
          "reference" : "DiagnosticReport/mii-exa-test-data-onko-befund-1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "List/mii-exa-test-data-onko-liste-evidenz-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-onko-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-onko-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-onko-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-onko-specimen-1</b></p><a name=\"mii-exa-test-data-onko-specimen-1\"> </a><a name=\"hcmii-exa-test-data-onko-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-specimen\">MII PR Onkologie Specimen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: ONKO-SPECIMEN-001</p><p><b>accessionIdentifier</b>: <code>https://www.charite.de/fhir/sid/accession</code>/PATH-2021-12345</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119376003}\">Tissue specimen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2021-09-30</td></tr></table></div>"
      },
      "identifier" : [{
        "value" : "ONKO-SPECIMEN-001"
      }],
      "accessionIdentifier" : {
        "system" : "https://www.charite.de/fhir/sid/accession",
        "value" : "PATH-2021-12345"
      },
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119376003",
          "display" : "Tissue specimen"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "collection" : {
        "collectedDateTime" : "2021-09-30"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-onko-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DiagnosticReport/mii-exa-test-data-onko-befund-1",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-test-data-onko-befund-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-befund"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_mii-exa-test-data-onko-befund-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-test-data-onko-befund-1</b></p><a name=\"mii-exa-test-data-onko-befund-1\"> </a><a name=\"hcmii-exa-test-data-onko-befund-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-befund\">MII PR Onkologie Befund</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2><span title=\"Codes:{http://loinc.org 22034-3}\">Pathology report Cancer Narrative</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</td></tr></table><p><b>Report Details</b></p><p>High-grade seröses Adenokarzinom des Ovars, pT3c pN1 M1b (HEP), L1 V0 Pn0, R0</p></div>"
      },
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "22034-3",
          "display" : "Pathology report Cancer Narrative"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "specimen" : [{
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      }],
      "conclusion" : "High-grade seröses Adenokarzinom des Ovars, pT3c pN1 M1b (HEP), L1 V0 Pn0, R0"
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-test-data-onko-befund-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-grading-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-grading-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-grading"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-grading-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-grading-1</b></p><a name=\"mii-exa-test-data-onko-grading-1\"> </a><a name=\"hcmii-exa-test-data-onko-grading-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-grading\">MII PR Onkologie Grading</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33732-9}, {http://snomed.info/sct 371469007}\">Histology grade [Identifier] in Cancer specimen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-grading 3}\">schlecht differenziert</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "33732-9",
          "display" : "Histology grade [Identifier] in Cancer specimen"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "371469007",
          "display" : "Histologic grade of neoplasm"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-grading",
          "code" : "3",
          "display" : "schlecht differenziert"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-grading-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tumorgroesse-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tumorgroesse-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorgroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tumorgroesse-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tumorgroesse-1</b></p><a name=\"mii-exa-test-data-onko-tumorgroesse-1\"> </a><a name=\"hcmii-exa-test-data-onko-tumorgroesse-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorgroesse\">MII PR Onkologie Tumorgröße</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21889-1}, {http://snomed.info/sct 371479009}\">Size Tumor</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: 22 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 C56.9}\">Ovar</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 787377000}\">Gross examination and sampling of tissue specimen</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "21889-1",
          "display" : "Size Tumor"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "371479009",
          "display" : "Tumor size, largest dimension (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueQuantity" : {
        "value" : 22,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "C56.9",
          "display" : "Ovar"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "787377000",
          "display" : "Gross examination and sampling of tissue specimen"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tumorgroesse-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-histologie-icdo3-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-histologie-icdo3-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-histologie-icdo3"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-histologie-icdo3-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-histologie-icdo3-1</b></p><a name=\"mii-exa-test-data-onko-histologie-icdo3-1\"> </a><a name=\"hcmii-exa-test-data-onko-histologie-icdo3-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-histologie-icdo3\">MII PR Onkologie Histologie ICD-O-3</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 59847-4}\">Histology and Behavior ICD-O-3 Cancer</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 8441/3}\">Seröses Adenokarzinom</span></p><p><b>bodySite</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-seitenlokalisation L}, {http://terminology.hl7.org/CodeSystem/icd-o-3 C56.9}\">Links</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "59847-4",
          "display" : "Histology and Behavior ICD-O-3 Cancer"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "8441/3",
          "display" : "Seröses Karzinom o.n.A."
        }],
        "text" : "Seröses Adenokarzinom"
      },
      "bodySite" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-seitenlokalisation",
          "code" : "L",
          "display" : "Links"
        },
        {
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "C56.9",
          "display" : "Ovar"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-histologie-icdo3-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-lymphknoten"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1</b></p><a name=\"mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1\"> </a><a name=\"hcmii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-lymphknoten\">MII PR Onkologie Anzahl der untersuchten Lymphknoten</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21894-1}, {http://snomed.info/sct 444025001}\">Regional lymph nodes examined [#] Specimen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: 23 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "21894-1",
          "display" : "Regional lymph nodes examined [#] Specimen"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "444025001",
          "display" : "Number of lymph nodes examined"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueQuantity" : {
        "value" : 23,
        "unit" : "1",
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-lymphknoten"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1</b></p><a name=\"mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1\"> </a><a name=\"hcmii-exa-test-data-onko-anzahl-befallene-lymphknoten-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-lymphknoten\">MII PR Onkologie Anzahl der befallenen Lymphknoten</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21893-3}, {http://snomed.info/sct 443527007}\">Regional lymph nodes positive [#] Specimen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: 2 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "21893-3",
          "display" : "Regional lymph nodes positive [#] Specimen"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "443527007",
          "display" : "Number of lymph nodes containing metastatic neoplasm"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueQuantity" : {
        "value" : 2,
        "unit" : "1",
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1</b></p><a name=\"mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1\"> </a><a name=\"hcmii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten\">MII PR Onkologie Anzahl der untersuchten Sentinel-Lymphknoten</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85347-3}, {http://snomed.info/sct 444411008}\">Sentinel lymph nodes examined [#] in Cancer specimen by Light microscopy</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: 2 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85347-3",
          "display" : "Sentinel lymph nodes examined [#] in Cancer specimen by Light microscopy"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "444411008",
          "display" : "Number of sentinel lymph nodes examined"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueQuantity" : {
        "value" : 2,
        "unit" : "1",
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-sentinel-lymphknoten"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1</b></p><a name=\"mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1\"> </a><a name=\"hcmii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-sentinel-lymphknoten\">MII PR Onkologie Anzahl der befallenen Sentinel-Lymphknoten</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 92832-5}\">Sentinel lymph nodes with metastasis [#] in Cancer specimen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: 1 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "92832-5",
          "display" : "Sentinel lymph nodes with metastasis [#] in Cancer specimen"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueQuantity" : {
        "value" : 1,
        "unit" : "1",
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-t-kategorie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-t-kategorie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-t-kategorie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-t-kategorie-1</b></p><a name=\"mii-exa-test-data-onko-tnm-t-kategorie-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-t-kategorie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie\">MII PR Onkologie TNM T-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 384625004}\">pT category</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm T3c}\">T3c</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "p",
              "display" : "p"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "384625004",
          "display" : "pT category"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "T3c"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-n-kategorie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-n-kategorie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-n-kategorie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-n-kategorie-1</b></p><a name=\"mii-exa-test-data-onko-tnm-n-kategorie-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-n-kategorie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie\">MII PR Onkologie TNM N-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 371494008}\">pN category (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm N1}\">N1</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p><p><b>hasMember</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1.html\">Observation Regional lymph nodes positive [#] Specimen</a></li><li><a href=\"Observation-mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1.html\">Observation Regional lymph nodes examined [#] Specimen</a></li></ul></div>"
      },
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "p",
              "display" : "p"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "371494008",
          "display" : "pN category (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "N1"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      },
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-n-kategorie-sn-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-n-kategorie-sn-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-n-kategorie-sn-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-n-kategorie-sn-1</b></p><a name=\"mii-exa-test-data-onko-tnm-n-kategorie-sn-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-n-kategorie-sn-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie\">MII PR Onkologie TNM N-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 371494008}\">pN category (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm N0}\">N0</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p><p><b>hasMember</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1.html\">Observation Sentinel lymph nodes with metastasis [#] in Cancer specimen</a></li><li><a href=\"Observation-mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1.html\">Observation Sentinel lymph nodes examined [#] in Cancer specimen by Light microscopy</a></li></ul></div>"
      },
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "p",
              "display" : "p"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "371494008",
          "display" : "pN category (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-itc-suffix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "i-",
              "display" : "(i-)"
            }]
          }
        },
        {
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-sn-suffix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "sn",
              "display" : "(sn)"
            }]
          }
        }],
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "N0",
          "display" : "N0"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      },
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-sn-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-m-kategorie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-m-kategorie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-m-kategorie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-m-kategorie-1</b></p><a name=\"mii-exa-test-data-onko-tnm-m-kategorie-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-m-kategorie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie\">MII PR Onkologie TNM M-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-operation-1.html\">Procedure Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal</a></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 371497001}\">pM category</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm M1b}\">M1b</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p><p><b>hasMember</b>: <a href=\"Observation-mii-exa-test-data-onko-fernmetastasen-1.html\">Observation Site of distant metastasis</a></p></div>"
      },
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-operation-1"
      }],
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "p",
              "display" : "p"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "371497001",
          "display" : "pM category"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-itc-suffix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "i+",
              "display" : "(i+)"
            }]
          }
        }],
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "M1b"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      },
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-onko-fernmetastasen-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-m-kategorie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-l-kategorie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-l-kategorie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-l-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-l-kategorie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-l-kategorie-1</b></p><a name=\"mii-exa-test-data-onko-tnm-l-kategorie-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-l-kategorie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-l-kategorie\">MII PR Onkologie TNM L-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 395715009}\">Status of lymphatic (small vessel) invasion by tumor</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm L1}\">L1</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "395715009",
          "display" : "Status of lymphatic (small vessel) invasion by tumor"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "L1"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-l-kategorie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-v-kategorie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-v-kategorie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-v-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-v-kategorie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-v-kategorie-1</b></p><a name=\"mii-exa-test-data-onko-tnm-v-kategorie-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-v-kategorie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-v-kategorie\">MII PR Onkologie TNM V-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 371493002}\">Status of venous (large vessel) invasion by tumor</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm V0}\">V0</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "371493002",
          "display" : "Status of venous (large vessel) invasion by tumor"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "V0"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-v-kategorie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-pn-kategorie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-pn-kategorie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-pn-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-pn-kategorie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-pn-kategorie-1</b></p><a name=\"mii-exa-test-data-onko-tnm-pn-kategorie-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-pn-kategorie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-pn-kategorie\">MII PR Onkologie TNM Pn-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 371513001}\">Presence of direct invasion by primary malignant neoplasm to nerve</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm Pn0}\">Pn0</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "371513001",
          "display" : "Presence of direct invasion by primary malignant neoplasm to nerve"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "Pn0"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-pn-kategorie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-s-kategorie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-s-kategorie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-s-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-s-kategorie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-s-kategorie-1</b></p><a name=\"mii-exa-test-data-onko-tnm-s-kategorie-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-s-kategorie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-s-kategorie\">MII PR Onkologie TNM S-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399424006}\">Serum tumor marker category</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm S1}\">S1</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399424006",
          "display" : "Serum tumor marker category"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "S1"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-s-kategorie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-y-symbol-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-y-symbol-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-y-symbol"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-y-symbol-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-y-symbol-1</b></p><a name=\"mii-exa-test-data-onko-tnm-y-symbol-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-y-symbol-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-y-symbol\">MII PR Onkologie TNM y-Symbol</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 101658-3}\">Cancer staging after multimodality therapy</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 421755005}\">y</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "101658-3",
          "display" : "Cancer staging after multimodality therapy"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "421755005",
          "display" : "y"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-y-symbol-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-r-symbol-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-r-symbol-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-r-symbol"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-r-symbol-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-r-symbol-1</b></p><a name=\"mii-exa-test-data-onko-tnm-r-symbol-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-r-symbol-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-r-symbol\">MII PR Onkologie TNM r-Symbol</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 101659-1}\">Cancer staging after tumor recurrence</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 421188008}\">r</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "101659-1",
          "display" : "Cancer staging after tumor recurrence"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "421188008",
          "display" : "r"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-r-symbol-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-a-symbol-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-a-symbol-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-a-symbol"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-a-symbol-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-a-symbol-1</b></p><a name=\"mii-exa-test-data-onko-tnm-a-symbol-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-a-symbol-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-a-symbol\">MII PR Onkologie TNM a-Symbol</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 101660-9}\">Cancer staging during autopsy</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 421426001}\">a</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "101660-9",
          "display" : "Cancer staging during autopsy"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "421426001",
          "display" : "a"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-a-symbol-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-m-symbol-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-m-symbol-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-symbol"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-m-symbol-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-m-symbol-1</b></p><a name=\"mii-exa-test-data-onko-tnm-m-symbol-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-m-symbol-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-symbol\">MII PR Onkologie TNM m-Symbol</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 42030-7}\">Multiple tumors reported as single primary Cancer</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm m}\">(m)</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "42030-7",
          "display" : "Multiple tumors reported as single primary Cancer"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "m",
          "display" : "(m)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-m-symbol-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-klassifikation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-klassifikation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-klassifikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-klassifikation-1</b></p><a name=\"mii-exa-test-data-onko-tnm-klassifikation-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-klassifikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation\">MII PR Onkologie TNM-Klassifikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399588009}\">Pathologic TNM stage grouping</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm IVB}\">Stadium IVB</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p><p><b>hasMember</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-onko-tnm-t-kategorie-1.html\">Observation pT category</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-n-kategorie-1.html\">Observation pN category (observable entity)</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-m-kategorie-1.html\">Observation pM category</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-l-kategorie-1.html\">Observation Status of lymphatic (small vessel) invasion by tumor</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-v-kategorie-1.html\">Observation Status of venous (large vessel) invasion by tumor</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-pn-kategorie-1.html\">Observation Presence of direct invasion by primary malignant neoplasm to nerve</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-y-symbol-1.html\">Observation Cancer staging after multimodality therapy</a></li></ul></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399588009",
          "display" : "Pathologic TNM stage grouping"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "IVB",
          "display" : "Stadium IVB"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      },
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-m-kategorie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-l-kategorie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-v-kategorie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-pn-kategorie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-y-symbol-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-t-kategorie-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-t-kategorie-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-t-kategorie-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-t-kategorie-2</b></p><a name=\"mii-exa-test-data-onko-tnm-t-kategorie-2\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-t-kategorie-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie\">MII PR Onkologie TNM T-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onkologie TNM y-Präfix</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm y}\">y</span></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399504009}\">cT category (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-08-17</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm T2}\">T2</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 42030-7}\">Multiple tumors reported as single primary Cancer</span></td><td><span title=\"Codes:{https://www.uicc.org/resources/tnm m}\">(m)</span></td></tr></table></div>"
      },
      "modifierExtension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-y-praefix",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.uicc.org/resources/tnm",
            "code" : "y",
            "display" : "y"
          }]
        }
      }],
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "c",
              "display" : "c"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399504009",
          "display" : "cT category (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-08-17",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "T2"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "42030-7",
            "display" : "Multiple tumors reported as single primary Cancer"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.uicc.org/resources/tnm",
            "code" : "m",
            "display" : "(m)"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-n-kategorie-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-n-kategorie-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-n-kategorie-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-n-kategorie-2</b></p><a name=\"mii-exa-test-data-onko-tnm-n-kategorie-2\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-n-kategorie-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie\">MII PR Onkologie TNM N-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onkologie TNM r-Präfix</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm r}\">r</span></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399534004}\">cN category (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-08-17</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm N0}\">N0</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "modifierExtension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-r-praefix",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.uicc.org/resources/tnm",
            "code" : "r",
            "display" : "r"
          }]
        }
      }],
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "c",
              "display" : "c"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399534004",
          "display" : "cN category (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-08-17",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "N0"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-m-kategorie-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-m-kategorie-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-m-kategorie-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-m-kategorie-2</b></p><a name=\"mii-exa-test-data-onko-tnm-m-kategorie-2\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-m-kategorie-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie\">MII PR Onkologie TNM M-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onkologie TNM y-Präfix</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm y}\">y</span></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399387003}\">cM category (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-08-17</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm M0}\">M0</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "modifierExtension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-y-praefix",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.uicc.org/resources/tnm",
            "code" : "y",
            "display" : "y"
          }]
        }
      }],
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "c",
              "display" : "c"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399387003",
          "display" : "cM category (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-08-17",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "M0"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-m-kategorie-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-t-kategorie-3",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-t-kategorie-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-t-kategorie-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-t-kategorie-3</b></p><a name=\"mii-exa-test-data-onko-tnm-t-kategorie-3\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-t-kategorie-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie\">MII PR Onkologie TNM T-Kategorie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onkologie TNM a-Präfix</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm a}\">a</span></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 384625004}\">pT category</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>effective</b>: 2024-05-15</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm T3}\">T3</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p></div>"
      },
      "modifierExtension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-a-praefix",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.uicc.org/resources/tnm",
            "code" : "a",
            "display" : "a"
          }]
        }
      }],
      "status" : "final",
      "code" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.uicc.org/resources/tnm",
              "code" : "p",
              "display" : "p"
            }]
          }
        }],
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "384625004",
          "display" : "pT category"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "effectiveDateTime" : "2024-05-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "T3"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-klassifikation-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-klassifikation-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-klassifikation-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-klassifikation-2</b></p><a name=\"mii-exa-test-data-onko-tnm-klassifikation-2\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-klassifikation-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation\">MII PR Onkologie TNM-Klassifikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399537006}\">Clinical TNM stage grouping</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-08-17</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm IB}\">Stadium IB</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p><p><b>hasMember</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-onko-tnm-t-kategorie-2.html\">Observation cT category (observable entity)</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-n-kategorie-2.html\">Observation cN category (observable entity)</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-m-kategorie-2.html\">Observation cM category (observable entity)</a></li></ul></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399537006",
          "display" : "Clinical TNM stage grouping"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-08-17",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "IB",
          "display" : "Stadium IB"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      },
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-2"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-2"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-m-kategorie-2"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation-synthetisiert"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1</b></p><a name=\"mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1\"> </a><a name=\"hcmii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation-synthetisiert\">MII PR Onkologie TNM-Klassifikation (synthetisiert)</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399703000}\">Integrated TNM category</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-12</p><p><b>value</b>: <span title=\"Codes:{https://www.uicc.org/resources/tnm IVB}\">Stadium IVB</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version 8}\">8. Auflage</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-onko-sequencer-1.html\">Device: status = active; manufacturer = Illumina</a></p><p><b>hasMember</b>: <a href=\"Observation-mii-exa-test-data-onko-tnm-m-kategorie-1.html\">Observation pM category</a></p><p><b>derivedFrom</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-onko-tnm-klassifikation-1.html\">Observation Pathologic TNM stage grouping</a></li><li><a href=\"Observation-mii-exa-test-data-onko-tnm-klassifikation-2.html\">Observation Clinical TNM stage grouping</a></li></ul><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-formel tnm-formel}\">TNM-Formel</span></td><td>ypT3c pN1 M1b (Stadium IVB)</td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399703000",
          "display" : "Integrated TNM category"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-12",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.uicc.org/resources/tnm",
          "code" : "IVB",
          "display" : "Stadium IVB"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-version",
          "code" : "8",
          "display" : "8. Auflage"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-onko-sequencer-1"
      },
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-onko-tnm-m-kategorie-1"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-2"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tnm-formel",
            "code" : "tnm-formel",
            "display" : "TNM-Formel"
          }]
        },
        "valueString" : "ypT3c pN1 M1b (Stadium IVB)"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-gleason-gesamt-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-gleason-gesamt-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-score-gesamt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-gleason-gesamt-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-gleason-gesamt-1</b></p><a name=\"mii-exa-test-data-onko-prostata-gleason-gesamt-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-gleason-gesamt-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-score-gesamt\">MII PR Onkologie Prostata Gleason Score Gesamt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 372278000}, {http://loinc.org 35266-6}\">Gleason score (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 57403001}\">Gleason grade score 7 out of 10 (finding)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "372278000",
          "display" : "Gleason score (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "35266-6",
          "display" : "Gleason score in Specimen Qualitative"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "57403001",
          "display" : "Gleason grade score 7 out of 10 (finding)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-gleason-gesamt-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tumormarker-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tumormarker-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tumormarker-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tumormarker-1</b></p><a name=\"mii-exa-test-data-onko-tumormarker-1\"> </a><a name=\"hcmii-exa-test-data-onko-tumormarker-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker\">MII PR Onkologie Tumormarker</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Labor Interpretationsbeeinflussende Eigenschaft</b>: <a href=\"http://snomed.info/id/118127007\">SNOMED CT: 118127007</a> (Specimen lipemic (finding))</p><p><b>identifier</b>: Observation Instance Identifier/TM-2021-000356</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-onko-therapieempfehlung-op-1.html\">ServiceRequest Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 10334-1}\">Cancer Ag 125 [Units/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-09-28</p><p><b>issued</b>: 2021-09-28 15:30:00+0200</p><p><b>value</b>: &gt;356 U/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeU/mL = 'U/mL')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>note</b>: </p><blockquote><div><p>CA-125 deutlich erhöht, passend zum Ovarialkarzinom.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 414464004}\">Immunoassay method (procedure)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-onko-sequencer-1.html\">Device: status = active; manufacturer = Illumina</a></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>0 U/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeU/mL = 'U/mL')</span></td><td>35 U/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeU/mL = 'U/mL')</span></td></tr></table></div>"
      },
      "modifierExtension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/InterpretationsbeeinflussendeEigenschaft",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "118127007",
          "display" : "Specimen lipemic (finding)"
        }
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/tumormarker-befunde",
        "value" : "TM-2021-000356",
        "assigner" : {
          "reference" : "Organization/mii-exa-test-data-organization-charite"
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-onko-therapieempfehlung-op-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10334-1",
          "display" : "Cancer Ag 125 [Units/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1",
        "identifier" : {
          "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
          "value" : "ONKO-TEST-001"
        }
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1",
        "identifier" : {
          "system" : "https://www.charite.de/fhir/sid/fallnummer",
          "value" : "F-2021-004711"
        }
      },
      "effectiveDateTime" : "2021-09-28",
      "_effectiveDateTime" : {
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/QuelleKlinischesBezugsdatum",
          "valueCoding" : {
            "system" : "http://snomed.info/sct",
            "code" : "399445004",
            "display" : "Specimen collection date (observable entity)"
          }
        }]
      },
      "issued" : "2021-09-28T15:30:00+02:00",
      "valueQuantity" : {
        "value" : 356,
        "_value" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/quantity-precision",
            "valueInteger" : 0
          }]
        },
        "comparator" : ">",
        "unit" : "U/mL",
        "system" : "http://unitsofmeasure.org",
        "code" : "U/mL"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "note" : [{
        "text" : "CA-125 deutlich erhöht, passend zum Ovarialkarzinom."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "414464004",
          "display" : "Immunoassay method (procedure)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1",
        "identifier" : {
          "system" : "https://www.charite.de/fhir/sid/proben",
          "value" : "PROBE-2021-000356"
        }
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-onko-sequencer-1",
        "identifier" : {
          "system" : "https://www.charite.de/fhir/sid/geraete",
          "value" : "ANALYZER-0815"
        }
      },
      "referenceRange" : [{
        "low" : {
          "value" : 0,
          "system" : "http://unitsofmeasure.org",
          "code" : "U/mL"
        },
        "high" : {
          "value" : 35,
          "system" : "http://unitsofmeasure.org",
          "code" : "U/mL"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tumormarker-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tumormarker-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tumormarker-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tumormarker-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tumormarker-2</b></p><a name=\"mii-exa-test-data-onko-tumormarker-2\"> </a><a name=\"hcmii-exa-test-data-onko-tumormarker-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker\">MII PR Onkologie Tumormarker</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/TM-2021-000411</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 10334-1}\">Cancer Ag 125 [Units/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-11-15</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 10828004}\">Positive (qualifier value)</span></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/tumormarker-befunde",
        "value" : "TM-2021-000411",
        "assigner" : {
          "reference" : "Organization/mii-exa-test-data-organization-charite"
        }
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10334-1",
          "display" : "Cancer Ag 125 [Units/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-11-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "10828004",
          "display" : "Positive (qualifier value)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tumormarker-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tumormarker-3",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tumormarker-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tumormarker-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tumormarker-3</b></p><a name=\"mii-exa-test-data-onko-tumormarker-3\"> </a><a name=\"hcmii-exa-test-data-onko-tumormarker-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker\">MII PR Onkologie Tumormarker</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/TM-2021-000502</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 10334-1}\">Cancer Ag 125 [Units/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-12-15</p><p><b>value</b>: 300-400</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/tumormarker-befunde",
        "value" : "TM-2021-000502",
        "assigner" : {
          "reference" : "Organization/mii-exa-test-data-organization-charite"
        }
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10334-1",
          "display" : "Cancer Ag 125 [Units/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-12-15",
      "valueRange" : {
        "low" : {
          "value" : 300,
          "system" : "http://unitsofmeasure.org",
          "code" : "U/mL"
        },
        "high" : {
          "value" : 400,
          "system" : "http://unitsofmeasure.org",
          "code" : "U/mL"
        }
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tumormarker-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tumormarker-4",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tumormarker-4",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tumormarker-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tumormarker-4</b></p><a name=\"mii-exa-test-data-onko-tumormarker-4\"> </a><a name=\"hcmii-exa-test-data-onko-tumormarker-4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker\">MII PR Onkologie Tumormarker</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/TM-2022-000017</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 10334-1}\">Cancer Ag 125 [Units/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2022-01-15</p><p><b>value</b>: 1 U/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeU/mL = 'U/mL')</span>/128 U/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeU/mL = 'U/mL')</span></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/tumormarker-befunde",
        "value" : "TM-2022-000017",
        "assigner" : {
          "reference" : "Organization/mii-exa-test-data-organization-charite"
        }
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10334-1",
          "display" : "Cancer Ag 125 [Units/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2022-01-15",
      "valueRatio" : {
        "numerator" : {
          "value" : 1,
          "system" : "http://unitsofmeasure.org",
          "code" : "U/mL"
        },
        "denominator" : {
          "value" : 128,
          "system" : "http://unitsofmeasure.org",
          "code" : "U/mL"
        }
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tumormarker-4"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tumormarker-5",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tumormarker-5",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tumormarker-5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tumormarker-5</b></p><a name=\"mii-exa-test-data-onko-tumormarker-5\"> </a><a name=\"hcmii-exa-test-data-onko-tumormarker-5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumormarker\">MII PR Onkologie Tumormarker</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/TM-2022-000058</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 10334-1}\">Cancer Ag 125 [Units/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2022-02-15</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason error}\">Error</span></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/tumormarker-befunde",
        "value" : "TM-2022-000058",
        "assigner" : {
          "reference" : "Organization/mii-exa-test-data-organization-charite"
        }
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10334-1",
          "display" : "Cancer Ag 125 [Units/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2022-02-15",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "error",
          "display" : "Error"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tumormarker-5"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-onko-sequencer-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-onko-sequencer-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-onko-sequencer-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-onko-sequencer-1</b></p><a name=\"mii-exa-test-data-onko-sequencer-1\"> </a><a name=\"hcmii-exa-test-data-onko-sequencer-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>manufacturer</b>: Illumina</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Illumina NextSeq 550</td><td>User Friendly name</td></tr></table></div>"
      },
      "status" : "active",
      "manufacturer" : "Illumina",
      "deviceName" : [{
        "name" : "Illumina NextSeq 550",
        "type" : "user-friendly-name"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-onko-sequencer-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-charite",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-charite",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-charite\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-charite</b></p><a name=\"mii-exa-test-data-organization-charite\"> </a><a name=\"hcmii-exa-test-data-organization-charite\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Charité – Universitätsmedizin Berlin</p></div>"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Charité – Universitätsmedizin Berlin"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-charite"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-figo-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-figo-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-weitere-klassifikationen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-figo-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-figo-1</b></p><a name=\"mii-exa-test-data-onko-figo-1\"> </a><a name=\"hcmii-exa-test-data-onko-figo-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-weitere-klassifikationen\">MII PR Onkologie Weitere Klassifikationen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 254386003}\">FIGO Klassifikation für ovariale Tumore</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: <span title=\"Codes:{http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl C128095}\">IVB</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 254386003}\">Federation Internationale de gynecologie et d'obstetrique staging of ovarian malignancy</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "254386003",
          "display" : "Federation Internationale de gynecologie et d'obstetrique staging of ovarian malignancy"
        }],
        "text" : "FIGO Klassifikation für ovariale Tumore"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
          "code" : "C128095",
          "display" : "FIGO Stage IVB Ovarian Cancer 2014"
        }],
        "text" : "IVB"
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "254386003",
          "display" : "Federation Internationale de gynecologie et d'obstetrique staging of ovarian malignancy"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-figo-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-residualstatus-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-residualstatus-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-residualstatus"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-residualstatus-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-residualstatus-1</b></p><a name=\"mii-exa-test-data-onko-residualstatus-1\"> </a><a name=\"hcmii-exa-test-data-onko-residualstatus-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-residualstatus\">MII PR Onkologie Residualstatus</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-operation-1.html\">Procedure Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal</a></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 84892-9}, {http://snomed.info/sct 445200009}\">Residual tumor classification [Type] in Cancer specimen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus R0}\">Kein Residualtumor</span></p></div>"
      },
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-operation-1"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "84892-9",
          "display" : "Residual tumor classification [Type] in Cancer specimen"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "445200009",
          "display" : "Status of residual neoplasm"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus",
          "code" : "R0",
          "display" : "Kein Residualtumor"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-residualstatus-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-fernmetastasen-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-fernmetastasen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fernmetastasen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-fernmetastasen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-fernmetastasen-1</b></p><a name=\"mii-exa-test-data-onko-fernmetastasen-1\"> </a><a name=\"hcmii-exa-test-data-onko-fernmetastasen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fernmetastasen\">MII PR Onkologie Fernmetastasen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 385421009}\">Site of distant metastasis</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-22</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-fernmetastasen HEP}\">Leber</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 10200004}\">Liver structure (body structure)</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "385421009",
          "display" : "Site of distant metastasis"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-22",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-fernmetastasen",
          "code" : "HEP",
          "display" : "Leber"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "10200004",
          "display" : "Liver structure (body structure)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-fernmetastasen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-ecog-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-ecog-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-ecog"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-ecog-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-ecog-1</b></p><a name=\"mii-exa-test-data-onko-ecog-1\"> </a><a name=\"hcmii-exa-test-data-onko-ecog-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-ecog\">MII PR Onkologie Allgemeiner Leistungszustand ECOG</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 423740007}, {http://loinc.org 89262-0}\">ECOG performance status</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-15</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-allgemeiner-leistungszustand-ecog 1}, {http://loinc.org LA9623-5}\">Einschränkung bei körperlicher Anstrengung, aber gehfähig; leichte körperliche Arbeit bzw. Arbeit im Sitzen (z. B. leichte Hausarbeit oder Büroarbeit) möglich (70 - 80 % nach Karnofsky)</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "423740007",
          "display" : "ECOG performance status"
        },
        {
          "system" : "http://loinc.org",
          "code" : "89262-0",
          "display" : "Physical performance [ECOG]"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-allgemeiner-leistungszustand-ecog",
          "code" : "1",
          "display" : "Einschränkung bei körperlicher Anstrengung, aber gehfähig; leichte körperliche Arbeit bzw. Arbeit im Sitzen (z. B. leichte Hausarbeit oder Büroarbeit) möglich (70 - 80 % nach Karnofsky)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "LA9623-5",
          "display" : "Restricted in physically strenuous activity"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-ecog-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-karnofsky-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-karnofsky-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-karnofsky"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-karnofsky-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-karnofsky-1</b></p><a name=\"mii-exa-test-data-onko-karnofsky-1\"> </a><a name=\"hcmii-exa-test-data-onko-karnofsky-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-karnofsky\">MII PR Onkologie Allgemeiner Leistungszustand nach Karnofsky</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 761869008}, {http://loinc.org 89243-0}\">KPS (Karnofsky Performance Status) score</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-15</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-allgemeiner-leistungszustand-karnofsky 80%}, {http://loinc.org LA29177-5}\">80%</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "761869008",
          "display" : "KPS (Karnofsky Performance Status) score"
        },
        {
          "system" : "http://loinc.org",
          "code" : "89243-0",
          "display" : "Karnofsky Performance Status score"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-allgemeiner-leistungszustand-karnofsky",
          "code" : "80%",
          "display" : "80%"
        },
        {
          "system" : "http://loinc.org",
          "code" : "LA29177-5",
          "display" : "Normal activity with effort"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-karnofsky-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-asa-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-asa-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-asa-klassifikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-asa-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-asa-1</b></p><a name=\"mii-exa-test-data-onko-asa-1\"> </a><a name=\"hcmii-exa-test-data-onko-asa-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-asa-klassifikation\">MII PR Onkologie ASA-Klassifikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 97816-3}\">American society of anesthesiologists morbidity state</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-09-29</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-asa-obds 2}\">ASA II</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "97816-3",
          "display" : "American society of anesthesiologists morbidity state"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-09-29",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-asa-obds",
          "code" : "2",
          "display" : "ASA II"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-asa-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-operation-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-operation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-operation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-operation-1</b></p><a name=\"mii-exa-test-data-onko-operation-1\"> </a><a name=\"hcmii-exa-test-data-onko-operation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation\">MII PR Onkologie Operation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Operation Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>MII EX Onko Operation Urgency</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency E}\">Elektiveingriff</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-10-01</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 5-547.0}, {http://snomed.info/sct 86481000}\">Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-09-30</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 15497006}\">Ovarian structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus R0}\">Kein Residualtumor</span></p><p><b>complication</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation N}\">Nein</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm T81.0}\">Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert</span></p><p><b>note</b>: </p><blockquote><div><p>Debulking-Operation mit vollständiger makroskopischer Tumorentfernung.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-urgency",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency",
            "code" : "E",
            "display" : "Elektiveingriff"
          }],
          "text" : "Elektiveingriff"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-10-01"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "L",
              "display" : "links"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "5-547.0",
          "display" : "Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "86481000",
          "display" : "Laparotomy"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-09-30",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "15497006",
          "display" : "Ovarian structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus",
          "code" : "R0",
          "display" : "Kein Residualtumor"
        }]
      },
      "complication" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation",
          "code" : "N",
          "display" : "Nein"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "T81.0",
          "display" : "Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert"
        }]
      }],
      "note" : [{
        "text" : "Debulking-Operation mit vollständiger makroskopischer Tumorentfernung."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-operation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-strahlentherapie-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-strahlentherapie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-strahlentherapie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-strahlentherapie-1</b></p><a name=\"mii-exa-test-data-onko-strahlentherapie-1\"> </a><a name=\"hcmii-exa-test-data-onko-strahlentherapie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie\">MII PR Onkologie Strahlentherapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Strahlentherapie Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>MII EX Onko Strahlentherapie Stellung zur OP</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop A}\">adjuvant</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2022-03-16</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-2.html\">CarePlan: identifier = TK-2021-002; status = completed; intent = plan; category = postoperative Tumorkonferenz (Planung der postoperativen Therapie, z. B. zur Frage adjuvante Therapie); created = 2021-10-15</a></p><p><b>partOf</b>: <a href=\"Observation-mii-exa-test-data-onko-verlauf-1.html\">Observation Status of regression of tumor (observable entity)</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 108290001}\">Radiation oncology AND/OR radiotherapy</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 8-522}, {http://snomed.info/sct 33195004}\">Hochvoltstrahlentherapie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2022-02-01 --&gt; 2022-03-15</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 12921003}\">Pelvic structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund E}\">reguläres Ende</span></p><p><b>note</b>: </p><blockquote><div><p>Adjuvante Bestrahlung des Beckens nach Operation.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-stellungzurop",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop",
            "code" : "A",
            "display" : "adjuvant"
          }],
          "text" : "adjuvant"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2022-03-16"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-2"
      }],
      "partOf" : [{
        "reference" : "Observation/mii-exa-test-data-onko-verlauf-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "108290001",
          "display" : "Radiation oncology AND/OR radiotherapy"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "8-522",
          "display" : "Hochvoltstrahlentherapie"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "33195004",
          "display" : "External beam radiation therapy procedure"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2022-02-01",
        "end" : "2022-03-15"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "12921003",
          "display" : "Pelvic structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund",
          "code" : "E",
          "display" : "reguläres Ende"
        }]
      },
      "note" : [{
        "text" : "Adjuvante Bestrahlung des Beckens nach Operation."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-strahlentherapie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-strahlentherapie-bestrahlung-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-strahlentherapie-bestrahlung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-strahlentherapie-bestrahlung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-strahlentherapie-bestrahlung-1</b></p><a name=\"mii-exa-test-data-onko-strahlentherapie-bestrahlung-1\"> </a><a name=\"hcmii-exa-test-data-onko-strahlentherapie-bestrahlung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie\">MII PR Onkologie Strahlentherapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Procedure Method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-applikationsart PRCJ}\">perkutan mit Chemotherapie/Sensitizer</span></p><p><b>MII EX Onko Strahlentherapie Bestrahlung Gesamtdosis</b>: 50 Gy<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeGy = 'Gy')</span></p><p><b>MII EX Onko Strahlentherapie Bestrahlung Einzeldosis</b>: 2 Gy<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeGy = 'Gy')</span></p><p><b>MII EX Onko Strahlentherapie Bestrahlung Boost</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-boost SIB}\">simultan integrierter Boost</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2022-03-16</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-2.html\">CarePlan: identifier = TK-2021-002; status = completed; intent = plan; category = postoperative Tumorkonferenz (Planung der postoperativen Therapie, z. B. zur Frage adjuvante Therapie); created = 2021-10-15</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-strahlentherapie-1.html\">Procedure Hochvoltstrahlentherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 1287742003}\">Radiotherapy (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 8-522.6}\">Hochvoltstrahlentherapie: Linearbeschleuniger mehr als 6 MeV Photonen oder schnelle Elektronen, bis zu 2 Bestrahlungsfelder</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2022-02-01 --&gt; 2022-03-15</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet 5.12}, {http://snomed.info/sct 12921003}\">Becken sonstige</span></p><p><b>note</b>: </p><blockquote><div><p>Perkutane Bestrahlung des Beckens, 25 Fraktionen à 2 Gy.</p>\n</div></blockquote><p><b>usedCode</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-strahlenart UH}\">Photonen (ultraharte Röntgenstrahlen, inklusive Gamma-Strahler)</span></p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/procedure-method",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-applikationsart",
            "code" : "PRCJ",
            "display" : "perkutan mit Chemotherapie/Sensitizer"
          }]
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-gesamtdosis",
        "valueQuantity" : {
          "value" : 50,
          "unit" : "Gy",
          "system" : "http://unitsofmeasure.org",
          "code" : "Gy"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-einzeldosis",
        "valueQuantity" : {
          "value" : 2,
          "unit" : "Gy",
          "system" : "http://unitsofmeasure.org",
          "code" : "Gy"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-boost",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-boost",
            "code" : "SIB",
            "display" : "simultan integrierter Boost"
          }]
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2022-03-16"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-2"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-strahlentherapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1287742003",
          "display" : "Radiotherapy (procedure)"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "8-522.6",
          "display" : "Hochvoltstrahlentherapie: Linearbeschleuniger mehr als 6 MeV Photonen oder schnelle Elektronen, bis zu 2 Bestrahlungsfelder"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2022-02-01",
        "end" : "2022-03-15"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-seitenlokalisation",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-seitenlokalisation",
              "code" : "L",
              "display" : "links"
            }]
          }
        }],
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet",
          "code" : "5.12",
          "display" : "Becken sonstige"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "12921003",
          "display" : "Pelvic structure (body structure)"
        }]
      }],
      "note" : [{
        "text" : "Perkutane Bestrahlung des Beckens, 25 Fraktionen à 2 Gy."
      }],
      "usedCode" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-strahlenart",
          "code" : "UH",
          "display" : "Photonen (ultraharte Röntgenstrahlen, inklusive Gamma-Strahler)"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-strahlentherapie-bestrahlung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-nuklearmedizin"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1</b></p><a name=\"mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1\"> </a><a name=\"hcmii-exa-test-data-onko-bestrahlung-nuklearmedizin-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-nuklearmedizin\">MII PR Onkologie Strahlentherapie Nuklearmedizin</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Procedure Method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-applikationsart MRJT}\">Radiojod-Therapie</span></p><p><b>MII EX Onko Strahlentherapie Bestrahlung Gesamtdosis</b>: 3700 MBq<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeMBq = 'MBq')</span></p><p><b>MII EX Onko Strahlentherapie Bestrahlung Einzeldosis</b>: 3700 MBq<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeMBq = 'MBq')</span></p><p><b>MII EX Onko Strahlentherapie Bestrahlung Boost</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-boost N}\">nein, ohne Boost</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2022-04-04</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-strahlentherapie-1.html\">Procedure Hochvoltstrahlentherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 399315003}\">Radionuclide therapy</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 8-531}\">Radiojodtherapie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2022-04-01 --&gt; 2022-04-03</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet 2.11}, {http://snomed.info/sct 69748006}\">Schilddrüse</span></p><p><b>note</b>: </p><blockquote><div><p>Radiojodtherapie mit 3700 MBq I-131.</p>\n</div></blockquote><p><b>usedCode</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-strahlenart UH}\">Photonen (ultraharte Röntgenstrahlen, inklusive Gamma-Strahler)</span></p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/procedure-method",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-applikationsart",
            "code" : "MRJT",
            "display" : "Radiojod-Therapie"
          }]
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-gesamtdosis",
        "valueQuantity" : {
          "value" : 3700,
          "unit" : "MBq",
          "system" : "http://unitsofmeasure.org",
          "code" : "MBq"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-einzeldosis",
        "valueQuantity" : {
          "value" : 3700,
          "unit" : "MBq",
          "system" : "http://unitsofmeasure.org",
          "code" : "MBq"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-boost",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-boost",
            "code" : "N",
            "display" : "nein, ohne Boost"
          }]
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2022-04-04"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-strahlentherapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "399315003",
          "display" : "Radionuclide therapy"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "8-531",
          "display" : "Radiojodtherapie"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2022-04-01",
        "end" : "2022-04-03"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "extension" : [{
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-seitenlokalisation",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-seitenlokalisation",
              "code" : "T",
              "display" : "trifft nicht zu"
            }]
          }
        }],
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet",
          "code" : "2.11",
          "display" : "Schilddrüse"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "69748006",
          "display" : "Thyroid structure (body structure)"
        }]
      }],
      "note" : [{
        "text" : "Radiojodtherapie mit 3700 MBq I-131."
      }],
      "usedCode" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-strahlenart",
          "code" : "UH",
          "display" : "Photonen (ultraharte Röntgenstrahlen, inklusive Gamma-Strahler)"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-systemische-therapie-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-systemische-therapie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-systemische-therapie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-systemische-therapie-1</b></p><a name=\"mii-exa-test-data-onko-systemische-therapie-1\"> </a><a name=\"hcmii-exa-test-data-onko-systemische-therapie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie\">MII PR Onkologie Systemische Therapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Systemische Therapie Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>MII EX Onko Systemische Therapie Stellung zur OP</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop N}\">neoadjuvant</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-09-06</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-operation-1.html\">Procedure Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 18629005}\">Administration of drug or medicament</span></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ CH}, {http://fhir.de/CodeSystem/bfarm/ops 8-54}\">Chemotherapie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-07-05 --&gt; 2021-09-05</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 15497006}\">Ovarian structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund E}\">reguläres Ende</span></p><p><b>note</b>: </p><blockquote><div><p>Neoadjuvante Chemotherapie nach CarboTax-Schema.</p>\n</div></blockquote><p><b>usedCode</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-systemische-therapie-protokolle CarboTax}\">CarboTax</span></p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-systemische-therapie-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-systemische-therapie-stellungzurop",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop",
            "code" : "N",
            "display" : "neoadjuvant"
          }],
          "text" : "neoadjuvant"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-09-06"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-operation-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "18629005",
          "display" : "Administration of drug or medicament"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
          "code" : "CH",
          "display" : "Chemotherapie"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "8-54",
          "display" : "Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2021-07-05",
        "end" : "2021-09-05"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "15497006",
          "display" : "Ovarian structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund",
          "code" : "E",
          "display" : "reguläres Ende"
        }]
      },
      "note" : [{
        "text" : "Neoadjuvante Chemotherapie nach CarboTax-Schema."
      }],
      "usedCode" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-systemische-therapie-protokolle",
          "code" : "CarboTax",
          "display" : "CarboTax"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationStatement/mii-exa-test-data-onko-medikation-1",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "mii-exa-test-data-onko-medikation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_mii-exa-test-data-onko-medikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement mii-exa-test-data-onko-medikation-1</b></p><a name=\"mii-exa-test-data-onko-medikation-1\"> </a><a name=\"hcmii-exa-test-data-onko-medikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation\">MII PR Onkologie Systemische Therapie Medikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/onko-medikation</code>/ONKO-MED-2021-001</p><p><b>basedOn</b>: </p><ul><li><a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></li><li><a href=\"MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-medikation-2.html\">MedicationRequest: status = active; intent = proposal; medication[x] = Paclitaxel; authoredOn = 2021-06-20</a></li></ul><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/medication-statement-category inpatient}\">Inpatient</span></p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01CD01}\">Paclitaxel 175 mg/m2 i.v.</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>context</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-07-05 --&gt; 2021-09-05</p><p><b>dateAsserted</b>: 2021-07-05</p><p><b>informationSource</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C56}\">Bösartige Neubildung des Ovars</span></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>note</b>: </p><blockquote><div><p>CarboTax Schema</p>\n</div></blockquote><blockquote><p><b>dosage</b></p><p><b>sequence</b>: 1</p><p><b>text</b>: 175 mg/m2 i.v. über 3 Stunden, Tag 1 des 21-Tage-Zyklus</p><p><b>timing</b>: Events: 2021-07-05 09:00:00+0200 , Count 3  times, Duration 180days , 1-1 per 21-28 days</p><p><b>asNeeded</b>: false</p><p><b>site</b>: <span title=\"Codes:{http://snomed.info/sct 368049005}\">Structure of vein of upper extremity (body structure)</span></p><p><b>route</b>: <span title=\"Codes:{http://snomed.info/sct 47625008}\">Intravenous route (qualifier value)</span></p><blockquote><p><b>doseAndRate</b></p><p><b>dose</b>: 300 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>rate</b>: 100 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Stunde<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeh = 'h')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>dose</b>: 250-300 mg</p><p><b>rate</b>: 100 mg/h<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/h = 'mg/h')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>rate</b>: 80-120 mg/h</p></blockquote><p><b>maxDosePerPeriod</b>: 300 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/21 Tage<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  coded = 'd')</span></p><p><b>maxDosePerAdministration</b>: 300 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/onko-medikation",
        "value" : "ONKO-MED-2021-001"
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      },
      {
        "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-2"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medication-statement-category",
          "code" : "inpatient",
          "display" : "Inpatient"
        }]
      },
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2021",
          "code" : "L01CD01",
          "display" : "Paclitaxel"
        }],
        "text" : "Paclitaxel 175 mg/m2 i.v."
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "context" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectivePeriod" : {
        "start" : "2021-07-05",
        "end" : "2021-09-05"
      },
      "dateAsserted" : "2021-07-05",
      "informationSource" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "C56",
          "display" : "Bösartige Neubildung des Ovars"
        }]
      }],
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "note" : [{
        "text" : "CarboTax Schema"
      }],
      "dosage" : [{
        "sequence" : 1,
        "text" : "175 mg/m2 i.v. über 3 Stunden, Tag 1 des 21-Tage-Zyklus",
        "timing" : {
          "event" : ["2021-07-05T09:00:00+02:00"],
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2021-07-05",
              "end" : "2021-09-05"
            },
            "count" : 3,
            "countMax" : 6,
            "duration" : 180,
            "durationMax" : 240,
            "durationUnit" : "min",
            "frequency" : 1,
            "frequencyMax" : 1,
            "period" : 21,
            "periodMax" : 28,
            "periodUnit" : "d",
            "dayOfWeek" : ["mon"],
            "timeOfDay" : ["09:00:00"]
          }
        },
        "asNeededBoolean" : false,
        "site" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368049005",
            "display" : "Structure of vein of upper extremity (body structure)"
          }]
        },
        "route" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "47625008",
            "display" : "Intravenous route (qualifier value)"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 300,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "rateRatio" : {
            "numerator" : {
              "value" : 100,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "Stunde",
              "system" : "http://unitsofmeasure.org",
              "code" : "h"
            }
          }
        },
        {
          "doseRange" : {
            "low" : {
              "value" : 250,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "high" : {
              "value" : 300,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            }
          },
          "rateQuantity" : {
            "value" : 100,
            "unit" : "mg/h",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg/h"
          }
        },
        {
          "rateRange" : {
            "low" : {
              "value" : 80,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            },
            "high" : {
              "value" : 120,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            }
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 300,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 21,
            "unit" : "Tage",
            "system" : "http://unitsofmeasure.org",
            "code" : "d"
          }
        },
        "maxDosePerAdministration" : {
          "value" : 300,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationStatement/mii-exa-test-data-onko-medikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationStatement/mii-exa-test-data-onko-medikation-2",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "mii-exa-test-data-onko-medikation-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_mii-exa-test-data-onko-medikation-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement mii-exa-test-data-onko-medikation-2</b></p><a name=\"mii-exa-test-data-onko-medikation-2\"> </a><a name=\"hcmii-exa-test-data-onko-medikation-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation\">MII PR Onkologie Systemische Therapie Medikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01XA02}\">Carboplatin</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>effective</b>: 2021-07-05 --&gt; 2021-09-05</p><p><b>note</b>: </p><blockquote><div><p>CarboTax Schema</p>\n</div></blockquote><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>Timing</b></td><td><b>AsNeeded[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>AUC5 i.v. bei Bedarfsanpassung nach Nierenfunktion</td><td>30min , Morning, Once</td><td><span title=\"Codes:{http://snomed.info/sct 428165003}\">Renal impairment (disorder)</span></td></tr></table></div>"
      },
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2021",
          "code" : "L01XA02",
          "display" : "Carboplatin"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2021-07-05",
        "end" : "2021-09-05"
      },
      "note" : [{
        "text" : "CarboTax Schema"
      }],
      "dosage" : [{
        "text" : "AUC5 i.v. bei Bedarfsanpassung nach Nierenfunktion",
        "timing" : {
          "repeat" : {
            "boundsDuration" : {
              "value" : 8,
              "unit" : "Wochen",
              "system" : "http://unitsofmeasure.org",
              "code" : "wk"
            },
            "when" : ["MORN"],
            "offset" : 30
          }
        },
        "asNeededCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "428165003",
            "display" : "Renal impairment (disorder)"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationStatement/mii-exa-test-data-onko-medikation-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationStatement/mii-exa-test-data-onko-medikation-3",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "mii-exa-test-data-onko-medikation-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_mii-exa-test-data-onko-medikation-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement mii-exa-test-data-onko-medikation-3</b></p><a name=\"mii-exa-test-data-onko-medikation-3\"> </a><a name=\"hcmii-exa-test-data-onko-medikation-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation\">MII PR Onkologie Systemische Therapie Medikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01XK02}\">Niraparib</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>effective</b>: 2022-01-25 --&gt; (ongoing)</p><p><b>note</b>: </p><blockquote><div><p>Erhaltungstherapie mit PARP-Inhibitor</p>\n</div></blockquote><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>Timing</b></td></tr><tr><td style=\"display: none\">*</td><td>Einschleichen über 2-4 Wochen</td><td>Once</td></tr></table></div>"
      },
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2022",
          "code" : "L01XK02",
          "display" : "Niraparib"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2022-01-25"
      },
      "note" : [{
        "text" : "Erhaltungstherapie mit PARP-Inhibitor"
      }],
      "dosage" : [{
        "text" : "Einschleichen über 2-4 Wochen",
        "timing" : {
          "repeat" : {
            "boundsRange" : {
              "low" : {
                "value" : 2,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              },
              "high" : {
                "value" : 4,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              }
            }
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationStatement/mii-exa-test-data-onko-medikation-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/CarePlan/mii-exa-test-data-onko-tumorkonferenz-1",
    "resource" : {
      "resourceType" : "CarePlan",
      "id" : "mii-exa-test-data-onko-tumorkonferenz-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_mii-exa-test-data-onko-tumorkonferenz-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: CarePlan mii-exa-test-data-onko-tumorkonferenz-1</b></p><a name=\"mii-exa-test-data-onko-tumorkonferenz-1\"> </a><a name=\"hcmii-exa-test-data-onko-tumorkonferenz-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz\">MII PR Onkologie Tumorkonferenz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: TK-2021-001</p><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>category</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ praeth}\">prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>created</b>: 2021-06-20</p><p><b>addresses</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>supportingInfo</b>: <a href=\"DiagnosticReport-mii-exa-test-data-onko-befund-1.html\">Diagnostic Report for 'Pathology report Cancer Narrative' for '-&gt;Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)'</a></p><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Status</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ OP}\">Operation</span></td><td>Scheduled</td></tr></table></blockquote><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Status</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ CH}\">Chemotherapie</span></td><td>Scheduled</td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "value" : "TK-2021-001"
      }],
      "status" : "active",
      "intent" : "plan",
      "category" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ",
          "code" : "praeth",
          "display" : "prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie)"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "created" : "2021-06-20",
      "addresses" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "supportingInfo" : [{
        "reference" : "DiagnosticReport/mii-exa-test-data-onko-befund-1"
      }],
      "activity" : [{
        "detail" : {
          "code" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
              "code" : "OP",
              "display" : "Operation"
            }]
          },
          "status" : "scheduled"
        }
      },
      {
        "detail" : {
          "code" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
              "code" : "CH",
              "display" : "Chemotherapie"
            }]
          },
          "status" : "scheduled"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/CarePlan/mii-exa-test-data-onko-tumorkonferenz-2",
    "resource" : {
      "resourceType" : "CarePlan",
      "id" : "mii-exa-test-data-onko-tumorkonferenz-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_mii-exa-test-data-onko-tumorkonferenz-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: CarePlan mii-exa-test-data-onko-tumorkonferenz-2</b></p><a name=\"mii-exa-test-data-onko-tumorkonferenz-2\"> </a><a name=\"hcmii-exa-test-data-onko-tumorkonferenz-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz\">MII PR Onkologie Tumorkonferenz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: TK-2021-002</p><p><b>status</b>: Completed</p><p><b>intent</b>: Plan</p><p><b>category</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ postop}\">postoperative Tumorkonferenz (Planung der postoperativen Therapie, z. B. zur Frage adjuvante Therapie)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>created</b>: 2021-10-15</p><p><b>addresses</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Status</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ ST}\">Strahlentherapie</span></td><td>Completed</td></tr></table></blockquote><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Status</b></td><td><b>StatusReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ CH}\">Chemotherapie</span></td><td>Cancelled</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieabweichung J}\">ja</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "value" : "TK-2021-002"
      }],
      "status" : "completed",
      "intent" : "plan",
      "category" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ",
          "code" : "postop",
          "display" : "postoperative Tumorkonferenz (Planung der postoperativen Therapie, z. B. zur Frage adjuvante Therapie)"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "created" : "2021-10-15",
      "addresses" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "activity" : [{
        "detail" : {
          "code" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
              "code" : "ST",
              "display" : "Strahlentherapie"
            }]
          },
          "status" : "completed"
        }
      },
      {
        "detail" : {
          "code" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
              "code" : "CH",
              "display" : "Chemotherapie"
            }]
          },
          "status" : "cancelled",
          "statusReason" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieabweichung",
              "code" : "J",
              "display" : "ja"
            }]
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/CarePlan/mii-exa-test-data-onko-tumorkonferenz-molekular-1",
    "resource" : {
      "resourceType" : "CarePlan",
      "id" : "mii-exa-test-data-onko-tumorkonferenz-molekular-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_mii-exa-test-data-onko-tumorkonferenz-molekular-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: CarePlan mii-exa-test-data-onko-tumorkonferenz-molekular-1</b></p><a name=\"mii-exa-test-data-onko-tumorkonferenz-molekular-1\"> </a><a name=\"hcmii-exa-test-data-onko-tumorkonferenz-molekular-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz\">MII PR Onkologie Tumorkonferenz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: MTB-2022-001</p><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>category</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ praeth}\">Molekulares Tumorboard</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>created</b>: 2022-03-10</p><p><b>addresses</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Status</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ ZS}\">Zielgerichtete Substanzen</span></td><td>Scheduled</td></tr></table></blockquote><blockquote><p><b>activity</b></p><p><b>progress</b>: </p><blockquote><div><p>BRCA1 mutation detected - PARP inhibitor recommended</p>\n</div></blockquote><p><b>reference</b>: <a href=\"RequestGroup-mii-exa-test-data-onko-therapieempfehlung-parp-1.html\">RequestGroup Zielgerichtete Substanzen</a></p></blockquote></div>"
      },
      "identifier" : [{
        "value" : "MTB-2022-001"
      }],
      "status" : "active",
      "intent" : "plan",
      "category" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ",
          "code" : "praeth",
          "display" : "prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie)"
        }],
        "text" : "Molekulares Tumorboard"
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "created" : "2022-03-10",
      "addresses" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "activity" : [{
        "detail" : {
          "code" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
              "code" : "ZS",
              "display" : "Zielgerichtete Substanzen"
            }]
          },
          "status" : "scheduled"
        }
      },
      {
        "progress" : [{
          "text" : "BRCA1 mutation detected - PARP inhibitor recommended"
        }],
        "reference" : {
          "reference" : "RequestGroup/mii-exa-test-data-onko-therapieempfehlung-parp-1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-molekular-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-onko-therapieempfehlung-op-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-onko-therapieempfehlung-op-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-operation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-onko-therapieempfehlung-op-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-onko-therapieempfehlung-op-1</b></p><a name=\"mii-exa-test-data-onko-therapieempfehlung-op-1\"> </a><a name=\"hcmii-exa-test-data-onko-therapieempfehlung-op-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-operation\">MII PR Onkologie Therapieempfehlung Operation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: TE-OP-2021-001</p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>status</b>: Active</p><p><b>intent</b>: Proposal</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 5-547.0}\">Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>authoredOn</b>: 2021-06-20</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>supportingInfo</b>: <a href=\"DiagnosticReport-mii-exa-test-data-onko-befund-1.html\">Diagnostic Report for 'Pathology report Cancer Narrative' for '-&gt;Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)'</a></p></div>"
      },
      "identifier" : [{
        "value" : "TE-OP-2021-001"
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "status" : "active",
      "intent" : "proposal",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "5-547.0",
          "display" : "Resektion von Gewebe in der Bauchregion ohne sichere Organzuordnung: Intraperitoneal"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "authoredOn" : "2021-06-20",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "supportingInfo" : [{
        "reference" : "DiagnosticReport/mii-exa-test-data-onko-befund-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-onko-therapieempfehlung-op-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-1",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-onko-therapieempfehlung-medikation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-onko-therapieempfehlung-medikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-onko-therapieempfehlung-medikation-1</b></p><a name=\"mii-exa-test-data-onko-therapieempfehlung-medikation-1\"> </a><a name=\"hcmii-exa-test-data-onko-therapieempfehlung-medikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation\">MII PR Onkologie Therapieempfehlung Medikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/onko-beschluss</code>/TE-MED-2021-001</p><p><b>status</b>: Active</p><p><b>intent</b>: Proposal</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01XA02}\">Carboplatin AUC5 i.v.</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>supportingInformation</b>: <a href=\"Observation-mii-exa-test-data-onko-genetische-variante-1.html\">Observation Genetic variant assessment</a></p><p><b>authoredOn</b>: 2021-06-20</p><p><b>requester</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C56}\">Bösartige Neubildung des Ovars</span></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>text</b>: AUC5 i.v. Tag 1, alle 21 Tage</p><p><b>timing</b>: Events: 2021-07-05 09:00:00+0200 , Count 3  times, Duration 60days , 1-1 per 21-28 days</p><p><b>asNeeded</b>: false</p><p><b>site</b>: <span title=\"Codes:{http://snomed.info/sct 368049005}\">Structure of vein of upper extremity (body structure)</span></p><p><b>route</b>: <span title=\"Codes:{http://snomed.info/sct 47625008}\">Intravenous route (qualifier value)</span></p><blockquote><p><b>doseAndRate</b></p><p><b>dose</b>: 450 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>rate</b>: 450 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Stunde<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeh = 'h')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>dose</b>: 400-450 mg</p><p><b>rate</b>: 450 mg/h<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/h = 'mg/h')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>rate</b>: 300-500 mg/h</p></blockquote><p><b>maxDosePerPeriod</b>: 450 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/21 Tage<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  coded = 'd')</span></p><p><b>maxDosePerAdministration</b>: 450 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p></blockquote><h3>Substitutions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Allowed[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>false</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/onko-beschluss",
        "value" : "TE-MED-2021-001"
      }],
      "status" : "active",
      "intent" : "proposal",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2021",
          "code" : "L01XA02",
          "display" : "Carboplatin"
        }],
        "text" : "Carboplatin AUC5 i.v."
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "supportingInformation" : [{
        "reference" : "Observation/mii-exa-test-data-onko-genetische-variante-1"
      }],
      "authoredOn" : "2021-06-20",
      "requester" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "C56",
          "display" : "Bösartige Neubildung des Ovars"
        }]
      }],
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "dosageInstruction" : [{
        "sequence" : 1,
        "text" : "AUC5 i.v. Tag 1, alle 21 Tage",
        "timing" : {
          "event" : ["2021-07-05T09:00:00+02:00"],
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2021-07-05",
              "end" : "2021-09-05"
            },
            "count" : 3,
            "countMax" : 6,
            "duration" : 60,
            "durationMax" : 90,
            "durationUnit" : "min",
            "frequency" : 1,
            "frequencyMax" : 1,
            "period" : 21,
            "periodMax" : 28,
            "periodUnit" : "d",
            "dayOfWeek" : ["mon"],
            "timeOfDay" : ["09:00:00"]
          }
        },
        "asNeededBoolean" : false,
        "site" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "368049005",
            "display" : "Structure of vein of upper extremity (body structure)"
          }]
        },
        "route" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "47625008",
            "display" : "Intravenous route (qualifier value)"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 450,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "rateRatio" : {
            "numerator" : {
              "value" : 450,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "Stunde",
              "system" : "http://unitsofmeasure.org",
              "code" : "h"
            }
          }
        },
        {
          "doseRange" : {
            "low" : {
              "value" : 400,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "high" : {
              "value" : 450,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            }
          },
          "rateQuantity" : {
            "value" : 450,
            "unit" : "mg/h",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg/h"
          }
        },
        {
          "rateRange" : {
            "low" : {
              "value" : 300,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            },
            "high" : {
              "value" : 500,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            }
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 450,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 21,
            "unit" : "Tage",
            "system" : "http://unitsofmeasure.org",
            "code" : "d"
          }
        },
        "maxDosePerAdministration" : {
          "value" : 450,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        }
      }],
      "substitution" : {
        "allowedBoolean" : false
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-2",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-onko-therapieempfehlung-medikation-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-onko-therapieempfehlung-medikation-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-onko-therapieempfehlung-medikation-2</b></p><a name=\"mii-exa-test-data-onko-therapieempfehlung-medikation-2\"> </a><a name=\"hcmii-exa-test-data-onko-therapieempfehlung-medikation-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation\">MII PR Onkologie Therapieempfehlung Medikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Proposal</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01CD01}\">Paclitaxel</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>authoredOn</b>: 2021-06-20</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>Timing</b></td><td><b>AsNeeded[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>175 mg/m2 i.v. bei Bedarf nach Vertraeglichkeit</td><td>30min , Morning, Once</td><td><span title=\"Codes:{http://snomed.info/sct 422587007}\">Nausea (finding)</span></td></tr></table><p><b>priorPrescription</b>: <a href=\"MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-medikation-1.html\">MedicationRequest: identifier = https://www.charite.de/fhir/sid/onko-beschluss#TE-MED-2021-001; status = active; intent = proposal; medication[x] = Carboplatin; authoredOn = 2021-06-20; reasonCode = Bösartige Neubildung des Ovars</a></p></div>"
      },
      "status" : "active",
      "intent" : "proposal",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2021",
          "code" : "L01CD01",
          "display" : "Paclitaxel"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "authoredOn" : "2021-06-20",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "dosageInstruction" : [{
        "text" : "175 mg/m2 i.v. bei Bedarf nach Vertraeglichkeit",
        "timing" : {
          "repeat" : {
            "boundsDuration" : {
              "value" : 8,
              "unit" : "Wochen",
              "system" : "http://unitsofmeasure.org",
              "code" : "wk"
            },
            "when" : ["MORN"],
            "offset" : 30
          }
        },
        "asNeededCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "422587007",
            "display" : "Nausea (finding)"
          }]
        }
      }],
      "priorPrescription" : {
        "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/RequestGroup/mii-exa-test-data-onko-therapieempfehlung-kombi-1",
    "resource" : {
      "resourceType" : "RequestGroup",
      "id" : "mii-exa-test-data-onko-therapieempfehlung-kombi-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RequestGroup_mii-exa-test-data-onko-therapieempfehlung-kombi-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RequestGroup mii-exa-test-data-onko-therapieempfehlung-kombi-1</b></p><a name=\"mii-exa-test-data-onko-therapieempfehlung-kombi-1\"> </a><a name=\"hcmii-exa-test-data-onko-therapieempfehlung-kombi-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie\">MII PR Onkologie Therapieempfehlung Kombinationstherapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: TE-KOMBI-2021-001</p><p><b>status</b>: Active</p><p><b>intent</b>: Proposal</p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ CH}\">Carboplatin + Paclitaxel (CarboTax)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>authoredOn</b>: 2021-06-20</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><blockquote><p><b>action</b></p><p><b>title</b>: CarboTax Chemotherapie</p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ CH}\">Chemotherapie</span></p><h3>Actions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Title</b></td><td><b>Resource</b></td></tr><tr><td style=\"display: none\">*</td><td>Carboplatin</td><td><a href=\"MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-medikation-1.html\">MedicationRequest: identifier = https://www.charite.de/fhir/sid/onko-beschluss#TE-MED-2021-001; status = active; intent = proposal; medication[x] = Carboplatin; authoredOn = 2021-06-20; reasonCode = Bösartige Neubildung des Ovars</a></td></tr><tr><td style=\"display: none\">*</td><td>Paclitaxel</td><td><a href=\"MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-medikation-2.html\">MedicationRequest: status = active; intent = proposal; medication[x] = Paclitaxel; authoredOn = 2021-06-20</a></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "value" : "TE-KOMBI-2021-001"
      }],
      "status" : "active",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
          "code" : "CH",
          "display" : "Chemotherapie"
        }],
        "text" : "Carboplatin + Paclitaxel (CarboTax)"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "authoredOn" : "2021-06-20",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "action" : [{
        "title" : "CarboTax Chemotherapie",
        "code" : [{
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
            "code" : "CH",
            "display" : "Chemotherapie"
          }]
        }],
        "action" : [{
          "title" : "Carboplatin",
          "resource" : {
            "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-1"
          }
        },
        {
          "title" : "Paclitaxel",
          "resource" : {
            "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-2"
          }
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "RequestGroup/mii-exa-test-data-onko-therapieempfehlung-kombi-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/RequestGroup/mii-exa-test-data-onko-therapieempfehlung-parp-1",
    "resource" : {
      "resourceType" : "RequestGroup",
      "id" : "mii-exa-test-data-onko-therapieempfehlung-parp-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RequestGroup_mii-exa-test-data-onko-therapieempfehlung-parp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RequestGroup mii-exa-test-data-onko-therapieempfehlung-parp-1</b></p><a name=\"mii-exa-test-data-onko-therapieempfehlung-parp-1\"> </a><a name=\"hcmii-exa-test-data-onko-therapieempfehlung-parp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie\">MII PR Onkologie Therapieempfehlung Kombinationstherapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Proposal</p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ ZS}\">PARP-Inhibitor Erhaltungstherapie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>authoredOn</b>: 2022-03-10</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><h3>Actions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Title</b></td><td><b>Description</b></td><td><b>Resource</b></td></tr><tr><td style=\"display: none\">*</td><td>Niraparib Erhaltung</td><td>PARP-Inhibitor basierend auf BRCA1 Mutationsstatus</td><td><a href=\"MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-niraparib.html\">MedicationRequest: status = active; intent = option; medication[x] = Niraparib; authoredOn = 2022-03-10; note = Erhaltungstherapie bei BRCA1-positivem Ovarialkarzinom</a></td></tr></table></div>"
      },
      "status" : "active",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
          "code" : "ZS",
          "display" : "Zielgerichtete Substanzen"
        }],
        "text" : "PARP-Inhibitor Erhaltungstherapie"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "authoredOn" : "2022-03-10",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "action" : [{
        "title" : "Niraparib Erhaltung",
        "description" : "PARP-Inhibitor basierend auf BRCA1 Mutationsstatus",
        "resource" : {
          "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-niraparib"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "RequestGroup/mii-exa-test-data-onko-therapieempfehlung-parp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-niraparib",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-onko-therapieempfehlung-niraparib",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-onko-therapieempfehlung-niraparib\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-onko-therapieempfehlung-niraparib</b></p><a name=\"mii-exa-test-data-onko-therapieempfehlung-niraparib\"> </a><a name=\"hcmii-exa-test-data-onko-therapieempfehlung-niraparib\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation\">MII PR Onkologie Therapieempfehlung Medikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Option</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01XK02}\">Niraparib</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>authoredOn</b>: 2022-03-10</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>note</b>: </p><blockquote><div><p>Erhaltungstherapie bei BRCA1-positivem Ovarialkarzinom</p>\n</div></blockquote><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>Timing</b></td></tr><tr><td style=\"display: none\">*</td><td>Einschleichen über 2-4 Wochen</td><td>Once</td></tr></table></div>"
      },
      "status" : "active",
      "intent" : "option",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2022",
          "code" : "L01XK02",
          "display" : "Niraparib"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "authoredOn" : "2022-03-10",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "note" : [{
        "text" : "Erhaltungstherapie bei BRCA1-positivem Ovarialkarzinom"
      }],
      "dosageInstruction" : [{
        "text" : "Einschleichen über 2-4 Wochen",
        "timing" : {
          "repeat" : {
            "boundsRange" : {
              "low" : {
                "value" : 2,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              },
              "high" : {
                "value" : 4,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              }
            }
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-niraparib"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/AdverseEvent/mii-exa-test-data-onko-nebenwirkung-1",
    "resource" : {
      "resourceType" : "AdverseEvent",
      "id" : "mii-exa-test-data-onko-nebenwirkung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-nebenwirkung-adverse-event"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdverseEvent_mii-exa-test-data-onko-nebenwirkung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdverseEvent mii-exa-test-data-onko-nebenwirkung-1</b></p><a name=\"mii-exa-test-data-onko-nebenwirkung-1\"> </a><a name=\"hcmii-exa-test-data-onko-nebenwirkung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-nebenwirkung-adverse-event\">MII PR Onkologie Nebenwirkung von Strahlentherapie und systemische Therapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onkologie Nebenwirkung CTCAE-Version</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-version 5.0}\">CTCAE Version 5.0</span></p><p><b>actuality</b>: Adverse Event</p><p><b>event</b>: <span title=\"Codes:{https://www.meddra.org 10016256}\">Fatigue nach Chemotherapie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>date</b>: 2021-08-15</p><p><b>seriousness</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-grad 2}\">CTCAE Grad 2 - Mäßig</span></p><h3>SuspectEntities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Instance</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-nebenwirkung-ctcae-version",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-version",
            "code" : "5.0",
            "display" : "CTCAE Version 5.0"
          }]
        }
      }],
      "actuality" : "actual",
      "event" : {
        "coding" : [{
          "system" : "https://www.meddra.org",
          "version" : "Version 27.0",
          "code" : "10016256",
          "display" : "Fatigue"
        }],
        "text" : "Fatigue nach Chemotherapie"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "date" : "2021-08-15",
      "seriousness" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-grad",
          "code" : "2",
          "display" : "moderat"
        }],
        "text" : "CTCAE Grad 2 - Mäßig"
      },
      "suspectEntity" : [{
        "instance" : {
          "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "AdverseEvent/mii-exa-test-data-onko-nebenwirkung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/AdverseEvent/mii-exa-test-data-onko-nebenwirkung-2",
    "resource" : {
      "resourceType" : "AdverseEvent",
      "id" : "mii-exa-test-data-onko-nebenwirkung-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-nebenwirkung-adverse-event"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdverseEvent_mii-exa-test-data-onko-nebenwirkung-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdverseEvent mii-exa-test-data-onko-nebenwirkung-2</b></p><a name=\"mii-exa-test-data-onko-nebenwirkung-2\"> </a><a name=\"hcmii-exa-test-data-onko-nebenwirkung-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-nebenwirkung-adverse-event\">MII PR Onkologie Nebenwirkung von Strahlentherapie und systemische Therapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onkologie Nebenwirkung CTCAE-Version</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-version 5.0}\">CTCAE Version 5.0</span></p><p><b>actuality</b>: Adverse Event</p><p><b>event</b>: <span title=\"Codes:{https://www.meddra.org 10032759}\">Polyneuropathy</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>date</b>: 2022-04-01</p><p><b>seriousness</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-grad 3}\">schwerwiegend</span></p><h3>SuspectEntities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Instance</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Procedure-mii-exa-test-data-onko-strahlentherapie-1.html\">Procedure Hochvoltstrahlentherapie</a></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-nebenwirkung-ctcae-version",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-version",
            "code" : "5.0",
            "display" : "CTCAE Version 5.0"
          }]
        }
      }],
      "actuality" : "actual",
      "event" : {
        "coding" : [{
          "system" : "https://www.meddra.org",
          "version" : "Version 27.0",
          "code" : "10032759",
          "display" : "Polyneuropathy"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "date" : "2022-04-01",
      "seriousness" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-nebenwirkung-ctcae-grad",
          "code" : "3",
          "display" : "schwerwiegend"
        }]
      },
      "suspectEntity" : [{
        "instance" : {
          "reference" : "Procedure/mii-exa-test-data-onko-strahlentherapie-1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "AdverseEvent/mii-exa-test-data-onko-nebenwirkung-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-verlauf-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-verlauf-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-verlauf-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-verlauf-1</b></p><a name=\"mii-exa-test-data-onko-verlauf-1\"> </a><a name=\"hcmii-exa-test-data-onko-verlauf-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf\">MII PR Onkologie Verlauf</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: VERLAUF-001</p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 396432002}\">Status of regression of tumor (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2022-06-15</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-gesamtbeurteilung V}\">Vollremission (complete remission, CR)</span></p><p><b>hasMember</b>: <a href=\"Observation-mii-exa-test-data-onko-fernmetastasen-1.html\">Observation Site of distant metastasis</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 445200009}\">Status of residual neoplasm (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-primaertumor K}\">kein Tumor nachweisbar</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399656008}\">Presence of metastatic neoplasm in regional lymph node (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-lymphknoten K}\">kein Lymphknotenbefall nachweisbar</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399608002}\">Status of distant metastasis (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-fernmetastasen K}\">keine Fernmetastasen nachweisbar</span></p></blockquote></div>"
      },
      "identifier" : [{
        "value" : "VERLAUF-001"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "396432002",
          "display" : "Status of regression of tumor (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2022-06-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-gesamtbeurteilung",
          "code" : "V",
          "display" : "Vollremission (complete remission, CR)"
        }]
      },
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-onko-fernmetastasen-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "445200009",
            "display" : "Status of residual neoplasm (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-primaertumor",
            "code" : "K",
            "display" : "kein Tumor nachweisbar"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "399656008",
            "display" : "Presence of metastatic neoplasm in regional lymph node (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-lymphknoten",
            "code" : "K",
            "display" : "kein Lymphknotenbefall nachweisbar"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "399608002",
            "display" : "Status of distant metastasis (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-fernmetastasen",
            "code" : "K",
            "display" : "keine Fernmetastasen nachweisbar"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-verlauf-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-verlauf-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-verlauf-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-verlauf-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-verlauf-2</b></p><a name=\"mii-exa-test-data-onko-verlauf-2\"> </a><a name=\"hcmii-exa-test-data-onko-verlauf-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf\">MII PR Onkologie Verlauf</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 396432002}\">Status of regression of tumor (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>effective</b>: 2023-01-20</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-gesamtbeurteilung T}\">Teilremission (partial remission, PR)</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 445200009}\">Status of residual neoplasm (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-primaertumor K}\">kein Tumor nachweisbar</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399656008}\">Presence of metastatic neoplasm in regional lymph node (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-lymphknoten P}\">bekannter Lymphknotenbefall Progress</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399608002}\">Status of distant metastasis (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-fernmetastasen K}\">keine Fernmetastasen nachweisbar</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "396432002",
          "display" : "Status of regression of tumor (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "effectiveDateTime" : "2023-01-20",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-gesamtbeurteilung",
          "code" : "T",
          "display" : "Teilremission (partial remission, PR)"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "445200009",
            "display" : "Status of residual neoplasm (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-primaertumor",
            "code" : "K",
            "display" : "kein Tumor nachweisbar"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "399656008",
            "display" : "Presence of metastatic neoplasm in regional lymph node (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-lymphknoten",
            "code" : "P",
            "display" : "bekannter Lymphknotenbefall Progress"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "399608002",
            "display" : "Status of distant metastasis (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-fernmetastasen",
            "code" : "K",
            "display" : "keine Fernmetastasen nachweisbar"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-verlauf-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tod-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tod-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tod"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tod-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tod-1</b></p><a name=\"mii-exa-test-data-onko-tod-1\"> </a><a name=\"hcmii-exa-test-data-onko-tod-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tod\">MII PR Onkologie Tod</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 184305005}\">Cause of death</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2024-05-15</p><p><b>value</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C56}\">Bösartige Neubildung des Ovars</span></p><p><b>interpretation</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tod J}\">Ja, die Person ist an einer Tumorerkrankung oder Folge einer Tumorerkrankung (einschließlich Behandlungskomplikation) verstorben.</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "184305005",
          "display" : "Cause of death"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2024-05-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2026",
          "code" : "C56",
          "display" : "Bösartige Neubildung des Ovars"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tod",
          "code" : "J",
          "display" : "Ja, die Person ist an einer Tumorerkrankung oder Folge einer Tumorerkrankung (einschließlich Behandlungskomplikation) verstorben."
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tod-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-tod-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-tod-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tod"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-tod-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-tod-2</b></p><a name=\"mii-exa-test-data-onko-tod-2\"> </a><a name=\"hcmii-exa-test-data-onko-tod-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tod\">MII PR Onkologie Tod</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 184305005}\">Cause of death</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>effective</b>: 2024-06-01</p><p><b>interpretation</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tod U}\">unbekannt</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "184305005",
          "display" : "Cause of death"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "effectiveDateTime" : "2024-06-01",
      "interpretation" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-tod",
          "code" : "U",
          "display" : "unbekannt"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-tod-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-genetische-variante-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-genetische-variante-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-genetische-variante"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-genetische-variante-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-genetische-variante-1</b></p><a name=\"mii-exa-test-data-onko-genetische-variante-1\"> </a><a name=\"hcmii-exa-test-data-onko-genetische-variante-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-genetische-variante\">MII PR Onkologie Genetische Variante</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-15</p><p><b>issued</b>: 2021-06-16 09:00:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>interpretation</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-genetische-variante-auspraegung M}\">Mutation/positiv</span></p><p><b>note</b>: </p><blockquote><div><p>BRCA1 pathogene Variante nachgewiesen</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-onko-sequencer-1.html\">Device: status = active; manufacturer = Illumina</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org HGNC:1100}\">BRCA1</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs conclusion-string}\">Conclusion Text</span></p><p><b>value</b>: Pathogene BRCA1-Frameshift-Variante c.68_69del (p.Glu23fs) nachgewiesen.</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48001-2}\">Cytogenetic (chromosome) location</span></p><p><b>value</b>: <span title=\"Codes:\">17q21.31</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 62374-4}\">Human reference sequence assembly version</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA26806-2}\">GRCh38</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48000-4}\">Chromosome [Identifier] in Blood or Tissue by Molecular genetics method</span></p><p><b>value</b>: <span title=\"Codes:\">Chromosom 17</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48004-6}\">DNA change (c.HGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org NM_007294.4:c.68_69del}\">NM_007294.4:c.68_69del</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81290-9}\">Genomic DNA change (gHGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org NC_000017.11:g.43124027_43124028del}\">NC_000017.11:g.43124027_43124028del</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48005-3}\">Amino acid change (pHGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org NP_009225.1:p.Glu23fs}\">NP_009225.1:p.Glu23fs</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48013-7}\">Genomic reference sequence [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.ncbi.nlm.nih.gov/refseq NC_000017.11}\">NC_000017.11</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 51958-7}\">Transcript reference sequence [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.ncbi.nlm.nih.gov/refseq NM_007294.4}\">NM_007294.4</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81254-5}\">Genomic allele start-end</span></p><p><b>value</b>: 43124027-43124028</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81302-2}\">Structural variant inner start and end</span></p><p><b>value</b>: 43124027-43124028</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81301-4}\">Structural variant outer start and end</span></p><p><b>value</b>: 43124020-43124035</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69547-8}\">Genomic ref allele [ID]</span></p><p><b>value</b>: TTC</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69551-0}\">Genomic alt allele [ID]</span></p><p><b>value</b>: T</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48019-4}\">DNA change type</span></p><p><b>value</b>: <span title=\"Codes:{http://www.sequenceontology.org SO:0000159}\">deletion</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48002-0}\">Genomic source class [Type]</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6684-0}\">Somatic</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81258-6}\">Sample variant allelic frequency [NFr]</span></p><p><b>value</b>: 34 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 82121-5}\">Allelic read depth</span></p><p><b>value</b>: 120</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 53034-5}\">Allelic state</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6706-1}\">Heterozygous</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 94186-4}\">Origin of germline genetic variant [Type]</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6684-0}\">Somatisch</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81252-9}\">Discrete genetic variant</span></p><p><b>value</b>: <span title=\"Codes:{http://www.ncbi.nlm.nih.gov/clinvar 17662}\">NM_007294.4(BRCA1):c.68_69del</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 82155-3}\">Genomic structural variant copy number</span></p><p><b>value</b>: 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs variant-confidence-status}\">Variant Confidence Status</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs high}\">hohe Konfidenz</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 87706-8}\">Laboratory device Detection limit</span></p><p><b>value</b>: 5 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 47999-8}\">DNA region name [Identifier]</span></p><p><b>value</b>: Exon 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 95123-6}\">Gene fusion transcript details in Blood or Tissue by Molecular genetics method Narrative</span></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 260415000}\">keine Genfusion nachweisbar</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-15",
      "issued" : "2021-06-16T09:00:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-genetische-variante-auspraegung",
          "code" : "M",
          "display" : "Mutation/positiv"
        }]
      }],
      "note" : [{
        "text" : "BRCA1 pathogene Variante nachgewiesen"
      }],
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-onko-sequencer-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org",
            "code" : "HGNC:1100",
            "display" : "BRCA1"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "conclusion-string"
          }]
        },
        "valueString" : "Pathogene BRCA1-Frameshift-Variante c.68_69del (p.Glu23fs) nachgewiesen."
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48001-2"
          }]
        },
        "valueCodeableConcept" : {
          "text" : "17q21.31"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "62374-4"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26806-2",
            "display" : "GRCh38"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48000-4"
          }]
        },
        "valueCodeableConcept" : {
          "text" : "Chromosom 17"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48004-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "NM_007294.4:c.68_69del"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81290-9"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "NC_000017.11:g.43124027_43124028del"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48005-3"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "NP_009225.1:p.Glu23fs"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48013-7"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.ncbi.nlm.nih.gov/refseq",
            "code" : "NC_000017.11"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "51958-7"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.ncbi.nlm.nih.gov/refseq",
            "code" : "NM_007294.4"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81254-5"
          }]
        },
        "valueRange" : {
          "low" : {
            "value" : 43124027
          },
          "high" : {
            "value" : 43124028
          }
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81302-2"
          }]
        },
        "valueRange" : {
          "low" : {
            "value" : 43124027
          },
          "high" : {
            "value" : 43124028
          }
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81301-4"
          }]
        },
        "valueRange" : {
          "low" : {
            "value" : 43124020
          },
          "high" : {
            "value" : 43124035
          }
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "69547-8"
          }]
        },
        "valueString" : "TTC"
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "69551-0"
          }]
        },
        "valueString" : "T"
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48019-4"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.sequenceontology.org",
            "code" : "SO:0000159",
            "display" : "deletion"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48002-0"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6684-0",
            "display" : "Somatic"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81258-6"
          }]
        },
        "valueQuantity" : {
          "value" : 34,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "82121-5"
          }]
        },
        "valueQuantity" : {
          "value" : 120
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "53034-5"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6706-1",
            "display" : "Heterozygous"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "94186-4"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6684-0",
            "display" : "Somatic"
          }],
          "text" : "Somatisch"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81252-9"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.ncbi.nlm.nih.gov/clinvar",
            "code" : "17662",
            "display" : "NM_007294.4(BRCA1):c.68_69del"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "82155-3"
          }]
        },
        "valueQuantity" : {
          "value" : 2
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "variant-confidence-status"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs",
            "code" : "high",
            "display" : "High"
          }],
          "text" : "hohe Konfidenz"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "87706-8"
          }]
        },
        "valueQuantity" : {
          "value" : 5,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "47999-8"
          }]
        },
        "valueString" : "Exon 2"
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "95123-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "260415000",
            "display" : "Not detected"
          }],
          "text" : "keine Genfusion nachweisbar"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-genetische-variante-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-genetische-variante-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-genetische-variante-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-genetische-variante"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-genetische-variante-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-genetische-variante-2</b></p><a name=\"mii-exa-test-data-onko-genetische-variante-2\"> </a><a name=\"hcmii-exa-test-data-onko-genetische-variante-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-genetische-variante\">MII PR Onkologie Genetische Variante</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>effective</b>: 2021-06-15</p><p><b>interpretation</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-genetische-variante-auspraegung W}\">Wildtyp/nicht mutiert/ negativ</span></p><p><b>note</b>: </p><blockquote><div><p>KRAS Wildtyp (keine Mutation nachweisbar)</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "effectiveDateTime" : "2021-06-15",
      "interpretation" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-genetische-variante-auspraegung",
          "code" : "W",
          "display" : "Wildtyp/nicht mutiert/ negativ"
        }]
      }],
      "note" : [{
        "text" : "KRAS Wildtyp (keine Mutation nachweisbar)"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-genetische-variante-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-studienteilnahme-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-studienteilnahme-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-studienteilnahme"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-studienteilnahme-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-studienteilnahme-1</b></p><a name=\"mii-exa-test-data-onko-studienteilnahme-1\"> </a><a name=\"hcmii-exa-test-data-onko-studienteilnahme-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-studienteilnahme\">MII PR Onkologie Studienteilnahme</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 709491003}\">Enrollment in clinical trial</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: </p><ul><li><a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></li><li>OVAR-21 Studie</li></ul><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-07-01</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-studienteilnahme J}\">Ja</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "709491003",
          "display" : "Enrollment in clinical trial"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      },
      {
        "display" : "OVAR-21 Studie"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-07-01",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-studienteilnahme",
          "code" : "J",
          "display" : "Ja"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-studienteilnahme-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-studienteilnahme-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-studienteilnahme-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-studienteilnahme"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-studienteilnahme-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-studienteilnahme-2</b></p><a name=\"mii-exa-test-data-onko-studienteilnahme-2\"> </a><a name=\"hcmii-exa-test-data-onko-studienteilnahme-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-studienteilnahme\">MII PR Onkologie Studienteilnahme</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 709491003}\">Enrollment in clinical trial</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>effective</b>: 2021-07-01</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-studienteilnahme N}\">Nein</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "709491003",
          "display" : "Enrollment in clinical trial"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "effectiveDateTime" : "2021-07-01",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-studienteilnahme",
          "code" : "N",
          "display" : "Nein"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-studienteilnahme-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-mamma-menopause-status-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-mamma-menopause-status-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-menopause-status"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-mamma-menopause-status-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-mamma-menopause-status-1</b></p><a name=\"mii-exa-test-data-onko-mamma-menopause-status-1\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-menopause-status-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-menopause-status\">MII PR Onkologie Menopausenstatus Mamma</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 161712005}\">Menopause, function (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-15</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 22636003}\">Premenopausal state (finding)</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "161712005",
          "display" : "Menopause, function (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "22636003",
          "display" : "Premenopausal state (finding)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-mamma-menopause-status-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-estrogen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1</b></p><a name=\"mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-estrogen\">MII PR Onkologie Rezeptorstatus Estrogen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 40556-3}\">Estrogen receptor Ag [Presence] in Tissue by Immune stain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-18</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-rezeptorstatus-leitlinie positiv}\">Positive</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1234804006}\">Percent of cells with estrogen receptor in primary malignant neoplasm of breast by immunohistochemistry (observable entity)</span></p><p><b>value</b>: 85 %</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1236874005}\">Intensity of stain of estrogen receptor in primary malignant neoplasm of breast by immunohistochemistry (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA13035-3}\">Impaired</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "40556-3",
          "display" : "Estrogen receptor Ag [Presence] in Tissue by Immune stain"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-18",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-rezeptorstatus-leitlinie",
          "code" : "positiv",
          "display" : "positiv"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1234804006",
            "display" : "Percent of cells with estrogen receptor in primary malignant neoplasm of breast by immunohistochemistry (observable entity)"
          }]
        },
        "valueQuantity" : {
          "value" : 85,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "H",
            "display" : "High"
          }]
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1236874005",
            "display" : "Intensity of stain of estrogen receptor in primary malignant neoplasm of breast by immunohistochemistry (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA13035-3",
            "display" : "Impaired"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-progesteron"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1</b></p><a name=\"mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-progesteron\">MII PR Onkologie Rezeptorstatus Progesteron</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85339-0}\">Progesterone receptor Ag [Presence] in Breast cancer specimen by Immune stain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-18</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-rezeptorstatus-leitlinie positiv}\">Positive</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1234803000}\">Percent of cells with progesterone receptor in primary malignant neoplasm of breast by immunohistochemistry</span></p><p><b>value</b>: 70 %</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1237278006}\">Intensity of stain of progesterone receptor in primary malignant neoplasm of breast by immunohistochemistry (observable entity)</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA13035-3}\">Impaired</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85339-0",
          "display" : "Progesterone receptor Ag [Presence] in Breast cancer specimen by Immune stain"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-18",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-rezeptorstatus-leitlinie",
          "code" : "positiv",
          "display" : "positiv"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1234803000",
            "display" : "Percent of cells with progesterone receptor in primary malignant neoplasm of breast by immunohistochemistry"
          }]
        },
        "valueQuantity" : {
          "value" : 70,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1237278006",
            "display" : "Intensity of stain of progesterone receptor in primary malignant neoplasm of breast by immunohistochemistry (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA13035-3",
            "display" : "Impaired"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-mamma-her2neu-status-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-mamma-her2neu-status-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-her2neu-status"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-mamma-her2neu-status-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-mamma-her2neu-status-1</b></p><a name=\"mii-exa-test-data-onko-mamma-her2neu-status-1\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-her2neu-status-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-her2neu-status\">MII PR Onkologie Her2neu Status</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48676-1}\">HER2 Ag [Interpretation] in Tissue</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-18</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-obds N}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-leitlinie negativ}\">negativ</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 85319-2}\">HER2 Ag [Presence] in Breast cancer specimen by Immune stain</span></td><td><span title=\"Codes:{http://loinc.org LA11840-8}\">Mixed</span></td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48676-1",
          "display" : "HER2 Ag [Interpretation] in Tissue"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-18",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-obds",
          "code" : "N",
          "display" : "negativ"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-leitlinie",
          "code" : "negativ",
          "display" : "HER2-negativ"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "85319-2",
            "display" : "HER2 Ag [Presence] in Breast cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA11840-8",
            "display" : "Mixed"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-mamma-her2neu-status-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-mamma-her2neu-status-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-mamma-her2neu-status-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-her2neu-status"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-mamma-her2neu-status-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-mamma-her2neu-status-2</b></p><a name=\"mii-exa-test-data-onko-mamma-her2neu-status-2\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-her2neu-status-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-her2neu-status\">MII PR Onkologie Her2neu Status</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48676-1}\">HER2 Ag [Interpretation] in Tissue</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-20</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-obds P}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-leitlinie positiv}\">positiv</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85319-2}\">HER2 Ag [Presence] in Breast cancer specimen by Immune stain</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA11843-2}\">3+</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96893-3}\">ERBB2 gene duplication in Tumor by FISH</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}\">Positive</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48676-1",
          "display" : "HER2 Ag [Interpretation] in Tissue"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-20",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-obds",
          "code" : "P",
          "display" : "positiv"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-mamma-her2neu-status-leitlinie",
          "code" : "positiv",
          "display" : "HER2-positiv"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "85319-2",
            "display" : "HER2 Ag [Presence] in Breast cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA11843-2",
            "display" : "3+"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96893-3",
            "display" : "ERBB2 gene duplication in Tumor by FISH"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6576-8",
            "display" : "Positive"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-mamma-her2neu-status-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-mamma-praeop-markierung-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-mamma-praeop-markierung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-praeoperative-markierung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-mamma-praeop-markierung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-mamma-praeop-markierung-1</b></p><a name=\"mii-exa-test-data-onko-mamma-praeop-markierung-1\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-praeop-markierung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-praeoperative-markierung\">MII PR Onkologie Präoperative Markierung Mamma</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-mamma-operation-1.html\">Procedure Partielle (brusterhaltende) Exzision der Mamma: Exzision</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 103693007}\">Diagnostic procedure (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 433222002}\">Insertion of guide wire into breast using ultrasound guidance (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-09-28 08:00:00+0200</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p></div>"
      },
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-mamma-operation-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "103693007",
          "display" : "Diagnostic procedure (procedure)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "433222002",
          "display" : "Insertion of guide wire into breast using ultrasound guidance (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-09-28T08:00:00+02:00",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-mamma-praeop-markierung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-mamma-operation-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-mamma-operation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-operation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-mamma-operation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-mamma-operation-1</b></p><a name=\"mii-exa-test-data-onko-mamma-operation-1\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-operation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-operation\">MII PR Onkologie Mamma Operation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Operation Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-10-01</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>MII EX Onko Operation Urgency</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency E}\">Elektiveingriff</span></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 5-870.0}, {http://snomed.info/sct 392021009}\">Partielle (brusterhaltende) Exzision der Mamma: Exzision</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-09-30</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 76752008}\">Breast structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus R0}\">Kein Residualtumor</span></p><p><b>complication</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation N}\">Nein</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm T81.0}\">Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert</span></p><p><b>note</b>: </p><blockquote><div><p>Brusterhaltende Exzision mit Drahtmarkierung.</p>\n</div></blockquote><p><b>usedCode</b>: <span title=\"Codes:{http://snomed.info/sct 168750009}\">Mammography abnormal</span>, <span title=\"Codes:{http://snomed.info/sct 433222002}\">Insertion of guide wire into breast using ultrasound guidance (procedure)</span></p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-10-01"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-urgency",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency",
            "code" : "E",
            "display" : "Elektiveingriff"
          }],
          "text" : "Elektiveingriff"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "L",
              "display" : "links"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "5-870.0",
          "display" : "Partielle (brusterhaltende) Exzision der Mamma: Exzision"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "392021009",
          "display" : "Lumpectomy of breast (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-09-30",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "76752008",
          "display" : "Breast structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus",
          "code" : "R0",
          "display" : "Kein Residualtumor"
        }]
      },
      "complication" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation",
          "code" : "N",
          "display" : "Nein"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "T81.0",
          "display" : "Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert"
        }]
      }],
      "note" : [{
        "text" : "Brusterhaltende Exzision mit Drahtmarkierung."
      }],
      "usedCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "168750009",
          "display" : "Mammography abnormal"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "433222002",
          "display" : "Insertion of guide wire into breast using ultrasound guidance (procedure)"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-mamma-operation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-mamma-sozialdienst-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-mamma-sozialdienst-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-sozialdienst"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-mamma-sozialdienst-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-mamma-sozialdienst-1</b></p><a name=\"mii-exa-test-data-onko-mamma-sozialdienst-1\"> </a><a name=\"hcmii-exa-test-data-onko-mamma-sozialdienst-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-sozialdienst\">MII PR Onkologie Präoperative Drahtmarkierung Mamma</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Operation Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-10-06</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>MII EX Onko Operation Urgency</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency E}\">Elektiveingriff</span></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-mamma-operation-1.html\">Procedure Partielle (brusterhaltende) Exzision der Mamma: Exzision</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 9-401.5}\">(Neuro-)psychologische und psychosoziale Interventionen: Sozialrechtliche Beratung</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-10-05</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 76752008}\">Breast structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus R0}\">Kein Residualtumor</span></p><p><b>complication</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation N}\">Nein</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm T81.0}\">Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert</span></p><p><b>note</b>: </p><blockquote><div><p>Psychosoziale Beratung durch den Sozialdienst.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-10-06"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-urgency",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency",
            "code" : "E",
            "display" : "Elektiveingriff"
          }],
          "text" : "Elektiveingriff"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-mamma-operation-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "9-401.5",
          "display" : "(Neuro-)psychologische und psychosoziale Interventionen: Sozialrechtliche Beratung"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-10-05",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "76752008",
          "display" : "Breast structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus",
          "code" : "R0",
          "display" : "Kein Residualtumor"
        }]
      },
      "complication" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation",
          "code" : "N",
          "display" : "Nein"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "T81.0",
          "display" : "Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert"
        }]
      }],
      "note" : [{
        "text" : "Psychosoziale Beratung durch den Sozialdienst."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-mamma-sozialdienst-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-psa-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-psa-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-psa"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-psa-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-psa-1</b></p><a name=\"mii-exa-test-data-onko-prostata-psa-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-psa-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-psa\">MII PR Onkologie PSA-Wert</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 2857-1}\">Prostate specific Ag [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-01</p><p><b>value</b>: 12.5</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "2857-1",
          "display" : "Prostate specific Ag [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-01",
      "valueQuantity" : {
        "value" : 12.5
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-psa-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-anzahl-stanzen-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-anzahl-stanzen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-anzahl-stanzen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-anzahl-stanzen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-anzahl-stanzen-1</b></p><a name=\"mii-exa-test-data-onko-prostata-anzahl-stanzen-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-anzahl-stanzen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-anzahl-stanzen\">MII PR Onkologie Prostata Anzahl Stanzen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 44652-6}\">Total number of cores in Tissue core</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-10</p><p><b>value</b>: 12</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "44652-6",
          "display" : "Total number of cores in Tissue core"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-10",
      "valueInteger" : 12
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-anzahl-stanzen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-positive-stanzen-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-positive-stanzen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-anzahl-positive-stanzen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-positive-stanzen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-positive-stanzen-1</b></p><a name=\"mii-exa-test-data-onko-prostata-positive-stanzen-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-positive-stanzen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-anzahl-positive-stanzen\">MII PR Onkologie Prostata Anzahl positiver Stanzen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 44651-8}\">Tissue cores.positive.carcinoma in Tissue core</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-10</p><p><b>value</b>: 4</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "44651-8",
          "display" : "Tissue cores.positive.carcinoma in Tissue core"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-10",
      "valueInteger" : 4
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-positive-stanzen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-ca-befall-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-ca-befall-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-ca-befall-stanze"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-ca-befall-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-ca-befall-1</b></p><a name=\"mii-exa-test-data-onko-prostata-ca-befall-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-ca-befall-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-ca-befall-stanze\">MII PR Onkologie Ca-Befall Stanze</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 44654-2}\">Tissue involved by tumor in Prostate tumor</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-10</p><p><b>value</b>: 65 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "44654-2",
          "display" : "Tissue involved by tumor in Prostate tumor"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-10",
      "valueQuantity" : {
        "value" : 65,
        "unit" : "%",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-ca-befall-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-gleason-primary-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-gleason-primary-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-patterns"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-gleason-primary-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-gleason-primary-1</b></p><a name=\"mii-exa-test-data-onko-prostata-gleason-primary-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-gleason-primary-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-patterns\">MII PR Onkologie Prostata Gleason Pattern</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 384994009}\">Primary Gleason pattern (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-10</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 369772003}\">Gleason Pattern 3</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "384994009",
          "display" : "Primary Gleason pattern (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-10",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "369772003",
          "display" : "Gleason Pattern 3"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-gleason-primary-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-gleason-secondary-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-gleason-secondary-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-patterns"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-gleason-secondary-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-gleason-secondary-1</b></p><a name=\"mii-exa-test-data-onko-prostata-gleason-secondary-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-gleason-secondary-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-patterns\">MII PR Onkologie Prostata Gleason Pattern</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 384995005}\">Secondary Gleason pattern (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>effective</b>: 2021-06-10</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 369773008}\">Gleason Pattern 4</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "384995005",
          "display" : "Secondary Gleason pattern (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "effectiveDateTime" : "2021-06-10",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "369773008",
          "display" : "Gleason Pattern 4"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-gleason-secondary-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-gleason-grade-group-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-gleason-grade-group-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-grade-group"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-gleason-grade-group-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-gleason-grade-group-1</b></p><a name=\"mii-exa-test-data-onko-prostata-gleason-grade-group-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-gleason-grade-group-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-grade-group\">MII PR Onkologie Prostata Gleason Grade Group</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1812491000004107}\">Histologic grade of primary malignant neoplasm of prostate by International Society of Urological Pathology technique (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-10</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 1279714001}\">International Society of Urological Pathology grade group 2 (Gleason score 3 + 4 = 7) (qualifier value)</span></p><p><b>derivedFrom</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-onko-prostata-gleason-primary-1.html\">Observation Primary Gleason pattern (observable entity)</a></li><li><a href=\"Observation-mii-exa-test-data-onko-prostata-gleason-secondary-1.html\">Observation Secondary Gleason pattern (observable entity)</a></li></ul></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1812491000004107",
          "display" : "Histologic grade of primary malignant neoplasm of prostate by International Society of Urological Pathology technique (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-10",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1279714001",
          "display" : "International Society of Urological Pathology grade group 2 (Gleason score 3 + 4 = 7) (qualifier value)"
        }]
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-onko-prostata-gleason-primary-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-gleason-secondary-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-gleason-grade-group-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-prostata-surgery-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-prostata-surgery-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostata-operation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-prostata-surgery-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-prostata-surgery-1</b></p><a name=\"mii-exa-test-data-onko-prostata-surgery-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-surgery-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostata-operation\">MII PR Onko Prostata Operation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Operation Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-07-16</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>MII EX Onko Operation Urgency</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency E}\">Elektiveingriff</span></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 5-604.0}, {http://snomed.info/sct 176258007}\">Radikale Prostatovesikulektomie: Retropubisch</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-07-15</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 41216001}\">Prostatic structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus R0}\">Kein Residualtumor</span></p><p><b>complication</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation N}\">Nein</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm T81.0}\">Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert</span></p><p><b>note</b>: </p><blockquote><div><p>Radikale retropubische Prostatovesikulektomie.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-07-16"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-urgency",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency",
            "code" : "E",
            "display" : "Elektiveingriff"
          }],
          "text" : "Elektiveingriff"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "5-604.0",
          "display" : "Radikale Prostatovesikulektomie: Retropubisch"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "176258007",
          "display" : "Open prostatectomy (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-07-15",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "41216001",
          "display" : "Prostatic structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus",
          "code" : "R0",
          "display" : "Kein Residualtumor"
        }]
      },
      "complication" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation",
          "code" : "N",
          "display" : "Nein"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "T81.0",
          "display" : "Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert"
        }]
      }],
      "note" : [{
        "text" : "Radikale retropubische Prostatovesikulektomie."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-prostata-surgery-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-prostata-komplikation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-prostata-komplikation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-clavien-dindo"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-prostata-komplikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-prostata-komplikation-1</b></p><a name=\"mii-exa-test-data-onko-prostata-komplikation-1\"> </a><a name=\"hcmii-exa-test-data-onko-prostata-komplikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-clavien-dindo\">MII PR Onkologie Clavien Dindo</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 789279006}\">Clavien-Dindo classification grade (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: </p><ul><li><a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></li><li><a href=\"Procedure-mii-exa-test-data-onko-prostata-surgery-1.html\">Procedure Radikale Prostatovesikulektomie: Retropubisch</a></li></ul><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-15</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 1367522003}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-prostata-postsurgical-complications J}\">Clavien-Dindo classification grade IIIa (finding)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-onko-specimen-1.html\">Specimen: identifier = ONKO-SPECIMEN-001; accessionIdentifier = https://www.charite.de/fhir/sid/accession#PATH-2021-12345; status = available; type = Tissue specimen</a></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "789279006",
          "display" : "Clavien-Dindo classification grade (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      },
      {
        "reference" : "Procedure/mii-exa-test-data-onko-prostata-surgery-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1367522003",
          "display" : "Clavien-Dindo classification grade IIIa (finding)"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-prostata-postsurgical-complications",
          "code" : "J",
          "display" : "Ja"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-prostata-komplikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-krk-abstand-anokutan-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-krk-abstand-anokutan-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-anokutan"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-krk-abstand-anokutan-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-krk-abstand-anokutan-1</b></p><a name=\"mii-exa-test-data-onko-krk-abstand-anokutan-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-abstand-anokutan-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-anokutan\">MII PR Onkologie Abstand Anokutan</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 33748-5}\">Distance from anal verge</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-15</p><p><b>value</b>: 10.5 cm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "33748-5",
          "display" : "Distance from anal verge"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-15",
      "valueQuantity" : {
        "value" : 10.5,
        "unit" : "cm",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-krk-abstand-anokutan-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-krk-abstand-crm-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-krk-abstand-crm-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-circumferelle-resektionsebene"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-krk-abstand-crm-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-krk-abstand-crm-1</b></p><a name=\"mii-exa-test-data-onko-krk-abstand-crm-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-abstand-crm-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-circumferelle-resektionsebene\">MII PR Onkologie Abstand Circumferelle Resektionsebene</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 44668-2}\">Deprecated M stage of distant metastasis Qualitative by CAP cancer protocols</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: 3.2 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "44668-2",
          "display" : "Deprecated M stage of distant metastasis Qualitative by CAP cancer protocols"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueQuantity" : {
        "value" : 3.2,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-krk-abstand-crm-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-krk-abstand-aboral-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-krk-abstand-aboral-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-aboral"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-krk-abstand-aboral-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-krk-abstand-aboral-1</b></p><a name=\"mii-exa-test-data-onko-krk-abstand-aboral-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-abstand-aboral-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-aboral\">MII PR Onkologie Abstand Aboral</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81175-2}\">Distance of tumor from closest margin [Length] in Specimen by Macroscopy</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-05</p><p><b>value</b>: 45 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "81175-2",
          "display" : "Distance of tumor from closest margin [Length] in Specimen by Macroscopy"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-05",
      "valueQuantity" : {
        "value" : 45,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-krk-abstand-aboral-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-krk-abstand-mesorektal-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-krk-abstand-mesorektal-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-mrt-mesorektale-faszie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-krk-abstand-mesorektal-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-krk-abstand-mesorektal-1</b></p><a name=\"mii-exa-test-data-onko-krk-abstand-mesorektal-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-abstand-mesorektal-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-mrt-mesorektale-faszie\">MII PR Onkologie KRK MRT/CT Abstand Mesorektale Faszie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{https://radelement.org RDE96}\">Distance to MRF</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-20</p><p><b>value</b>: 8 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "https://radelement.org",
          "code" : "RDE96",
          "display" : "Distance to MRF"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-20",
      "valueQuantity" : {
        "value" : 8,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-krk-abstand-mesorektal-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-anastomoseninsuffizienz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1</b></p><a name=\"mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-anastomoseninsuffizienz-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-anastomoseninsuffizienz\">MII PR Onkologie KRK Anastomoseninsuffizienz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 236091002}\">Large intestine anastomotic leak (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Procedure-mii-exa-test-data-onko-krk-operation-1.html\">Procedure Rektumresektion unter Sphinktererhaltung: Tiefe anteriore Resektion: Offen chirurgisch mit Enterostoma und Blindverschluss</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-10-15</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-krk-anastomoseninsuffizienz K}\">Keine Insuffizienz oder höchstens Grad A</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "236091002",
          "display" : "Large intestine anastomotic leak (disorder)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-krk-operation-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-10-15",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-krk-anastomoseninsuffizienz",
          "code" : "K",
          "display" : "Keine Insuffizienz oder höchstens Grad A"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-krk-stoma-markierung-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-krk-stoma-markierung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-stoma-markierung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-krk-stoma-markierung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-krk-stoma-markierung-1</b></p><a name=\"mii-exa-test-data-onko-krk-stoma-markierung-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-stoma-markierung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-stoma-markierung\">MII PR Onkologie KRK Stoma-Markierung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-09-25</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>status</b>: Completed</p><p><b>statusReason</b>: <span title=\"Codes:{http://snomed.info/sct 397943006}\">Planned (qualifier value)</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 225134005}, {http://fhir.de/CodeSystem/bfarm/ops 5-460}\">Marking position of planned stoma site (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-09-25 10:00:00+0200</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 699600004}\">Structure of left lower quadrant of abdomen (body structure)</span></p><p><b>note</b>: </p><blockquote><div><p>Stomaposition praeoperativ markiert.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-09-25"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "status" : "completed",
      "statusReason" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "397943006",
          "display" : "Planned (qualifier value)"
        }]
      },
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "225134005",
          "display" : "Marking position of planned stoma site (procedure)"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "5-460",
          "display" : "Anlegen eines Enterostomas, doppelläufig, als selbständiger Eingriff"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-09-25T10:00:00+02:00",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "699600004",
          "display" : "Structure of left lower quadrant of abdomen (body structure)"
        }]
      }],
      "note" : [{
        "text" : "Stomaposition praeoperativ markiert."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-krk-stoma-markierung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-krk-operation-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-krk-operation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-operation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-krk-operation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-krk-operation-1</b></p><a name=\"mii-exa-test-data-onko-krk-operation-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-operation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-operation\">MII PR Onkologie Präoperative Drahtmarkierung Mamma</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Operation Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-10-01</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>MII EX Onko Operation Urgency</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency E}\">Elektiveingriff</span></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/ops 5-484.52}\">Rektumresektion unter Sphinktererhaltung: Tiefe anteriore Resektion: Offen chirurgisch mit Enterostoma und Blindverschluss</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-09-30</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 34402009}\">Rectum structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus R0}\">Kein Residualtumor</span></p><p><b>complication</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation N}\">Nein</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm T81.0}\">Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert</span></p><p><b>note</b>: </p><blockquote><div><p>Tiefe anteriore Rektumresektion mit protektivem Enterostoma.</p>\n</div></blockquote><p><b>usedCode</b>: <span title=\"Codes:{http://snomed.info/sct 76164006}\">Biopsy of colon</span></p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-10-01"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-urgency",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency",
            "code" : "E",
            "display" : "Elektiveingriff"
          }],
          "text" : "Elektiveingriff"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "T",
              "display" : "trifft nicht zu"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "5-484.52",
          "display" : "Rektumresektion unter Sphinktererhaltung: Tiefe anteriore Resektion: Offen chirurgisch mit Enterostoma und Blindverschluss"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-09-30",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "34402009",
          "display" : "Rectum structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus",
          "code" : "R0",
          "display" : "Kein Residualtumor"
        }]
      },
      "complication" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation",
          "code" : "N",
          "display" : "Nein"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "T81.0",
          "display" : "Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert"
        }]
      }],
      "note" : [{
        "text" : "Tiefe anteriore Rektumresektion mit protektivem Enterostoma."
      }],
      "usedCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "76164006",
          "display" : "Biopsy of colon"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-krk-operation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-onko-krk-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-onko-krk-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-specimen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-onko-krk-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-onko-krk-specimen-1</b></p><a name=\"mii-exa-test-data-onko-krk-specimen-1\"> </a><a name=\"hcmii-exa-test-data-onko-krk-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-specimen\">MII PR Onkologie Specimen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>accessionIdentifier</b>: <code>https://www.charite.de/fhir/sid/patho/befundbericht</code>/E_21_04711</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119376003}\">Tissue specimen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2021-09-30 11:00:00+0200</td><td><span title=\"Codes:{http://snomed.info/sct 34402009}\">Rectum structure</span></td></tr></table><p><b>condition</b>: <span title=\"Codes:{http://snomed.info/sct 17621005}\">Normal (qualifier value)</span></p></div>"
      },
      "accessionIdentifier" : {
        "system" : "https://www.charite.de/fhir/sid/patho/befundbericht",
        "value" : "E_21_04711"
      },
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119376003",
          "display" : "Tissue specimen"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "collection" : {
        "collectedDateTime" : "2021-09-30T11:00:00+02:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "34402009",
            "display" : "Rectum structure"
          }]
        }
      },
      "condition" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "17621005",
          "display" : "Normal (qualifier value)"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-onko-krk-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-breslow-tiefe-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-breslow-tiefe-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-breslow-tiefe"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-breslow-tiefe-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-breslow-tiefe-1</b></p><a name=\"mii-exa-test-data-onko-melanom-breslow-tiefe-1\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-breslow-tiefe-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-breslow-tiefe\">MII PR Onkologie Melanom Breslow Tiefe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 106243009}\">Breslow depth staging for melanoma of skin (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-20</p><p><b>value</b>: 1.8 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 117617002}\">Immunohistochemistry procedure</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "106243009",
          "display" : "Breslow depth staging for melanoma of skin (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-20",
      "valueQuantity" : {
        "value" : 1.8,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "117617002",
          "display" : "Immunohistochemistry procedure"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-breslow-tiefe-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-breslow-tiefe-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-breslow-tiefe-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-breslow-tiefe"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-breslow-tiefe-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-breslow-tiefe-2</b></p><a name=\"mii-exa-test-data-onko-melanom-breslow-tiefe-2\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-breslow-tiefe-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-breslow-tiefe\">MII PR Onkologie Melanom Breslow Tiefe</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 106243009}\">Breslow depth staging for melanoma of skin (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-20</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "106243009",
          "display" : "Breslow depth staging for melanoma of skin (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-20",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "unknown",
          "display" : "Unknown"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-breslow-tiefe-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-ulzeration-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-ulzeration-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ulzeration"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-ulzeration-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-ulzeration-1</b></p><a name=\"mii-exa-test-data-onko-melanom-ulzeration-1\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-ulzeration-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ulzeration\">MII PR Onkologie Melanom Ulzeration</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 6270001000004106}\">Presence of ulcer in primary malignant melanoma of skin (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-20</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-melanom-ulzeration J}\">Ja</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 117617002}\">Immunohistochemistry procedure</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6270001000004106",
          "display" : "Presence of ulcer in primary malignant melanoma of skin (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-20",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-melanom-ulzeration",
          "code" : "J",
          "display" : "Ja"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "117617002",
          "display" : "Immunohistochemistry procedure"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-ulzeration-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-ulzeration-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-ulzeration-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ulzeration"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-ulzeration-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-ulzeration-2</b></p><a name=\"mii-exa-test-data-onko-melanom-ulzeration-2\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-ulzeration-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ulzeration\">MII PR Onkologie Melanom Ulzeration</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 6270001000004106}\">Presence of ulcer in primary malignant melanoma of skin (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>effective</b>: 2021-06-22</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-melanom-ulzeration N}\">Nein</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 117617002}\">Immunohistochemistry procedure</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6270001000004106",
          "display" : "Presence of ulcer in primary malignant melanoma of skin (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "effectiveDateTime" : "2021-06-22",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-melanom-ulzeration",
          "code" : "N",
          "display" : "Nein"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "117617002",
          "display" : "Immunohistochemistry procedure"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-ulzeration-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-ulzeration-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-ulzeration-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ulzeration"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-ulzeration-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-ulzeration-dar-1</b></p><a name=\"mii-exa-test-data-onko-melanom-ulzeration-dar-1\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-ulzeration-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ulzeration\">MII PR Onkologie Melanom Ulzeration</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 6270001000004106}\">Presence of ulcer in primary malignant melanoma of skin (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-20</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p><p><b>note</b>: </p><blockquote><div><p>Ulzerationsstatus nicht beurteilbar: Praeparat fragmentiert, Oberflaeche nicht vollstaendig erhalten.</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6270001000004106",
          "display" : "Presence of ulcer in primary malignant melanoma of skin (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-20",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "unknown",
          "display" : "Unknown"
        }]
      },
      "note" : [{
        "text" : "Ulzerationsstatus nicht beurteilbar: Praeparat fragmentiert, Oberflaeche nicht vollstaendig erhalten."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-ulzeration-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-sicherheitsabstand-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-sicherheitsabstand-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-sicherheitsabstand"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-sicherheitsabstand-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-sicherheitsabstand-1</b></p><a name=\"mii-exa-test-data-onko-melanom-sicherheitsabstand-1\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-sicherheitsabstand-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-sicherheitsabstand\">MII PR Onkologie Melanom Sicherheitsabstand</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 396511007}\">Distance of in situ melanoma from closest lateral surgical margin in excised specimen of skin (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-07-10</p><p><b>value</b>: 10 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "396511007",
          "display" : "Distance of in situ melanoma from closest lateral surgical margin in excised specimen of skin (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-07-10",
      "valueQuantity" : {
        "value" : 10,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-sicherheitsabstand-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-sicherheitsabstand-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-sicherheitsabstand-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-sicherheitsabstand"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-sicherheitsabstand-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-sicherheitsabstand-2</b></p><a name=\"mii-exa-test-data-onko-melanom-sicherheitsabstand-2\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-sicherheitsabstand-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-sicherheitsabstand\">MII PR Onkologie Melanom Sicherheitsabstand</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 396511007}\">Distance of in situ melanoma from closest lateral surgical margin in excised specimen of skin (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-07-10</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "396511007",
          "display" : "Distance of in situ melanoma from closest lateral surgical margin in excised specimen of skin (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-07-10",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-sicherheitsabstand-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-ldh-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-ldh-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ldh"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-ldh-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-ldh-1</b></p><a name=\"mii-exa-test-data-onko-melanom-ldh-1\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-ldh-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ldh\">MII PR Onkologie Melanom LDH</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 14804-9}\">Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma by Lactate to pyruvate reaction</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>effective</b>: 2021-06-18</p><p><b>value</b>: 180 U/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeU/L = 'U/L')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "14804-9",
          "display" : "Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma by Lactate to pyruvate reaction"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "effectiveDateTime" : "2021-06-18",
      "valueQuantity" : {
        "value" : 180,
        "unit" : "U/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "U/L"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-ldh-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-onko-melanom-ldh-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-onko-melanom-ldh-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ldh"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-onko-melanom-ldh-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-onko-melanom-ldh-2</b></p><a name=\"mii-exa-test-data-onko-melanom-ldh-2\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-ldh-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ldh\">MII PR Onkologie Melanom LDH</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 14804-9}\">Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma by Lactate to pyruvate reaction</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>effective</b>: 2022-03-15</p><p><b>value</b>: 320 U/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeU/L = 'U/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>note</b>: </p><blockquote><div><p>LDH deutlich erhöht, Hinweis auf Tumorprogression</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "14804-9",
          "display" : "Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma by Lactate to pyruvate reaction"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "effectiveDateTime" : "2022-03-15",
      "valueQuantity" : {
        "value" : 320,
        "unit" : "U/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "U/L"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "note" : [{
        "text" : "LDH deutlich erhöht, Hinweis auf Tumorprogression"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-onko-melanom-ldh-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-onko-melanom-exzision-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-onko-melanom-exzision-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-exzision"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-onko-melanom-exzision-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-onko-melanom-exzision-1</b></p><a name=\"mii-exa-test-data-onko-melanom-exzision-1\"> </a><a name=\"hcmii-exa-test-data-onko-melanom-exzision-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-exzision\">MII PR Onko Melanom Exzision</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Operation Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2021-07-06</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>MII EX Onko Operation Urgency</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency E}\">Elektiveingriff</span></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html\">CarePlan: identifier = TK-2021-001; status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); created = 2021-06-20</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-onko-systemische-therapie-1.html\">Procedure Chemotherapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 387713003}\">Surgical procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 177281002}, {http://fhir.de/CodeSystem/bfarm/ops 5-895.34}\">Excision of melanoma (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-onko-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.charite.de/fhir/sid/patientenidentifikation#ONKO-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-onko-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2021-06-10 --&gt; 2021-10-15</a></p><p><b>performed</b>: 2021-07-05</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-onko-diagnose-1.html\">Condition Bösartige Neubildung des Ovars</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 368208006}\">Left upper arm structure</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus R0}\">Kein Residualtumor</span></p><p><b>complication</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation N}\">Nein</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm T81.0}\">Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert</span></p><p><b>note</b>: </p><blockquote><div><p>Exzision des Melanoms am linken Oberarm mit Sicherheitsabstand.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K",
            "display" : "kurativ"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2021-07-06"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-operation-urgency",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-urgency",
            "code" : "E",
            "display" : "Elektiveingriff"
          }],
          "text" : "Elektiveingriff"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387713003",
          "display" : "Surgical procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "177281002",
          "display" : "Excision of melanoma (procedure)"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "L",
              "display" : "links"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2021",
          "code" : "5-895.34",
          "display" : "Radikale und ausgedehnte Exzision von erkranktem Gewebe an Haut und Unterhaut: Ohne primären Wundverschluss: Oberarm und Ellenbogen"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "performedDateTime" : "2021-07-05",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "368208006",
          "display" : "Left upper arm structure"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-residualstatus",
          "code" : "R0",
          "display" : "Kein Residualtumor"
        }]
      },
      "complication" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation",
          "code" : "N",
          "display" : "Nein"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2021",
          "code" : "T81.0",
          "display" : "Blutung und Hämatom als Komplikation eines Eingriffes, anderenorts nicht klassifiziert"
        }]
      }],
      "note" : [{
        "text" : "Exzision des Melanoms am linken Oberarm mit Sicherheitsabstand."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-onko-melanom-exzision-1"
    }
  }]
}

```
