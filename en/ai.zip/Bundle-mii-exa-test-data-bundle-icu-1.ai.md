# mii-exa-test-data-bundle-icu-1 - MII KDS Test Data v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-test-data-bundle-icu-1**

## Example Bundle: mii-exa-test-data-bundle-icu-1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-test-data-bundle-icu-1",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2025-06-18T13:51:00+02:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-icu-patient-1",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-icu-patient-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-icu-patient-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-icu-patient-1</b></p><a name=\"mii-exa-test-data-icu-patient-1\"> </a><a name=\"hcmii-exa-test-data-icu-patient-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\">NamingSystemKVID/K220635158</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/standort-b",
        "value" : "ICU-TEST-001"
      },
      {
        "system" : "http://fhir.de/sid/gkv/kvid-10",
        "value" : "K220635158"
      }],
      "name" : [{
        "family" : "Musterperson",
        "given" : ["Kim"]
      }],
      "gender" : "female",
      "birthDate" : "1956-03-14"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-icu-patient-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-icu-encounter-1",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-icu-encounter-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-icu-encounter-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-icu-encounter-1</b></p><a name=\"mii-exa-test-data-icu-encounter-1\"> </a><a name=\"hcmii-exa-test-data-icu-encounter-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>period</b>: 2024-05-01 --&gt; 2024-05-14</p><h3>Diagnoses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Condition</b></td><td><b>Use</b></td><td><b>Rank</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Condition-mii-exa-test-data-icu-diagnose-1.html\">Condition COVID-19, Virus nachgewiesen</a></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/diagnosis-role AD}\">Admission diagnosis</span></td><td>1</td></tr></table></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP",
        "display" : "inpatient encounter"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "period" : {
        "start" : "2024-05-01",
        "end" : "2024-05-14"
      },
      "diagnosis" : [{
        "condition" : {
          "reference" : "Condition/mii-exa-test-data-icu-diagnose-1"
        },
        "use" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/diagnosis-role",
            "code" : "AD",
            "display" : "Admission diagnosis"
          }]
        },
        "rank" : 1
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-icu-encounter-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-icu-diagnose-1",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-icu-diagnose-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-icu-diagnose-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-icu-diagnose-1</b></p><a name=\"mii-exa-test-data-icu-diagnose-1\"> </a><a name=\"hcmii-exa-test-data-icu-diagnose-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/StructureDefinition/Diagnose\">MII PR Diagnose Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm U07.1}\">COVID-19, Virus nachgewiesen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>recordedDate</b>: 2024-05-01</p><p><b>note</b>: </p><blockquote><div><p>COVID-19 Virus nachgewiesen</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "U07.1"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "recordedDate" : "2024-05-01",
      "note" : [{
        "text" : "COVID-19 Virus nachgewiesen"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-icu-diagnose-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-haemofiltration-einzelmesswerte"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-haemofiltration-einzelmesswerte\">MII PR ICU Bilanz Ausfuhr Haemofiltration Einzelmesswerte</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-haemofiltr-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251850009}, {http://loinc.org 99741-1}\">Ultrafiltrate fluid loss (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 120 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-haemofiltr-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251850009",
          "display" : "Ultrafiltrate fluid loss (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "99741-1",
          "display" : "Ultrafiltrate volume removed"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 120,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-drainage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-drainage-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-drainage-generisch"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-drainage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-drainage-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-drainage-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-drainage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-drainage-generisch\">MII PR ICU Bilanz Ausfuhr Drainage Generisch</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-drainage-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251843005}, {urn:iso:std:iso:11073:10101 157740}\">Fluid output from drain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 50 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-drainage-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251843005",
          "display" : "Fluid output from drain"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "157740"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 50,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-drainage-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-fluessigkeit-gesamt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-fluessigkeit-gesamt\">MII PR ICU Bilanz Ausfuhr Fluessigkeit Gesamt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-fluess-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251847006}, {http://loinc.org 9257-7}\">Total fluid loss</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 2200 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-fluess-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251847006",
          "display" : "Total fluid loss"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9257-7",
          "display" : "Fluid output total Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 2200,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-gallenfluessigkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-gallenfluessigkeit\">MII PR ICU Bilanz Ausfuhr Gallenfluessigkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-galle-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9113-2}, {http://snomed.info/sct 1162667009}\">Fluid output biliary drain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 30 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 28273000}\">Bile duct structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-galle-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9113-2",
          "display" : "Fluid output biliary drain"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1162667009",
          "display" : "Volume of drainage of bile duct (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 30,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "28273000",
          "display" : "Bile duct structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-gallenfluessigkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-gallenfluessigkeit\">MII PR ICU Bilanz Ausfuhr Gallenfluessigkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-gallengang-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9113-2}, {http://snomed.info/sct 1162667009}\">Fluid output biliary drain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 25 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 28273000}\">Bile duct structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-gallengang-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9113-2",
          "display" : "Fluid output biliary drain"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1162667009",
          "display" : "Volume of drainage of bile duct (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 25,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "28273000",
          "display" : "Bile duct structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-magensonde"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-magensonde\">MII PR ICU Bilanz Ausfuhr Magensonde</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-magen-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 79561-7}, {http://snomed.info/sct 1162665001}\">Fluid output enteral tube [Volume] Measured</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 100 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 69695003}\">Stomach structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-magen-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "79561-7",
          "display" : "Fluid output enteral tube [Volume] Measured"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1162665001",
          "display" : "Volume of drainage of gastric contents (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 100,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "69695003",
          "display" : "Stomach structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-op-drainage"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-op-drainage\">MII PR ICU Bilanz Ausfuhr OP Drainage</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-opdrain-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251844004}\">Fluid output from surgical drain (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 75 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-opdrain-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251844004",
          "display" : "Fluid output from surgical drain (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 75,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-pankreasdrainage"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-pankreasdrainage\">MII PR ICU Bilanz Ausfuhr Pankreasdrainage</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-pankreas-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1162668004}\">Volume of drainage of pancreatic fluid (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 20 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 15776009}\">Pancreatic structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-pankreas-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1162668004",
          "display" : "Volume of drainage of pancreatic fluid (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 20,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "15776009",
          "display" : "Pancreatic structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-stuhlgang"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-stuhlgang\">MII PR ICU Bilanz Ausfuhr Stuhlgang</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-stuhl-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9217-1}\">Output.stool [Volume]</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 200 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 71854001}\">Colon structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-stuhl-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9217-1",
          "display" : "Output.stool [Volume]"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 200,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "71854001",
          "display" : "Colon structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-urin"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-urin\">MII PR ICU Bilanz Ausfuhr Urin</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-urin-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9187-6}, {http://snomed.info/sct 364201005}\">Urine output</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 1800 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 89837001}\">Urinary bladder structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td><td><b>Text</b></td></tr><tr><td style=\"display: none\">*</td><td>800 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td>2000 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td>Urinausfuhr Erwachsene pro 24h</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-urin-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9187-6",
          "display" : "Urine output"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364201005",
          "display" : "Urine output observable (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 1800,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "89837001",
          "display" : "Urinary bladder structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      },
      "referenceRange" : [{
        "low" : {
          "value" : 800,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "high" : {
          "value" : 2000,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "text" : "Urinausfuhr Erwachsene pro 24h"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-wunddrainage"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-wunddrainage\">MII PR ICU Bilanz Ausfuhr Wunddrainage</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ausf-wunde-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251845003}, {http://loinc.org 9203-1}\">Fluid output from wound drain (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 45 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ausf-wunde-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251845003",
          "display" : "Fluid output from wound drain (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9203-1",
          "display" : "Fluid output wound drain"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 45,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-blutverlust"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-blutverlust-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-blutverlust\">MII PR ICU Bilanz Ausfuhr Blutverlust</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-blutverlust-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250771004}, {http://loinc.org 81661-1}\">Actual blood loss</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 150 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-blutverlust-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250771004",
          "display" : "Actual blood loss"
        },
        {
          "system" : "http://loinc.org",
          "code" : "81661-1",
          "display" : "Blood loss [Volume] Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 150,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-enterale-fluessigkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-enterale-fluessigkeit\">MII PR ICU Bilanz Einfuhr Enterale Fluessigkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-enteral-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251854000}, {http://loinc.org 8953-2}\">Enteral fluid input (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 1500 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-enteral-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251854000",
          "display" : "Enteral fluid input (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "8953-2",
          "display" : "Fluid intake enteral tube Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 1500,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-fluessigkeit-gesamt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-fluessigkeit-gesamt\">MII PR ICU Bilanz Einfuhr Fluessigkeit Gesamt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-fluess-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251852001}, {http://loinc.org 9103-3}\">Total fluid input (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 2500 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-fluess-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251852001",
          "display" : "Total fluid input (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9103-3",
          "display" : "Fluid intake total Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 2500,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-fluessigkeit-gesamt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-oral-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-fluessigkeit-gesamt\">MII PR ICU Bilanz Einfuhr Fluessigkeit Gesamt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-oral-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251852001}, {http://loinc.org 9103-3}\">Total fluid input (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 800 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-oral-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251852001",
          "display" : "Total fluid input (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9103-3",
          "display" : "Fluid intake total Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 800,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-fluessigkeit-gesamt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-ausfuhr-fluessigkeit-gesamt\">MII PR ICU Bilanz Ausfuhr Fluessigkeit Gesamt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ges-ausf-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251847006}, {http://loinc.org 9257-7}\">Total fluid loss</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 2400 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ges-ausf-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251847006",
          "display" : "Total fluid loss"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9257-7",
          "display" : "Fluid output total Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 2400,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-fluessigkeit-gesamt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-ges-einf-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-fluessigkeit-gesamt\">MII PR ICU Bilanz Einfuhr Fluessigkeit Gesamt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-ges-einf-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251852001}, {http://loinc.org 9103-3}\">Total fluid input (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 2800 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-ges-einf-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251852001",
          "display" : "Total fluid input (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9103-3",
          "display" : "Fluid intake total Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 2800,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-tages-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-tages-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-tagesbilanz-fluessigkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-tages-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-tages-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-tages-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-tages-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-tagesbilanz-fluessigkeit\">MII PR ICU Bilanz Tagesbilanz Fluessigkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-tages-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251856003}, {http://loinc.org 9097-7}\">Fluid balance status (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 400 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td><td><b>Text</b></td></tr><tr><td style=\"display: none\">*</td><td>-500 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td>500 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td>ausgeglichene Tagesbilanz</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-tages-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251856003",
          "display" : "Fluid balance status (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9097-7",
          "display" : "Fluid balance 24 hour"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 400,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      },
      "referenceRange" : [{
        "low" : {
          "value" : -500,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "high" : {
          "value" : 500,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "text" : "ausgeglichene Tagesbilanz"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-tages-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-muttermilch"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-muttermilch\">MII PR ICU Bilanz Einfuhr Muttermilch</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-mumi-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1204299001}\">Measured volume of intake of breast milk (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 06:00:00+0200</p><p><b>issued</b>: 2024-05-06 08:00:00+0200</p><p><b>value</b>: 40 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-mumi-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1204299001",
          "display" : "Measured volume of intake of breast milk (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T06:00:00+02:00",
      "issued" : "2024-05-06T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 40,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-abgepumpte-muttermilch"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-abgepumpte-muttermilch\">MII PR ICU Bilanz Einfuhr Abgepumpte Muttermilch</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-mumi-abgep-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 819975003}\">Intake of maternal expressed breast milk (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 06:00:00+0200</p><p><b>issued</b>: 2024-05-06 08:00:00+0200</p><p><b>value</b>: 35 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-mumi-abgep-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "819975003",
          "display" : "Intake of maternal expressed breast milk (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T06:00:00+02:00",
      "issued" : "2024-05-06T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 35,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-spendermilch"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-spendermilch\">MII PR ICU Bilanz Einfuhr Spendermilch</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-spendermilch-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 819973005}\">Donor breastmilk intake (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 06:00:00+0200</p><p><b>issued</b>: 2024-05-06 08:00:00+0200</p><p><b>value</b>: 30 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-spendermilch-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "819973005",
          "display" : "Donor breastmilk intake (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T06:00:00+02:00",
      "issued" : "2024-05-06T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 30,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-saeuglingsnahrung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-saeuglingsnahrung\">MII PR ICU Bilanz Einfuhr Saeuglingsnahrung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-saeugling-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1204305004}\">Measured volume of intake of infant formula</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 06:00:00+0200</p><p><b>issued</b>: 2024-05-06 08:00:00+0200</p><p><b>value</b>: 60 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-saeugling-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1204305004",
          "display" : "Measured volume of intake of infant formula"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T06:00:00+02:00",
      "issued" : "2024-05-06T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 60,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-orale-fluessigkeit"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-einfuhr-orale-fluessigkeit\">MII PR ICU Bilanz Einfuhr Orale Fluessigkeit</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-einf-oral-fluess-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251853006}, {http://loinc.org 9000-1}\">Oral fluid input (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 06:00:00+0200</p><p><b>issued</b>: 2024-05-06 08:00:00+0200</p><p><b>value</b>: 150 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-einf-oral-fluess-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251853006",
          "display" : "Oral fluid input (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "9000-1",
          "display" : "Fluid intake oral Measured"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T06:00:00+02:00",
      "issued" : "2024-05-06T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 150,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-bilanz-status-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-bilanz-status-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-bilanz-status-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-bilanz-status-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-bilanz-status-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-bilanz-status-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz\">MII PR ICU Bilanz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-bilanz-status-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}, {http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251856003}\">Fluid balance status (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 06:00:00+0200</p><p><b>issued</b>: 2024-05-06 08:00:00+0200</p><p><b>value</b>: 300 ml<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeml = 'ml')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 258104002}\">Measured (qualifier value)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-PDMS-001; status = active; type = Software</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-bilanz-status-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364396009",
          "display" : "Fluid balance observable (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251856003",
          "display" : "Fluid balance status (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T06:00:00+02:00",
      "issued" : "2024-05-06T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 300,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "258104002",
          "display" : "Measured (qualifier value)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-status-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-gcs-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-gcs-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-gcs"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-gcs-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-gcs-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-gcs-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-gcs-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-gcs\">MII PR ICU Score GCS</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9269-2}, {http://snomed.info/sct 248241002}, {urn:iso:std:iso:11073:10101 153728}\">Glasgow coma score total</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 08:15:00+0200</p><p><b>issued</b>: 2024-05-06 10:15:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 8 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><p><b>hasMember</b>: <a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-befund-1.html\">Observation Pupil finding (finding)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9267-6}\">Glasgow coma score eye opening</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6554-5}\">Eye opening to pain</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9270-0}\">Glasgow coma score verbal</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6558-6}\">Incomprehensible sounds</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9268-4}\">Glasgow coma score motor</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6565-1}\">Withdrawal from pain</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9269-2",
          "display" : "Glasgow coma score total"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "248241002"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "153728"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T08:15:00+02:00",
      "issued" : "2024-05-06T10:15:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 8,
        "unit" : "{score}",
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-befund-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9267-6",
            "display" : "Glasgow coma score eye opening"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6554-5",
            "display" : "Eye opening to pain"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9270-0",
            "display" : "Glasgow coma score verbal"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6558-6",
            "display" : "Incomprehensible sounds"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9268-4",
            "display" : "Glasgow coma score motor"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6565-1",
            "display" : "Withdrawal from pain"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-gcs-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-rass-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-rass-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-rass"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-rass-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-rass-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-rass-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-rass-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-rass\">MII PR ICU Score RASS</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1345050000}\">Richmond Agitation Sedation Scale score (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 08:00:00+0200</p><p><b>issued</b>: 2024-05-06 10:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA33965-7}\">Moderate sedation -3</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><p><b>note</b>: </p><blockquote><div><p>RASS -3: Bewegung/Augenoeffnung auf Ansprache, kein Blickkontakt (moderate Sedierung unter ECMO).</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1345050000",
          "display" : "Richmond Agitation Sedation Scale score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T08:00:00+02:00",
      "issued" : "2024-05-06T10:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA33965-7",
          "display" : "Moderate sedation -3"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "note" : [{
        "text" : "RASS -3: Bewegung/Augenoeffnung auf Ansprache, kein Blickkontakt (moderate Sedierung unter ECMO)."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-sofa-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-sofa-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-sofa-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-sofa-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-sofa-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-sofa-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-sofa\">MII PR ICU Score SOFA</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96789-3}, {http://snomed.info/sct 1187491009}\">Sequential Organ Failure Assessment SOFA</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 09:00:00+0200</p><p><b>issued</b>: 2024-05-06 11:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 9</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>hasMember</b>: <a href=\"Observation-mii-exa-test-data-patient-1-icu-score-gcs-1.html\">Observation Glasgow coma score total</a></p><p><b>derivedFrom</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-score-gcs-1.html\">Observation Glasgow coma score total</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-vent-horowitz-1.html\">Observation Horowitz index in Arterial blood</a></li></ul><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96823-0}, {http://snomed.info/sct xxxx}\">Respiration [Score] SOFA</span></p><p><b>value</b>: 3</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96824-8}, {http://snomed.info/sct xxx}\">Coagulation [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96825-5}, {http://snomed.info/sct xxx}\">Liver [Score] SOFA</span></p><p><b>value</b>: 0</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96826-3}, {http://snomed.info/sct xxx}\">Cardiovascular [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96827-1}, {http://snomed.info/sct xxxx}\">Central nervous system [Score] SOFA</span></p><p><b>value</b>: 3</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96828-9}, {http://snomed.info/sct xxx}\">Renal [Score] SOFA</span></p><p><b>value</b>: 1</p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "96789-3",
          "display" : "Sequential Organ Failure Assessment SOFA"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "1187491009",
          "display" : "Sequential Organ Failure Assessment score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T09:00:00+02:00",
      "issued" : "2024-05-06T11:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueInteger" : 9,
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-gcs-1"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-gcs-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-horowitz-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96823-0",
            "display" : "Respiration [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Respiratory"
          }]
        },
        "valueInteger" : 3
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96824-8",
            "display" : "Coagulation [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Coagulation"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96825-5",
            "display" : "Liver [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Hepatic"
          }]
        },
        "valueInteger" : 0
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96826-3",
            "display" : "Cardiovascular [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Cardiovascular"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96827-1",
            "display" : "Central nervous system [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxxx",
            "display" : "SOFA Subscore - Neurological"
          }]
        },
        "valueInteger" : 3
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96828-9",
            "display" : "Renal [Score] SOFA"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "xxx",
            "display" : "SOFA Subscore - Renal"
          }]
        },
        "valueInteger" : 1
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-sofa-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-cam-icu-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-cam-icu-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-cam-icu"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-cam-icu-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-cam-icu-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-cam-icu-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-cam-icu-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-cam-icu\">MII PR ICU Score CAM-ICU</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 99844-5}, {http://snomed.info/sct 450740000}\">Confusion Assessment Method for the ICU</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 08:30:00+0200</p><p><b>issued</b>: 2024-05-06 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 10828004}\">Positive (qualifier value)</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>hasMember</b>: <a href=\"Observation-mii-exa-test-data-patient-1-icu-score-rass-1.html\">Observation Richmond Agitation Sedation Scale score (observable entity)</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-patient-1-icu-score-rass-1.html\">Observation Richmond Agitation Sedation Scale score (observable entity)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85634-4}\">Acute change from mental status baseline or Fluctuation in mental status in past 24 hours [CAM.ICU]</span></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 52101004}\">Present (qualifier value)</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85631-0}\">Feature 2: Inattention</span></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 52101004}\">Present (qualifier value)</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 95815-7}\">Feature 3: Altered level of consciousness</span></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 52101004}\">Present (qualifier value)</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85651-8}\">Feature 4: Disorganized thinking</span></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 2667000}\">Absent (qualifier value)</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "99844-5",
          "display" : "Confusion Assessment Method for the ICU"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "450740000",
          "display" : "Confusion Assessment Method for the intensive care unit score"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T08:30:00+02:00",
      "issued" : "2024-05-06T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "10828004",
          "display" : "Positive (qualifier value)"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-1"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "85634-4",
            "display" : "Is there evidence of an acute change in mental status from the patient's baseline [CAM.CMS]"
          }],
          "text" : "Acute change from mental status baseline or Fluctuation in mental status in past 24 hours [CAM.ICU]"
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "52101004",
            "display" : "Present (qualifier value)"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "85631-0",
            "display" : "Did the patient have difficulty focusing attention [CAM.CMS]"
          }],
          "text" : "Feature 2: Inattention"
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "52101004",
            "display" : "Present (qualifier value)"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "95815-7",
            "display" : "Altered level of consciousness during assessment period [CAM.CMS]"
          }],
          "text" : "Feature 3: Altered level of consciousness"
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "52101004",
            "display" : "Present (qualifier value)"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "85651-8",
            "display" : "Was the patient's thinking disorganized or incoherent [CAM.CMS]"
          }],
          "text" : "Feature 4: Disorganized thinking"
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "2667000",
            "display" : "Absent (qualifier value)"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-cam-icu-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-icdsc-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-icdsc-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-icdsc"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-icdsc-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-icdsc-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-icdsc-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-icdsc-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-icdsc\">MII PR ICU Score ICDSC</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1351995008}\">Intensive Care Delirium Screening Checklist score (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 20:00:00+0200</p><p><b>issued</b>: 2024-05-06 22:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 6</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>hasMember</b>: <a href=\"Observation-mii-exa-test-data-patient-1-icu-score-rass-1.html\">Observation Richmond Agitation Sedation Scale score (observable entity)</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-patient-1-icu-score-rass-1.html\">Observation Richmond Agitation Sedation Scale score (observable entity)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Altered level of consciousness</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Inattention</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Disorientation</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Hallucination, delusion, or psychosis</span></p><p><b>value</b>: 0</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Psychomotor agitation or retardation</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Inappropriate speech or mood</span></p><p><b>value</b>: 0</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Sleep/wake cycle disturbance</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Symptom fluctuation</span></p><p><b>value</b>: 1</p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "1351995008",
          "display" : "Intensive Care Delirium Screening Checklist score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T20:00:00+02:00",
      "issued" : "2024-05-06T22:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueInteger" : 6,
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-1"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-1"
      }],
      "component" : [{
        "code" : {
          "text" : "Altered level of consciousness"
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "text" : "Inattention"
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "text" : "Disorientation"
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "text" : "Hallucination, delusion, or psychosis"
        },
        "valueInteger" : 0
      },
      {
        "code" : {
          "text" : "Psychomotor agitation or retardation"
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "text" : "Inappropriate speech or mood"
        },
        "valueInteger" : 0
      },
      {
        "code" : {
          "text" : "Sleep/wake cycle disturbance"
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "text" : "Symptom fluctuation"
        },
        "valueInteger" : 1
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-icdsc-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-nrs-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-nrs-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-numerische-ratingskala"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-nrs-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-nrs-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-nrs-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-nrs-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-numerische-ratingskala\">MII PR ICU Score Numerische Ratingskala</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1284857008}\">Numeric Pain Rating Scale score</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 10:00:00+0200</p><p><b>issued</b>: 2024-05-06 12:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 4</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 38214-3}\">Visuelle Analogskala als Gegenprobe</span></td><td>45 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></td></tr></table></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "1284857008"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T10:00:00+02:00",
      "issued" : "2024-05-06T12:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueInteger" : 4,
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "38214-3",
            "display" : "Pain severity [Score] Visual analog score"
          }],
          "text" : "Visuelle Analogskala als Gegenprobe"
        },
        "valueQuantity" : {
          "value" : 45,
          "unit" : "mm",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-nrs-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-vas-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-vas-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-visuelle-analogskala"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-vas-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-vas-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-vas-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-vas-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-visuelle-analogskala\">MII PR ICU Score Visuelle Analogskala</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 38214-3}, {http://snomed.info/sct 443394008}\">Pain severity [Score] Visual analog score</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 10:05:00+0200</p><p><b>issued</b>: 2024-05-06 12:05:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 45 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 72514-3}\">Numerische Ratingskala als Gegenprobe</span></td><td>4</td></tr></table></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "38214-3",
          "display" : "Pain severity [Score] Visual analog score"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "443394008"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T10:05:00+02:00",
      "issued" : "2024-05-06T12:05:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 45,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "72514-3",
            "display" : "Pain severity - 0-10 verbal numeric rating [Score] - Reported"
          }],
          "text" : "Numerische Ratingskala als Gegenprobe"
        },
        "valueInteger" : 4
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-vas-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-wbf-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-wbf-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-wong-baker-faces-schmerzskala"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-wbf-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-wbf-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-wbf-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-wbf-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-wong-baker-faces-schmerzskala\">MII PR ICU Score Wong-Baker-FACES-Schmerzskala</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Assessment</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 38221-8}, {http://snomed.info/sct 718581005}\">Pain severity Wong-Baker FACES pain rating scale</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 10:10:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 6 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Assessment"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "38221-8"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "718581005"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T10:10:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 6,
        "unit" : "{score}",
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-wbf-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-fpsr-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-fpsr-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-faces-pain-scale-revised"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-fpsr-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-fpsr-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-fpsr-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-fpsr-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-faces-pain-scale-revised\">MII PR ICU Score Faces Pain Scale Revised</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1284909003}\">Faces Pain Scale - Revised score (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 10:15:00+0200</p><p><b>issued</b>: 2024-05-06 12:15:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 6 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 72514-3}\">Numerische Ratingskala als Gegenprobe</span></td><td>6</td></tr></table></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "1284909003",
          "display" : "Faces Pain Scale - Revised score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T10:15:00+02:00",
      "issued" : "2024-05-06T12:15:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 6,
        "unit" : "{score}",
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "72514-3",
            "display" : "Pain severity - 0-10 verbal numeric rating [Score] - Reported"
          }],
          "text" : "Numerische Ratingskala als Gegenprobe"
        },
        "valueInteger" : 6
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-fpsr-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-zopa-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-zopa-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-zopa"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-zopa-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-zopa-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-zopa-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-zopa-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-zopa\">MII PR ICU Score ZOPA</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://dgai.de DGAI-ZOPA}\">Zuerich Observation Pain Assessment (ZOPA)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 08:45:00+0200</p><p><b>issued</b>: 2024-05-06 10:45:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 52101004}\">Present (qualifier value)</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://dgai.de",
          "code" : "DGAI-ZOPA",
          "display" : "Zuerich Observation Pain Assessment (ZOPA)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T08:45:00+02:00",
      "issued" : "2024-05-06T10:45:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52101004",
          "display" : "Present (qualifier value)"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-zopa-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-befund-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-befund-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenbefund"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-befund-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-befund-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-befund-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-befund-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenbefund\">MII PR ICU Untersuchung Pupillenbefund</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-befund-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 247010007}, {http://loinc.org 80310-6}\">Pupil finding (finding)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>hasMember</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1.html\">Observation Pupil afferent light reaction</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1.html\">Observation Pupil afferent light reaction</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1.html\">Observation Indirect light pupillary reflex</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1.html\">Observation Indirect light pupillary reflex</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-re-1.html\">Observation Size of pupil</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-li-1.html\">Observation Size of pupil</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-form-re-1.html\">Observation Pupil shape</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-form-li-1.html\">Observation Pupil shape</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-symmetrie-1.html\">Observation Finding of proportion of pupil (finding)</a></li></ul></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-befund-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "247010007",
          "display" : "Pupil finding (finding)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "80310-6",
          "display" : "Pupil assessment panel"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-befund-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-form-re-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-form-re-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-form-re-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-form-re-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-form-re-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform\">MII PR ICU Untersuchung Pupillenform</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-form-re-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363954009}\">Pupil shape</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA24884-1}\">Round</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-form-re-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363954009",
          "display" : "Pupil shape"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA24884-1",
          "display" : "Round"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-form-li-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-form-li-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-form-li-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-form-li-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-form-li-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform\">MII PR ICU Untersuchung Pupillenform</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-form-li-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363954009}\">Pupil shape</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA24884-1}\">Round</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-form-li-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363954009",
          "display" : "Pupil shape"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA24884-1",
          "display" : "Round"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-groesse-re-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-groesse-re-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-groesse-re-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-groesse-re-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-groesse-re-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse\">MII PR ICU Untersuchung Pupillengroesse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-groesse-re-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363953003}\">Size of pupil</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: 3 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-groesse-re-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363953003",
          "display" : "Size of pupil"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueQuantity" : {
        "value" : 3,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-groesse-li-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-groesse-li-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-groesse-li-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-groesse-li-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-groesse-li-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse\">MII PR ICU Untersuchung Pupillengroesse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-groesse-li-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363953003}\">Size of pupil</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: 5 mm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm = 'mm')</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-groesse-li-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363953003",
          "display" : "Size of pupil"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueQuantity" : {
        "value" : 5,
        "unit" : "mm",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm"
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt\">MII PR ICU Untersuchung Pupillenlichtreaktion Direkt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-dir-re-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 45832002}\">Pupil afferent light reaction</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA25441-9}\">Reactive to light</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-dir-re-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "45832002"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA25441-9",
          "display" : "Reactive to light"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt\">MII PR ICU Untersuchung Pupillenlichtreaktion Direkt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-dir-li-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 45832002}\">Pupil afferent light reaction</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA24899-9}\">Sluggishly reactive to light</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-dir-li-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "45832002"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA24899-9",
          "display" : "Sluggishly reactive to light"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt\">MII PR ICU Untersuchung Pupillenlichtreaktion Indirekt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-ind-re-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 84917001}\">Indirect light pupillary reflex</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA25441-9}\">Reactive to light</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-ind-re-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84917001"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA25441-9",
          "display" : "Reactive to light"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt\">MII PR ICU Untersuchung Pupillenlichtreaktion Indirekt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-ind-li-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 84917001}\">Indirect light pupillary reflex</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA24899-9}\">Sluggishly reactive to light</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-ind-li-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84917001"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA24899-9",
          "display" : "Sluggishly reactive to light"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-symmetrie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillensymmetrie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-symmetrie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-symmetrie-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-symmetrie-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-symmetrie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillensymmetrie\">MII PR ICU Untersuchung Pupillensymmetrie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-symmetrie-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 301942005}\">Finding of proportion of pupil (finding)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 07:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unsupported}\">Unsupported</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 67019001}\">Structure of pupil of both eyes (body structure)</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-symmetrie-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "301942005",
          "display" : "Finding of proportion of pupil (finding)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T07:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "unsupported",
          "display" : "Unsupported"
        }]
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "67019001",
          "display" : "Structure of pupil of both eyes (body structure)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-art-druck-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-art-druck-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-arterieller-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-art-druck-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-art-druck-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-art-druck-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-art-druck-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-arterieller-druck\">MII PR ICU Arterieller Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-art-druck-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 386534000}\">Arterial blood pressure</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 85 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-art-druck-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "386534000",
          "display" : "Arterial blood pressure"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 85,
        "unit" : "mmHg",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm[Hg]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-art-druck-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-blutfluss-cardiovasculaeres-geraet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-blutfluss-cardiovasculaeres-geraet\">MII PR ICU Blutfluss Cardiovasculaeres Geraet</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-blutfl-cardio-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 444479000}\">Rate of blood flow through cardiovascular device</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 4.5 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-blutfl-cardio-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "444479000",
          "display" : "Rate of blood flow through cardiovascular device"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 4.5,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-blutfluss-extrakorporaler-gasaustausch"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-blutfl-extra-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-blutfluss-extrakorporaler-gasaustausch\">MII PR ICU Blutfluss Extrakorporaler Gasaustausch</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-blutfl-extra-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251288004}\">Extracorporeal gas exchange flow rate</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 4.5 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-blutfl-extra-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251288004",
          "display" : "Extracorporeal gas exchange flow rate"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 4.5,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-blutflussindex-extrakorporaler-gasaustausch"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-blutfl-idx-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-blutflussindex-extrakorporaler-gasaustausch\">MII PR ICU Blutflussindex Extrakorporaler Gasaustausch</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-blutfl-idx-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251289007}\">Extracorporeal gas exchange flow index</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 1.8 L/(min.m2)<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/(min.m2) = 'L/(min.m2)')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-blutfl-idx-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251289007",
          "display" : "Extracorporeal gas exchange flow index"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 1.8,
        "unit" : "L/(min.m2)",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/(min.m2)"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-dauer-extra-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-dauer-extra-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-dauer-extrakorporaler-gasaustausch"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-dauer-extra-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-dauer-extra-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-dauer-extra-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-dauer-extra-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-dauer-extrakorporaler-gasaustausch\">MII PR ICU Dauer Extrakorporaler Gasaustausch</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-dauer-extra-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 251286000}\">Extracorporeal gas exchange duration</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 72 hours<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeh = 'h')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-dauer-extra-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "251286000",
          "display" : "Extracorporeal gas exchange duration"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 72,
        "unit" : "hours",
        "system" : "http://unitsofmeasure.org",
        "code" : "h"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-dauer-extra-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-dauer-haemodialysesitzung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-dauer-haemo-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-dauer-haemodialysesitzung\">MII PR ICU Dauer Haemodialysesitzung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-dauer-haemo-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 445940005}\">Duration of haemodialysis session</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 4 hours<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeh = 'h')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-dauer-haemo-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "445940005",
          "display" : "Duration of haemodialysis session"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 4,
        "unit" : "hours",
        "system" : "http://unitsofmeasure.org",
        "code" : "h"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-gasfluss-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-gasfluss-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-gasfluss-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-gasfluss-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-gasfluss-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-gasfluss-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-gasfluss\">MII PR ICU Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-gasfluss-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 79063001}\">Gas flow rate (v)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 5 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-gasfluss-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "79063001",
          "display" : "Gas flow rate (v)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 5,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-gasfluss-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-haemodialyse-blutfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-haemodialyse-blutfluss\">MII PR ICU Haemodialyse Blutfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-haemo-blutfl-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 401000124105}\">Hemodialysis blood flow</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 250 mL/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL/min = 'mL/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-haemo-blutfl-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "401000124105",
          "display" : "Hemodialysis blood flow"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 250,
        "unit" : "mL/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-kalzium-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-kalzium-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-ionisiertes-kalzium-nierenersatzverfahren"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-kalzium-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-kalzium-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-kalzium-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-kalzium-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-ionisiertes-kalzium-nierenersatzverfahren\">MII PR ICU Ionisiertes Kalzium Nierenersatzverfahren</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-kalzium-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 83064-6}\">Calcium.ionized [Moles/volume] in Blood drawn from CRRT circuit</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 1.15 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemmol/L = 'mmol/L')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-kalzium-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "83064-6",
          "display" : "Calcium.ionized [Moles/volume] in Blood drawn from CRRT circuit"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 1.15,
        "unit" : "mmol/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "mmol/L"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-kalzium-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-substituatfl-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-substituatfl-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-substituatfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-substituatfl-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-substituatfl-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-substituatfl-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-substituatfl-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-substituatfluss\">MII PR ICU Substituatfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-substituatfl-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 708513005}\">Substitution flow rate</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 2000 mL/h<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL/h = 'mL/h')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-substituatfl-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "708513005",
          "display" : "Substitution flow rate"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 2000,
        "unit" : "mL/h",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL/h"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-substituatfl-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-substituatvol-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-substituatvol-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-substituatvolumen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-substituatvol-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-substituatvol-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-substituatvol-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-substituatvol-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-substituatvolumen\">MII PR ICU Substituatvolumen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-substituatvol-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 708514004}\">Substitution volume</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 48 L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL = 'L')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-substituatvol-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "708514004",
          "display" : "Substitution volume"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 48,
        "unit" : "L",
        "system" : "http://unitsofmeasure.org",
        "code" : "L"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-substituatvol-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-ven-druck-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-ven-druck-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-venoeser-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-ven-druck-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-ven-druck-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-ven-druck-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-ven-druck-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-ect-venoeser-druck\">MII PR ICU Venoeser Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-ven-druck-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 252076005}\">Venous pressure</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 15 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-ven-druck-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "252076005",
          "display" : "Venous pressure"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 15,
        "unit" : "mmHg",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm[Hg]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-ven-druck-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-event-o2-partial-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-event-o2-partial-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-sauerstoffpartialdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-event-o2-partial-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-event-o2-partial-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-event-o2-partial-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-event-o2-partial-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-sauerstoffpartialdruck\">MII PR ICU Exspiratorischer Sauerstoffpartialdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-event-o2-partial-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 442720002}, {http://loinc.org 3147-6}, {urn:iso:std:iso:11073:10101 153132}\">Expired oxygen tension (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 40 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-event-o2-partial-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "442720002",
          "display" : "Expired oxygen tension (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "3147-6",
          "display" : "Oxygen [Partial pressure] in Exhaled gas"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "153132",
          "display" : "Partial pressure of oxygen in airway gas measured during expiration."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 40,
        "unit" : "mmHg",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm[Hg]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-event-o2-partial-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-blutdruck-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-blutdruck-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-arterieller-blutdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-blutdruck-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-blutdruck-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-blutdruck-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-blutdruck-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-arterieller-blutdruck\">MII PR ICU MUV Arterieller Blutdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85354-9}, {http://snomed.info/sct 75367002}, {http://snomed.info/sct 364090009}\">Blood pressure panel with all children optional</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 45631007}\">Structure of radial artery (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 17146006}\">Arterial pressure monitoring, invasive method (regime/therapy)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-monitor-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-MONITOR-001; status = active; type = Biomedical equipment (physical object)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8480-6}, {http://snomed.info/sct 271649006}, {urn:iso:std:iso:11073:10101 150017}\">Systolic blood pressure</span></p><p><b>value</b>: 120 millimeter Mercury column<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8462-4}, {http://snomed.info/sct 271650006}, {urn:iso:std:iso:11073:10101 150018}\">Diastolic blood pressure</span></p><p><b>value</b>: 80 millimeter Mercury column<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8478-0}, {http://snomed.info/sct 6797001}, {urn:iso:std:iso:11073:10101 150019}\">Mean blood pressure</span></p><p><b>value</b>: 93 millimeter Mercury column<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85354-9",
          "display" : "Blood pressure panel with all children optional"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "75367002",
          "display" : "Blood pressure"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364090009",
          "display" : "Systemic arterial pressure"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "45631007",
          "display" : "Structure of radial artery (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "17146006",
          "display" : "Arterial pressure monitoring, invasive method (regime/therapy)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-monitor-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8480-6",
            "display" : "Systolic blood pressure"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "271649006",
            "display" : "Systolic blood pressure"
          },
          {
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "150017",
            "display" : "MDC_PRESS_BLD_NONINV_SYS"
          }]
        },
        "valueQuantity" : {
          "value" : 120,
          "unit" : "millimeter Mercury column",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8462-4",
            "display" : "Diastolic blood pressure"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "271650006",
            "display" : "Diastolic blood pressure"
          },
          {
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "150018",
            "display" : "MDC_PRESS_BLD_NONINV_DIA"
          }]
        },
        "valueQuantity" : {
          "value" : 80,
          "unit" : "millimeter Mercury column",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8478-0",
            "display" : "Mean blood pressure"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "6797001",
            "display" : "Mean blood pressure"
          },
          {
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "150019",
            "display" : "MDC_PRESS_BLD_NONINV_MEAN"
          }]
        },
        "valueQuantity" : {
          "value" : 93,
          "unit" : "millimeter Mercury column",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-blutdruck-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-atemfreq-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-atemfreq-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-atemfrequenz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-atemfreq-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-atemfreq-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-atemfreq-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-atemfreq-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-atemfrequenz\">MII PR ICU MUV Atemfrequenz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-atemfreq-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9279-1}, {http://snomed.info/sct 86290005}\">Respiratory rate</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 14 breaths per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-atemfreq-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9279-1",
          "display" : "Respiratory rate"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "86290005",
          "display" : "Respiratory rate"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 14,
        "unit" : "breaths per minute",
        "system" : "http://unitsofmeasure.org",
        "code" : "/min"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-atemfreq-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-herzfreq-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-herzfreq-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-herzfrequenz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-herzfreq-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-herzfreq-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-herzfreq-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-herzfreq-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-herzfrequenz\">MII PR ICU MUV Herzfrequenz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-herzfreq-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 364075005}, {http://loinc.org 8867-4}, {urn:iso:std:iso:11073:10101 147842}\">Heart rate</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 72 beats per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 80891009}\">Heart structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 29303009}\">Electrocardiographic procedure</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-monitor-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-MONITOR-001; status = active; type = Biomedical equipment (physical object)</a></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>60 beats per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></td><td>100 beats per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></td></tr></table><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8867-4}\">Herzfrequenz, palpatorische Kontrollmessung</span></p><p><b>value</b>: 72 beats per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>60 beats per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></td><td>100 beats per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-herzfreq-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364075005",
          "display" : "Heart rate"
        },
        {
          "system" : "http://loinc.org",
          "code" : "8867-4",
          "display" : "Heart rate"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "147842",
          "display" : "MDC_ECG_HEART_RATE"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 72,
        "unit" : "beats per minute",
        "system" : "http://unitsofmeasure.org",
        "code" : "/min"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "80891009",
          "display" : "Heart structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "29303009",
          "display" : "Electrocardiographic procedure"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-monitor-1"
      },
      "referenceRange" : [{
        "low" : {
          "value" : 60,
          "unit" : "beats per minute",
          "system" : "http://unitsofmeasure.org",
          "code" : "/min"
        },
        "high" : {
          "value" : 100,
          "unit" : "beats per minute",
          "system" : "http://unitsofmeasure.org",
          "code" : "/min"
        }
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8867-4",
            "display" : "Heart rate"
          }],
          "text" : "Herzfrequenz, palpatorische Kontrollmessung"
        },
        "valueQuantity" : {
          "value" : 72,
          "unit" : "beats per minute",
          "system" : "http://unitsofmeasure.org",
          "code" : "/min"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "N",
            "display" : "Normal"
          }]
        }],
        "referenceRange" : [{
          "low" : {
            "value" : 60,
            "unit" : "beats per minute",
            "system" : "http://unitsofmeasure.org",
            "code" : "/min"
          },
          "high" : {
            "value" : 100,
            "unit" : "beats per minute",
            "system" : "http://unitsofmeasure.org",
            "code" : "/min"
          }
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-herzfreq-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-gewicht-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-gewicht-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergewicht"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-gewicht-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-gewicht-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-gewicht-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-gewicht-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergewicht\">MII PR ICU MUV Koerpergewicht</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span>, <span title=\"Codes:{http://snomed.info/sct 248326004}\">Body measure (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 29463-7}, {http://snomed.info/sct 27113001}\">Body weight</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 80 kilogram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codekg = 'kg')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "248326004",
          "display" : "Body measure (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29463-7",
          "display" : "Body weight"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "27113001",
          "display" : "Body weight"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 80,
        "unit" : "kilogram",
        "system" : "http://unitsofmeasure.org",
        "code" : "kg"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-gewicht-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-groesse-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-groesse-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-groesse-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-groesse-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-groesse-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-groesse-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergroesse\">MII PR ICU MUV Koerpergroesse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span>, <span title=\"Codes:{http://snomed.info/sct 248326004}\">Body measure (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8302-2}, {http://loinc.org 89269-5}, {http://snomed.info/sct 1153637007}\">Body height</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>value</b>: 175 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "248326004",
          "display" : "Body measure (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8302-2",
          "display" : "Body height"
        },
        {
          "system" : "http://loinc.org",
          "code" : "89269-5",
          "display" : "Body height Measured --at birth"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1153637007",
          "display" : "Body height"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "valueQuantity" : {
        "value" : 175,
        "unit" : "centimeter",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-groesse-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-kopfumfang-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-kopfumfang-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-kopfumfang"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-kopfumfang-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-kopfumfang-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-kopfumfang-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-kopfumfang-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-kopfumfang\">MII PR ICU MUV Kopfumfang</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span>, <span title=\"Codes:{http://snomed.info/sct 248326004}\">Body measure (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9843-4}, {http://snomed.info/sct 363812007}\">Head Occipital-frontal circumference</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>effective</b>: 2024-02-15 14:30:00+0100 --&gt; 2024-02-15 14:35:00+0100</p><p><b>value</b>: 57 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 69536005}\">Head structure (body structure)</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "248326004",
          "display" : "Body measure (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9843-4",
          "display" : "Head Occipital-frontal circumference"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "363812007"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2024-02-15T14:30:00+01:00",
        "end" : "2024-02-15T14:35:00+01:00"
      },
      "valueQuantity" : {
        "value" : 57,
        "unit" : "centimeter",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      },
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "69536005",
          "display" : "Head structure (body structure)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-kopfumfang-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-fio2-eingest-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion\">MII PR ICU Inspiratorische Sauerstofffraktion</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-fio2-eingest-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250774007}\">Inspired oxygen concentration (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 0.5 percent<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-fio2-eingest-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250774007",
          "display" : "Inspired oxygen concentration (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 0.5,
        "unit" : "percent",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-null-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-atemdr-null-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-null-expiratorischem-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-atemdr-null-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-atemdr-null-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-atemdr-null-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-atemdr-null-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-null-expiratorischem-gasfluss\">MII PR ICU Atemwegsdruck Bei Null Expiratorischem Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-atemdr-null-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20060-0}\">Pressure.airway^at zero inspiratory flow on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 3 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-atemdr-null-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20060-0",
          "display" : "Pressure.airway^at zero inspiratory flow on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 3,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-null-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-mittlerem-expiratorischem-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-mittlerem-expiratorischem-gasfluss\">MII PR ICU Atemwegsdruck Bei Mittlerem Expiratorischem Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-atemdr-mitt-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20056-8}\">Pressure.airway^at mean expiratory flow on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 8 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-atemdr-mitt-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20056-8",
          "display" : "Pressure.airway^at mean expiratory flow on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 8,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-einst-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-einst-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-einstellung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-einst-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-einst-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-einst-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-einst-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-einstellung\">MII PR ICU Atemzugvolumen Einstellung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-einst-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 416811008}, {http://loinc.org 20112-9}, {urn:iso:std:iso:11073:10101 16929196}\">Tidal volume setting (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 340 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-einst-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "416811008",
          "display" : "Tidal volume setting (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "20112-9",
          "display" : "Tidal volume setting Ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929196",
          "display" : "MDC_VENT_VOL_TIDAL_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 340,
        "unit" : "mL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-einst-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-beat-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-beat-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-waehrend-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-beat-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-beat-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-beat-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-beat-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-waehrend-beatmung\">MII PR ICU Atemzugvolumen Waehrend Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-beat-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250874002}, {http://loinc.org 76222-9}, {urn:iso:std:iso:11073:10101 151980}\">Ventilator delivered tidal volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 320 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-beat-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250874002",
          "display" : "Ventilator delivered tidal volume (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76222-9",
          "display" : "Tidal volume Ventilator --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151980",
          "display" : "Volume of gas delivered through the patient-connection port during a respiratory cycle."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 320,
        "unit" : "mL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-beat-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-mv-masch-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-mv-masch-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungsvolumen-pro-minute-maschineller-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-mv-masch-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-mv-masch-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-mv-masch-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-mv-masch-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungsvolumen-pro-minute-maschineller-beatmung\">MII PR ICU Beatmungsvolumen Pro Minute Maschineller Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-mv-masch-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250875001}, {http://loinc.org 76009-0}, {urn:iso:std:iso:11073:10101 152004}\">Ventilator delivered minute volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 7.5 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-mv-masch-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250875001",
          "display" : "Ventilator delivered minute volume (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76009-0",
          "display" : "Inspired minute Volume during Mechanical ventilation"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152004",
          "display" : "Total volume of gas breathed in during 1 min during mechanical ventilation."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 7.5,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-mv-masch-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-hohem-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-zeit-hoch-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-hohem-druck\">MII PR ICU Beatmungszeit Hohem Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-zeit-hoch-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76190-8}, {urn:iso:std:iso:11073:10101 16929860}\">High pressure hold time setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 1 seconds<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codes = 's')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-zeit-hoch-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76190-8",
          "display" : "High pressure hold time setting Ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929860",
          "display" : "MDC_VENT_TIME_PD_INSP_THIGH_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 1,
        "unit" : "seconds",
        "system" : "http://unitsofmeasure.org",
        "code" : "s"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-niedrigem-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-niedrigem-druck\">MII PR ICU Beatmungszeit Niedrigem Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-zeit-niedrig-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76229-4}, {urn:iso:std:iso:11073:10101 16929864}\">Low pressure hold time setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 0.8 seconds<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codes = 's')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-zeit-niedrig-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76229-4",
          "display" : "Low pressure hold time setting Ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929864",
          "display" : "MDC_VENT_TIME_PD_EXP_TLOW_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 0.8,
        "unit" : "seconds",
        "system" : "http://unitsofmeasure.org",
        "code" : "s"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-eingestellter-inspiratorischer-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-insp-flow-set-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-eingestellter-inspiratorischer-gasfluss\">MII PR ICU Eingestellter Inspiratorischer Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-insp-flow-set-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76275-7}\">Inspiratory flow setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 40 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-insp-flow-set-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76275-7",
          "display" : "Inspiratory flow setting Ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 40,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-te-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-te-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-ausatmungszeit-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-te-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-te-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-te-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-te-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-ausatmungszeit-beatmung\">MII PR ICU Einstellung Ausatmungszeit Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-te-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250820008}, {http://loinc.org 76187-4}\">Expiratory time (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 2 seconds<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codes = 's')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-te-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250820008",
          "display" : "Expiratory time (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76187-4",
          "display" : "Expiratory hold time setting"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 2,
        "unit" : "seconds",
        "system" : "http://unitsofmeasure.org",
        "code" : "s"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-te-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-ti-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-ti-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-einatmungszeit-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-ti-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-ti-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-ti-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-ti-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-einatmungszeit-beatmung\">MII PR ICU Einstellung Einatmungszeit Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-ti-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250819002}, {http://loinc.org 76334-2}, {urn:iso:std:iso:11073:10101 16929632}\">Inspiratory time (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 1 seconds<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codes = 's')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-ti-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250819002",
          "display" : "Inspiratory time (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76334-2",
          "display" : "Inspiratory time setting"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929632",
          "display" : "MDC_VENT_TIME_PD_INSP_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 1,
        "unit" : "seconds",
        "system" : "http://unitsofmeasure.org",
        "code" : "s"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-ti-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-etco2-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-etco2-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-endexpiratorischer-kohlendioxidpartialdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-etco2-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-etco2-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-etco2-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-etco2-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-endexpiratorischer-kohlendioxidpartialdruck\">MII PR ICU Endexpiratorischer Kohlendioxidpartialdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-etco2-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250790007}, {http://loinc.org 19891-1}, {urn:iso:std:iso:11073:10101 151708}\">End tidal carbon dioxide tension (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 35 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-etco2-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250790007",
          "display" : "End tidal carbon dioxide tension (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "19891-1",
          "display" : "Carbon dioxide^at end expiration"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151708",
          "display" : "Partial pressure of carbon dioxide in airway gas measured at the end of expiration."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 35,
        "unit" : "mmHg",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm[Hg]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-etco2-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-exp-flow-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-exp-flow-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-exp-flow-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-exp-flow-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-exp-flow-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-exp-flow-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-gasfluss\">MII PR ICU Exspiratorischer Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-exp-flow-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 60792-9}, {urn:iso:std:iso:11073:10101 151944}\">Expiratory gas flow Respiratory system airway --on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 35 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-exp-flow-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60792-9",
          "display" : "Expiratory gas flow Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151944",
          "display" : "Expiratory gas flow during mechanical ventilation. "
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 35,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-exp-flow-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-horowitz-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-horowitz-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-horowitz-in-arteriellem-blut"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-horowitz-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-horowitz-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-horowitz-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-horowitz-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-horowitz-in-arteriellem-blut\">MII PR ICU Horowitz In Arteriellem Blut</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-horowitz-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 50984-4}, {urn:iso:std:iso:11073:10101 150656}\">Horowitz index in Arterial blood</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 68 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-horowitz-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "50984-4",
          "display" : "Horowitz index in Arterial blood"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "150656",
          "display" : "Oxygenation Ratio, calculated as the ratio of PaO2 (partial pressure of arterial oxygen) divided by FiO2 (the fractional of inspired oxygen, e.g., FiO2 in air = 0.21)."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 68,
        "unit" : "mmHg",
        "system" : "http://unitsofmeasure.org",
        "code" : "mm[Hg]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-horowitz-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-fio2-gem-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-fio2-gem-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-fio2-gem-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-fio2-gem-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-fio2-gem-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-fio2-gem-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion\">MII PR ICU Inspiratorische Sauerstofffraktion</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-fio2-gem-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250774007}\">Inspired oxygen concentration (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 0.52 percent<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-fio2-gem-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250774007",
          "display" : "Inspired oxygen concentration (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 0.52,
        "unit" : "percent",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-fio2-gem-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorischer-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-insp-flow-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-insp-flow-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-insp-flow-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-insp-flow-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorischer-gasfluss\">MII PR ICU Inspiratorischer Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-insp-flow-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 60794-5}, {urn:iso:std:iso:11073:10101 151948}\">Inspiratory gas flow Respiratory system airway --on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 40 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-insp-flow-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60794-5",
          "display" : "Inspiratory gas flow Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151948",
          "display" : "MDC_VENT_FLOW_INSP"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 40,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pip-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pip-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pip-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pip-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pip-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pip-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-beatmungsdruck\">MII PR ICU Maximaler Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pip-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 27913002}, {http://loinc.org 76531-3}, {urn:iso:std:iso:11073:10101 151957}\">Maximum inspiratory pressure</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 27 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pip-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "27913002",
          "display" : "Maximum inspiratory pressure"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76531-3",
          "display" : "Pressure.max Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151957",
          "display" : "Maximum airway pressure during mechanical ventilation."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 27,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pip-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-freq-mech-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-freq-mech-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mechanische-atemfrequenz-beatmet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-freq-mech-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-freq-mech-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-freq-mech-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-freq-mech-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mechanische-atemfrequenz-beatmet\">MII PR ICU Mechanische Atemfrequenz Beatmet</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-freq-mech-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250876000}, {http://loinc.org 33438-3}, {urn:iso:std:iso:11073:10101 151586}\">Ventilator rate (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 12 breaths per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{Breaths}/min = '{Breaths}/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-freq-mech-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250876000",
          "display" : "Ventilator rate (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "33438-3",
          "display" : "Breath rate mechanical --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151586",
          "display" : "Rate of mechanical ventilation; method not specified."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 12,
        "unit" : "breaths per minute",
        "system" : "http://unitsofmeasure.org",
        "code" : "{Breaths}/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-mech-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-map-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-map-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-map-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-map-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-map-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-map-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-beatmungsdruck\">MII PR ICU Mittlerer Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-map-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 698821009}, {http://loinc.org 76530-5}, {urn:iso:std:iso:11073:10101 151975}\">Mean inspiratory airway pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 18 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-map-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "698821009",
          "display" : "Mean inspiratory airway pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76530-5",
          "display" : "Mean pressure Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151975",
          "display" : "Mean inspiratory airway pressure."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 18,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-map-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-peep-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-peep-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-positiv-endexpiratorischer-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-peep-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-peep-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-peep-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-peep-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-positiv-endexpiratorischer-druck\">MII PR ICU Positiv Endexpiratorischer Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-peep-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250854009}, {http://loinc.org 76248-4}, {urn:iso:std:iso:11073:10101 151976}\">Positive end expiratory pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 14 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-peep-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250854009",
          "display" : "Positive end expiratory pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76248-4",
          "display" : "PEEP Respiratory system --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151976",
          "display" : "Positive end expiratory pressure applied to the airway."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 14,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-peep-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-atemfrequenz-beatmet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-freq-spont-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-freq-spont-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-freq-spont-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-freq-spont-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-atemfrequenz-beatmet\">MII PR ICU Spontane Atemfrequenz Beatmet</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-freq-spont-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 152498}, {http://loinc.org 19839-0}\">Rate of breaths or inspiratory gas flow initiated and terminated by the patient where pressure and flow/volume delivery are determined by the patient without support or assistance by the ventilator. Includes unassisted breaths that are superimposed on the intermittently elevated baseline pressure with APRV, bilevel or spontaneous-only modes.</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 4 breaths per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-freq-spont-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152498",
          "display" : "Rate of breaths or inspiratory gas flow initiated and terminated by the patient where pressure and flow/volume delivery are determined by the patient without support or assistance by the ventilator. Includes unassisted breaths that are superimposed on the intermittently elevated baseline pressure with APRV, bilevel or spontaneous-only modes."
        },
        {
          "system" : "http://loinc.org",
          "code" : "19839-0",
          "display" : "Breath rate spontaneous --on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 4,
        "unit" : "breaths per minute",
        "system" : "http://unitsofmeasure.org",
        "code" : "/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-mechanische-atemfrequenz-beatmet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-mechanische-atemfrequenz-beatmet\">MII PR ICU Spontane Mechanische Atemfrequenz Beatmet</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-freq-spont-mech-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250810003}, {http://loinc.org 19840-8}, {urn:iso:std:iso:11073:10101 152490}\">Total breath rate (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 20 breaths per minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-freq-spont-mech-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250810003",
          "display" : "Total breath rate (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "19840-8",
          "display" : "Breath rate spontaneous and mechanical --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152490",
          "display" : "Total rate of breaths or inspiratory gas flow comprised of unassisted (P), supported (S), assisted (A), synchronized assisted (Z) and controlled (C) breath types."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 20,
        "unit" : "breaths per minute",
        "system" : "http://unitsofmeasure.org",
        "code" : "/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-atemzugvolumen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-spont-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-spont-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-spont-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-spont-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-atemzugvolumen\">MII PR ICU Spontanes Atemzugvolumen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-spont-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250816009}\">Spontaneous tidal volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 450 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-spont-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250816009",
          "display" : "Spontaneous tidal volume (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 450,
        "unit" : "mL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-mechanisches-atemzugvolumen-waehrend-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-mechanisches-atemzugvolumen-waehrend-beatmung\">MII PR ICU Spontanes Plus Mechanisches Atemzugvolumen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-spont-mech-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20118-6}\">Tidal volume.spontaneous+mechanical --on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 470 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-spont-mech-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20118-6",
          "display" : "Tidal volume.spontaneous+mechanical --on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 470,
        "unit" : "mL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-ps-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-ps-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-unterstuetzungsdruck-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-ps-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-ps-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-ps-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-ps-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-unterstuetzungsdruck-beatmung\">MII PR ICU Unterstuetzungsdruck Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-ps-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20079-0}\">Pressure support setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 12 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-ps-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20079-0",
          "display" : "Pressure support setting Ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 12,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-ps-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-ie-ratio-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-ie-ratio-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-zeitverhaeltnis-ein-ausatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-ie-ratio-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-ie-ratio-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-ie-ratio-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-ie-ratio-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-zeitverhaeltnis-ein-ausatmung\">MII PR ICU Zeitverhaeltnis Ein Ausatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-ie-ratio-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250822000}, {http://loinc.org 75931-6}, {urn:iso:std:iso:11073:10101 151832}\">Inspiration/expiration time ratio (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 0.5 ratio<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{ratio} = '{ratio}')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-ie-ratio-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250822000",
          "display" : "Inspiration/expiration time ratio (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "75931-6",
          "display" : "Inspiration/Expiration time Ratio"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151832",
          "display" : "Ratio of durations of inspiratory and expiratory phases."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 0.5,
        "unit" : "ratio",
        "system" : "http://unitsofmeasure.org",
        "code" : "{ratio}"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-ie-ratio-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-compliance-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-compliance-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-dynamische-kompliance"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-compliance-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-compliance-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-compliance-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-compliance-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-dynamische-kompliance\">MII PR ICU Dynamische Kompliance</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-compliance-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250823005}, {urn:iso:std:iso:11073:10101 151692}, {http://loinc.org 60827-3}\">Total dynamic compliance (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 50 mL/cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL/cm[H2O] = 'mL/cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-compliance-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250823005",
          "display" : "Total dynamic compliance (observable entity)"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151692",
          "display" : "Change of tidal volume per unit change of transthoracic pressure."
        },
        {
          "system" : "http://loinc.org",
          "code" : "60827-3",
          "display" : "Compliance.dynamic"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 50,
        "unit" : "mL/cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL/cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-compliance-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-dp-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-dp-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-druckdifferenz-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-dp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-dp-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-dp-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-dp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-druckdifferenz-beatmung\">MII PR ICU Druckdifferenz Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-dp-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76154-4}, {urn:iso:std:iso:11073:10101 152720}\">Airway pressure delta^on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 13 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-dp-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76154-4",
          "display" : "Airway pressure delta^on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152720",
          "display" : "Inspiratory airway pressure relative to PEEP or BAP."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 13,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-dp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pmax-insp-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pmax-insp-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-inspiratorischer-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pmax-insp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pmax-insp-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pmax-insp-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pmax-insp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-inspiratorischer-beatmungsdruck\">MII PR ICU Maximaler Inspiratorischer Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pmax-insp-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 27913002}, {urn:iso:std:iso:11073:10101 151973}\">Maximum inspiratory pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 28 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pmax-insp-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "27913002",
          "display" : "Maximum inspiratory pressure (observable entity)"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151973",
          "display" : "Maximum inspiratory airway pressure."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 28,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmax-insp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pmean-insp-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pmean-insp-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-inspiratorischer-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pmean-insp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pmean-insp-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pmean-insp-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pmean-insp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-inspiratorischer-beatmungsdruck\">MII PR ICU Mittlerer Inspiratorischer Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pmean-insp-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 698821009}, {http://loinc.org 60952-9}, {urn:iso:std:iso:11073:10101 151975}\">Mean inspiratory airway pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 14 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pmean-insp-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "698821009",
          "display" : "Mean inspiratory airway pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "60952-9",
          "display" : "Mean airway pressure --during inspiration"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151975",
          "display" : "Mean inspiratory airway pressure."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 14,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmean-insp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pplat-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pplat-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-plateau-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pplat-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pplat-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pplat-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pplat-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-plateau-beatmungsdruck\">MII PR ICU Plateau Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pplat-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 698822002}, {http://loinc.org 76259-1}, {urn:iso:std:iso:11073:10101 152424}\">Airway plateau pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 22 cmH2O<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm[H2O] = 'cm[H2O]')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pplat-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "698822002",
          "display" : "Airway plateau pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76259-1",
          "display" : "Pressure.plateau Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152424",
          "display" : "Pressure in airway in plateau phase during mechanical ventilation."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 22,
        "unit" : "cmH2O",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm[H2O]"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pplat-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-param-generisch-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-param-generisch-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-parameter-von-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-param-generisch-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-param-generisch-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-param-generisch-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-param-generisch-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-parameter-von-beatmung\">MII PR ICU Parameter von Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-param-generisch-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 426102006}\">Inspiratory minute volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:00:00+0200</p><p><b>issued</b>: 2024-05-05 11:00:00+0200</p><p><b>value</b>: 7.2 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-param-generisch-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "426102006",
          "display" : "Inspiratory minute volume (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:00:00+02:00",
      "issued" : "2024-05-05T11:00:00+02:00",
      "valueQuantity" : {
        "value" : 7.2,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-param-generisch-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-ect-param-generisch-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-ect-param-generisch-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-parameter-von-extrakorporalen-verfahren"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-ect-param-generisch-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-ect-param-generisch-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-param-generisch-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-param-generisch-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-parameter-von-extrakorporalen-verfahren\">MII PR ICU Parameter von Extrakorporalen Verfahren</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-ect-param-generisch-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html\">Procedure Extracorporeal membrane oxygenation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 79063001}\">Gas flow rate (v)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 20:00:00+0200</p><p><b>value</b>: 6 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></p><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html\">DeviceMetric: type = Extracorporeal circulation procedure; category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-ect-param-generisch-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "79063001",
          "display" : "Gas flow rate (v)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T20:00:00+02:00",
      "valueQuantity" : {
        "value" : 6,
        "unit" : "L/min",
        "system" : "http://unitsofmeasure.org",
        "code" : "L/min"
      },
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-ect-param-generisch-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-laenge-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-laenge-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerperlaenge"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-laenge-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-laenge-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-laenge-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-laenge-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerperlaenge\">MII PR ICU MUV Koerperlaenge</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-laenge-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1149101003}, {http://loinc.org 8306-3}\">Body height --lying</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-01 12:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 168 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 102538003}\">Recumbent body position (finding)</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8302-2}\">Stehend gemessene Koerpergroesse (anamnestisch)</span></p><p><b>value</b>: 170 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>150 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></td><td>190 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-laenge-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1149101003"
        },
        {
          "system" : "http://loinc.org",
          "code" : "8306-3",
          "display" : "Body height --lying"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-01T12:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 168,
        "unit" : "centimeter",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "102538003",
          "display" : "Recumbent body position (finding)"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8302-2",
            "display" : "Body height"
          }],
          "text" : "Stehend gemessene Koerpergroesse (anamnestisch)"
        },
        "valueQuantity" : {
          "value" : 170,
          "unit" : "centimeter",
          "system" : "http://unitsofmeasure.org",
          "code" : "cm"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "N",
            "display" : "Normal"
          }]
        }],
        "referenceRange" : [{
          "low" : {
            "value" : 150,
            "unit" : "centimeter",
            "system" : "http://unitsofmeasure.org",
            "code" : "cm"
          },
          "high" : {
            "value" : 190,
            "unit" : "centimeter",
            "system" : "http://unitsofmeasure.org",
            "code" : "cm"
          }
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-laenge-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-patient-1-icu-ect-extrakorp-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-extrakorporales-verfahren"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-patient-1-icu-ect-extrakorp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-patient-1-icu-ect-extrakorp-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-extrakorp-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-extrakorp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-extrakorporales-verfahren\">MII PR ICU Extrakorporales Verfahren</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>ExtensionProzedurDokumentationsdatum</b>: 2024-05-11 15:00:00+0200</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 233573008}, {http://fhir.de/CodeSystem/bfarm/ops 8-852.05}\">Extracorporeal membrane oxygenation (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>performed</b>: 2024-05-03 02:00:00+0200 --&gt; 2024-05-11 14:00:00+0200</p><p><b>recorder</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 83419000}\">Femoral vein structure (body structure)</span></p><p><b>note</b>: </p><blockquote><div><p>VV-ECMO ueber femoro-jugulaere Kanuelierung bei schwerem COVID-ARDS, komplikationsloser Lauf ueber 8 Tage.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2024-05-11T15:00:00+02:00"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "233573008",
          "display" : "Extracorporeal membrane oxygenation (procedure)"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "R",
              "display" : "rechts"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2024",
          "code" : "8-852.05",
          "display" : "Dauer der Behandlung 192 bis unter 240 Stunden"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2024-05-03T02:00:00+02:00",
        "end" : "2024-05-11T14:00:00+02:00"
      },
      "recorder" : {
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "83419000",
          "display" : "Femoral vein structure (body structure)"
        }]
      }],
      "note" : [{
        "text" : "VV-ECMO ueber femoro-jugulaere Kanuelierung bei schwerem COVID-ARDS, komplikationsloser Lauf ueber 8 Tage."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-patient-1-icu-vent-beatmung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-patient-1-icu-vent-beatmung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-patient-1-icu-vent-beatmung-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-beatmung-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-beatmung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-beatmung\">MII PR ICU Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>ExtensionProzedurDokumentationsdatum</b>: 2024-05-13 10:00:00+0200</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 243147009}, {http://fhir.de/CodeSystem/bfarm/ops 8-718.73}\">Controlled ventilation (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>performed</b>: 2024-05-01 18:00:00+0200 --&gt; 2024-05-13 09:00:00+0200</p><p><b>recorder</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 44567001}\">Trachea structure (body structure)</span></p><p><b>note</b>: </p><blockquote><div><p>Invasive Beatmung mit ultraprotektiver Lungen-Ruhigstellung unter VV-ECMO, strukturierte Beatmungsentwoehnung mit taeglichen Spontanatmungsversuchen, Extubation am 13.05.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2024-05-13T10:00:00+02:00"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "243147009",
          "display" : "Controlled ventilation (procedure)"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "B"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2024",
          "code" : "8-718.73",
          "display" : "Mindestens 11 bis höchstens 20 Behandlungstage"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2024-05-01T18:00:00+02:00",
        "end" : "2024-05-13T09:00:00+02:00"
      },
      "recorder" : {
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "44567001",
          "display" : "Trachea structure (body structure)"
        }]
      }],
      "note" : [{
        "text" : "Invasive Beatmung mit ultraprotektiver Lungen-Ruhigstellung unter VV-ECMO, strukturierte Beatmungsentwoehnung mit taeglichen Spontanatmungsversuchen, Extubation am 13.05."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-patient-1-icu-device-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-patient-1-icu-device-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-patient-1-icu-device-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-patient-1-icu-device-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-device-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-device-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device\">MII PR ICU Device</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/ICU-VENT-001</p><p><b>status</b>: Active</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Draeger Evita V500</td><td>Manufacturer name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 706172005}\">Ventilator (physical object)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>SW 2.64</td></tr></table><h3>Properties</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>ValueQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:11073:10101 16929196}\">MDC_VENT_VOL_TIDAL_SETTING</span></td><td>340 mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td></tr></table><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "ICU-VENT-001"
      }],
      "status" : "active",
      "deviceName" : [{
        "name" : "Draeger Evita V500",
        "type" : "manufacturer-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "706172005",
          "display" : "Ventilator (physical object)"
        }]
      },
      "version" : [{
        "value" : "SW 2.64"
      }],
      "property" : [{
        "type" : {
          "coding" : [{
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "16929196",
            "display" : "MDC_VENT_VOL_TIDAL_SETTING"
          }]
        },
        "valueQuantity" : [{
          "value" : 340,
          "unit" : "mL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-patient-1-icu-device-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-patient-1-icu-device-ecmo-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-patient-1-icu-device-ecmo-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-patient-1-icu-device-ecmo-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-patient-1-icu-device-ecmo-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-device-ecmo-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-device-ecmo-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device\">MII PR ICU Device</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/ICU-ECMO-001</p><p><b>status</b>: Active</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Getinge Cardiohelp</td><td>Manufacturer name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 303607000}\">VV-ECMO-System (extrakorporale Membranoxygenierung)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>SW 4.1</td></tr></table><h3>Properties</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>ValueQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 251288004}\">Extracorporeal gas exchange flow rate (observable entity)</span></td><td>4.5 L/min<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeL/min = 'L/min')</span></td></tr></table><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "ICU-ECMO-001"
      }],
      "status" : "active",
      "deviceName" : [{
        "name" : "Getinge Cardiohelp",
        "type" : "manufacturer-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "303607000",
          "display" : "Biomedical equipment (physical object)"
        }],
        "text" : "VV-ECMO-System (extrakorporale Membranoxygenierung)"
      },
      "version" : [{
        "value" : "SW 4.1"
      }],
      "property" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "251288004",
            "display" : "Extracorporeal gas exchange flow rate (observable entity)"
          }]
        },
        "valueQuantity" : [{
          "value" : 4.5,
          "unit" : "L/min",
          "system" : "http://unitsofmeasure.org",
          "code" : "L/min"
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-patient-1-icu-device-ecmo-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1",
    "resource" : {
      "resourceType" : "DeviceMetric",
      "id" : "mii-exa-test-data-patient-1-icu-ect-dm-param-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-dm-eingest-gem-parameter-extrakorporale-verfahren"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DeviceMetric_mii-exa-test-data-patient-1-icu-ect-dm-param-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DeviceMetric mii-exa-test-data-patient-1-icu-ect-dm-param-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-ect-dm-param-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-ect-dm-param-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-dm-eingest-gem-parameter-extrakorporale-verfahren\">MII PR ICU DeviceMetric Eingestellte Gemessene Parameter Extrakorporale Verfahren</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 182744004}\">Extracorporeal circulation procedure</span></p><p><b>source</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-ecmo-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-ECMO-001; status = active; type = Biomedical equipment (physical object)</a></p><p><b>category</b>: Measurement</p></div>"
      },
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "182744004",
          "display" : "Extracorporeal circulation procedure"
        }]
      },
      "source" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-ecmo-1"
      },
      "category" : "measurement"
    },
    "request" : {
      "method" : "PUT",
      "url" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1",
    "resource" : {
      "resourceType" : "DeviceMetric",
      "id" : "mii-exa-test-data-patient-1-icu-vent-dm-param-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-dm-eingestellte-gemessene-parameter-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DeviceMetric_mii-exa-test-data-patient-1-icu-vent-dm-param-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DeviceMetric mii-exa-test-data-patient-1-icu-vent-dm-param-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-dm-param-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-dm-param-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-dm-eingestellte-gemessene-parameter-beatmung\">MII PR ICU DeviceMetric Eingestellte Gemessene Parameter Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>source</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-VENT-001; status = active; type = Ventilator (physical object)</a></p><p><b>category</b>: Measurement</p></div>"
      },
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      },
      "source" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-1"
      },
      "category" : "measurement"
    },
    "request" : {
      "method" : "PUT",
      "url" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-patient-1-icu-device-monitor-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-patient-1-icu-device-monitor-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-patient-1-icu-device-monitor-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-patient-1-icu-device-monitor-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-device-monitor-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-device-monitor-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device\">MII PR ICU Device</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/ICU-MONITOR-001</p><p><b>status</b>: Active</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Philips IntelliVue MX800</td><td>Manufacturer name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 303607000}\">Patientenmonitor (Multiparameter)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>SW M.04.00</td></tr></table><h3>Properties</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>ValueCode</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 364075005}\">Heart rate (observable entity)</span></td><td><span title=\"Codes:{http://snomed.info/sct 255238004}\">Continuous (qualifier value)</span></td></tr></table><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "ICU-MONITOR-001"
      }],
      "status" : "active",
      "deviceName" : [{
        "name" : "Philips IntelliVue MX800",
        "type" : "manufacturer-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "303607000",
          "display" : "Biomedical equipment (physical object)"
        }],
        "text" : "Patientenmonitor (Multiparameter)"
      },
      "version" : [{
        "value" : "SW M.04.00"
      }],
      "property" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "364075005",
            "display" : "Heart rate (observable entity)"
          }]
        },
        "valueCode" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "255238004",
            "display" : "Continuous (qualifier value)"
          }]
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-patient-1-icu-device-monitor-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-patient-1-icu-device-pdms-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-patient-1-icu-device-pdms-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-patient-1-icu-device-pdms-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-patient-1-icu-device-pdms-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-device-pdms-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-device-pdms-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-device\">MII PR ICU Device</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/device-identifier</code>/ICU-PDMS-001</p><p><b>status</b>: Active</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>ICU-PDMS Bilanzierungsmodul</td><td>User Friendly name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 706687001}\">Patientendaten-Management-System (Bilanzierung)</span></p><h3>Versions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td>R2024.1</td></tr></table><h3>Properties</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>ValueCode</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 364396009}\">Fluid balance observable (observable entity)</span></td><td><span title=\"Codes:{http://snomed.info/sct 255238004}\">Continuous (qualifier value)</span></td></tr></table><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/device-identifier",
        "value" : "ICU-PDMS-001"
      }],
      "status" : "active",
      "deviceName" : [{
        "name" : "ICU-PDMS Bilanzierungsmodul",
        "type" : "user-friendly-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "706687001",
          "display" : "Software"
        }],
        "text" : "Patientendaten-Management-System (Bilanzierung)"
      },
      "version" : [{
        "value" : "R2024.1"
      }],
      "property" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "364396009",
            "display" : "Fluid balance observable (observable entity)"
          }]
        },
        "valueCode" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "255238004",
            "display" : "Continuous (qualifier value)"
          }]
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Practitioner/mii-exa-test-data-icu-practitioner-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-test-data-icu-practitioner-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_mii-exa-test-data-icu-practitioner-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-test-data-icu-practitioner-1</b></p><a name=\"mii-exa-test-data-icu-practitioner-1\"> </a><a name=\"hcmii-exa-test-data-icu-practitioner-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/practitioner-identifier</code>/ICU-ARZT-001</p><p><b>name</b>: Katharina Weber </p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/practitioner-identifier",
        "value" : "ICU-ARZT-001"
      }],
      "name" : [{
        "family" : "Weber",
        "given" : ["Katharina"],
        "prefix" : ["Dr. med."]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-nrs-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-nrs-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-numerische-ratingskala"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-nrs-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-nrs-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-nrs-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-nrs-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-numerische-ratingskala\">MII PR ICU Score Numerische Ratingskala</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1284857008}\">Numeric Pain Rating Scale score</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 10:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason temp-unknown}\">Temporarily Unknown</span></p><p><b>note</b>: </p><blockquote><div><p>Selbstauskunft unter Sedierung (RASS -3) nicht erhebbar; Fremdeinschaetzung via ZOPA.</p>\n</div></blockquote><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>DataAbsentReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 38214-3}\">Visuelle Analogskala als Gegenprobe</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></td></tr></table></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1284857008"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T10:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "temp-unknown",
          "display" : "Temporarily Unknown"
        }]
      },
      "note" : [{
        "text" : "Selbstauskunft unter Sedierung (RASS -3) nicht erhebbar; Fremdeinschaetzung via ZOPA."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "38214-3",
            "display" : "Pain severity [Score] Visual analog score"
          }],
          "text" : "Visuelle Analogskala als Gegenprobe"
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-performed",
            "display" : "Not Performed"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-nrs-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-gewicht-var-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-gewicht-var-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergewicht"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-gewicht-var-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-gewicht-var-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-gewicht-var-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-gewicht-var-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergewicht\">MII PR ICU MUV Koerpergewicht</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 29463-7}, {http://snomed.info/sct 27113001}\">Body weight</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>effective</b>: 2024-05-06 08:00:00+0200 --&gt; 2024-05-06 08:05:00+0200</p><p><b>value</b>: 79.5 kilogram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codekg = 'kg')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29463-7",
          "display" : "Body weight"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "27113001",
          "display" : "Body weight"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2024-05-06T08:00:00+02:00",
        "end" : "2024-05-06T08:05:00+02:00"
      },
      "valueQuantity" : {
        "value" : 79.5,
        "unit" : "kilogram",
        "system" : "http://unitsofmeasure.org",
        "code" : "kg"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-gewicht-var-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-groesse-var-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-groesse-var-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-groesse-var-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-groesse-var-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-groesse-var-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-groesse-var-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergroesse\">MII PR ICU MUV Koerpergroesse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8302-2}, {http://snomed.info/sct 1153637007}\">Body height</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>effective</b>: 2024-05-06 08:05:00+0200 --&gt; 2024-05-06 08:10:00+0200</p><p><b>value</b>: 175 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8302-2",
          "display" : "Body height"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1153637007",
          "display" : "Body height"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2024-05-06T08:05:00+02:00",
        "end" : "2024-05-06T08:10:00+02:00"
      },
      "valueQuantity" : {
        "value" : 175,
        "unit" : "centimeter",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-groesse-var-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-laenge-var-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-laenge-var-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerperlaenge"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-laenge-var-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-laenge-var-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-laenge-var-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-laenge-var-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerperlaenge\">MII PR ICU MUV Koerperlaenge</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1149101003}, {http://loinc.org 8306-3}\">Body height --lying</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>effective</b>: 2024-05-06 08:10:00+0200 --&gt; 2024-05-06 08:15:00+0200</p><p><b>value</b>: 168 centimeter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codecm = 'cm')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1149101003"
        },
        {
          "system" : "http://loinc.org",
          "code" : "8306-3",
          "display" : "Body height --lying"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2024-05-06T08:10:00+02:00",
        "end" : "2024-05-06T08:15:00+02:00"
      },
      "valueQuantity" : {
        "value" : 168,
        "unit" : "centimeter",
        "system" : "http://unitsofmeasure.org",
        "code" : "cm"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-laenge-var-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-mittlerem-expiratorischem-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-mittlerem-expiratorischem-gasfluss\">MII PR ICU Atemwegsdruck Bei Mittlerem Expiratorischem Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-atemdr-mitt-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20056-8}\">Pressure.airway^at mean expiratory flow on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-atemdr-mitt-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20056-8",
          "display" : "Pressure.airway^at mean expiratory flow on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-null-expiratorischem-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemwegsdruck-bei-null-expiratorischem-gasfluss\">MII PR ICU Atemwegsdruck Bei Null Expiratorischem Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-atemdr-null-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20060-0}\">Pressure.airway^at zero inspiratory flow on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-atemdr-null-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20060-0",
          "display" : "Pressure.airway^at zero inspiratory flow on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-einstellung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-einstellung\">MII PR ICU Atemzugvolumen Einstellung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-einst-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 416811008}, {http://loinc.org 20112-9}, {urn:iso:std:iso:11073:10101 16929196}\">Tidal volume setting (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-einst-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "416811008",
          "display" : "Tidal volume setting (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "20112-9",
          "display" : "Tidal volume setting Ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929196",
          "display" : "MDC_VENT_VOL_TIDAL_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-waehrend-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-atemzugvolumen-waehrend-beatmung\">MII PR ICU Atemzugvolumen Waehrend Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-beat-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250874002}, {http://loinc.org 76222-9}, {urn:iso:std:iso:11073:10101 151980}\">Ventilator delivered tidal volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-beat-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250874002",
          "display" : "Ventilator delivered tidal volume (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76222-9",
          "display" : "Tidal volume Ventilator --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151980",
          "display" : "Volume of gas delivered through the patient-connection port during a respiratory cycle."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungsvolumen-pro-minute-maschineller-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungsvolumen-pro-minute-maschineller-beatmung\">MII PR ICU Beatmungsvolumen Pro Minute Maschineller Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-mv-masch-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250875001}, {http://loinc.org 76009-0}, {urn:iso:std:iso:11073:10101 152004}\">Ventilator delivered minute volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-mv-masch-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250875001",
          "display" : "Ventilator delivered minute volume (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76009-0",
          "display" : "Inspired minute Volume during Mechanical ventilation"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152004",
          "display" : "Total volume of gas breathed in during 1 min during mechanical ventilation."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-hohem-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-hohem-druck\">MII PR ICU Beatmungszeit Hohem Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-zeit-hoch-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76190-8}, {urn:iso:std:iso:11073:10101 16929860}\">High pressure hold time setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-zeit-hoch-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76190-8",
          "display" : "High pressure hold time setting Ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929860",
          "display" : "MDC_VENT_TIME_PD_INSP_THIGH_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-niedrigem-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-beatmungszeit-niedrigem-druck\">MII PR ICU Beatmungszeit Niedrigem Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-zeit-niedrig-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76229-4}, {urn:iso:std:iso:11073:10101 16929864}\">Low pressure hold time setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-zeit-niedrig-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76229-4",
          "display" : "Low pressure hold time setting Ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929864",
          "display" : "MDC_VENT_TIME_PD_EXP_TLOW_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-dp-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-dp-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-druckdifferenz-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-dp-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-dp-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-dp-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-dp-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-druckdifferenz-beatmung\">MII PR ICU Druckdifferenz Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-dp-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76154-4}, {urn:iso:std:iso:11073:10101 152720}\">Airway pressure delta^on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-dp-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76154-4",
          "display" : "Airway pressure delta^on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152720",
          "display" : "Inspiratory airway pressure relative to PEEP or BAP."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-dp-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-compliance-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-compliance-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-dynamische-kompliance"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-compliance-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-compliance-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-compliance-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-compliance-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-dynamische-kompliance\">MII PR ICU Dynamische Kompliance</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-compliance-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250823005}, {urn:iso:std:iso:11073:10101 151692}, {http://loinc.org 60827-3}\">Total dynamic compliance (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-compliance-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250823005",
          "display" : "Total dynamic compliance (observable entity)"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151692",
          "display" : "Change of tidal volume per unit change of transthoracic pressure."
        },
        {
          "system" : "http://loinc.org",
          "code" : "60827-3",
          "display" : "Compliance.dynamic"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-compliance-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-eingestellter-inspiratorischer-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-eingestellter-inspiratorischer-gasfluss\">MII PR ICU Eingestellter Inspiratorischer Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-insp-flow-set-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 76275-7}\">Inspiratory flow setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-insp-flow-set-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76275-7",
          "display" : "Inspiratory flow setting Ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-te-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-te-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-ausatmungszeit-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-te-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-te-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-te-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-te-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-ausatmungszeit-beatmung\">MII PR ICU Einstellung Ausatmungszeit Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-te-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250820008}, {http://loinc.org 76187-4}\">Expiratory time (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-te-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250820008",
          "display" : "Expiratory time (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76187-4",
          "display" : "Expiratory hold time setting"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-te-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-ti-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-ti-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-einatmungszeit-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-ti-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-ti-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-ti-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-ti-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-einstellung-einatmungszeit-beatmung\">MII PR ICU Einstellung Einatmungszeit Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-ti-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250819002}, {http://loinc.org 76334-2}, {urn:iso:std:iso:11073:10101 16929632}\">Inspiratory time (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-ti-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250819002",
          "display" : "Inspiratory time (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76334-2",
          "display" : "Inspiratory time setting"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "16929632",
          "display" : "MDC_VENT_TIME_PD_INSP_SETTING"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-ti-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-etco2-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-etco2-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-endexpiratorischer-kohlendioxidpartialdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-etco2-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-etco2-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-etco2-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-etco2-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-endexpiratorischer-kohlendioxidpartialdruck\">MII PR ICU Endexpiratorischer Kohlendioxidpartialdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-etco2-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250790007}, {http://loinc.org 19891-1}, {urn:iso:std:iso:11073:10101 151708}\">End tidal carbon dioxide tension (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-etco2-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250790007",
          "display" : "End tidal carbon dioxide tension (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "19891-1",
          "display" : "Carbon dioxide^at end expiration"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151708",
          "display" : "Partial pressure of carbon dioxide in airway gas measured at the end of expiration."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-etco2-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-gasfluss\">MII PR ICU Exspiratorischer Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-exp-flow-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 60792-9}, {urn:iso:std:iso:11073:10101 151944}\">Expiratory gas flow Respiratory system airway --on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-exp-flow-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60792-9",
          "display" : "Expiratory gas flow Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151944",
          "display" : "Expiratory gas flow during mechanical ventilation. "
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-sauerstoffpartialdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-event-o2-partial-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-exspiratorischer-sauerstoffpartialdruck\">MII PR ICU Exspiratorischer Sauerstoffpartialdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-event-o2-partial-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 442720002}, {http://loinc.org 3147-6}, {urn:iso:std:iso:11073:10101 153132}\">Expired oxygen tension (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-event-o2-partial-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "442720002",
          "display" : "Expired oxygen tension (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "3147-6",
          "display" : "Oxygen [Partial pressure] in Exhaled gas"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "153132",
          "display" : "Partial pressure of oxygen in airway gas measured during expiration."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-horowitz-in-arteriellem-blut"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-horowitz-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-horowitz-in-arteriellem-blut\">MII PR ICU Horowitz In Arteriellem Blut</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-horowitz-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 50984-4}, {urn:iso:std:iso:11073:10101 150656}\">Horowitz index in Arterial blood</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-horowitz-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "50984-4",
          "display" : "Horowitz index in Arterial blood"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "150656",
          "display" : "Oxygenation Ratio, calculated as the ratio of PaO2 (partial pressure of arterial oxygen) divided by FiO2 (the fractional of inspired oxygen, e.g., FiO2 in air = 0.21)."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorische-sauerstofffraktion\">MII PR ICU Inspiratorische Sauerstofffraktion</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-fio2-gem-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250774007}\">Inspired oxygen concentration (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-fio2-gem-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250774007",
          "display" : "Inspired oxygen concentration (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorischer-gasfluss"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-inspiratorischer-gasfluss\">MII PR ICU Inspiratorischer Gasfluss</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-insp-flow-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 60794-5}, {urn:iso:std:iso:11073:10101 151948}\">Inspiratory gas flow Respiratory system airway --on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-insp-flow-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60794-5",
          "display" : "Inspiratory gas flow Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151948",
          "display" : "MDC_VENT_FLOW_INSP"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pip-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pip-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pip-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pip-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pip-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pip-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-beatmungsdruck\">MII PR ICU Maximaler Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pip-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 27913002}, {http://loinc.org 76531-3}, {urn:iso:std:iso:11073:10101 151957}\">Maximum inspiratory pressure</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pip-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "27913002",
          "display" : "Maximum inspiratory pressure"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76531-3",
          "display" : "Pressure.max Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151957",
          "display" : "Maximum airway pressure during mechanical ventilation."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pip-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-inspiratorischer-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-maximaler-inspiratorischer-beatmungsdruck\">MII PR ICU Maximaler Inspiratorischer Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pmax-insp-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 27913002}, {urn:iso:std:iso:11073:10101 151973}\">Maximum inspiratory pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pmax-insp-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "27913002",
          "display" : "Maximum inspiratory pressure (observable entity)"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151973",
          "display" : "Maximum inspiratory airway pressure."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mechanische-atemfrequenz-beatmet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mechanische-atemfrequenz-beatmet\">MII PR ICU Mechanische Atemfrequenz Beatmet</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-freq-mech-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250876000}, {http://loinc.org 33438-3}, {urn:iso:std:iso:11073:10101 151586}\">Ventilator rate (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-freq-mech-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250876000",
          "display" : "Ventilator rate (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "33438-3",
          "display" : "Breath rate mechanical --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151586",
          "display" : "Rate of mechanical ventilation; method not specified."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-map-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-map-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-map-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-map-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-map-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-map-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-beatmungsdruck\">MII PR ICU Mittlerer Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-map-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 698821009}, {http://loinc.org 76530-5}, {urn:iso:std:iso:11073:10101 151975}\">Mean inspiratory airway pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-map-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "698821009",
          "display" : "Mean inspiratory airway pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76530-5",
          "display" : "Mean pressure Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151975",
          "display" : "Mean inspiratory airway pressure."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-map-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-inspiratorischer-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-mittlerer-inspiratorischer-beatmungsdruck\">MII PR ICU Mittlerer Inspiratorischer Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pmean-insp-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 698821009}, {http://loinc.org 60952-9}, {urn:iso:std:iso:11073:10101 151975}\">Mean inspiratory airway pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pmean-insp-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "698821009",
          "display" : "Mean inspiratory airway pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "60952-9",
          "display" : "Mean airway pressure --during inspiration"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151975",
          "display" : "Mean inspiratory airway pressure."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-pplat-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-pplat-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-plateau-beatmungsdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-pplat-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-pplat-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-pplat-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-pplat-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-plateau-beatmungsdruck\">MII PR ICU Plateau Beatmungsdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-pplat-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 698822002}, {http://loinc.org 76259-1}, {urn:iso:std:iso:11073:10101 152424}\">Airway plateau pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-pplat-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "698822002",
          "display" : "Airway plateau pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76259-1",
          "display" : "Pressure.plateau Respiratory system airway --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152424",
          "display" : "Pressure in airway in plateau phase during mechanical ventilation."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-pplat-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-peep-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-peep-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-positiv-endexpiratorischer-druck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-peep-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-peep-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-peep-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-peep-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-positiv-endexpiratorischer-druck\">MII PR ICU Positiv Endexpiratorischer Druck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-peep-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250854009}, {http://loinc.org 76248-4}, {urn:iso:std:iso:11073:10101 151976}\">Positive end expiratory pressure (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-peep-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250854009",
          "display" : "Positive end expiratory pressure (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "76248-4",
          "display" : "PEEP Respiratory system --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151976",
          "display" : "Positive end expiratory pressure applied to the airway."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-peep-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-atemfrequenz-beatmet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-atemfrequenz-beatmet\">MII PR ICU Spontane Atemfrequenz Beatmet</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-freq-spont-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 152498}, {http://loinc.org 19839-0}\">Rate of breaths or inspiratory gas flow initiated and terminated by the patient where pressure and flow/volume delivery are determined by the patient without support or assistance by the ventilator. Includes unassisted breaths that are superimposed on the intermittently elevated baseline pressure with APRV, bilevel or spontaneous-only modes.</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-freq-spont-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152498",
          "display" : "Rate of breaths or inspiratory gas flow initiated and terminated by the patient where pressure and flow/volume delivery are determined by the patient without support or assistance by the ventilator. Includes unassisted breaths that are superimposed on the intermittently elevated baseline pressure with APRV, bilevel or spontaneous-only modes."
        },
        {
          "system" : "http://loinc.org",
          "code" : "19839-0",
          "display" : "Breath rate spontaneous --on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-mechanische-atemfrequenz-beatmet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontane-mechanische-atemfrequenz-beatmet\">MII PR ICU Spontane Mechanische Atemfrequenz Beatmet</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-freq-spont-mech-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250810003}, {http://loinc.org 19840-8}, {urn:iso:std:iso:11073:10101 152490}\">Total breath rate (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-freq-spont-mech-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250810003",
          "display" : "Total breath rate (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "19840-8",
          "display" : "Breath rate spontaneous and mechanical --on ventilator"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "152490",
          "display" : "Total rate of breaths or inspiratory gas flow comprised of unassisted (P), supported (S), assisted (A), synchronized assisted (Z) and controlled (C) breath types."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-atemzugvolumen"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-atemzugvolumen\">MII PR ICU Spontanes Atemzugvolumen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-spont-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250816009}\">Spontaneous tidal volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-spont-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250816009",
          "display" : "Spontaneous tidal volume (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-mechanisches-atemzugvolumen-waehrend-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-spontanes-mechanisches-atemzugvolumen-waehrend-beatmung\">MII PR ICU Spontanes Plus Mechanisches Atemzugvolumen</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-vt-spont-mech-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20118-6}\">Tidal volume.spontaneous+mechanical --on ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-vt-spont-mech-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20118-6",
          "display" : "Tidal volume.spontaneous+mechanical --on ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-ps-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-ps-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-unterstuetzungsdruck-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-ps-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-ps-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-ps-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-ps-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-unterstuetzungsdruck-beatmung\">MII PR ICU Unterstuetzungsdruck Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-ps-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 20079-0}\">Pressure support setting Ventilator</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-ps-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "20079-0",
          "display" : "Pressure support setting Ventilator"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-ps-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-zeitverhaeltnis-ein-ausatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-vent-zeitverhaeltnis-ein-ausatmung\">MII PR ICU Zeitverhaeltnis Ein Ausatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-ie-ratio-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 250822000}, {http://loinc.org 75931-6}, {urn:iso:std:iso:11073:10101 151832}\">Inspiration/expiration time ratio (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-ie-ratio-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "250822000",
          "display" : "Inspiration/expiration time ratio (observable entity)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "75931-6",
          "display" : "Inspiration/Expiration time Ratio"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "151832",
          "display" : "Ratio of durations of inspiratory and expiratory phases."
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-applicable",
          "display" : "Not Applicable"
        }]
      },
      "note" : [{
        "text" : "Nicht anwendbar: Beatmungsgeraet am 07.05.2024 um 06:00 Uhr im Standby (Spontanatmungsversuch am T-Stueck) - es war kein Beatmungsparameter eingestellt."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-parameter-von-beatmung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-parameter-von-beatmung\">MII PR ICU Parameter von Beatmung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-vent-param-generisch-dar-1</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html\">Procedure Controlled ventilation (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 40617009}\">Artificial ventilation (regime/therapy)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 426102006}\">Inspiratory minute volume (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 06:00:00+0200</p><p><b>issued</b>: 2024-05-07 06:10:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert.</p>\n</div></blockquote><p><b>device</b>: <a href=\"DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html\">DeviceMetric: type = Artificial ventilation (regime/therapy); category = measurement</a></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-vent-param-generisch-dar-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40617009",
          "display" : "Artificial ventilation (regime/therapy)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "426102006",
          "display" : "Inspiratory minute volume (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T06:00:00+02:00",
      "issued" : "2024-05-07T06:10:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Nicht erhoben: Patientin war am 07.05.2024 um 06:00 Uhr fuer den Spontanatmungsversuch am T-Stueck vom Respirator diskonnektiert, das Beatmungsgeraet lieferte keinen Messwert."
      }],
      "device" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-groesse-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-groesse-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-groesse-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-groesse-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-groesse-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-groesse-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerpergroesse\">MII PR ICU MUV Koerpergroesse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-groesse-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span>, <span title=\"Codes:{http://snomed.info/sct 248326004}\">Body measure (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8302-2}, {http://snomed.info/sct 1153637007}\">Body height</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Stehend gemessene Koerpergroesse bei analgosedierter, beatmeter Patientin nicht erhebbar; stattdessen wurde die liegende Koerperlaenge dokumentiert.</p>\n</div></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-groesse-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "248326004",
          "display" : "Body measure (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8302-2",
          "display" : "Body height"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1153637007",
          "display" : "Body height"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-05T08:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Stehend gemessene Koerpergroesse bei analgosedierter, beatmeter Patientin nicht erhebbar; stattdessen wurde die liegende Koerperlaenge dokumentiert."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-groesse-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-kopfumfang"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-kopfumfang\">MII PR ICU MUV Kopfumfang</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-kopfumfang-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span>, <span title=\"Codes:{http://snomed.info/sct 248326004}\">Body measure (observable entity)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9843-4}, {http://snomed.info/sct 363812007}\">Head Occipital-frontal circumference</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-05 08:30:00+0200 --&gt; 2024-05-05 08:35:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Kopfumfang nicht gemessen: bei der erwachsenen Intensivpatientin nicht Bestandteil der Routineerhebung.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 69536005}\">Head structure (body structure)</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-kopfumfang-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "248326004",
          "display" : "Body measure (observable entity)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9843-4",
          "display" : "Head Occipital-frontal circumference"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "363812007"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectivePeriod" : {
        "start" : "2024-05-05T08:30:00+02:00",
        "end" : "2024-05-05T08:35:00+02:00"
      },
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Kopfumfang nicht gemessen: bei der erwachsenen Intensivpatientin nicht Bestandteil der Routineerhebung."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "69536005",
          "display" : "Head structure (body structure)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-rass-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-rass-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-rass"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-rass-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-rass-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-rass-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-rass-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-rass\">MII PR ICU Score RASS</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-score-rass-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1345050000}\">Richmond Agitation Sedation Scale score (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 12:00:00+0200</p><p><b>issued</b>: 2024-05-06 12:10:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason temp-unknown}\">Temporarily Unknown</span></p><p><b>note</b>: </p><blockquote><div><p>RASS unter kontinuierlicher Muskelrelaxierung (Cisatracurium-Perfusor) nicht beurteilbar; Neubewertung nach Relaxansstopp.</p>\n</div></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-score-rass-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1345050000",
          "display" : "Richmond Agitation Sedation Scale score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T12:00:00+02:00",
      "issued" : "2024-05-06T12:10:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "temp-unknown",
          "display" : "Temporarily Unknown"
        }]
      },
      "note" : [{
        "text" : "RASS unter kontinuierlicher Muskelrelaxierung (Cisatracurium-Perfusor) nicht beurteilbar; Neubewertung nach Relaxansstopp."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-herzfrequenz"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-herzfrequenz\">MII PR ICU MUV Herzfrequenz</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-herzfreq-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 364075005}, {http://loinc.org 8867-4}, {urn:iso:std:iso:11073:10101 147842}\">Heart rate</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 14:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason temp-unknown}\">Temporarily Unknown</span></p><p><b>note</b>: </p><blockquote><div><p>EKG-Monitoring waehrend des Transports zur CT-Diagnostik abgesteckt; auch die palpatorische Kontrollmessung wurde nicht durchgefuehrt.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 80891009}\">Heart structure (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 29303009}\">Electrocardiographic procedure</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>DataAbsentReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 8867-4}\">Herzfrequenz, palpatorische Kontrollmessung</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-herzfreq-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "364075005",
          "display" : "Heart rate"
        },
        {
          "system" : "http://loinc.org",
          "code" : "8867-4",
          "display" : "Heart rate"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "147842",
          "display" : "MDC_ECG_HEART_RATE"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T14:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "temp-unknown",
          "display" : "Temporarily Unknown"
        }]
      },
      "note" : [{
        "text" : "EKG-Monitoring waehrend des Transports zur CT-Diagnostik abgesteckt; auch die palpatorische Kontrollmessung wurde nicht durchgefuehrt."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "80891009",
          "display" : "Heart structure (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "29303009",
          "display" : "Electrocardiographic procedure"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8867-4",
            "display" : "Heart rate"
          }],
          "text" : "Herzfrequenz, palpatorische Kontrollmessung"
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-performed",
            "display" : "Not Performed"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-laenge-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-laenge-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerperlaenge"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-laenge-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-laenge-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-laenge-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-laenge-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-koerperlaenge\">MII PR ICU MUV Koerperlaenge</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-laenge-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1149101003}, {http://loinc.org 8306-3}\">Body height --lying</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 14:00:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Laengenmessung waehrend der 16-stuendigen Bauchlagerung nicht durchfuehrbar; die stehende Koerpergroesse ist bei beatmeter Patientin ebenfalls nicht erhebbar.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 102538003}\">Recumbent body position (finding)</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>DataAbsentReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 8302-2}\">Stehend gemessene Koerpergroesse</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-laenge-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1149101003"
        },
        {
          "system" : "http://loinc.org",
          "code" : "8306-3",
          "display" : "Body height --lying"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T14:00:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Laengenmessung waehrend der 16-stuendigen Bauchlagerung nicht durchfuehrbar; die stehende Koerpergroesse ist bei beatmeter Patientin ebenfalls nicht erhebbar."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "102538003",
          "display" : "Recumbent body position (finding)"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8302-2",
            "display" : "Body height"
          }],
          "text" : "Stehend gemessene Koerpergroesse"
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-performed",
            "display" : "Not Performed"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-laenge-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-arterieller-blutdruck"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-muv-arterieller-blutdruck\">MII PR ICU MUV Arterieller Blutdruck</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-muv-blutdruck-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85354-9}, {http://snomed.info/sct 75367002}, {http://snomed.info/sct 364090009}\">Blood pressure panel with all children optional</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 14:00:00+0200</p><p><b>note</b>: </p><blockquote><div><p>Arterielle Druckmessung waehrend des Wechsels von Druckaufnehmer und Spuelsystem (14:00 Uhr) fuer ca. 5 Minuten unterbrochen; nicht-invasive Ersatzmessung erst um 14:10 Uhr.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 45631007}\">Structure of radial artery (body structure)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 17146006}\">Arterial pressure monitoring, invasive method (regime/therapy)</span></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-patient-1-icu-device-monitor-1.html\">Device: identifier = https://www.charite.de/fhir/sid/device-identifier#ICU-MONITOR-001; status = active; type = Biomedical equipment (physical object)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8480-6}, {http://snomed.info/sct 271649006}, {urn:iso:std:iso:11073:10101 150017}\">Systolic blood pressure</span></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason temp-unknown}\">Temporarily Unknown</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8462-4}, {http://snomed.info/sct 271650006}, {urn:iso:std:iso:11073:10101 150018}\">Diastolic blood pressure</span></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason temp-unknown}\">Temporarily Unknown</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8478-0}, {http://snomed.info/sct 6797001}, {urn:iso:std:iso:11073:10101 150019}\">Mean blood pressure</span></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason temp-unknown}\">Temporarily Unknown</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-muv-blutdruck-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85354-9",
          "display" : "Blood pressure panel with all children optional"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "75367002",
          "display" : "Blood pressure"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "364090009",
          "display" : "Systemic arterial pressure"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T14:00:00+02:00",
      "note" : [{
        "text" : "Arterielle Druckmessung waehrend des Wechsels von Druckaufnehmer und Spuelsystem (14:00 Uhr) fuer ca. 5 Minuten unterbrochen; nicht-invasive Ersatzmessung erst um 14:10 Uhr."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "45631007",
          "display" : "Structure of radial artery (body structure)"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "17146006",
          "display" : "Arterial pressure monitoring, invasive method (regime/therapy)"
        }]
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-monitor-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8480-6",
            "display" : "Systolic blood pressure"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "271649006",
            "display" : "Systolic blood pressure"
          },
          {
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "150017",
            "display" : "MDC_PRESS_BLD_NONINV_SYS"
          }]
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "temp-unknown",
            "display" : "Temporarily Unknown"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8462-4",
            "display" : "Diastolic blood pressure"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "271650006",
            "display" : "Diastolic blood pressure"
          },
          {
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "150018",
            "display" : "MDC_PRESS_BLD_NONINV_DIA"
          }]
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "temp-unknown",
            "display" : "Temporarily Unknown"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8478-0",
            "display" : "Mean blood pressure"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "6797001",
            "display" : "Mean blood pressure"
          },
          {
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "150019",
            "display" : "MDC_PRESS_BLD_NONINV_MEAN"
          }]
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "temp-unknown",
            "display" : "Temporarily Unknown"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-gcs-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-gcs-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-gcs"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-gcs-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-gcs-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-gcs-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-gcs-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-gcs\">MII PR ICU Score GCS</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-score-gcs-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9269-2}, {http://snomed.info/sct 248241002}, {urn:iso:std:iso:11073:10101 153728}\">Glasgow coma score total</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 12:00:00+0200</p><p><b>issued</b>: 2024-05-06 12:10:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 6 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p><p><b>note</b>: </p><blockquote><div><p>Verbale Reaktion bei orotracheal intubierter und beatmeter Patientin nicht beurteilbar; Gesamtscore als Summe aus Augenoeffnen (2) und motorischer Reaktion (4) = 6T dokumentiert.</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9267-6}\">Glasgow coma score eye opening</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6554-5}\">Eye opening to pain</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9268-4}\">Glasgow coma score motor</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6565-1}\">Withdrawal from pain</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9270-0}\">Glasgow coma score verbal</span></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-applicable}\">Not Applicable</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-score-gcs-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9269-2",
          "display" : "Glasgow coma score total"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "248241002"
        },
        {
          "system" : "urn:iso:std:iso:11073:10101",
          "code" : "153728"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T12:00:00+02:00",
      "issued" : "2024-05-06T12:10:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 6,
        "unit" : "{score}",
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "note" : [{
        "text" : "Verbale Reaktion bei orotracheal intubierter und beatmeter Patientin nicht beurteilbar; Gesamtscore als Summe aus Augenoeffnen (2) und motorischer Reaktion (4) = 6T dokumentiert."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9267-6",
            "display" : "Glasgow coma score eye opening"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6554-5",
            "display" : "Eye opening to pain"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9268-4",
            "display" : "Glasgow coma score motor"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6565-1",
            "display" : "Withdrawal from pain"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "9270-0",
            "display" : "Glasgow coma score verbal"
          }]
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-applicable",
            "display" : "Not Applicable"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-gcs-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-vas-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-vas-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-visuelle-analogskala"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-vas-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-vas-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-vas-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-vas-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-visuelle-analogskala\">MII PR ICU Score Visuelle Analogskala</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-score-vas-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 38214-3}, {http://snomed.info/sct 443394008}\">Pain severity [Score] Visual analog score</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 12:00:00+0200</p><p><b>issued</b>: 2024-05-06 12:10:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason temp-unknown}\">Temporarily Unknown</span></p><p><b>note</b>: </p><blockquote><div><p>Selbsteinschaetzung unter Analgosedierung (RASS -4) weder per VAS noch per NRS erhebbar; Fremdeinschaetzung erfolgte ueber ZOPA.</p>\n</div></blockquote><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>DataAbsentReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 72514-3}\">Numerische Ratingskala als Gegenprobe</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-score-vas-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "38214-3",
          "display" : "Pain severity [Score] Visual analog score"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "443394008"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T12:00:00+02:00",
      "issued" : "2024-05-06T12:10:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "temp-unknown",
          "display" : "Temporarily Unknown"
        }]
      },
      "note" : [{
        "text" : "Selbsteinschaetzung unter Analgosedierung (RASS -4) weder per VAS noch per NRS erhebbar; Fremdeinschaetzung erfolgte ueber ZOPA."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "72514-3",
            "display" : "Pain severity - 0-10 verbal numeric rating [Score] - Reported"
          }],
          "text" : "Numerische Ratingskala als Gegenprobe"
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-performed",
            "display" : "Not Performed"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-vas-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-fpsr-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-fpsr-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-faces-pain-scale-revised"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-fpsr-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-fpsr-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-fpsr-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-fpsr-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-faces-pain-scale-revised\">MII PR ICU Score Faces Pain Scale Revised</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-score-fpsr-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1284909003}\">Faces Pain Scale - Revised score (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-07 10:15:00+0200</p><p><b>issued</b>: 2024-05-07 10:25:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: 4 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p><p><b>note</b>: </p><blockquote><div><p>Bildgestuetzte Selbsteinschaetzung (FPS-R) gelang, die zusaetzliche numerische Gegenprobe wurde bei Erschoepfung der Patientin nicht durchgefuehrt.</p>\n</div></blockquote><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>DataAbsentReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 72514-3}\">Numerische Ratingskala als Gegenprobe</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-score-fpsr-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
          "code" : "1284909003",
          "display" : "Faces Pain Scale - Revised score (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-07T10:15:00+02:00",
      "issued" : "2024-05-07T10:25:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueQuantity" : {
        "value" : 4,
        "unit" : "{score}",
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "note" : [{
        "text" : "Bildgestuetzte Selbsteinschaetzung (FPS-R) gelang, die zusaetzliche numerische Gegenprobe wurde bei Erschoepfung der Patientin nicht durchgefuehrt."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "72514-3",
            "display" : "Pain severity - 0-10 verbal numeric rating [Score] - Reported"
          }],
          "text" : "Numerische Ratingskala als Gegenprobe"
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-performed",
            "display" : "Not Performed"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-fpsr-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-score-zopa-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-score-zopa-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-zopa"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-score-zopa-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-score-zopa-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-score-zopa-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-score-zopa-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-zopa\">MII PR ICU Score ZOPA</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-score-zopa-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category survey}\">Survey</span>, <span title=\"Codes:{http://snomed.info/sct 273249006}\">Assessment scales (assessment scale)</span></p><p><b>code</b>: <span title=\"Codes:{http://dgai.de DGAI-ZOPA}\">Zuerich Observation Pain Assessment (ZOPA)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 12:00:00+0200</p><p><b>issued</b>: 2024-05-06 12:10:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-test-data-icu-practitioner-1.html\">Practitioner Katharina Weber </a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 52101004}\">Present (qualifier value)</span></p><p><b>note</b>: </p><blockquote><div><p>ZOPA als Fremdeinschaetzung erhoben, weil die Selbsteinschaetzung per NRS bei intubierter, analgosedierter Patientin nicht moeglich ist.</p>\n</div></blockquote><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>DataAbsentReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 72514-3}\">Numerische Ratingskala (Selbsteinschaetzung)</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-score-zopa-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "survey",
          "display" : "Survey"
        }]
      },
      {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "273249006",
          "display" : "Assessment scales (assessment scale)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://dgai.de",
          "code" : "DGAI-ZOPA",
          "display" : "Zuerich Observation Pain Assessment (ZOPA)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T12:00:00+02:00",
      "issued" : "2024-05-06T12:10:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52101004",
          "display" : "Present (qualifier value)"
        }]
      },
      "note" : [{
        "text" : "ZOPA als Fremdeinschaetzung erhoben, weil die Selbsteinschaetzung per NRS bei intubierter, analgosedierter Patientin nicht moeglich ist."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "72514-3",
            "display" : "Pain severity - 0-10 verbal numeric rating [Score] - Reported"
          }],
          "text" : "Numerische Ratingskala (Selbsteinschaetzung)"
        },
        "dataAbsentReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "not-performed",
            "display" : "Not Performed"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-score-zopa-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-befund-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-befund-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenbefund"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-befund-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-befund-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-befund-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-befund-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenbefund\">MII PR ICU Untersuchung Pupillenbefund</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-befund-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 247010007}, {http://loinc.org 80310-6}\">Pupil finding (finding)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>note</b>: </p><blockquote><div><p>Pupillenstatus um 19:30 Uhr bei ausgepraegtem periorbitalem Lidoedem beidseits nicht durchfuehrbar; alle neun Einzelbefunde tragen denselben Grund.</p>\n</div></blockquote><p><b>hasMember</b>: </p><ul><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1.html\">Observation Pupil afferent light reaction</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1.html\">Observation Pupil afferent light reaction</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1.html\">Observation Indirect light pupillary reflex</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1.html\">Observation Indirect light pupillary reflex</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1.html\">Observation Size of pupil</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1.html\">Observation Size of pupil</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1.html\">Observation Pupil shape</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1.html\">Observation Pupil shape</a></li><li><a href=\"Observation-mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1.html\">Observation Finding of proportion of pupil (finding)</a></li></ul></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-befund-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "247010007",
          "display" : "Pupil finding (finding)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "80310-6",
          "display" : "Pupil assessment panel"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "note" : [{
        "text" : "Pupillenstatus um 19:30 Uhr bei ausgepraegtem periorbitalem Lidoedem beidseits nicht durchfuehrbar; alle neun Einzelbefunde tragen denselben Grund."
      }],
      "hasMember" : [{
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-befund-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-form-re-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform\">MII PR ICU Untersuchung Pupillenform</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-form-re-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363954009}\">Pupil shape</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Pupille rechts bei ausgepraegtem periorbitalem Lidoedem nicht einsehbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-form-re-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363954009",
          "display" : "Pupil shape"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Pupille rechts bei ausgepraegtem periorbitalem Lidoedem nicht einsehbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-form-li-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform\">MII PR ICU Untersuchung Pupillenform</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-form-li-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363954009}\">Pupil shape</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Pupille links bei ausgepraegtem periorbitalem Lidoedem nicht einsehbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-form-li-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363954009",
          "display" : "Pupil shape"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Pupille links bei ausgepraegtem periorbitalem Lidoedem nicht einsehbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse\">MII PR ICU Untersuchung Pupillengroesse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-groesse-re-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363953003}\">Size of pupil</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Pupillometrie rechts bei ausgepraegtem periorbitalem Lidoedem nicht durchfuehrbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-groesse-re-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363953003",
          "display" : "Size of pupil"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Pupillometrie rechts bei ausgepraegtem periorbitalem Lidoedem nicht durchfuehrbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse\">MII PR ICU Untersuchung Pupillengroesse</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-groesse-li-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 363953003}\">Size of pupil</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Pupillometrie links bei ausgepraegtem periorbitalem Lidoedem nicht durchfuehrbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-groesse-li-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363953003",
          "display" : "Size of pupil"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Pupillometrie links bei ausgepraegtem periorbitalem Lidoedem nicht durchfuehrbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt\">MII PR ICU Untersuchung Pupillenlichtreaktion Direkt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-dir-re-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 45832002}\">Pupil afferent light reaction</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Direkte Lichtreaktion rechts bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-dir-re-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "45832002"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Direkte Lichtreaktion rechts bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt\">MII PR ICU Untersuchung Pupillenlichtreaktion Direkt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-dir-li-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 45832002}\">Pupil afferent light reaction</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Direkte Lichtreaktion links bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-dir-li-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "45832002"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Direkte Lichtreaktion links bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt\">MII PR ICU Untersuchung Pupillenlichtreaktion Indirekt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-ind-re-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 84917001}\">Indirect light pupillary reflex</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Konsensuelle Lichtreaktion rechts bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 52378001}\">Structure of pupil of right eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-ind-re-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84917001"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Konsensuelle Lichtreaktion rechts bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "52378001",
          "display" : "Structure of pupil of right eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt\">MII PR ICU Untersuchung Pupillenlichtreaktion Indirekt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-licht-ind-li-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 84917001}\">Indirect light pupillary reflex</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Konsensuelle Lichtreaktion links bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 16089004}\">Structure of pupil of left eye</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-licht-ind-li-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84917001"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Konsensuelle Lichtreaktion links bei ausgepraegtem periorbitalem Lidoedem nicht pruefbar."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16089004",
          "display" : "Structure of pupil of left eye"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillensymmetrie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1</b></p><a name=\"mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1\"> </a><a name=\"hcmii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillensymmetrie\">MII PR ICU Untersuchung Pupillensymmetrie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/icu-observation-id</code>/icu-pupille-symmetrie-dar-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 301942005}\">Finding of proportion of pupil (finding)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-icu-patient-1.html\">Kim Musterperson  Female, DoB: 1956-03-14 ( https://www.medizininformatik-initiative.de/fhir/sid/standort-b#ICU-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-icu-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-05-01 --&gt; 2024-05-14</a></p><p><b>effective</b>: 2024-05-06 19:30:00+0200</p><p><b>dataAbsentReason</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason not-performed}\">Not Performed</span></p><p><b>note</b>: </p><blockquote><div><p>Seitenvergleich bei beidseits nicht einsehbaren Pupillen (periorbitales Lidoedem) nicht moeglich.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 67019001}\">Structure of pupil of both eyes (body structure)</span></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/icu-observation-id",
        "value" : "icu-pupille-symmetrie-dar-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "301942005",
          "display" : "Finding of proportion of pupil (finding)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "effectiveDateTime" : "2024-05-06T19:30:00+02:00",
      "dataAbsentReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
          "code" : "not-performed",
          "display" : "Not Performed"
        }]
      },
      "note" : [{
        "text" : "Seitenvergleich bei beidseits nicht einsehbaren Pupillen (periorbitales Lidoedem) nicht moeglich."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "67019001",
          "display" : "Structure of pupil of both eyes (body structure)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1"
    }
  }]
}

```
