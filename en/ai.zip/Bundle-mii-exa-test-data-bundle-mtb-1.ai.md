# mii-exa-test-data-bundle-mtb-1 - MII KDS Test Data v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-test-data-bundle-mtb-1**

## Example Bundle: mii-exa-test-data-bundle-mtb-1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-test-data-bundle-mtb-1",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2025-06-18T13:51:00+02:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-mtb-patient-1",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-mtb-patient-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-mtb-patient-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-mtb-patient-1</b></p><a name=\"mii-exa-test-data-mtb-patient-1\"> </a><a name=\"hcmii-exa-test-data-mtb-patient-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</p><hr/></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "MTB-TEST-001"
      }],
      "name" : [{
        "family" : "Tumorfall",
        "given" : ["Elena"]
      }],
      "gender" : "female",
      "birthDate" : "1971-04-12"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-mtb-patient-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-mtb-encounter-1",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-mtb-encounter-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-mtb-encounter-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-mtb-encounter-1</b></p><a name=\"mii-exa-test-data-mtb-encounter-1\"> </a><a name=\"hcmii-exa-test-data-mtb-encounter-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>period</b>: 2024-01-15 --&gt; 2024-06-30</p></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP",
        "display" : "inpatient encounter"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "period" : {
        "start" : "2024-01-15",
        "end" : "2024-06-30"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-mtb-encounter-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ClinicalImpression/mii-exa-test-data-mtb-behandlungsepisode-1",
    "resource" : {
      "resourceType" : "ClinicalImpression",
      "id" : "mii-exa-test-data-mtb-behandlungsepisode-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-behandlungsepisode"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalImpression_mii-exa-test-data-mtb-behandlungsepisode-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalImpression mii-exa-test-data-mtb-behandlungsepisode-1</b></p><a name=\"mii-exa-test-data-mtb-behandlungsepisode-1\"> </a><a name=\"hcmii-exa-test-data-mtb-behandlungsepisode-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-behandlungsepisode\">MII PR MTB Behandlungsepisode</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX MTB Leitlinienbehandlung Status</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-leitlinienbehandlung-status#mii-cs-mtb-leitlinienbehandlung-status-exhausted\">MII CS Leitlinienbehandlung Status: exhausted</a> (exhausted)</p><p><b>status</b>: Completed</p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>effective</b>: 2024-01-15 --&gt; 2024-06-30</p><p><b>problem</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><blockquote><p><b>investigation</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 106221001}\">Genetic finding</span></p><p><b>item</b>: <a href=\"DiagnosticReport-mii-exa-test-data-mtb-ngs-bericht-1.html\">Diagnostic Report for 'Genetic analysis report' for '-&gt;Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)'</a></p></blockquote><blockquote><p><b>investigation</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 60568-3}\">Pathology synoptic report</span></p><p><b>item</b>: <a href=\"DiagnosticReport-mii-exa-test-data-mtb-molecular-pathology-report-1.html\">Diagnostic Report for 'Pathology synoptic report' for '-&gt;Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)'</a></p></blockquote><blockquote><p><b>investigation</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 424122007}\">ECOG performance status finding</span></p><p><b>item</b>: <a href=\"Observation-mii-exa-test-data-mtb-labobs-ecog-1.html\">Observation ECOG Performance Status score</a></p></blockquote><blockquote><p><b>investigation</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 105511-0}\">Was consent given</span></p><p><b>item</b>: <a href=\"Observation-mii-exa-test-data-mtb-consent-given-1.html\">Observation Was consent given</a></p></blockquote><p><b>supportingInfo</b>: </p><ul><li><a href=\"Procedure-mii-exa-test-data-mtb-systemische-vortherapie-1.html\">Procedure Chemotherapy (procedure)</a></li><li><a href=\"Observation-mii-exa-test-data-mtb-labobs-vorbefund-1.html\">Observation Circulating cell-free genomic DNA [Mass/volume] in Plasma</a></li><li><a href=\"CarePlan-mii-exa-test-data-mtb-therapieplan-1.html\">CarePlan: status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); description = MTB-Beschluss mit Therapieempfehlungen und Studieneinschluss; created = 2024-03-28</a></li></ul></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-leitlinienbehandlung-status",
        "valueCoding" : {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-leitlinienbehandlung-status",
          "code" : "exhausted",
          "display" : "exhausted"
        }
      }],
      "status" : "completed",
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2024-01-15",
        "end" : "2024-06-30"
      },
      "problem" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "investigation" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "106221001",
            "display" : "Genetic finding"
          }]
        },
        "item" : [{
          "reference" : "DiagnosticReport/mii-exa-test-data-mtb-ngs-bericht-1"
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "60568-3",
            "display" : "Pathology synoptic report"
          }]
        },
        "item" : [{
          "reference" : "DiagnosticReport/mii-exa-test-data-mtb-molecular-pathology-report-1"
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "424122007",
            "display" : "ECOG performance status finding"
          }]
        },
        "item" : [{
          "reference" : "Observation/mii-exa-test-data-mtb-labobs-ecog-1"
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "105511-0",
            "display" : "Was consent given"
          }]
        },
        "item" : [{
          "reference" : "Observation/mii-exa-test-data-mtb-consent-given-1"
        }]
      }],
      "supportingInfo" : [{
        "extension" : [{
          "extension" : [{
            "url" : "Therapielinie",
            "valueUnsignedInt" : 1
          },
          {
            "url" : "Zulassungsstatus",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-zulassungsstatus",
                "code" : "in-label"
              }]
            }
          }],
          "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-leitlinie-dokumentation"
        }],
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-vortherapie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-labobs-vorbefund-1"
      },
      {
        "reference" : "CarePlan/mii-exa-test-data-mtb-therapieplan-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ClinicalImpression/mii-exa-test-data-mtb-behandlungsepisode-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-consent-given-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-consent-given-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-consent-given"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-consent-given-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-consent-given-1</b></p><a name=\"mii-exa-test-data-mtb-consent-given-1\"> </a><a name=\"hcmii-exa-test-data-mtb-consent-given-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-consent-given\">MII PR MTB Consent</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 105511-0}\">Was consent given</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-01-10</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 373066001}\">Yes (qualifier value)</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "105511-0",
          "display" : "Was consent given"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-01-10",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes (qualifier value)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-consent-given-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-mtb-diagnose-primaertumor-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnose-primaertumor"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-mtb-diagnose-primaertumor-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-mtb-diagnose-primaertumor-1</b></p><a name=\"mii-exa-test-data-mtb-diagnose-primaertumor-1\"> </a><a name=\"hcmii-exa-test-data-mtb-diagnose-primaertumor-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnose-primaertumor\">MII PR MTB Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2024-01-05</p><p><b>MII EX Onko Histology Morphology Behavior ICDO3</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 8140/3}\">Adenokarzinom o.n.A.</span></p><p><b>Condition Due To</b>: <span title=\"Codes:{http://snomed.info/sct 77176002}\">Smoker (finding)</span></p><p><b>Condition Occurred Following</b>: <span title=\"Codes:{http://snomed.info/sct 65958008}\">Chronic disease of respiratory system (disorder)</span></p><p><b>Condition Related</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-2.html\">Condition Bösartige Neubildung der Prostata</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-diagnose</code>/DIAG-2024-001</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung 7}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 55342001}\">Neoplastic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C34.1}\">Bösartige Neubildung: Oberlappen (-Bronchus)</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/icd-o-3 C34.1}, {http://snomed.info/sct 45653009}\">Lungenoberlappen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>onset</b>: 2023-12-15</p><p><b>recordedDate</b>: 2024-01-05</p><blockquote><p><b>stage</b></p><p><b>assessment</b>: <a href=\"Observation-mii-exa-test-data-mtb-tumorausbreitung-1.html\">Observation Tumor stage</a></p><p><b>type</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C19251}\">Stage at Diagnosis</span></p></blockquote><blockquote><p><b>stage</b></p><p><b>assessment</b>: <a href=\"Observation-mii-exa-test-data-mtb-oncotree-1.html\">Observation Histologic grade of neoplasm (observable entity)</a></p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 371441004}\">Histologic type of proliferative mass</span></p></blockquote><h3>Evidences</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Detail</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 49727002}\">Cough (finding)</span></td><td><a href=\"List-mii-exa-test-data-mtb-evidenz-liste-1.html\">List for 'Unspecified List Type' for '-&gt;Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)'</a></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Erstdiagnose eines EGFR-mutierten NSCLC des rechten Oberlappens.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2024-01-05"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-histology-morphology-behavior-icdo3",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
            "code" : "8140/3",
            "display" : "Adenocarcinoma, NOS"
          }],
          "text" : "Adenokarzinom o.n.A."
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-dueTo",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "77176002",
            "display" : "Smoker (finding)"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-occurredFollowing",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "65958008",
            "display" : "Chronic disease of respiratory system (disorder)"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-related",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-2"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-diagnose",
        "value" : "DIAG-2024-001"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
          "code" : "7"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55342001",
          "display" : "Neoplastic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_DIAGNOSESICHERHEIT",
              "code" : "G",
              "display" : "Gesicherte Diagnose"
            }
          },
          {
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "R",
              "display" : "rechts"
            }
          },
          {
            "url" : "http://fhir.de/StructureDefinition/icd-10-gm-mehrfachcodierungs-kennzeichen",
            "valueCoding" : {
              "system" : "http://fhir.de/CodeSystem/icd-10-gm-mehrfachcodierungs-kennzeichen",
              "code" : "!"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "C34.1",
          "display" : "Bösartige Neubildung: Oberlappen (-Bronchus)"
        }]
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "C34.1",
          "display" : "Lungenoberlappen"
        },
        {
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "45653009",
          "display" : "Structure of upper lobe of lung (body structure)"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "onsetDateTime" : "2023-12-15",
      "recordedDate" : "2024-01-05",
      "stage" : [{
        "assessment" : [{
          "reference" : "Observation/mii-exa-test-data-mtb-tumorausbreitung-1"
        }],
        "type" : {
          "coding" : [{
            "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
            "code" : "C19251",
            "display" : "Stage at Diagnosis"
          }]
        }
      },
      {
        "assessment" : [{
          "reference" : "Observation/mii-exa-test-data-mtb-oncotree-1"
        }],
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "371441004",
            "display" : "Histologic type of proliferative mass"
          }]
        }
      }],
      "evidence" : [{
        "code" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "49727002",
            "display" : "Cough (finding)"
          }]
        }],
        "detail" : [{
          "reference" : "List/mii-exa-test-data-mtb-evidenz-liste-1"
        }]
      }],
      "note" : [{
        "text" : "Erstdiagnose eines EGFR-mutierten NSCLC des rechten Oberlappens."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-mtb-diagnose-primaertumor-2",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-mtb-diagnose-primaertumor-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnose-primaertumor"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-mtb-diagnose-primaertumor-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-mtb-diagnose-primaertumor-2</b></p><a name=\"mii-exa-test-data-mtb-diagnose-primaertumor-2\"> </a><a name=\"hcmii-exa-test-data-mtb-diagnose-primaertumor-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnose-primaertumor\">MII PR MTB Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2018-03-01</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical resolved}\">Resolved</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung 7}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 55342001}\">Neoplastic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C61}\">Bösartige Neubildung der Prostata</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>onset</b>: 46 Jahre<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></p><p><b>abatement</b>: 2019-06-30</p><p><b>recordedDate</b>: 2018-03-01</p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2018-03-01"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "resolved"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
          "code" : "7"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55342001",
          "display" : "Neoplastic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2018",
          "code" : "C61",
          "display" : "Bösartige Neubildung der Prostata"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "onsetAge" : {
        "extension" : [{
          "url" : "http://fhir.de/StructureDefinition/lebensphase",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "41847000",
              "display" : "Adulthood (qualifier value)"
            }]
          }
        }],
        "value" : 46,
        "unit" : "Jahre",
        "system" : "http://unitsofmeasure.org",
        "code" : "a"
      },
      "abatementDateTime" : "2019-06-30",
      "recordedDate" : "2018-03-01"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-mtb-diagnose-primaertumor-3",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-mtb-diagnose-primaertumor-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnose-primaertumor"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-mtb-diagnose-primaertumor-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-mtb-diagnose-primaertumor-3</b></p><a name=\"mii-exa-test-data-mtb-diagnose-primaertumor-3\"> </a><a name=\"hcmii-exa-test-data-mtb-diagnose-primaertumor-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnose-primaertumor\">MII PR MTB Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2015-05-01</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical resolved}\">Resolved</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung 7}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 55342001}\">Neoplastic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C44.3}\">Sonstige bösartige Neubildungen: Haut sonstiger und nicht näher bezeichneter Teile des Gesichtes</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>abatement</b>: 45 Jahre<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></p><p><b>recordedDate</b>: 2015-05-01</p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2015-05-01"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "resolved"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
          "code" : "7"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55342001",
          "display" : "Neoplastic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2015",
          "code" : "C44.3",
          "display" : "Sonstige bösartige Neubildungen: Haut sonstiger und nicht näher bezeichneter Teile des Gesichtes"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "abatementAge" : {
        "extension" : [{
          "url" : "http://fhir.de/StructureDefinition/lebensphase",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "41847000",
              "display" : "Adulthood (qualifier value)"
            }]
          }
        }],
        "value" : 45,
        "unit" : "Jahre",
        "system" : "http://unitsofmeasure.org",
        "code" : "a"
      },
      "recordedDate" : "2015-05-01"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-oncotree-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-oncotree-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-oncotree"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-oncotree-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-oncotree-1</b></p><a name=\"mii-exa-test-data-mtb-oncotree-1\"> </a><a name=\"hcmii-exa-test-data-mtb-oncotree-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-oncotree\">MII PR MTB Oncotree Klassifikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 371469007}\">Histologic grade of neoplasm (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-01-05</p><p><b>value</b>: <span title=\"Codes:{http://data.mskcc.org/ontologies/oncotree NSCLC}\">Non-Small Cell Lung Cancer</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "371469007",
          "display" : "Histologic grade of neoplasm (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-01-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://data.mskcc.org/ontologies/oncotree",
          "code" : "NSCLC",
          "display" : "Non-Small Cell Lung Cancer"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-oncotree-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-mtb-systemische-vortherapie-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-mtb-systemische-vortherapie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemische-vortherapie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-mtb-systemische-vortherapie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-mtb-systemische-vortherapie-1</b></p><a name=\"mii-exa-test-data-mtb-systemische-vortherapie-1\"> </a><a name=\"hcmii-exa-test-data-mtb-systemische-vortherapie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemische-vortherapie\">MII PR MTB Systemische Vortherapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Systemische Therapie Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2023-11-20</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>MII EX Onko Systemische Therapie Stellung zur OP</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop O}\">ohne Bezug zur operativen Therapie</span></p><blockquote><p><b>MII EX MTB Leitlinie Dokumentation</b></p><ul><li>Therapielinie: 1</li><li>Zulassungsstatus: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-zulassungsstatus in-label}\">In-Label</span></li></ul></blockquote><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-mtb-therapieplan-1.html\">CarePlan: status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); description = MTB-Beschluss mit Therapieempfehlungen und Studieneinschluss; created = 2024-03-28</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-mtb-systemische-therapie-1.html\">Procedure Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie</a></p><p><b>status</b>: Completed</p><p><b>statusReason</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-systemische-therapie-status-grund regular-completion}\">regular-completion</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 277132007}\">Therapeutic procedure (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 367336001}, {https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ CH}, {http://fhir.de/CodeSystem/bfarm/ops 8-54}\">Chemotherapy (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>performed</b>: 2023-06-01 --&gt; 2023-11-15</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 39607008}\">Lung structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund E}\">reguläres Ende</span></p><p><b>note</b>: </p><blockquote><div><p>Platinbasierte Erstlinien-Chemotherapie vor MTB-Vorstellung.</p>\n</div></blockquote><p><b>usedCode</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-systemische-therapie-protokolle CarboTax}\">CarboTax</span></p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-systemische-therapie-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2023-11-20"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-systemische-therapie-stellungzurop",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop",
            "code" : "O"
          }],
          "text" : "ohne Bezug zur operativen Therapie"
        }
      },
      {
        "extension" : [{
          "url" : "Therapielinie",
          "valueUnsignedInt" : 1
        },
        {
          "url" : "Zulassungsstatus",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-zulassungsstatus",
              "code" : "in-label",
              "display" : "In-Label"
            }]
          }
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-leitlinie-dokumentation"
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-mtb-therapieplan-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
      }],
      "status" : "completed",
      "statusReason" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-systemische-therapie-status-grund",
          "code" : "regular-completion"
        }]
      },
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "277132007",
          "display" : "Therapeutic procedure (procedure)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "367336001",
          "display" : "Chemotherapy (procedure)"
        },
        {
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
          "code" : "CH"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "R",
              "display" : "rechts"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2023",
          "code" : "8-54",
          "display" : "Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2023-06-01",
        "end" : "2023-11-15"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "39607008",
          "display" : "Lung structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund",
          "code" : "E"
        }]
      },
      "note" : [{
        "text" : "Platinbasierte Erstlinien-Chemotherapie vor MTB-Vorstellung."
      }],
      "usedCode" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-systemische-therapie-protokolle",
          "code" : "CarboTax",
          "display" : "CarboTax"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-mtb-systemische-vortherapie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-tumorausbreitung-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-tumorausbreitung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-tumorausbreitung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-tumorausbreitung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-tumorausbreitung-1</b></p><a name=\"mii-exa-test-data-mtb-tumorausbreitung-1\"> </a><a name=\"hcmii-exa-test-data-mtb-tumorausbreitung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-tumorausbreitung\">MII PR MTB Tumorausbreitung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 473302008}\">Aware of diagnosis</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 371508000}\">Tumor stage</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-01-05</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 255127006}\">Local tumor spread</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "473302008",
          "display" : "Aware of diagnosis"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "371508000",
          "display" : "Tumor stage"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-01-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "255127006",
          "display" : "Local tumor spread"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-tumorausbreitung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-who-grad-tumor-zns-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-who-grad-tumor-zns-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-who-grad-tumor-zns"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-who-grad-tumor-zns-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-who-grad-tumor-zns-1</b></p><a name=\"mii-exa-test-data-mtb-who-grad-tumor-zns-1\"> </a><a name=\"hcmii-exa-test-data-mtb-who-grad-tumor-zns-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-who-grad-tumor-zns\">MII PR MTB WHO Grad Tumor ZNS</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 396921005}\">WHO grade finding for central nervous system tumor</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-01-05</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 1228852002}\">World Health Organization grade 4 (qualifier value)</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "396921005",
          "display" : "WHO grade finding for central nervous system tumor"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-01-05",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1228852002",
          "display" : "World Health Organization grade 4 (qualifier value)"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-who-grad-tumor-zns-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DiagnosticReport/mii-exa-test-data-mtb-ngs-bericht-1",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-test-data-mtb-ngs-bericht-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-ngs-bericht"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_mii-exa-test-data-mtb-ngs-bericht-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-test-data-mtb-ngs-bericht-1</b></p><a name=\"mii-exa-test-data-mtb-ngs-bericht-1\"> </a><a name=\"hcmii-exa-test-data-mtb-ngs-bericht-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-ngs-bericht\">MII PR MTB NGS-Bericht</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2><span title=\"Codes:{http://loinc.org 51969-4}\">Genetic analysis report</span> (<span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</td></tr><tr><td>Reported</td><td>2024-03-15 00:00:00+0000</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>Relevant Time</b></td><td><b>Reported</b></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-mutationslast-1.html\"><span title=\"Codes:{http://loinc.org 94076-7}\">Mutations/Megabase [# Ratio] in Tumor</span></a></td><td>14.2 mutations per megabase<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{Mutations}/1000000{Base} = '{Mutations}/1000000{Base}')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></td><td>2024-03-01</td><td>2024-03-01 10:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1.html\"><span title=\"Codes:{http://loinc.org 81695-9}\">Microsatellite instability [Interpretation] in Cancer specimen Qualitative</span></a></td><td>0.15 ratio<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></td><td>2024-03-01</td><td>2024-03-01 10:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-brcaness-1.html\"><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker brcaness}\">BRCAness</span></a></td><td>0.72 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></td><td>2024-03-01</td><td>2024-03-01 10:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-hrd-score-1.html\"><span title=\"Codes:{http://loinc.org 107286-7}\">Homologous recombination deficiency status analysis [Presence] in Tissue by Molecular genetics method</span></a></td><td>42</td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></td><td>2024-03-01</td><td>2024-03-01 10:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-ploidie-1.html\"><span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C18303}, {http://loinc.org 69548-6}\">DNA Ploidy Analysis</span></a></td><td>2.3 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></td><td>2024-03-01</td><td>2024-03-01 10:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2024-02-25</td><td>2024-03-01 09:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-copy-number-variant-1.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2024-02-25</td><td>2024-03-01 09:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-dna-fusion-1.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2024-02-25</td><td>2024-03-01 09:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-rna-fusion-1.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2024-02-25</td><td>2024-03-01 09:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-rna-seq-1.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2024-02-25</td><td>2024-03-01 09:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-therapeutische-implikation-1.html\"><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs therapeutic-implication}\">Therapeutic Implication</span></a></td><td/><td>Final</td><td>2024-03-05</td><td>2024-03-05 12:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-diagnostische-implikation-1.html\"><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></a></td><td/><td>Final</td><td>2024-03-05</td><td>2024-03-05 12:00:00+0100</td></tr></table></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "51969-4",
          "display" : "Genetic analysis report"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "issued" : "2024-03-15T00:00:00.000Z",
      "specimen" : [{
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-mutationslast-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-brcaness-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-hrd-score-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-ploidie-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-copy-number-variant-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-dna-fusion-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-rna-fusion-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-rna-seq-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-therapeutische-implikation-1"
      },
      {
        "reference" : "Observation/mii-exa-test-data-mtb-diagnostische-implikation-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-test-data-mtb-ngs-bericht-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-mtb-genomic-study-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-mtb-genomic-study-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-genomic-study"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-mtb-genomic-study-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-mtb-genomic-study-1</b></p><a name=\"mii-exa-test-data-mtb-genomic-study-1\"> </a><a name=\"hcmii-exa-test-data-mtb-genomic-study-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-genomic-study\">MII PR MTB Genomic Study</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Genomic Study Analysis Extension</b>: <a href=\"Procedure-mii-exa-test-data-mtb-genomic-study-analysis-1.html\">Procedure: extension = Next-Generation (NGS)/Massively parallel sequencing (MPS),SNV,GRCh38,,Comprehensive Genomic Profiling Panel (Solid Tumor, 523 Gene),-&gt;Specimen: status = available; type = Tissue,; identifier = https://www.charite.de/fhir/sid/mtb-genomic-study#GSA-2024-001; status = completed; category = Laboratory; performed[x] = 2024-02-21</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-genomic-study</code>/GS-2024-001</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs func-var}\">Functional variation detection</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>performed</b>: 2024-02-20</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-ext",
        "valueReference" : {
          "reference" : "Procedure/mii-exa-test-data-mtb-genomic-study-analysis-1"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-genomic-study",
        "value" : "GS-2024-001"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs",
          "code" : "func-var",
          "display" : "Functional variation detection"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "performedDateTime" : "2024-02-20",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-mtb-genomic-study-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-mtb-genomic-study-analysis-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-mtb-genomic-study-analysis-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-genomic-study-analysis"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-mtb-genomic-study-analysis-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-mtb-genomic-study-analysis-1</b></p><a name=\"mii-exa-test-data-mtb-genomic-study-analysis-1\"> </a><a name=\"hcmii-exa-test-data-mtb-genomic-study-analysis-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-genomic-study-analysis\">MII PR MTB Genomic Study Analysis</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Genomic Study Analysis Method Type</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs ngs-mps}\">Next-Generation (NGS)/Massively parallel sequencing (MPS)</span></p><p><b>Genomic Study Analysis Change Type</b>: <span title=\"Codes:{http://www.sequenceontology.org SO:0001483}\">SNV</span></p><p><b>Genomic Study Analysis Genome Build</b>: <span title=\"Codes:{http://loinc.org LA26806-2}\">GRCh38</span></p><blockquote><p><b>Genomic Study Analysis Device</b></p><ul><li>device: <a href=\"Device-mii-exa-test-data-mtb-device-sequencer-1.html\">Device: manufacturer = Illumina; type = Biomedical equipment</a></li><li>function: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-genomicanalysis-devicefunction sequencing-device}\">Sequenziergerät</span></li></ul></blockquote><p><b>Genomic Study Analysis Title</b>: Comprehensive Genomic Profiling Panel (Solid Tumor, 523 Gene)</p><p><b>Genomic Study Analysis Specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><blockquote><p><b>Genomic Study Analysis Regions</b></p><ul><li>description: Hybrid-Capture-Panel, kodierende Bereiche von 523 Genen (u.a. EGFR, ERBB2, ALK)</li><li>studied: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3236}\">EGFR</span></li><li>studied: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3430}\">ERBB2</span></li></ul></blockquote><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-genomic-study</code>/GSA-2024-001</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>performed</b>: 2024-02-21</p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-method-type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs",
            "code" : "ngs-mps",
            "display" : "Next-Generation (NGS)/Massively parallel sequencing (MPS)"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-change-type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.sequenceontology.org",
            "code" : "SO:0001483",
            "display" : "SNV"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-genome-build",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26806-2",
            "display" : "GRCh38"
          }]
        }
      },
      {
        "extension" : [{
          "url" : "device",
          "valueReference" : {
            "reference" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
          }
        },
        {
          "url" : "function",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-genomicanalysis-devicefunction",
              "code" : "sequencing-device"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-device"
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-title",
        "valueString" : "Comprehensive Genomic Profiling Panel (Solid Tumor, 523 Gene)"
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-specimen",
        "valueReference" : {
          "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
        }
      },
      {
        "extension" : [{
          "url" : "description",
          "valueString" : "Hybrid-Capture-Panel, kodierende Bereiche von 523 Genen (u.a. EGFR, ERBB2, ALK)"
        },
        {
          "url" : "studied",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://www.genenames.org/geneId",
              "code" : "HGNC:3236",
              "display" : "EGFR"
            }]
          }
        },
        {
          "url" : "studied",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://www.genenames.org/geneId",
              "code" : "HGNC:3430",
              "display" : "ERBB2"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-regions"
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-genomic-study",
        "value" : "GSA-2024-001"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "performedDateTime" : "2024-02-21"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-mtb-genomic-study-analysis-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Device/mii-exa-test-data-mtb-device-sequencer-1",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-test-data-mtb-device-sequencer-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/genomic-study-device"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_mii-exa-test-data-mtb-device-sequencer-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-test-data-mtb-device-sequencer-1</b></p><a name=\"mii-exa-test-data-mtb-device-sequencer-1\"> </a><a name=\"hcmii-exa-test-data-mtb-device-sequencer-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/genomic-study-device\">Genomic Study Device</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>definition</b>: <a href=\"DeviceDefinition-mii-exa-test-data-mtb-panel-devicedef-1.html\">DeviceDefinition: extension = ; manufacturer[x] = Illumina; type = Genpanel; version = 2.0; onlineInformation = https://emea.illumina.com/products/by-type/clinical-research-products/trusight-oncology-500.html; note = Panel deckt SNVs, CNVs, Fusionen und Signaturen ab.</a></p><p><b>manufacturer</b>: Illumina</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Illumina NovaSeq 6000</td><td>User Friendly name</td></tr></table><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 303607000}\">NGS-Sequenzierer</span></p></div>"
      },
      "definition" : {
        "reference" : "DeviceDefinition/mii-exa-test-data-mtb-panel-devicedef-1"
      },
      "manufacturer" : "Illumina",
      "deviceName" : [{
        "name" : "Illumina NovaSeq 6000",
        "type" : "user-friendly-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "303607000",
          "display" : "Biomedical equipment"
        }],
        "text" : "NGS-Sequenzierer"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DeviceDefinition/mii-exa-test-data-mtb-panel-devicedef-1",
    "resource" : {
      "resourceType" : "DeviceDefinition",
      "id" : "mii-exa-test-data-mtb-panel-devicedef-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-panel-devicedefinition"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DeviceDefinition_mii-exa-test-data-mtb-panel-devicedef-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DeviceDefinition mii-exa-test-data-mtb-panel-devicedef-1</b></p><a name=\"mii-exa-test-data-mtb-panel-devicedef-1\"> </a><a name=\"hcmii-exa-test-data-mtb-panel-devicedef-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-panel-devicedefinition\">MII PR MTB Panel DeviceDefinition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>MII EX MTB Panel Gene List</b></p><ul><li>geneList: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/ValueSet/mii-vs-mtb-panel-cgp\">MII VS MTB Panel CGP</a></li><li>scope: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-panel-capability snv-detection}\">SNV-Detektion</span></li></ul></blockquote><p><b>manufacturer</b>: Illumina</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>TruSight Oncology 500</td><td>User Friendly name</td></tr></table><p><b>type</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-genomicanalysis-devicefunction gene-panel}\">Genpanel</span></p><p><b>version</b>: 2.0</p><h3>Capabilities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-panel-capability snv-detection}\">SNV-Detektion</span></td></tr></table><p><b>onlineInformation</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://emea.illumina.com/products/by-type/clinical-research-products/trusight-oncology-500.html\">https://emea.illumina.com/products/by-type/clinical-research-products/trusight-oncology-500.html</a></p><p><b>note</b>: </p><blockquote><div><p>Panel deckt SNVs, CNVs, Fusionen und Signaturen ab.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "geneList",
          "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/ValueSet/mii-vs-mtb-panel-cgp"
        },
        {
          "url" : "scope",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-panel-capability",
              "code" : "snv-detection"
            }]
          }
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-panel-gene-list"
      }],
      "manufacturerString" : "Illumina",
      "deviceName" : [{
        "name" : "TruSight Oncology 500",
        "type" : "user-friendly-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-genomicanalysis-devicefunction",
          "code" : "gene-panel"
        }]
      },
      "version" : ["2.0"],
      "capability" : [{
        "type" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-panel-capability",
            "code" : "snv-detection"
          }]
        }
      }],
      "onlineInformation" : "https://emea.illumina.com/products/by-type/clinical-research-products/trusight-oncology-500.html",
      "note" : [{
        "text" : "Panel deckt SNVs, CNVs, Fusionen und Signaturen ab."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "DeviceDefinition/mii-exa-test-data-mtb-panel-devicedef-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-einfache-variante-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-einfache-variante-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-einfache-variante"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-einfache-variante-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-einfache-variante-1</b></p><a name=\"mii-exa-test-data-mtb-einfache-variante-1\"> </a><a name=\"hcmii-exa-test-data-mtb-einfache-variante-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-einfache-variante\">MII PR MTB Einfache Variante</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-variante</code>/VAR-EGFR-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>effective</b>: 2024-02-25</p><p><b>issued</b>: 2024-03-01 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mtb-device-sequencer-1.html\">Device: manufacturer = Illumina; type = Biomedical equipment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3236}\">EGFR</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48005-3}\">Amino acid change (pHGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org NP_005219.2:p.Leu858Arg}\">NP_005219.2:p.Leu858Arg</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-variante",
        "value" : "VAR-EGFR-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "effectiveDateTime" : "2024-02-25",
      "issued" : "2024-03-01T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3236",
            "display" : "EGFR"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48005-3",
            "display" : "Amino acid change (pHGVS)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "NP_005219.2:p.Leu858Arg"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-copy-number-variant-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-copy-number-variant-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-copy-number-variant"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-copy-number-variant-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-copy-number-variant-1</b></p><a name=\"mii-exa-test-data-mtb-copy-number-variant-1\"> </a><a name=\"hcmii-exa-test-data-mtb-copy-number-variant-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-copy-number-variant\">MII PR MTB Copy Number Variant</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-variante</code>/CNV-ERBB2-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>effective</b>: 2024-02-25</p><p><b>issued</b>: 2024-03-01 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mtb-device-sequencer-1.html\">Device: manufacturer = Illumina; type = Biomedical equipment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3430}\">ERBB2</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://bwhc.de/mtb/genetics-copy-number-variant type}\">type</span></p><p><b>value</b>: <span title=\"Codes:{http://bwhc.de/mtb/genetics-copy-number-variant high-level-gain}\">high-level-gain</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 82155-3}\">Genomic structural variant copy number</span></p><p><b>value</b>: 12 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker relative-copy-number}\">Relative Copy Number of Allele A and B</span></p><p><b>value</b>: 3.8 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-variante",
        "value" : "CNV-ERBB2-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "effectiveDateTime" : "2024-02-25",
      "issued" : "2024-03-01T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3430",
            "display" : "ERBB2"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://bwhc.de/mtb/genetics-copy-number-variant",
            "code" : "type"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://bwhc.de/mtb/genetics-copy-number-variant",
            "code" : "high-level-gain",
            "display" : "high-level-gain"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "82155-3",
            "display" : "Genomic structural variant copy number"
          }]
        },
        "valueQuantity" : {
          "value" : 12,
          "system" : "http://unitsofmeasure.org",
          "code" : "1"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "relative-copy-number"
          }]
        },
        "valueQuantity" : {
          "value" : 3.8,
          "system" : "http://unitsofmeasure.org",
          "code" : "1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-copy-number-variant-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-dna-fusion-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-dna-fusion-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-dna-fusion"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-dna-fusion-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-dna-fusion-1</b></p><a name=\"mii-exa-test-data-mtb-dna-fusion-1\"> </a><a name=\"hcmii-exa-test-data-mtb-dna-fusion-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-dna-fusion\">MII PR MTB DNA Fusion</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-variante</code>/FUS-DNA-EML4ALK-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>effective</b>: 2024-02-25</p><p><b>issued</b>: 2024-03-01 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mtb-device-sequencer-1.html\">Device: manufacturer = Illumina; type = Biomedical equipment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:427}\">ALK</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-chromosome}\">Five Prime Chromosome</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-chromosome}\">Three Prime Chromosome</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-position}\">Five Prime Position</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-position}\">Three Prime Position</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-gene}\">Five Prime Gene</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-gene}\">Three Prime Gene</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-variante",
        "value" : "FUS-DNA-EML4ALK-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "effectiveDateTime" : "2024-02-25",
      "issued" : "2024-03-01T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:427",
            "display" : "ALK"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-chromosome"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-chromosome"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-position"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-position"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-gene"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-gene"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-dna-fusion-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-rna-fusion-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-rna-fusion-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-rna-fusion"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-rna-fusion-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-rna-fusion-1</b></p><a name=\"mii-exa-test-data-mtb-rna-fusion-1\"> </a><a name=\"hcmii-exa-test-data-mtb-rna-fusion-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-rna-fusion\">MII PR MTB RNA Fusion</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-variante</code>/FUS-RNA-BCRABL1-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>effective</b>: 2024-02-25</p><p><b>issued</b>: 2024-03-01 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mtb-device-sequencer-1.html\">Device: manufacturer = Illumina; type = Biomedical equipment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:76}\">ABL1</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-gene}\">Five Prime Gene</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-transcript-id}\">Five Prime Transcript ID</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-exon-id}\">Five Prime Exon ID</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-position}\">Five Prime Position</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker five-prime-strand}\">Five Prime Strand</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-gene}\">Three Prime Gene</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-transcript-id}\">Three Prime Transcript ID</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-exon-id}\">Three Prime Exon ID</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-position}\">Three Prime Position</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker three-prime-strand}\">Three Prime Strand</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-variante",
        "value" : "FUS-RNA-BCRABL1-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "effectiveDateTime" : "2024-02-25",
      "issued" : "2024-03-01T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:76",
            "display" : "ABL1"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-gene"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-transcript-id"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-exon-id"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-position"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "five-prime-strand"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-gene"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-transcript-id"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-exon-id"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-position"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
            "code" : "three-prime-strand"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-rna-fusion-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-rna-seq-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-rna-seq-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-rna-seq"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-rna-seq-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-rna-seq-1</b></p><a name=\"mii-exa-test-data-mtb-rna-seq-1\"> </a><a name=\"hcmii-exa-test-data-mtb-rna-seq-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-rna-seq\">MII PR MTB RNA Seq</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-variante</code>/RNASEQ-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>effective</b>: 2024-02-25</p><p><b>issued</b>: 2024-03-01 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>device</b>: <a href=\"Device-mii-exa-test-data-mtb-device-sequencer-1.html\">Device: manufacturer = Illumina; type = Biomedical equipment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></td><td><span title=\"Codes:{http://www.genenames.org/geneId HGNC:7989}\">NRAS</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-variante",
        "value" : "RNASEQ-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "effectiveDateTime" : "2024-02-25",
      "issued" : "2024-03-01T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:7989",
            "display" : "NRAS"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-rna-seq-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-diagnostische-implikation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-diagnostische-implikation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnostische-implikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-diagnostische-implikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-diagnostische-implikation-1</b></p><a name=\"mii-exa-test-data-mtb-diagnostische-implikation-1\"> </a><a name=\"hcmii-exa-test-data-mtb-diagnostische-implikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-diagnostische-implikation\">MII PR MTB Diagnostische Implikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Related artifact</b>: No display for RelatedArtifact  (type: citation; citation: Soria JC et al. Osimertinib in Untreated EGFR-Mutated Advanced NSCLC. N Engl J Med 2018. PMID 29151359)</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-05</p><p><b>issued</b>: 2024-03-05 12:00:00+0100</p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 53037-8}\">Genetic variation clinical significance [Imp]</span></td><td><span title=\"Codes:{http://loinc.org LA6668-3}\">Pathogenic</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/workflow-relatedArtifact",
        "valueRelatedArtifact" : {
          "type" : "citation",
          "citation" : "Soria JC et al. Osimertinib in Untreated EGFR-Mutated Advanced NSCLC. N Engl J Med 2018. PMID 29151359"
        }
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "diagnostic-implication",
          "display" : "Diagnostic Implication"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-05",
      "issued" : "2024-03-05T12:00:00+01:00",
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "53037-8"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6668-3",
            "display" : "Pathogenic"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-diagnostische-implikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-therapeutische-implikation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-therapeutische-implikation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapeutische-implikation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-therapeutische-implikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-therapeutische-implikation-1</b></p><a name=\"mii-exa-test-data-mtb-therapeutische-implikation-1\"> </a><a name=\"hcmii-exa-test-data-mtb-therapeutische-implikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapeutische-implikation\">MII PR MTB Therapeutische Implikation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX MTB Empfehlung Evidenzgraduierung</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-empfehlung-evidenzgrad m1A}\">Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.</span></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs therapeutic-implication}\">Therapeutic Implication</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-05</p><p><b>issued</b>: 2024-03-05 12:00:00+0100</p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs conclusion-string}\">Conclusion Text</span></p><p><b>value</b>: EGFR L858R mutation predicts sensitivity to EGFR TKI therapy (EL m1A).</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 51963-7}\">Medication assessed [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01EB01}\">Gefitinib</span></p></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-evidenzgraduierung",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-empfehlung-evidenzgrad",
            "code" : "m1A"
          }]
        }
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "therapeutic-implication",
          "display" : "Therapeutic Implication"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-05",
      "issued" : "2024-03-05T12:00:00+01:00",
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "conclusion-string"
          }]
        },
        "valueString" : "EGFR L858R mutation predicts sensitivity to EGFR TKI therapy (EL m1A)."
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "51963-7",
            "display" : "Medication assessed [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/bfarm/atc",
            "version" : "2024",
            "code" : "L01EB01",
            "display" : "Gefitinib"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-therapeutische-implikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-molekularer-biomarker-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-molekularer-biomarker-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-molekularer-biomarker"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-molekularer-biomarker-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-molekularer-biomarker-1</b></p><a name=\"mii-exa-test-data-mtb-molekularer-biomarker-1\"> </a><a name=\"hcmii-exa-test-data-mtb-molekularer-biomarker-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-molekularer-biomarker\">MII PR MTB Molekularer Biomarker</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-01</p><p><b>issued</b>: 2024-03-01 10:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3236}\">EGFR</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs protein}\">protein category</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-01",
      "issued" : "2024-03-01T10:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3236",
            "display" : "EGFR"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "protein",
            "display" : "protein category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-molekularer-biomarker-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-mutationslast-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-mutationslast-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-mutationslast"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-mutationslast-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-mutationslast-1</b></p><a name=\"mii-exa-test-data-mtb-mutationslast-1\"> </a><a name=\"hcmii-exa-test-data-mtb-mutationslast-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-mutationslast\">MII PR MTB Mutationslast</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 94076-7}\">Mutations/Megabase [# Ratio] in Tumor</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-01</p><p><b>issued</b>: 2024-03-01 10:00:00+0100</p><p><b>value</b>: 14.2 mutations per megabase<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{Mutations}/1000000{Base} = '{Mutations}/1000000{Base}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3236}\">EGFR</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs nucleicAcid}\">nucleic acid category</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "94076-7",
          "display" : "Mutations/Megabase [# Ratio] in Tumor"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-01",
      "issued" : "2024-03-01T10:00:00+01:00",
      "valueQuantity" : {
        "value" : 14.2,
        "unit" : "mutations per megabase",
        "system" : "http://unitsofmeasure.org",
        "code" : "{Mutations}/1000000{Base}"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3236",
            "display" : "EGFR"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "nucleicAcid",
            "display" : "nucleic acid category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-mutationslast-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-mikrosatelliteninstabilitaet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1</b></p><a name=\"mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1\"> </a><a name=\"hcmii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-mikrosatelliteninstabilitaet\">MII PR MTB Mikrosatelliteninstabilität</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81695-9}\">Microsatellite instability [Interpretation] in Cancer specimen Qualitative</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-01</p><p><b>issued</b>: 2024-03-01 10:00:00+0100</p><p><b>value</b>: 0.15 ratio<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3236}\">EGFR</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs nucleicAcid}\">nucleic acid category</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "81695-9",
          "display" : "Microsatellite instability [Interpretation] in Cancer specimen Qualitative"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-01",
      "issued" : "2024-03-01T10:00:00+01:00",
      "valueQuantity" : {
        "value" : 0.15,
        "unit" : "ratio",
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3236",
            "display" : "EGFR"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "nucleicAcid",
            "display" : "nucleic acid category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-hrd-score-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-hrd-score-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-hrd-score"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-hrd-score-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-hrd-score-1</b></p><a name=\"mii-exa-test-data-mtb-hrd-score-1\"> </a><a name=\"hcmii-exa-test-data-mtb-hrd-score-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-hrd-score\">MII PR MTB HRD Score</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/HRD-2024-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 107286-7}\">Homologous recombination deficiency status analysis [Presence] in Tissue by Molecular genetics method</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-01</p><p><b>issued</b>: 2024-03-01 10:00:00+0100</p><p><b>value</b>: 42</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C120466}\">Large-Scale State Transition</span></p><p><b>value</b>: 15</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C129774}\">Telomeric Allelic Imbalance Region</span></p><p><b>value</b>: 14</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C18016}\">Loss of Heterozygosity</span></p><p><b>value</b>: 13</p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "HRD-2024-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "107286-7"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-01",
      "issued" : "2024-03-01T10:00:00+01:00",
      "valueInteger" : 42,
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
            "code" : "C120466",
            "display" : "Large-Scale State Transition"
          }]
        },
        "valueInteger" : 15
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
            "code" : "C129774",
            "display" : "Telomeric Allelic Imbalance Region"
          }]
        },
        "valueInteger" : 14
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
            "code" : "C18016",
            "display" : "Loss of Heterozygosity"
          }]
        },
        "valueInteger" : 13
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-hrd-score-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-brcaness-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-brcaness-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-brcaness"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-brcaness-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-brcaness-1</b></p><a name=\"mii-exa-test-data-mtb-brcaness-1\"> </a><a name=\"hcmii-exa-test-data-mtb-brcaness-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-brcaness\">MII PR MTB BRCAness</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/BRCANESS-2024-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker brcaness}\">BRCAness</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-01</p><p><b>issued</b>: 2024-03-01 10:00:00+0100</p><p><b>value</b>: 0.72 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:1100}\">BRCA1</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs nucleicAcid}\">nucleic acid category</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "BRCANESS-2024-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-molekulare-biomarker",
          "code" : "brcaness"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-01",
      "issued" : "2024-03-01T10:00:00+01:00",
      "valueQuantity" : {
        "value" : 0.72,
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:1100",
            "display" : "BRCA1"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "nucleicAcid",
            "display" : "nucleic acid category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-brcaness-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-ploidie-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-ploidie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-ploidie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-ploidie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-ploidie-1</b></p><a name=\"mii-exa-test-data-mtb-ploidie-1\"> </a><a name=\"hcmii-exa-test-data-mtb-ploidie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-ploidie\">MII PR MTB Ploidie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C18303}, {http://loinc.org 69548-6}\">DNA Ploidy Analysis</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-01</p><p><b>issued</b>: 2024-03-01 10:00:00+0100</p><p><b>value</b>: 2.3 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3236}\">EGFR</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs nucleicAcid}\">nucleic acid category</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
          "code" : "C18303",
          "display" : "DNA Ploidy Analysis"
        },
        {
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-01",
      "issued" : "2024-03-01T10:00:00+01:00",
      "valueQuantity" : {
        "value" : 2.3,
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3236",
            "display" : "EGFR"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "nucleicAcid",
            "display" : "nucleic acid category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-ploidie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-biomarker-her2-status-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-biomarker-her2-status-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-biomarker-her2-status"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-biomarker-her2-status-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-biomarker-her2-status-1</b></p><a name=\"mii-exa-test-data-mtb-biomarker-her2-status-1\"> </a><a name=\"hcmii-exa-test-data-mtb-biomarker-her2-status-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-biomarker-her2-status\">MII PR Biomarker Her2 Status</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48676-1}\">HER2 Ag [Interpretation] in Tissue</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-01</p><p><b>issued</b>: 2024-03-01 10:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}\">Positive</span></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3430}\">ERBB2</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs molgen}\">molecular sequence adjacent category</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48676-1",
          "display" : "HER2 Ag [Interpretation] in Tissue"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-01",
      "issued" : "2024-03-01T10:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        }]
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3430",
            "display" : "ERBB2"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "molgen",
            "display" : "molecular sequence adjacent category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-biomarker-her2-status-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DiagnosticReport/mii-exa-test-data-mtb-molecular-pathology-report-1",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-test-data-mtb-molecular-pathology-report-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-molecular-pathology-report"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_mii-exa-test-data-mtb-molecular-pathology-report-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-test-data-mtb-molecular-pathology-report-1</b></p><a name=\"mii-exa-test-data-mtb-molecular-pathology-report-1\"> </a><a name=\"hcmii-exa-test-data-mtb-molecular-pathology-report-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-molecular-pathology-report\">MII PR MTB Molecular Pathology Report</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2><span title=\"Codes:{http://loinc.org 60568-3}\">Pathology synoptic report</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</td></tr><tr><td>Reported</td><td>2024-03-10 09:00:00+0100</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>Relevant Time</b></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-immunohistochemistry-1.html\"><span title=\"Codes:{http://loinc.org 85147-7}, {http://snomed.info/sct 1234806008}\">PD-L1 by clone 22C3 in Tissue by Immune stain Report</span></a></td><td>80 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{/100} = '{/100}')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></td><td>2024-03-08</td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60568-3",
          "display" : "Pathology synoptic report"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "issued" : "2024-03-10T09:00:00+01:00",
      "specimen" : [{
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-immunohistochemistry-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-test-data-mtb-molecular-pathology-report-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-immunohistochemistry-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-immunohistochemistry-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-immunohistochemistry-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-immunohistochemistry-1</b></p><a name=\"mii-exa-test-data-mtb-immunohistochemistry-1\"> </a><a name=\"hcmii-exa-test-data-mtb-immunohistochemistry-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry\">MII PR MTB Immunohistochemistry</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/IHC-2024-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85147-7}, {http://snomed.info/sct 1234806008}\">PD-L1 by clone 22C3 in Tissue by Immune stain Report</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: 80 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{/100} = '{/100}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></td><td><span title=\"Codes:{http://www.genenames.org/geneId HGNC:17635}\">CD274</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "IHC-2024-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85147-7",
          "display" : "PD-L1 by clone 22C3 in Tissue by Immune stain Report"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1234806008",
          "display" : "Observation using immunohistochemistry (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueQuantity" : {
        "value" : 80,
        "unit" : "%",
        "system" : "http://unitsofmeasure.org",
        "code" : "{/100}"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:17635",
            "display" : "CD274"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-immunohistochemistry-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-immunohistochemistry-her2-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-immunohistochemistry-her2-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-her2"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-immunohistochemistry-her2-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-immunohistochemistry-her2-1</b></p><a name=\"mii-exa-test-data-mtb-immunohistochemistry-her2-1\"> </a><a name=\"hcmii-exa-test-data-mtb-immunohistochemistry-her2-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-her2\">MII PR MTB Immunohistochemistry</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/IHC-2024-002</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 18474-7}, {http://snomed.info/sct 1234806008}\">HER2 Ag [Presence] in Tissue by Immune stain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}\">Positive</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></td><td><span title=\"Codes:{http://www.genenames.org/geneId HGNC:3430}\">ERBB2</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "IHC-2024-002"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18474-7",
          "display" : "HER2 Ag [Presence] in Tissue by Immune stain"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1234806008",
          "display" : "Observation using immunohistochemistry (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3430",
            "display" : "ERBB2"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-immunohistochemistry-her2-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-immunohistochemistry-pdl1-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-immunohistochemistry-pdl1-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-pdl1"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-immunohistochemistry-pdl1-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-immunohistochemistry-pdl1-1</b></p><a name=\"mii-exa-test-data-mtb-immunohistochemistry-pdl1-1\"> </a><a name=\"hcmii-exa-test-data-mtb-immunohistochemistry-pdl1-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-pdl1\">MII PR MTB Immunohistochemistry</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/IHC-2024-003</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85147-7}, {http://snomed.info/sct 1234806008}\">PD-L1 by clone 22C3 in Tissue by Immune stain Report</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: 80 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{/100} = '{/100}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:17635}\">CD274</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs immuneStain}\">immune stain category</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C184941}\">PD-L1 Tumor Proportion Score</span></p><p><b>value</b>: 80 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C176582}\">PD-L1 Combined Positive Score</span></p><p><b>value</b>: 85 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html C199175}\">Cells.programmed cell death ligand 1/Viable tumor cells in Tissue by Immune stain</span></p><p><b>value</b>: 5 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 83053-9}\">Cells.programmed cell death ligand 1/Viable tumor cells in Tissue by Immune stain</span></p><p><b>value</b>: 80 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "IHC-2024-003"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85147-7",
          "display" : "PD-L1 by clone 22C3 in Tissue by Immune stain Report"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1234806008",
          "display" : "Observation using immunohistochemistry (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueQuantity" : {
        "value" : 80,
        "unit" : "%",
        "system" : "http://unitsofmeasure.org",
        "code" : "{/100}"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:17635",
            "display" : "CD274"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "immuneStain",
            "display" : "immune stain category"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
            "code" : "C184941",
            "display" : "PD-L1 Tumor Proportion Score"
          }]
        },
        "valueQuantity" : {
          "value" : 80,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "POS",
            "display" : "Positive"
          }]
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
            "code" : "C176582",
            "display" : "PD-L1 Combined Positive Score"
          }]
        },
        "valueQuantity" : {
          "value" : 85,
          "unit" : "{score}",
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "POS",
            "display" : "Positive"
          }]
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "https://nih-ncpi.github.io/ncpi-fhir-ig/CodeSystem-ncit.html",
            "code" : "C199175",
            "display" : "Cells.programmed cell death ligand 1/Viable tumor cells in Tissue by Immune stain"
          }]
        },
        "valueQuantity" : {
          "value" : 5,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "POS",
            "display" : "Positive"
          }]
        }]
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "83053-9",
            "display" : "Cells.programmed cell death ligand 1/Viable tumor cells in Tissue by Immune stain"
          }]
        },
        "valueQuantity" : {
          "value" : 80,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "POS",
            "display" : "Positive"
          }]
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-immunohistochemistry-pdl1-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-ihc-phosphorylation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-ihc-phosphorylation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-phosphorylation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-ihc-phosphorylation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-ihc-phosphorylation-1</b></p><a name=\"mii-exa-test-data-mtb-ihc-phosphorylation-1\"> </a><a name=\"hcmii-exa-test-data-mtb-ihc-phosphorylation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-phosphorylation\">MII PR MTB Immunohistochemistry Phosphorylation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/IHC-2024-004</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 55229-9}, {http://snomed.info/sct 1234806008}\">Immune stain study</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}\">Positive</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></td><td><span title=\"Codes:{http://www.genenames.org/geneId HGNC:3236}\">EGFR</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "IHC-2024-004"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "55229-9",
          "display" : "Immune stain study"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "1234806008",
          "display" : "Observation using immunohistochemistry (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3236",
            "display" : "EGFR"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-ihc-phosphorylation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-ihc-mmr-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-ihc-mmr-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-mmr"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-ihc-mmr-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-ihc-mmr-1</b></p><a name=\"mii-exa-test-data-mtb-ihc-mmr-1\"> </a><a name=\"hcmii-exa-test-data-mtb-ihc-mmr-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-immunohistochemistry-mmr\">MII PR MTB Immunohistochemistry Mismatch Repair Status</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/IHC-2024-005</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85337-4}\">Estrogen receptor Ag [Presence] in Breast cancer specimen by Immune stain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}\">Positive</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:7127}\">MLH1</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs immuneStain}\">immune stain category</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81691-8}\">MLH-1 Ag [Presence] in Cancer specimen by Immune stain</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA26197-6}\">Intact nuclear expression</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96272-0}\">DNA mismatch repair protein Mlh3 Ag [Presence] in Cancer specimen by Immune stain</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA26197-6}\">Intact nuclear expression</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81692-6}\">MSH-2 Ag [Presence] in Cancer specimen by Immune stain</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA26197-6}\">Intact nuclear expression</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 96271-2}\">DNA mismatch repair protein Msh3 Ag [Presence] in Cancer specimen by Immune stain</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA26197-6}\">Intact nuclear expression</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81693-4}\">MSH-6 Ag [Presence] in Cancer specimen by Immune stain</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA26197-6}\">Intact nuclear expression</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81694-2}\">PMS2 Ag [Presence] in Cancer specimen by Immune stain</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA26197-6}\">Intact nuclear expression</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "IHC-2024-005"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85337-4",
          "display" : "Estrogen receptor Ag [Presence] in Breast cancer specimen by Immune stain"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:7127",
            "display" : "MLH1"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "immuneStain",
            "display" : "immune stain category"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81691-8",
            "display" : "MLH-1 Ag [Presence] in Cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26197-6",
            "display" : "Intact nuclear expression"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96272-0",
            "display" : "DNA mismatch repair protein Mlh3 Ag [Presence] in Cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26197-6",
            "display" : "Intact nuclear expression"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81692-6",
            "display" : "MSH-2 Ag [Presence] in Cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26197-6",
            "display" : "Intact nuclear expression"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "96271-2",
            "display" : "DNA mismatch repair protein Msh3 Ag [Presence] in Cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26197-6",
            "display" : "Intact nuclear expression"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81693-4",
            "display" : "MSH-6 Ag [Presence] in Cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26197-6",
            "display" : "Intact nuclear expression"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81694-2",
            "display" : "PMS2 Ag [Presence] in Cancer specimen by Immune stain"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26197-6",
            "display" : "Intact nuclear expression"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-ihc-mmr-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-ihc-msi-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-ihc-msi-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-msi"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-ihc-msi-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-ihc-msi-1</b></p><a name=\"mii-exa-test-data-mtb-ihc-msi-1\"> </a><a name=\"hcmii-exa-test-data-mtb-ihc-msi-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-msi\">MII PR MTB Immunohistochemistry Microsatellite Instability</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/IHC-2024-006</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 62862-8}\">Microsatellite instability [Presence] in Tissue by Immune stain</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA14122-8}\">Stable</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:7127}\">MLH1</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs immuneStain}\">immune stain category</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "IHC-2024-006"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "62862-8",
          "display" : "Microsatellite instability [Presence] in Tissue by Immune stain"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA14122-8",
          "display" : "Stable"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:7127",
            "display" : "MLH1"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "immuneStain",
            "display" : "immune stain category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-ihc-msi-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-insituhybridization-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-insituhybridization-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-insituhybridization"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-insituhybridization-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-insituhybridization-1</b></p><a name=\"mii-exa-test-data-mtb-insituhybridization-1\"> </a><a name=\"hcmii-exa-test-data-mtb-insituhybridization-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-insituhybridization\">MII PR MTB In Situ Hybridization</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/ISH-2024-001</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 49683-6}, {http://snomed.info/sct 51864006}\">ERBB2 gene copy number/Chromosome 17 copy number in Tissue by FISH</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: 2.4/1</p><p><b>interpretation</b>: <span title=\"Codes:{http://snomed.info/sct 260385009}\">Negative (qualifier value)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 1303773004}\">Fluorescence in situ hybridization technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3430}\">ERBB2</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs nucleicAcid}\">nucleic acid category</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "ISH-2024-001"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "49683-6",
          "display" : "ERBB2 gene copy number/Chromosome 17 copy number in Tissue by FISH"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "51864006",
          "display" : "Nucleic acid hybridization, function (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueRatio" : {
        "numerator" : {
          "value" : 2.4
        },
        "denominator" : {
          "value" : 1
        }
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "260385009",
          "display" : "Negative (qualifier value)"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1303773004",
          "display" : "Fluorescence in situ hybridization technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3430",
            "display" : "ERBB2"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "biomarker-category"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs",
            "code" : "nucleicAcid",
            "display" : "nucleic acid category"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-insituhybridization-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-insituhybridization-her2-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-insituhybridization-her2-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-insituhybridization-her2"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-insituhybridization-her2-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-insituhybridization-her2-1</b></p><a name=\"mii-exa-test-data-mtb-insituhybridization-her2-1\"> </a><a name=\"hcmii-exa-test-data-mtb-insituhybridization-her2-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-insituhybridization-her2\">MII PR MTB In Situ Hybridization HER2</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/ISH-2024-002</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 49683-6}, {http://snomed.info/sct 51864006}\">ERBB2 gene copy number/Chromosome 17 copy number in Tissue by FISH</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-03-08</p><p><b>issued</b>: 2024-03-10 09:00:00+0100</p><p><b>value</b>: 1.8/1</p><p><b>interpretation</b>: <span title=\"Codes:{http://snomed.info/sct 260385009}\">Negative (qualifier value)</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 1303773004}\">Fluorescence in situ hybridization technique (qualifier value)</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-mtb-einfache-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 74860-8}\">ERBB2 gene copy number/nucleus in Tissue by FISH</span></p><p><b>value</b>: 3.6 #</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 74861-6}\">Chromosome 17 copy number/nucleus in Tissue by FISH</span></p><p><b>value</b>: 2 #</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 62361-1}\">Cells counted [#]</span></p><p><b>value</b>: 60 #</p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "ISH-2024-002"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "49683-6",
          "display" : "ERBB2 gene copy number/Chromosome 17 copy number in Tissue by FISH"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "51864006",
          "display" : "Nucleic acid hybridization, function (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-03-08",
      "issued" : "2024-03-10T09:00:00+01:00",
      "valueRatio" : {
        "numerator" : {
          "value" : 1.8
        },
        "denominator" : {
          "value" : 1
        }
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "260385009",
          "display" : "Negative (qualifier value)"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1303773004",
          "display" : "Fluorescence in situ hybridization technique (qualifier value)"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "74860-8",
            "display" : "ERBB2 gene copy number/nucleus in Tissue by FISH"
          }]
        },
        "valueQuantity" : {
          "value" : 3.6,
          "unit" : "#"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "74861-6",
            "display" : "Chromosome 17 copy number/nucleus in Tissue by FISH"
          }]
        },
        "valueQuantity" : {
          "value" : 2,
          "unit" : "#"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "62361-1",
            "display" : "Cells counted [#]"
          }]
        },
        "valueQuantity" : {
          "value" : 60,
          "unit" : "#"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-insituhybridization-her2-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-tumorzellgehalt-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-tumorzellgehalt-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-tumorzellgehalt"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-tumorzellgehalt-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-tumorzellgehalt-1</b></p><a name=\"mii-exa-test-data-mtb-tumorzellgehalt-1\"> </a><a name=\"hcmii-exa-test-data-mtb-tumorzellgehalt-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-tumorzellgehalt\">MII PR MTB Tumorzellgehalt</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 93356-4}\">Cells with cytogenetic abnormality [#] in Blood or Tissue by Molecular genetics method</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>value</b>: 45 percent<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-bestimmungsmethode-tumorzellgehalt histologic}\">Histologisch</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "93356-4",
          "display" : "Cells with cytogenetic abnormality [#] in Blood or Tissue by Molecular genetics method"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "valueQuantity" : {
        "value" : 45,
        "unit" : "percent",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-bestimmungsmethode-tumorzellgehalt",
          "code" : "histologic"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-tumorzellgehalt-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/CarePlan/mii-exa-test-data-mtb-therapieplan-1",
    "resource" : {
      "resourceType" : "CarePlan",
      "id" : "mii-exa-test-data-mtb-therapieplan-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieplan"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_mii-exa-test-data-mtb-therapieplan-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: CarePlan mii-exa-test-data-mtb-therapieplan-1</b></p><a name=\"mii-exa-test-data-mtb-therapieplan-1\"> </a><a name=\"hcmii-exa-test-data-mtb-therapieplan-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieplan\">MII PR MTB Therapieplan</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>category</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ praeth}\">prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie)</span></p><p><b>description</b>: MTB-Beschluss mit Therapieempfehlungen und Studieneinschluss</p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>created</b>: 2024-03-28</p><p><b>addresses</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>supportingInfo</b>: <a href=\"ClinicalImpression-mii-exa-test-data-mtb-behandlungsepisode-1.html\">ClinicalImpression: extension = exhausted (MII CS Leitlinienbehandlung Status#exhausted); status = completed; effective[x] = 2024-01-15 --&gt; 2024-06-30</a></p><blockquote><p><b>activity</b></p><p><b>progress</b>: </p><blockquote><div><p>Therapieempfehlung in Umsetzung</p>\n</div></blockquote><p><b>reference</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-1.html\">MedicationRequest: extension = 1,Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.,http://www.ncbi.nlm.nih.gov/pubmed#29151359; identifier = https://www.charite.de/fhir/sid/mtb-beschluss#TE-2024-001; status = draft; intent = proposal; medication[x] = Osimertinib; authoredOn = 2024-03-28; reasonCode = Bösartige Neubildung: Oberlappen (-Bronchus); note = Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante.</a></p></blockquote><blockquote><p><b>activity</b></p><p><b>reference</b>: <a href=\"RequestGroup-mii-exa-test-data-mtb-therapieempfehlung-kombination-1.html\">RequestGroup zielgerichtete Substanzen</a></p></blockquote><blockquote><p><b>activity</b></p><p><b>reference</b>: <a href=\"ServiceRequest-mii-exa-test-data-mtb-studieneinschluss-anfrage-1.html\">ServiceRequest Referral to clinical trial (procedure)</a></p></blockquote><blockquote><p><b>activity</b></p><p><b>reference</b>: <a href=\"ServiceRequest-mii-exa-test-data-mtb-humangenetische-beratung-1.html\">ServiceRequest Genetic consultation (procedure)</a></p></blockquote><blockquote><p><b>activity</b></p><p><b>reference</b>: <a href=\"ServiceRequest-mii-exa-test-data-mtb-histologie-evaluation-1.html\">ServiceRequest Refer for histology (procedure)</a></p></blockquote><blockquote><p><b>activity</b></p><p><b>reference</b>: <a href=\"ServiceRequest-mii-exa-test-data-mtb-biopsie-auftrag-1.html\">ServiceRequest Biopsy (procedure)</a></p></blockquote><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Status</b></td><td><b>StatusReason</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ CH}\">Chemotherapie</span></td><td>Completed</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieabweichung N}\">regulär abgeschlossen</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "intent" : "plan",
      "category" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieplanung-typ",
          "code" : "praeth"
        }]
      }],
      "description" : "MTB-Beschluss mit Therapieempfehlungen und Studieneinschluss",
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "created" : "2024-03-28",
      "addresses" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "supportingInfo" : [{
        "reference" : "ClinicalImpression/mii-exa-test-data-mtb-behandlungsepisode-1"
      }],
      "activity" : [{
        "progress" : [{
          "text" : "Therapieempfehlung in Umsetzung"
        }],
        "reference" : {
          "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
        }
      },
      {
        "reference" : {
          "reference" : "RequestGroup/mii-exa-test-data-mtb-therapieempfehlung-kombination-1"
        }
      },
      {
        "reference" : {
          "reference" : "ServiceRequest/mii-exa-test-data-mtb-studieneinschluss-anfrage-1"
        }
      },
      {
        "reference" : {
          "reference" : "ServiceRequest/mii-exa-test-data-mtb-humangenetische-beratung-1"
        }
      },
      {
        "reference" : {
          "reference" : "ServiceRequest/mii-exa-test-data-mtb-histologie-evaluation-1"
        }
      },
      {
        "reference" : {
          "reference" : "ServiceRequest/mii-exa-test-data-mtb-biopsie-auftrag-1"
        }
      },
      {
        "detail" : {
          "code" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
              "code" : "CH",
              "display" : "Chemotherapie"
            }]
          },
          "status" : "completed",
          "statusReason" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapieabweichung",
              "code" : "N"
            }],
            "text" : "regulär abgeschlossen"
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "CarePlan/mii-exa-test-data-mtb-therapieplan-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-mtb-therapieempfehlung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-mtb-therapieempfehlung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-mtb-therapieempfehlung-1</b></p><a name=\"mii-exa-test-data-mtb-therapieempfehlung-1\"> </a><a name=\"hcmii-exa-test-data-mtb-therapieempfehlung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung\">MII PR MTB Therapieempfehlung Systemische Therapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX MTB Empfehlung Priorität</b>: 1</p><p><b>MII EX MTB Empfehlung Evidenzgraduierung</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-empfehlung-evidenzgrad m1A}\">Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.</span></p><p><b>MII EX MTB Empfehlung Publikation</b>: <code>http://www.ncbi.nlm.nih.gov/pubmed</code>/29151359</p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-beschluss</code>/TE-2024-001</p><p><b>status</b>: Draft</p><p><b>intent</b>: Proposal</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01EB04}, {http://fdasis.nlm.nih.gov 3C06JJ0Z2O}\">Osimertinib 80 mg</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>supportingInformation</b>: <a href=\"DiagnosticReport-mii-exa-test-data-mtb-ngs-bericht-1.html\">Diagnostic Report for 'Genetic analysis report' for '-&gt;Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)'</a></p><p><b>authoredOn</b>: 2024-03-28</p><p><b>requester</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C34.1}\">Bösartige Neubildung: Oberlappen (-Bronchus)</span></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-mtb-therapieplan-1.html\">CarePlan: status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); description = MTB-Beschluss mit Therapieempfehlungen und Studieneinschluss; created = 2024-03-28</a></p><p><b>note</b>: </p><blockquote><div><p>Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>text</b>: 80 mg einmal täglich oral</p><p><b>timing</b>: Events: 2024-04-15 08:00:00+0200 , Count 130  times, Duration 5days , 1-2 per 1-2 day</p><p><b>asNeeded</b>: false</p><p><b>site</b>: <span title=\"Codes:{http://snomed.info/sct 123851003}\">Mouth region structure (body structure)</span></p><p><b>route</b>: <span title=\"Codes:{http://snomed.info/sct 26643006}\">Oral route (qualifier value)</span></p><blockquote><p><b>doseAndRate</b></p><p><b>dose</b>: 80 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>rate</b>: 80 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Tag<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  coded = 'd')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>dose</b>: 40-80 mg</p><p><b>rate</b>: 3.3 mg/h<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/h = 'mg/h')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>rate</b>: 2-4 mg/h</p></blockquote><p><b>maxDosePerPeriod</b>: 160 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Tag<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  coded = 'd')</span></p><p><b>maxDosePerAdministration</b>: 80 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p></blockquote><h3>Substitutions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Allowed[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>false</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-prioritaet",
        "valuePositiveInt" : 1
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-evidenzgraduierung",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-empfehlung-evidenzgrad",
            "code" : "m1A"
          }]
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-publikation",
        "valueIdentifier" : {
          "system" : "http://www.ncbi.nlm.nih.gov/pubmed",
          "value" : "29151359"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-beschluss",
        "value" : "TE-2024-001"
      }],
      "status" : "draft",
      "intent" : "proposal",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2024",
          "code" : "L01EB04",
          "display" : "Osimertinib"
        },
        {
          "system" : "http://fdasis.nlm.nih.gov",
          "code" : "3C06JJ0Z2O",
          "display" : "OSIMERTINIB"
        }],
        "text" : "Osimertinib 80 mg"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "supportingInformation" : [{
        "reference" : "DiagnosticReport/mii-exa-test-data-mtb-ngs-bericht-1"
      }],
      "authoredOn" : "2024-03-28",
      "requester" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "code" : "C34.1",
          "display" : "Bösartige Neubildung: Oberlappen (-Bronchus)"
        }]
      }],
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-mtb-therapieplan-1"
      }],
      "note" : [{
        "text" : "Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante."
      }],
      "dosageInstruction" : [{
        "sequence" : 1,
        "text" : "80 mg einmal täglich oral",
        "timing" : {
          "event" : ["2024-04-15T08:00:00+02:00"],
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2024-04-15",
              "end" : "2024-08-30"
            },
            "count" : 130,
            "countMax" : 140,
            "duration" : 5,
            "durationMax" : 10,
            "durationUnit" : "min",
            "frequency" : 1,
            "frequencyMax" : 2,
            "period" : 1,
            "periodMax" : 2,
            "periodUnit" : "d",
            "dayOfWeek" : ["mon"],
            "timeOfDay" : ["08:00:00"]
          }
        },
        "asNeededBoolean" : false,
        "site" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "123851003",
            "display" : "Mouth region structure (body structure)"
          }]
        },
        "route" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "26643006",
            "display" : "Oral route (qualifier value)"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 80,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "rateRatio" : {
            "numerator" : {
              "value" : 80,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "Tag",
              "system" : "http://unitsofmeasure.org",
              "code" : "d"
            }
          }
        },
        {
          "doseRange" : {
            "low" : {
              "value" : 40,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "high" : {
              "value" : 80,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            }
          },
          "rateQuantity" : {
            "value" : 3.3,
            "unit" : "mg/h",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg/h"
          }
        },
        {
          "rateRange" : {
            "low" : {
              "value" : 2,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            },
            "high" : {
              "value" : 4,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            }
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 160,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Tag",
            "system" : "http://unitsofmeasure.org",
            "code" : "d"
          }
        },
        "maxDosePerAdministration" : {
          "value" : 80,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        }
      }],
      "substitution" : {
        "allowedBoolean" : false
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-2",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-mtb-therapieempfehlung-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-mtb-therapieempfehlung-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-mtb-therapieempfehlung-2</b></p><a name=\"mii-exa-test-data-mtb-therapieempfehlung-2\"> </a><a name=\"hcmii-exa-test-data-mtb-therapieempfehlung-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung\">MII PR MTB Therapieempfehlung Systemische Therapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Draft</p><p><b>intent</b>: Option</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01XX73}\">Sotorasib</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>authoredOn</b>: 2024-03-28</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Timing</b></td><td><b>AsNeeded[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>30min , Morning, Once</td><td><span title=\"Codes:{http://snomed.info/sct 422587007}\">Nausea (finding)</span></td></tr></table><p><b>priorPrescription</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-1.html\">MedicationRequest: extension = 1,Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.,http://www.ncbi.nlm.nih.gov/pubmed#29151359; identifier = https://www.charite.de/fhir/sid/mtb-beschluss#TE-2024-001; status = draft; intent = proposal; medication[x] = Osimertinib; authoredOn = 2024-03-28; reasonCode = Bösartige Neubildung: Oberlappen (-Bronchus); note = Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante.</a></p></div>"
      },
      "status" : "draft",
      "intent" : "option",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2024",
          "code" : "L01XX73",
          "display" : "Sotorasib"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "authoredOn" : "2024-03-28",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "dosageInstruction" : [{
        "timing" : {
          "repeat" : {
            "boundsDuration" : {
              "value" : 7,
              "unit" : "Tage",
              "system" : "http://unitsofmeasure.org",
              "code" : "d"
            },
            "when" : ["MORN"],
            "offset" : 30
          }
        },
        "asNeededCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "422587007",
            "display" : "Nausea (finding)"
          }]
        }
      }],
      "priorPrescription" : {
        "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-3",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-mtb-therapieempfehlung-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-mtb-therapieempfehlung-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-mtb-therapieempfehlung-3</b></p><a name=\"mii-exa-test-data-mtb-therapieempfehlung-3\"> </a><a name=\"hcmii-exa-test-data-mtb-therapieempfehlung-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung\">MII PR MTB Therapieempfehlung Systemische Therapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Draft</p><p><b>intent</b>: Option</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01EE01}\">Trametinib</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>authoredOn</b>: 2024-03-28</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>Timing</b></td></tr><tr><td style=\"display: none\">*</td><td>Ausschleichen über 1-2 Wochen</td><td>Once</td></tr></table></div>"
      },
      "status" : "draft",
      "intent" : "option",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2024",
          "code" : "L01EE01",
          "display" : "Trametinib"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "authoredOn" : "2024-03-28",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "dosageInstruction" : [{
        "text" : "Ausschleichen über 1-2 Wochen",
        "timing" : {
          "repeat" : {
            "boundsRange" : {
              "low" : {
                "value" : 1,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              },
              "high" : {
                "value" : 2,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              }
            }
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/RequestGroup/mii-exa-test-data-mtb-therapieempfehlung-kombination-1",
    "resource" : {
      "resourceType" : "RequestGroup",
      "id" : "mii-exa-test-data-mtb-therapieempfehlung-kombination-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung-kombination"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RequestGroup_mii-exa-test-data-mtb-therapieempfehlung-kombination-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RequestGroup mii-exa-test-data-mtb-therapieempfehlung-kombination-1</b></p><a name=\"mii-exa-test-data-mtb-therapieempfehlung-kombination-1\"> </a><a name=\"hcmii-exa-test-data-mtb-therapieempfehlung-kombination-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-therapieempfehlung-kombination\">MII PR MTB Therapieempfehlung Kombinationstherapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX MTB Empfehlung Priorität</b>: 2</p><p><b>MII EX MTB Empfehlung Evidenzgraduierung</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-empfehlung-evidenzgrad m1B}\">Predictive value of the biomarker or clinical effectiveness of the drug in a molecularly stratified cohort was demonstrated in a retrospective cohort or case–control study in the same tumor type.</span></p><p><b>MII EX MTB Empfehlung Publikation</b>: <code>http://doi.org</code>/10.1056/NEJMoa2030428</p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-beschluss</code>/KOMBI-2024-001</p><p><b>status</b>: Draft</p><p><b>intent</b>: Proposal</p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ ZS}\">zielgerichtete Substanzen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>authoredOn</b>: 2024-03-28</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><blockquote><p><b>action</b></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ ZS}\">zielgerichtete Substanzen</span></p><p><b>resource</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-2.html\">MedicationRequest: status = draft; intent = option; medication[x] = Sotorasib; authoredOn = 2024-03-28</a></p></blockquote><blockquote><p><b>action</b></p><p><b>resource</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-3.html\">MedicationRequest: status = draft; intent = option; medication[x] = Trametinib; authoredOn = 2024-03-28</a></p></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-prioritaet",
        "valuePositiveInt" : 2
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-evidenzgraduierung",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-empfehlung-evidenzgrad",
            "code" : "m1B"
          }]
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-publikation",
        "valueIdentifier" : {
          "system" : "http://doi.org",
          "value" : "10.1056/NEJMoa2030428"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-beschluss",
        "value" : "KOMBI-2024-001"
      }],
      "status" : "draft",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
          "code" : "ZS",
          "display" : "zielgerichtete Substanzen"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "authoredOn" : "2024-03-28",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "action" : [{
        "code" : [{
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
            "code" : "ZS",
            "display" : "zielgerichtete Substanzen"
          }]
        }],
        "resource" : {
          "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-2"
        }
      },
      {
        "resource" : {
          "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-3"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "RequestGroup/mii-exa-test-data-mtb-therapieempfehlung-kombination-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-mtb-studieneinschluss-anfrage-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-mtb-studieneinschluss-anfrage-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-studieneinschluss-anfrage"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-mtb-studieneinschluss-anfrage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-mtb-studieneinschluss-anfrage-1</b></p><a name=\"mii-exa-test-data-mtb-studieneinschluss-anfrage-1\"> </a><a name=\"hcmii-exa-test-data-mtb-studieneinschluss-anfrage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-studieneinschluss-anfrage\">MII PR MTB Studieneinschluss Anfrage</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX MTB Empfehlung Priorität</b>: 3.1</p><p><b>MII EX MTB Empfehlung Publikation</b>: <code>http://www.ncbi.nlm.nih.gov/pubmed</code>/34726479</p><p><b>status</b>: Draft</p><p><b>intent</b>: Proposal</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 110465008}\">Clinical trial (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 702475000}\">Referral to clinical trial (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>supportingInfo</b>: <a href=\"ResearchStudy-mii-exa-test-data-mtb-studie-1.html\">ResearchStudy Phase III NSCLC EGFR Mutation Study</a></p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-prioritaet",
        "valueDecimal" : 3.1
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-publikation",
        "valueIdentifier" : {
          "system" : "http://www.ncbi.nlm.nih.gov/pubmed",
          "value" : "34726479"
        }
      }],
      "status" : "draft",
      "intent" : "proposal",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "110465008",
          "display" : "Clinical trial (procedure)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "702475000",
          "display" : "Referral to clinical trial (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "supportingInfo" : [{
        "reference" : "ResearchStudy/mii-exa-test-data-mtb-studie-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-mtb-studieneinschluss-anfrage-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-mtb-studieneinschluss-anfrage-2",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-mtb-studieneinschluss-anfrage-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-studieneinschluss-anfrage"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-mtb-studieneinschluss-anfrage-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-mtb-studieneinschluss-anfrage-2</b></p><a name=\"mii-exa-test-data-mtb-studieneinschluss-anfrage-2\"> </a><a name=\"hcmii-exa-test-data-mtb-studieneinschluss-anfrage-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-studieneinschluss-anfrage\">MII PR MTB Studieneinschluss Anfrage</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Request status reason</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-therapiestatusgrund patient-death}\">Studieneinschluss nicht erfolgt - Patient vor Screening verstorben</span></p><p><b>MII EX MTB Empfehlung Priorität</b>: 3.2</p><p><b>status</b>: Revoked</p><p><b>intent</b>: Proposal</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 110465008}\">Clinical trial (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 702475000}\">Referral to clinical trial (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>supportingInfo</b>: <a href=\"ResearchStudy-mii-exa-test-data-mtb-studie-1.html\">ResearchStudy Phase III NSCLC EGFR Mutation Study</a></p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/request-statusReason",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-therapiestatusgrund",
            "code" : "patient-death",
            "display" : "Tod"
          }],
          "text" : "Studieneinschluss nicht erfolgt - Patient vor Screening verstorben"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-empfehlung-prioritaet",
        "valueDecimal" : 3.2
      }],
      "status" : "revoked",
      "intent" : "proposal",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "110465008",
          "display" : "Clinical trial (procedure)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "702475000",
          "display" : "Referral to clinical trial (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "supportingInfo" : [{
        "reference" : "ResearchStudy/mii-exa-test-data-mtb-studie-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-mtb-studieneinschluss-anfrage-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ResearchStudy/mii-exa-test-data-mtb-studie-1",
    "resource" : {
      "resourceType" : "ResearchStudy",
      "id" : "mii-exa-test-data-mtb-studie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-studie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ResearchStudy_mii-exa-test-data-mtb-studie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchStudy mii-exa-test-data-mtb-studie-1</b></p><a name=\"mii-exa-test-data-mtb-studie-1\"> </a><a name=\"hcmii-exa-test-data-mtb-studie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-studie\">MII PR MTB Studie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>MII EX Studie Backport Label</b></p><ul><li>value: Phase-III-Studie zu Osimertinib bei EGFR-mutiertem NSCLC</li><li>type: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/title-type scientific}\">Scientific title</span></li></ul></blockquote><blockquote><p><b>MII EX Studie Backport AssociatedParty</b></p><ul><li>role: <span title=\"Codes:{http://hl7.org/fhir/research-study-party-role sponsor}\">sponsor</span></li><li>party: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></li></ul></blockquote><blockquote><p><b>MII EX Studie Ethikvotum</b></p><ul><li>status: Zustimmende Bewertung</li><li>kommission: Ethikkommission der Charité - Universitätsmedizin Berlin</li><li>ethiknummer: EA1/456/24</li></ul></blockquote><p><b>MII EX Studie Studienregister</b>: <a href=\"Library-mii-exa-test-data-mtb-studien-register-1.html\">ClinicalTrials.gov</a></p><p><b>MII EX Studie Eligibility</b>: <a href=\"Group-mii-exa-test-data-mtb-studie-group-1.html\">Group Erwachsene mit EGFR-mutiertem NSCLC im Stadium IV</a></p><p><b>MII EX Studie Akronym</b>: NSCLC-EGFR-III</p><blockquote><p><b>MII EX Studie Rekrutierung</b></p><ul><li>rekrutierungsstart: 2024-01-01</li><li>rekrutierungsziel: 300</li><li>rekrutierungsstand: 120</li><li>rekrutierungsstand-datum: 2024-06-01</li></ul></blockquote><p><b>MII EX Studie Finanzierung</b>: Industriefinanzierte Studie</p><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/NamingSystem/mii-ns-mtb-nct</code>/05252390</p><p><b>title</b>: Phase III NSCLC EGFR Mutation Study</p><p><b>partOf</b>: <a href=\"ResearchStudy-mii-exa-test-data-mtb-studie-2.html\">ResearchStudy NSCLC Master Protocol</a></p><p><b>status</b>: Active</p><p><b>primaryPurposeType</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/research-study-prim-purp-type treatment}\">Treatment</span></p><p><b>phase</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/research-study-phase phase-3}\">Phase 3</span></p><p><b>category</b>: <span title=\"Codes:\">Interventionelle Arzneimittelstudie</span></p><p><b>focus</b>: <span title=\"Codes:\">EGFR-mutiertes NSCLC</span></p><p><b>keyword</b>: <span title=\"Codes:\">EGFR</span></p><h3>Arms</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td></tr><tr><td style=\"display: none\">*</td><td>Arm A: Osimertinib</td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "value",
          "valueString" : "Phase-III-Studie zu Osimertinib bei EGFR-mutiertem NSCLC"
        },
        {
          "url" : "type",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/title-type",
              "code" : "scientific"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ResearchStudy.label"
      },
      {
        "extension" : [{
          "url" : "role",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/research-study-party-role",
              "code" : "sponsor"
            }]
          }
        },
        {
          "url" : "party",
          "valueReference" : {
            "reference" : "Organization/mii-exa-test-data-organization-charite"
          }
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ResearchStudy.associatedParty"
      },
      {
        "extension" : [{
          "url" : "status",
          "valueString" : "Zustimmende Bewertung"
        },
        {
          "url" : "kommission",
          "valueString" : "Ethikkommission der Charité - Universitätsmedizin Berlin"
        },
        {
          "url" : "ethiknummer",
          "valueString" : "EA1/456/24"
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-ethikvotum"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-studienregister",
        "valueReference" : {
          "reference" : "Library/mii-exa-test-data-mtb-studien-register-1"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-eligibility",
        "valueReference" : {
          "reference" : "Group/mii-exa-test-data-mtb-studie-group-1"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-akronym",
        "valueString" : "NSCLC-EGFR-III"
      },
      {
        "extension" : [{
          "url" : "rekrutierungsstart",
          "valueDate" : "2024-01-01"
        },
        {
          "url" : "rekrutierungsziel",
          "valueInteger" : 300
        },
        {
          "url" : "rekrutierungsstand",
          "valueInteger" : 120
        },
        {
          "url" : "rekrutierungsstand-datum",
          "valueDate" : "2024-06-01"
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-rekrutierung"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-finanzierung",
        "valueString" : "Industriefinanzierte Studie"
      }],
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/NamingSystem/mii-ns-mtb-nct",
        "value" : "05252390"
      }],
      "title" : "Phase III NSCLC EGFR Mutation Study",
      "partOf" : [{
        "reference" : "ResearchStudy/mii-exa-test-data-mtb-studie-2"
      }],
      "status" : "active",
      "primaryPurposeType" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/research-study-prim-purp-type",
          "code" : "treatment",
          "display" : "Treatment"
        }]
      },
      "phase" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/research-study-phase",
          "code" : "phase-3",
          "display" : "Phase 3"
        }]
      },
      "category" : [{
        "text" : "Interventionelle Arzneimittelstudie"
      }],
      "focus" : [{
        "text" : "EGFR-mutiertes NSCLC"
      }],
      "keyword" : [{
        "text" : "EGFR"
      }],
      "arm" : [{
        "name" : "Arm A: Osimertinib"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ResearchStudy/mii-exa-test-data-mtb-studie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ResearchStudy/mii-exa-test-data-mtb-studie-2",
    "resource" : {
      "resourceType" : "ResearchStudy",
      "id" : "mii-exa-test-data-mtb-studie-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ResearchStudy_mii-exa-test-data-mtb-studie-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchStudy mii-exa-test-data-mtb-studie-2</b></p><a name=\"mii-exa-test-data-mtb-studie-2\"> </a><a name=\"hcmii-exa-test-data-mtb-studie-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>title</b>: NSCLC Master Protocol</p><p><b>status</b>: Active</p></div>"
      },
      "title" : "NSCLC Master Protocol",
      "status" : "active"
    },
    "request" : {
      "method" : "PUT",
      "url" : "ResearchStudy/mii-exa-test-data-mtb-studie-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Library/mii-exa-test-data-mtb-studien-register-1",
    "resource" : {
      "resourceType" : "Library",
      "id" : "mii-exa-test-data-mtb-studien-register-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Library_mii-exa-test-data-mtb-studien-register-1\"> </a>\n<div>\n    <table class=\"grid dict\">\n        \n        \n        <tr>\n            <th scope=\"row\"><b>Title: </b></th>\n            <td style=\"padding-left: 4px;\">ClinicalTrials.gov</td>\n        </tr>\n        \n\n        \n        \n        <tr>\n            <th scope=\"row\"><b>Id: </b></th>\n            <td style=\"padding-left: 4px;\">mii-exa-test-data-mtb-studien-register-1</td>\n        </tr>\n        \n\n        \n        \n\n        \n        <tr>\n            <th scope=\"row\"><b>Url: </b></th>\n            <td style=\"padding-left: 4px;\"><a href=\"Library-mii-exa-test-data-mtb-studien-register-1.html\">ClinicalTrials.gov</a></td>\n        </tr>\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n        <tr>\n            <th scope=\"row\"><b>Type: </b></th>\n            <td style=\"padding-left: 4px;\">\n                \n                    \n                        \n                        <p style=\"margin-bottom: 5px;\">\n                            <b>system: </b> <span><a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-library-type.html\">http://terminology.hl7.org/CodeSystem/library-type</a></span>\n                        </p>\n                        \n                        \n                        <p style=\"margin-bottom: 5px;\">\n                            <b>code: </b> <span>asset-collection</span>\n                        </p>\n                        \n                        \n                    \n                \n                \n            </td>\n        </tr>\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n    </table>\n</div>\n</div>"
      },
      "url" : "https://clinicaltrials.gov/study/NCT05252390",
      "name" : "ClinicalTrials_gov",
      "title" : "ClinicalTrials.gov",
      "status" : "active",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/library-type",
          "code" : "asset-collection"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Library/mii-exa-test-data-mtb-studien-register-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Group/mii-exa-test-data-mtb-studie-group-1",
    "resource" : {
      "resourceType" : "Group",
      "id" : "mii-exa-test-data-mtb-studie-group-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Group_mii-exa-test-data-mtb-studie-group-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Group mii-exa-test-data-mtb-studie-group-1</b></p><a name=\"mii-exa-test-data-mtb-studie-group-1\"> </a><a name=\"hcmii-exa-test-data-mtb-studie-group-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: Person</p><p><b>actual</b>: false</p><p><b>name</b>: Erwachsene mit EGFR-mutiertem NSCLC im Stadium IV</p></div>"
      },
      "type" : "person",
      "actual" : false,
      "name" : "Erwachsene mit EGFR-mutiertem NSCLC im Stadium IV"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Group/mii-exa-test-data-mtb-studie-group-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-mtb-humangenetische-beratung-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-mtb-humangenetische-beratung-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-humangenetische-beratung-auftrag"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-mtb-humangenetische-beratung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-mtb-humangenetische-beratung-1</b></p><a name=\"mii-exa-test-data-mtb-humangenetische-beratung-1\"> </a><a name=\"hcmii-exa-test-data-mtb-humangenetische-beratung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-humangenetische-beratung-auftrag\">MII PR MTB Human-genetische Beratung Auftrag</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Draft</p><p><b>intent</b>: Proposal</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 788339009}\">Genetic consultation (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>reasonCode</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-auftrag-begruendung secondary-tumor}\">Zweittumor</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p></div>"
      },
      "status" : "draft",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "788339009",
          "display" : "Genetic consultation (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-auftrag-begruendung",
          "code" : "secondary-tumor"
        }]
      }],
      "specimen" : [{
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-mtb-humangenetische-beratung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-mtb-histologie-evaluation-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-mtb-histologie-evaluation-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-histologie-evaluation-auftrag"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-mtb-histologie-evaluation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-mtb-histologie-evaluation-1</b></p><a name=\"mii-exa-test-data-mtb-histologie-evaluation-1\"> </a><a name=\"hcmii-exa-test-data-mtb-histologie-evaluation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-histologie-evaluation-auftrag\">MII PR MTB Histologie-Evaluation Auftrag</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Draft</p><p><b>intent</b>: Proposal</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 183825009}\">Refer for histology (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>reasonReference</b>: <a href=\"Observation-mii-exa-test-data-mtb-tumorzellgehalt-1.html\">Observation Cells with cytogenetic abnormality [#] in Blood or Tissue by Molecular genetics method</a></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p></div>"
      },
      "status" : "draft",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "183825009",
          "display" : "Refer for histology (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "reasonReference" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-tumorzellgehalt-1"
      }],
      "specimen" : [{
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-mtb-histologie-evaluation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-mtb-biopsie-auftrag-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-mtb-biopsie-auftrag-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-biopsie-auftrag"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-mtb-biopsie-auftrag-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-mtb-biopsie-auftrag-1</b></p><a name=\"mii-exa-test-data-mtb-biopsie-auftrag-1\"> </a><a name=\"hcmii-exa-test-data-mtb-biopsie-auftrag-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-biopsie-auftrag\">MII PR MTB Biopsie Auftrag</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Draft</p><p><b>intent</b>: Proposal</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 86273004}\">Biopsy (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>reasonReference</b>: <a href=\"Observation-mii-exa-test-data-mtb-tumorzellgehalt-1.html\">Observation Cells with cytogenetic abnormality [#] in Blood or Tissue by Molecular genetics method</a></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-test-data-mtb-specimen-1.html\">Specimen: status = available; type = Tissue</a></p></div>"
      },
      "status" : "draft",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "86273004",
          "display" : "Biopsy (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "reasonReference" : [{
        "reference" : "Observation/mii-exa-test-data-mtb-tumorzellgehalt-1"
      }],
      "specimen" : [{
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-mtb-biopsie-auftrag-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ClinicalImpression/mii-exa-test-data-mtb-follow-up-1",
    "resource" : {
      "resourceType" : "ClinicalImpression",
      "id" : "mii-exa-test-data-mtb-follow-up-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-follow-up-clinicalimpression"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalImpression_mii-exa-test-data-mtb-follow-up-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalImpression mii-exa-test-data-mtb-follow-up-1</b></p><a name=\"mii-exa-test-data-mtb-follow-up-1\"> </a><a name=\"hcmii-exa-test-data-mtb-follow-up-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-follow-up-clinicalimpression\">MII PR MTB Clinical Impresssion</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Completed</p><p><b>statusReason</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-systemische-therapie-status-grund medical-reason}\">medical-reason</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 390906007}\">Follow-up encounter (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>effective</b>: 2024-09-15</p><p><b>previous</b>: <a href=\"ClinicalImpression-mii-exa-test-data-mtb-behandlungsepisode-1.html\">ClinicalImpression: extension = exhausted (MII CS Leitlinienbehandlung Status#exhausted); status = completed; effective[x] = 2024-01-15 --&gt; 2024-06-30</a></p><h3>Investigations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-follow-up-status completed}\">completed</span></td></tr></table><p><b>supportingInfo</b>: </p><ul><li><a href=\"Procedure-mii-exa-test-data-mtb-systemische-therapie-1.html\">Procedure Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie</a></li><li><a href=\"Claim-mii-exa-test-data-mtb-antrag-kostenuebernahme-1.html\">Claim: status = active; type = Institutional; use = claim; created = 2024-04-01; priority = Normal</a></li><li><a href=\"ClaimResponse-mii-exa-test-data-mtb-antwort-kostenuebernahme-1.html\">ClaimResponse: extension = Angenommen; status = active; type = Institutional; use = claim; created = 2024-04-20; outcome = complete</a></li></ul></div>"
      },
      "status" : "completed",
      "statusReason" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-systemische-therapie-status-grund",
          "code" : "medical-reason"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "390906007",
          "display" : "Follow-up encounter (procedure)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "effectiveDateTime" : "2024-09-15",
      "previous" : {
        "reference" : "ClinicalImpression/mii-exa-test-data-mtb-behandlungsepisode-1"
      },
      "investigation" : [{
        "code" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-follow-up-status",
            "code" : "completed"
          }]
        }
      }],
      "supportingInfo" : [{
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
      },
      {
        "reference" : "Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-1"
      },
      {
        "reference" : "ClaimResponse/mii-exa-test-data-mtb-antwort-kostenuebernahme-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ClinicalImpression/mii-exa-test-data-mtb-follow-up-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Procedure/mii-exa-test-data-mtb-systemische-therapie-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-test-data-mtb-systemische-therapie-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemische-therapie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_mii-exa-test-data-mtb-systemische-therapie-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-test-data-mtb-systemische-therapie-1</b></p><a name=\"mii-exa-test-data-mtb-systemische-therapie-1\"> </a><a name=\"hcmii-exa-test-data-mtb-systemische-therapie-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemische-therapie\">MII PR MTB Systemische Therapie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX Onko Systemische Therapie Intention</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention K}\">kurativ</span></p><p><b>ExtensionProzedurDokumentationsdatum</b>: 2024-08-30</p><p><b>MII EX Prozedur Durchführungsabsicht</b>: <a href=\"http://snomed.info/id/262202000\">SNOMED CT: 262202000</a> (Therapeutic)</p><p><b>MII EX Onko Systemische Therapie Stellung zur OP</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop O}\">ohne Bezug zur operativen Therapie</span></p><p><b>Procedure Caused By</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-1.html\">MedicationRequest: extension = 1,Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.,http://www.ncbi.nlm.nih.gov/pubmed#29151359; identifier = https://www.charite.de/fhir/sid/mtb-beschluss#TE-2024-001; status = draft; intent = proposal; medication[x] = Osimertinib; authoredOn = 2024-03-28; reasonCode = Bösartige Neubildung: Oberlappen (-Bronchus); note = Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante.</a></p><p><b>basedOn</b>: <a href=\"CarePlan-mii-exa-test-data-mtb-therapieplan-1.html\">CarePlan: status = active; intent = plan; category = prätherapeutische Tumorkonferenz (Festlegung der Therapiestrategie); description = MTB-Beschluss mit Therapieempfehlungen und Studieneinschluss; created = 2024-03-28</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-mtb-systemische-vortherapie-1.html\">Procedure Chemotherapy (procedure)</a></p><p><b>status</b>: Completed</p><p><b>statusReason</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-therapiestatusgrund regular-completion}\">Reguläres Ende</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 367336001}\">Chemotherapy (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ ZS}, {http://fhir.de/CodeSystem/bfarm/ops 8-54}\">Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>performed</b>: 2024-04-15 --&gt; 2024-08-30</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 39607008}\">Lung structure (body structure)</span></p><p><b>outcome</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund E}\">reguläres Ende</span></p><p><b>note</b>: </p><blockquote><div><p>Zielgerichtete Therapie mit Osimertinib gemaess MTB-Beschluss.</p>\n</div></blockquote><p><b>usedCode</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-systemische-therapie-protokolle CarboTax}\">CarboTax</span></p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-systemische-therapie-intention",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-intention",
            "code" : "K"
          }],
          "text" : "kurativ"
        }
      },
      {
        "url" : "http://fhir.de/StructureDefinition/ProzedurDokumentationsdatum",
        "valueDateTime" : "2024-08-30"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/StructureDefinition/Durchfuehrungsabsicht",
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "262202000",
          "display" : "Therapeutic"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-systemische-therapie-stellungzurop",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop",
            "code" : "O"
          }],
          "text" : "ohne Bezug zur operativen Therapie"
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/procedure-causedBy",
        "valueReference" : {
          "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
        }
      }],
      "basedOn" : [{
        "reference" : "CarePlan/mii-exa-test-data-mtb-therapieplan-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-vortherapie-1"
      }],
      "status" : "completed",
      "statusReason" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-therapiestatusgrund",
          "code" : "regular-completion"
        }]
      },
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "367336001",
          "display" : "Chemotherapy (procedure)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-typ",
          "code" : "ZS"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/seitenlokalisation",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION",
              "code" : "R",
              "display" : "rechts"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/ops",
          "version" : "2024",
          "code" : "8-54",
          "display" : "Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "performedPeriod" : {
        "start" : "2024-04-15",
        "end" : "2024-08-30"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "version" : "http://snomed.info/sct/900000000000207008/version/20240201",
          "code" : "39607008",
          "display" : "Lung structure (body structure)"
        }]
      }],
      "outcome" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-ende-grund",
          "code" : "E"
        }]
      },
      "note" : [{
        "text" : "Zielgerichtete Therapie mit Osimertinib gemaess MTB-Beschluss."
      }],
      "usedCode" : [{
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-systemische-therapie-protokolle",
          "code" : "CarboTax",
          "display" : "CarboTax"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-1",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "mii-exa-test-data-mtb-systemische-therapie-medstatement-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemtherapie-medication-statement"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_mii-exa-test-data-mtb-systemische-therapie-medstatement-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement mii-exa-test-data-mtb-systemische-therapie-medstatement-1</b></p><a name=\"mii-exa-test-data-mtb-systemische-therapie-medstatement-1\"> </a><a name=\"hcmii-exa-test-data-mtb-systemische-therapie-medstatement-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemtherapie-medication-statement\">MII PR MTB Systemtherapie Medication Statement</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-medikation</code>/MEDSTMT-2024-001</p><p><b>basedOn</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-1.html\">MedicationRequest: extension = 1,Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.,http://www.ncbi.nlm.nih.gov/pubmed#29151359; identifier = https://www.charite.de/fhir/sid/mtb-beschluss#TE-2024-001; status = draft; intent = proposal; medication[x] = Osimertinib; authoredOn = 2024-03-28; reasonCode = Bösartige Neubildung: Oberlappen (-Bronchus); note = Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante.</a></p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-mtb-systemische-therapie-1.html\">Procedure Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/medication-statement-category inpatient}\">Inpatient</span></p><p><b>medication</b>: <span title=\"Codes:{http://fdasis.nlm.nih.gov 3C06JJ0Z2O}, {http://fhir.de/CodeSystem/bfarm/atc L01EB04}\">Osimertinib 80 mg Filmtabletten</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>context</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-04-15 --&gt; 2024-04-15</p><p><b>dateAsserted</b>: 2024-04-15</p><p><b>informationSource</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm C34.1}\">Bösartige Neubildung: Oberlappen (-Bronchus)</span></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>note</b>: </p><blockquote><div><p>Z1 Osimertinib 80mg oral, daily</p>\n</div></blockquote><blockquote><p><b>dosage</b></p><p><b>sequence</b>: 1</p><p><b>text</b>: 80 mg einmal täglich oral</p><p><b>timing</b>: Events: 2024-04-15 08:00:00+0200 , Count 130  times, Duration 5days , 1-2 per 1-2 day</p><p><b>asNeeded</b>: false</p><p><b>site</b>: <span title=\"Codes:{http://snomed.info/sct 123851003}\">Mouth region structure (body structure)</span></p><p><b>route</b>: <span title=\"Codes:{http://snomed.info/sct 26643006}\">Oral route (qualifier value)</span></p><blockquote><p><b>doseAndRate</b></p><p><b>type</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-dosisdichte volle-Dosis}\">volle Dosis</span></p><p><b>dose</b>: 80 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>rate</b>: 80 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Tag<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  coded = 'd')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>dose</b>: 40-80 mg</p><p><b>rate</b>: 3.3 mg/h<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/h = 'mg/h')</span></p></blockquote><blockquote><p><b>doseAndRate</b></p><p><b>rate</b>: 2-4 mg/h</p></blockquote><p><b>maxDosePerPeriod</b>: 160 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Tag<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  coded = 'd')</span></p><p><b>maxDosePerAdministration</b>: 80 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-medikation",
        "value" : "MEDSTMT-2024-001"
      }],
      "basedOn" : [{
        "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medication-statement-category",
          "code" : "inpatient",
          "display" : "Inpatient"
        }]
      },
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fdasis.nlm.nih.gov",
          "code" : "3C06JJ0Z2O",
          "display" : "OSIMERTINIB"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2024",
          "code" : "L01EB04",
          "display" : "Osimertinib"
        }],
        "text" : "Osimertinib 80 mg Filmtabletten"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "context" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectivePeriod" : {
        "start" : "2024-04-15",
        "end" : "2024-04-15"
      },
      "dateAsserted" : "2024-04-15",
      "informationSource" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "code" : "C34.1",
          "display" : "Bösartige Neubildung: Oberlappen (-Bronchus)"
        }]
      }],
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "note" : [{
        "text" : "Z1 Osimertinib 80mg oral, daily"
      }],
      "dosage" : [{
        "sequence" : 1,
        "text" : "80 mg einmal täglich oral",
        "timing" : {
          "event" : ["2024-04-15T08:00:00+02:00"],
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2024-04-15",
              "end" : "2024-08-30"
            },
            "count" : 130,
            "countMax" : 140,
            "duration" : 5,
            "durationMax" : 10,
            "durationUnit" : "min",
            "frequency" : 1,
            "frequencyMax" : 2,
            "period" : 1,
            "periodMax" : 2,
            "periodUnit" : "d",
            "dayOfWeek" : ["mon"],
            "timeOfDay" : ["08:00:00"]
          }
        },
        "asNeededBoolean" : false,
        "site" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "123851003",
            "display" : "Mouth region structure (body structure)"
          }]
        },
        "route" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "26643006",
            "display" : "Oral route (qualifier value)"
          }]
        },
        "doseAndRate" : [{
          "type" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-dosisdichte",
              "code" : "volle-Dosis",
              "display" : "volle Dosis"
            }]
          },
          "doseQuantity" : {
            "value" : 80,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "rateRatio" : {
            "numerator" : {
              "value" : 80,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "denominator" : {
              "value" : 1,
              "unit" : "Tag",
              "system" : "http://unitsofmeasure.org",
              "code" : "d"
            }
          }
        },
        {
          "doseRange" : {
            "low" : {
              "value" : 40,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            },
            "high" : {
              "value" : 80,
              "unit" : "mg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg"
            }
          },
          "rateQuantity" : {
            "value" : 3.3,
            "unit" : "mg/h",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg/h"
          }
        },
        {
          "rateRange" : {
            "low" : {
              "value" : 2,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            },
            "high" : {
              "value" : 4,
              "unit" : "mg/h",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/h"
            }
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 160,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Tag",
            "system" : "http://unitsofmeasure.org",
            "code" : "d"
          }
        },
        "maxDosePerAdministration" : {
          "value" : 80,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-2",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "mii-exa-test-data-mtb-systemische-therapie-medstatement-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemtherapie-medication-statement"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_mii-exa-test-data-mtb-systemische-therapie-medstatement-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement mii-exa-test-data-mtb-systemische-therapie-medstatement-2</b></p><a name=\"mii-exa-test-data-mtb-systemische-therapie-medstatement-2\"> </a><a name=\"hcmii-exa-test-data-mtb-systemische-therapie-medstatement-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemtherapie-medication-statement\">MII PR MTB Systemtherapie Medication Statement</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-mtb-systemische-therapie-1.html\">Procedure Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie</a></p><p><b>status</b>: Completed</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc A04AA55}\">Palonosetron, Kombinationen</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>effective</b>: 2024-04-15 --&gt; (ongoing)</p><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Text</b></td><td><b>Timing</b></td><td><b>AsNeeded[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td>Bei Bedarf bei Übelkeit, morgens</td><td>30min , Morning, Once</td><td><span title=\"Codes:{http://snomed.info/sct 422587007}\">Nausea (finding)</span></td></tr></table></div>"
      },
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
      }],
      "status" : "completed",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2024",
          "code" : "A04AA55",
          "display" : "Palonosetron, Kombinationen"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2024-04-15"
      },
      "dosage" : [{
        "sequence" : 1,
        "text" : "Bei Bedarf bei Übelkeit, morgens",
        "timing" : {
          "repeat" : {
            "boundsDuration" : {
              "value" : 7,
              "unit" : "Tage",
              "system" : "http://unitsofmeasure.org",
              "code" : "d"
            },
            "when" : ["MORN"],
            "offset" : 30
          }
        },
        "asNeededCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "422587007",
            "display" : "Nausea (finding)"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-3",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "mii-exa-test-data-mtb-systemische-therapie-medstatement-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemtherapie-medication-statement"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_mii-exa-test-data-mtb-systemische-therapie-medstatement-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement mii-exa-test-data-mtb-systemische-therapie-medstatement-3</b></p><a name=\"mii-exa-test-data-mtb-systemische-therapie-medstatement-3\"> </a><a name=\"hcmii-exa-test-data-mtb-systemische-therapie-medstatement-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-systemtherapie-medication-statement\">MII PR MTB Systemtherapie Medication Statement</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-mtb-systemische-therapie-1.html\">Procedure Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie</a></p><p><b>status</b>: Completed</p><p><b>medication</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc L01EB04}\">Osimertinib</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>effective</b>: 2024-08-15 --&gt; (ongoing)</p><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Text</b></td><td><b>Timing</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td>Ausschleichen über 1-2 Wochen</td><td>Once</td></tr></table></div>"
      },
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
      }],
      "status" : "completed",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2024",
          "code" : "L01EB04",
          "display" : "Osimertinib"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "effectivePeriod" : {
        "start" : "2024-08-15"
      },
      "dosage" : [{
        "sequence" : 1,
        "text" : "Ausschleichen über 1-2 Wochen",
        "timing" : {
          "repeat" : {
            "boundsRange" : {
              "low" : {
                "value" : 1,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              },
              "high" : {
                "value" : 2,
                "unit" : "Wochen",
                "system" : "http://unitsofmeasure.org",
                "code" : "wk"
              }
            }
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-response-befund-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-response-befund-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-response-befund"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-response-befund-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-response-befund-1</b></p><a name=\"mii-exa-test-data-mtb-response-befund-1\"> </a><a name=\"hcmii-exa-test-data-mtb-response-befund-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-response-befund\">MII PR MTB Response Befund</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/mtb-befund</code>/RESPONSE-2024-001</p><p><b>partOf</b>: <a href=\"Procedure-mii-exa-test-data-mtb-systemische-therapie-1.html\">Procedure Zytostatische Chemotherapie, Immuntherapie und antiretrovirale Therapie</a></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 396432002}\">Status of regression of tumor (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>focus</b>: <a href=\"Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html\">Condition Bösartige Neubildung: Oberlappen (-Bronchus)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-mtb-encounter-1.html\">Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-15 --&gt; 2024-06-30</a></p><p><b>effective</b>: 2024-07-20</p><p><b>value</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-response-befund-beurteilung PR}\">Partial Response</span></p><p><b>method</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-response-befund-beurteilungsmethode RECIST}\">RECIST</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 399656008}\">Presence of metastatic neoplasm in regional lymph node (observable entity)</span></td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-lymphknoten K}\">kein Lymphknotenbefall nachweisbar</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/mtb-befund",
        "value" : "RESPONSE-2024-001"
      }],
      "partOf" : [{
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
      }],
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "396432002",
          "display" : "Status of regression of tumor (observable entity)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "focus" : [{
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      }],
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "effectiveDateTime" : "2024-07-20",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-response-befund-beurteilung",
          "code" : "PR",
          "display" : "Partial Response"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-response-befund-beurteilungsmethode",
          "code" : "RECIST",
          "display" : "RECIST"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "399656008",
            "display" : "Presence of metastatic neoplasm in regional lymph node (observable entity)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-verlauf-lymphknoten",
            "code" : "K",
            "display" : "kein Lymphknotenbefall nachweisbar"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-response-befund-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-1",
    "resource" : {
      "resourceType" : "Claim",
      "id" : "mii-exa-test-data-mtb-antrag-kostenuebernahme-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-antrag-kostenuebernahme"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Claim_mii-exa-test-data-mtb-antrag-kostenuebernahme-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Claim mii-exa-test-data-mtb-antrag-kostenuebernahme-1</b></p><a name=\"mii-exa-test-data-mtb-antrag-kostenuebernahme-1\"> </a><a name=\"hcmii-exa-test-data-mtb-antrag-kostenuebernahme-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-antrag-kostenuebernahme\">MII PR MTB Antrag Kostenuebernahme</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/claim-type institutional}\">Institutional</span></p><p><b>use</b>: Claim</p><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>created</b>: 2024-04-01</p><p><b>provider</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></p><p><b>priority</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/processpriority normal}\">Normal</span></p><h3>Relateds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Claim</b></td><td><b>Relationship</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Claim-mii-exa-test-data-mtb-antrag-kostenuebernahme-2.html\">Claim: status = active; type = Institutional; use = claim; created = 2024-03-20; priority = Normal</a></td><td><span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-antrag-kostenuebernahme-antragsstadium follow-up-claim}\">Folgeantrag</span></td></tr></table><p><b>prescription</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-1.html\">MedicationRequest: extension = 1,Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.,http://www.ncbi.nlm.nih.gov/pubmed#29151359; identifier = https://www.charite.de/fhir/sid/mtb-beschluss#TE-2024-001; status = draft; intent = proposal; medication[x] = Osimertinib; authoredOn = 2024-03-28; reasonCode = Bösartige Neubildung: Oberlappen (-Bronchus); note = Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante.</a></p><h3>CareTeams</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Provider</b></td><td><b>Responsible</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td><a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></td><td>true</td></tr></table><h3>Insurances</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Focal</b></td><td><b>Coverage</b></td><td><b>ClaimResponse</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td>true</td><td>GKV-Versicherung</td><td><a href=\"ClaimResponse-mii-exa-test-data-mtb-antwort-kostenuebernahme-1.html\">ClaimResponse: extension = Angenommen; status = active; type = Institutional; use = claim; created = 2024-04-20; outcome = complete</a></td></tr></table></div>"
      },
      "status" : "active",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/claim-type",
          "code" : "institutional",
          "display" : "Institutional"
        }]
      },
      "use" : "claim",
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "created" : "2024-04-01",
      "provider" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "priority" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/processpriority",
          "code" : "normal"
        }]
      },
      "related" : [{
        "claim" : {
          "reference" : "Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-2"
        },
        "relationship" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-antrag-kostenuebernahme-antragsstadium",
            "code" : "follow-up-claim"
          }]
        }
      }],
      "prescription" : {
        "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
      },
      "careTeam" : [{
        "sequence" : 1,
        "provider" : {
          "reference" : "Organization/mii-exa-test-data-organization-charite"
        },
        "responsible" : true
      }],
      "insurance" : [{
        "sequence" : 1,
        "focal" : true,
        "coverage" : {
          "display" : "GKV-Versicherung"
        },
        "claimResponse" : {
          "reference" : "ClaimResponse/mii-exa-test-data-mtb-antwort-kostenuebernahme-1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-2",
    "resource" : {
      "resourceType" : "Claim",
      "id" : "mii-exa-test-data-mtb-antrag-kostenuebernahme-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-antrag-kostenuebernahme"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Claim_mii-exa-test-data-mtb-antrag-kostenuebernahme-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Claim mii-exa-test-data-mtb-antrag-kostenuebernahme-2</b></p><a name=\"mii-exa-test-data-mtb-antrag-kostenuebernahme-2\"> </a><a name=\"hcmii-exa-test-data-mtb-antrag-kostenuebernahme-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-antrag-kostenuebernahme\">MII PR MTB Antrag Kostenuebernahme</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/claim-type institutional}\">Institutional</span></p><p><b>use</b>: Claim</p><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>created</b>: 2024-03-20</p><p><b>provider</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></p><p><b>priority</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/processpriority normal}\">Normal</span></p><p><b>prescription</b>: <a href=\"MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-1.html\">MedicationRequest: extension = 1,Predictive value of the biomarker or clinical effectiveness of the corresponding drug in a molecularly stratified cohort was demonstrated in a prospective study or a meta-analysis in the same tumor type.,http://www.ncbi.nlm.nih.gov/pubmed#29151359; identifier = https://www.charite.de/fhir/sid/mtb-beschluss#TE-2024-001; status = draft; intent = proposal; medication[x] = Osimertinib; authoredOn = 2024-03-28; reasonCode = Bösartige Neubildung: Oberlappen (-Bronchus); note = Empfehlung mit Evidenzgrad m1A auf Basis der EGFR-L858R-Variante.</a></p><h3>CareTeams</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Provider</b></td><td><b>Responsible</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td><a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></td><td>true</td></tr></table><h3>Insurances</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Focal</b></td><td><b>Coverage</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td>true</td><td>GKV-Versicherung</td></tr></table></div>"
      },
      "status" : "active",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/claim-type",
          "code" : "institutional",
          "display" : "Institutional"
        }]
      },
      "use" : "claim",
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "created" : "2024-03-20",
      "provider" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "priority" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/processpriority",
          "code" : "normal"
        }]
      },
      "prescription" : {
        "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
      },
      "careTeam" : [{
        "sequence" : 1,
        "provider" : {
          "reference" : "Organization/mii-exa-test-data-organization-charite"
        },
        "responsible" : true
      }],
      "insurance" : [{
        "sequence" : 1,
        "focal" : true,
        "coverage" : {
          "display" : "GKV-Versicherung"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ClaimResponse/mii-exa-test-data-mtb-antwort-kostenuebernahme-1",
    "resource" : {
      "resourceType" : "ClaimResponse",
      "id" : "mii-exa-test-data-mtb-antwort-kostenuebernahme-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-antwort-kostenuebernahme"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClaimResponse_mii-exa-test-data-mtb-antwort-kostenuebernahme-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClaimResponse mii-exa-test-data-mtb-antwort-kostenuebernahme-1</b></p><a name=\"mii-exa-test-data-mtb-antwort-kostenuebernahme-1\"> </a><a name=\"hcmii-exa-test-data-mtb-antwort-kostenuebernahme-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-pr-mtb-antwort-kostenuebernahme\">MII PR MTB Anwort Kostenuebernahme</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX MTB Antwort Kostenuebernahme Entscheidung</b>: <span title=\"Codes:{https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-antwort-kostenuebernahme-entscheidung accepted}\">Angenommen</span></p><p><b>status</b>: Active</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/claim-type institutional}\">Institutional</span></p><p><b>use</b>: Claim</p><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>created</b>: 2024-04-20</p><p><b>insurer</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></p><p><b>request</b>: <a href=\"Claim-mii-exa-test-data-mtb-antrag-kostenuebernahme-1.html\">Claim: status = active; type = Institutional; use = claim; created = 2024-04-01; priority = Normal</a></p><p><b>outcome</b>: Processing Complete</p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/StructureDefinition/mii-ex-mtb-antwort-kostenuebernahme-entscheidung",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-mtb/CodeSystem/mii-cs-mtb-antwort-kostenuebernahme-entscheidung",
            "code" : "accepted"
          }]
        }
      }],
      "status" : "active",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/claim-type",
          "code" : "institutional",
          "display" : "Institutional"
        }]
      },
      "use" : "claim",
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "created" : "2024-04-20",
      "insurer" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "request" : {
        "reference" : "Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-1"
      },
      "outcome" : "complete"
    },
    "request" : {
      "method" : "PUT",
      "url" : "ClaimResponse/mii-exa-test-data-mtb-antwort-kostenuebernahme-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-labobs-ecog-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-labobs-ecog-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-labobs-ecog-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-labobs-ecog-1</b></p><a name=\"mii-exa-test-data-mtb-labobs-ecog-1\"> </a><a name=\"hcmii-exa-test-data-mtb-labobs-ecog-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 89247-1}\">ECOG Performance Status score</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>value</b>: 1</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "89247-1",
          "display" : "ECOG Performance Status score"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "valueInteger" : 1
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-labobs-ecog-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-mtb-labobs-vorbefund-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-mtb-labobs-vorbefund-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-mtb-labobs-vorbefund-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-mtb-labobs-vorbefund-1</b></p><a name=\"mii-exa-test-data-mtb-labobs-vorbefund-1\"> </a><a name=\"hcmii-exa-test-data-mtb-labobs-vorbefund-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 55233-8}\">Circulating cell-free genomic DNA [Mass/volume] in Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><p><b>value</b>: 15.2 ng/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/mL = 'ng/mL')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "55233-8",
          "display" : "Circulating cell-free genomic DNA [Mass/volume] in Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "valueQuantity" : {
        "value" : 15.2,
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/mL"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-mtb-labobs-vorbefund-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/List/mii-exa-test-data-mtb-evidenz-liste-1",
    "resource" : {
      "resourceType" : "List",
      "id" : "mii-exa-test-data-mtb-evidenz-liste-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-liste-evidenz-erstdiagnose"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_mii-exa-test-data-mtb-evidenz-liste-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List mii-exa-test-data-mtb-evidenz-liste-1</b></p><a name=\"mii-exa-test-data-mtb-evidenz-liste-1\"> </a><a name=\"hcmii-exa-test-data-mtb-evidenz-liste-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-liste-evidenz-erstdiagnose\">MII PR Onkologie Evidenz Diagnose Primärtumor</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2>Liste der Evidenz zum Erstdiagnosezeitpunkt</h2><table class=\"clstu\"><tr><td>Mode: Snapshot List </td><td>Status: Current </td></tr><tr><td>Subject: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-mtb-labobs-vorbefund-1.html\">Observation Circulating cell-free genomic DNA [Mass/volume] in Plasma</a></td></tr></table></div>"
      },
      "status" : "current",
      "mode" : "snapshot",
      "title" : "Liste der Evidenz zum Erstdiagnosezeitpunkt",
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "entry" : [{
        "item" : {
          "reference" : "Observation/mii-exa-test-data-mtb-labobs-vorbefund-1"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "List/mii-exa-test-data-mtb-evidenz-liste-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Specimen/mii-exa-test-data-mtb-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-test-data-mtb-specimen-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_mii-exa-test-data-mtb-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-test-data-mtb-specimen-1</b></p><a name=\"mii-exa-test-data-mtb-specimen-1\"> </a><a name=\"hcmii-exa-test-data-mtb-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0487 TISS}\">Tissue</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-mtb-patient-1.html\">Elena Tumorfall  Female, DoB: 1971-04-12 ( https://www.charite.de/fhir/sid/patientenidentifikation#MTB-TEST-001)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-01-20</td></tr></table></div>"
      },
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0487",
          "code" : "TISS",
          "display" : "Tissue"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "collection" : {
        "collectedDateTime" : "2024-01-20"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-test-data-mtb-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-charite",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-charite",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-charite\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-charite</b></p><a name=\"mii-exa-test-data-organization-charite\"> </a><a name=\"hcmii-exa-test-data-organization-charite\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Charité – Universitätsmedizin Berlin</p></div>"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Charité – Universitätsmedizin Berlin"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-charite"
    }
  }]
}

```
