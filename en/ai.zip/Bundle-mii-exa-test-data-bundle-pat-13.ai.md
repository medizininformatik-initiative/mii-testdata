# mii-exa-test-data-bundle-pat-13 - MII KDS Test Data v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-test-data-bundle-pat-13**

## Example Bundle: mii-exa-test-data-bundle-pat-13



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-test-data-bundle-pat-13",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2024-02-05T12:00:00+01:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-test-data-patient-13",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-test-data-patient-13",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/Patient",
        "http://fhir.de/ConsentManagement/StructureDefinition/Patient"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_mii-exa-test-data-patient-13\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-test-data-patient-13</b></p><a name=\"mii-exa-test-data-patient-13\"> </a><a name=\"hcmii-exa-test-data-patient-13\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/Patient\">MII PR Person Patient</a>, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.consent@2027.0.0-ballot&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Patient\">Consent Management: Patient</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\">Krankenversichertennummer/M456789012 (use: official, )</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">Wiclefstraße 8 Berlin 10551 DE </td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
            "code" : "KVZ10"
          }]
        },
        "system" : "http://fhir.de/sid/gkv/kvid-10",
        "value" : "M456789012",
        "assigner" : {
          "identifier" : {
            "use" : "official",
            "system" : "http://fhir.de/sid/arge-ik/iknr",
            "value" : "109519005"
          }
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/patientenidentifikation",
        "value" : "620447183",
        "assigner" : {
          "identifier" : {
            "type" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "XX"
              }]
            },
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "name" : [{
        "use" : "official",
        "family" : "Kastner",
        "given" : ["Miriam"]
      }],
      "gender" : "female",
      "birthDate" : "1989-06-11",
      "address" : [{
        "type" : "both",
        "line" : ["Wiclefstraße 8"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Wiclefstraße"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "8"
          }]
        }],
        "city" : "Berlin",
        "_city" : {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/destatis/ags",
            "valueCoding" : {
              "system" : "http://fhir.de/sid/destatis/ags",
              "code" : "11000000"
            }
          }]
        },
        "postalCode" : "10551",
        "country" : "DE"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-test-data-patient-13"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-patient-13-encounter-1",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-patient-13-encounter-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-patient-13-encounter-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-patient-13-encounter-1</b></p><a name=\"mii-exa-test-data-patient-13-encounter-1\"> </a><a name=\"hcmii-exa-test-data-patient-13-encounter-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung\">MII PR Fall Kontakt mit einer Gesundheitseinrichtung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Visit number/MII_0000018</p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/Kontaktebene einrichtungskontakt}\">Einrichtungskontakt</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/kontaktart-de ub}\">Untersuchung und Behandlung</span></p><p><b>serviceType</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel 0400}\">Nephrologie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>period</b>: 2023-11-14 10:00:00+0100 --&gt; 2023-11-14 11:30:00+0100</p><p><b>serviceProvider</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Charité - Universitätsmedizin Berlin</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "VN"
          }]
        },
        "system" : "https://www.charite.de/fhir/NamingSystem/Aufnahmenummern",
        "value" : "MII_0000018"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/Kontaktebene",
          "code" : "einrichtungskontakt"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/kontaktart-de",
          "code" : "ub"
        }]
      }],
      "serviceType" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel",
          "code" : "0400"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "period" : {
        "start" : "2023-11-14T10:00:00+01:00",
        "end" : "2023-11-14T11:30:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite",
        "display" : "Charité - Universitätsmedizin Berlin"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-patient-13-encounter-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-patient-13-encounter-2",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-patient-13-encounter-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-patient-13-encounter-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-patient-13-encounter-2</b></p><a name=\"mii-exa-test-data-patient-13-encounter-2\"> </a><a name=\"hcmii-exa-test-data-patient-13-encounter-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung\">MII PR Fall Kontakt mit einer Gesundheitseinrichtung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Visit number/MII_0000019</p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/Kontaktebene einrichtungskontakt}\">Einrichtungskontakt</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/kontaktart-de ub}\">Untersuchung und Behandlung</span></p><p><b>serviceType</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel 3700}\">Sonstige Fachabteilung</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>period</b>: 2023-12-08 09:00:00+0100 --&gt; 2023-12-08 10:45:00+0100</p><p><b>serviceProvider</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Charité - Universitätsmedizin Berlin</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "VN"
          }]
        },
        "system" : "https://www.charite.de/fhir/NamingSystem/Aufnahmenummern",
        "value" : "MII_0000019"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/Kontaktebene",
          "code" : "einrichtungskontakt"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/kontaktart-de",
          "code" : "ub"
        }]
      }],
      "serviceType" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel",
          "code" : "3700"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "period" : {
        "start" : "2023-12-08T09:00:00+01:00",
        "end" : "2023-12-08T10:45:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite",
        "display" : "Charité - Universitätsmedizin Berlin"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-patient-13-encounter-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Encounter/mii-exa-test-data-patient-13-encounter-3",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-test-data-patient-13-encounter-3",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_mii-exa-test-data-patient-13-encounter-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-test-data-patient-13-encounter-3</b></p><a name=\"mii-exa-test-data-patient-13-encounter-3\"> </a><a name=\"hcmii-exa-test-data-patient-13-encounter-3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-fall/StructureDefinition/KontaktGesundheitseinrichtung\">MII PR Fall Kontakt mit einer Gesundheitseinrichtung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Visit number/MII_0000020</p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/Kontaktebene einrichtungskontakt}\">Einrichtungskontakt</span>, <span title=\"Codes:{http://fhir.de/CodeSystem/kontaktart-de ub}\">Untersuchung und Behandlung</span></p><p><b>serviceType</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel 0100}\">Innere Medizin</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>period</b>: 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</p><p><b>serviceProvider</b>: <a href=\"Organization-mii-exa-test-data-organization-charite.html\">Charité - Universitätsmedizin Berlin</a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "VN"
          }]
        },
        "system" : "https://www.charite.de/fhir/NamingSystem/Aufnahmenummern",
        "value" : "MII_0000020"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/Kontaktebene",
          "code" : "einrichtungskontakt"
        }]
      },
      {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/kontaktart-de",
          "code" : "ub"
        }]
      }],
      "serviceType" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel",
          "code" : "0100"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "period" : {
        "start" : "2024-01-15T09:00:00+01:00",
        "end" : "2024-01-15T13:00:00+01:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite",
        "display" : "Charité - Universitätsmedizin Berlin"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Consent/mii-exa-test-data-patient-13-consent-1",
    "resource" : {
      "resourceType" : "Consent",
      "id" : "mii-exa-test-data-patient-13-consent-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-einwilligung"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_mii-exa-test-data-patient-13-consent-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent mii-exa-test-data-patient-13-consent-1</b></p><a name=\"mii-exa-test-data-patient-13-consent-1\"> </a><a name=\"hcmii-exa-test-data-patient-13-consent-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-einwilligung\">Profile - MI-I - Consent - Einwilligung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2>Participants</h2><table class=\"grid\"><tr><td><b>Role</b></td><td><b>Details</b></td></tr><tr><td title=\"Who the consent applies to\">Patient</td><td><a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></td></tr><tr><td title=\"Who manages the consent through its lifecycle.\">Manager</td><td><a href=\"Organization-mii-exa-test-data-organization-charite.html\">Organization Charité – Universitätsmedizin Berlin</a></td></tr></table><p>This consent is made under the regulation <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ActCode OPTIN}\">MII Broad Consent Opt-in</span> and the policy <code>urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791</code> .</p><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: 1px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top;\"><tr style=\"border: 2px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top\"><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Applicable Rule\">Rule</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Applicable Period\">Time Period</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Applicable Data\">What</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Other Applicable Rules\">Rules</a><span style=\"float: right\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Legend for this format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/></a></span></th></tr><tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck1.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: #F7F7F7\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck01.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin_end.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon-qi-hidden.png\" alt=\".\" style=\"background-color: #F7F7F7; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> deny</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2023-11-14 --&gt; 2053-11-13</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck010.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_blank.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2023-11-14 --&gt; 2053-11-13</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Code: <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.6}\">MDAT erheben</span></li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: #F7F7F7\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck010.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_blank.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: #F7F7F7; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2023-11-14 --&gt; 2053-11-13</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Code: <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.7}\">MDAT speichern, verarbeiten</span></li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck000.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_blank.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin_end.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 2023-11-14 --&gt; 2053-11-13</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Code: <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.8}\">MDAT wissenschaftlich nutzen</span></li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr><td colspan=\"4\" class=\"hierarchy\"><br/><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Legend for this format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/> Documentation for this format</a></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "domain",
          "valueReference" : {
            "reference" : "Organization/mii-exa-test-data-organization-charite",
            "display" : "MII Broad Consent Domäne Charité"
          }
        }],
        "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
      }],
      "status" : "active",
      "scope" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
          "code" : "research"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "57016-8"
        }]
      },
      {
        "coding" : [{
          "system" : "https://www.medizininformatik-initiative.de/fhir/modul-consent/CodeSystem/mii-cs-consent-version-modules",
          "code" : "2.16.840.1.113883.3.1937.777.24.2.184"
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-patient-13",
        "identifier" : {
          "system" : "http://fhir.de/sid/gkv/kvid-10",
          "value" : "M456789012"
        }
      },
      "dateTime" : "2023-11-14T10:15:00+01:00",
      "organization" : [{
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      }],
      "policy" : [{
        "uri" : "urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791"
      }],
      "policyRule" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          "code" : "OPTIN",
          "display" : "opt-in"
        }],
        "text" : "MII Broad Consent Opt-in"
      },
      "provision" : {
        "type" : "deny",
        "period" : {
          "start" : "2023-11-14",
          "end" : "2053-11-13"
        },
        "provision" : [{
          "type" : "permit",
          "period" : {
            "start" : "2023-11-14",
            "end" : "2053-11-13"
          },
          "code" : [{
            "coding" : [{
              "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
              "code" : "2.16.840.1.113883.3.1937.777.24.5.3.6",
              "display" : "MDAT erheben"
            }]
          }]
        },
        {
          "type" : "permit",
          "period" : {
            "start" : "2023-11-14",
            "end" : "2053-11-13"
          },
          "code" : [{
            "coding" : [{
              "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
              "code" : "2.16.840.1.113883.3.1937.777.24.5.3.7",
              "display" : "MDAT speichern, verarbeiten"
            }]
          }]
        },
        {
          "type" : "permit",
          "period" : {
            "start" : "2023-11-14",
            "end" : "2053-11-13"
          },
          "code" : [{
            "coding" : [{
              "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
              "code" : "2.16.840.1.113883.3.1937.777.24.5.3.8",
              "display" : "MDAT wissenschaftlich nutzen"
            }]
          }]
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Consent/mii-exa-test-data-patient-13-consent-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ServiceRequest/mii-exa-test-data-patient-13-labrequest-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-test-data-patient-13-labrequest-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ServiceRequestLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_mii-exa-test-data-patient-13-labrequest-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-test-data-patient-13-labrequest-1</b></p><a name=\"mii-exa-test-data-patient-13-labrequest-1\"> </a><a name=\"hcmii-exa-test-data-patient-13-labrequest-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ServiceRequestLab\">MII PR Labor Laboranforderung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Placer Identifier/LA_000013</p><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 2890-2}\">Protein-Kreatinin-Ratio und Serumkreatinin</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Nephrologie; period = 2023-11-14 10:00:00+0100 --&gt; 2023-11-14 11:30:00+0100</a></p><p><b>authoredOn</b>: 2023-11-14 10:20:00+0100</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PLAC"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/Laboranforderungen",
        "value" : "LA_000013",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "status" : "completed",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "2890-2",
          "display" : "Protein/Creatinine [Mass Ratio] in Urine"
        }],
        "text" : "Protein-Kreatinin-Ratio und Serumkreatinin"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-1"
      },
      "authoredOn" : "2023-11-14T10:20:00+01:00",
      "requester" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-test-data-patient-13-labrequest-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/DiagnosticReport/mii-exa-test-data-patient-13-labreport-1",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-test-data-patient-13-labreport-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/DiagnosticReportLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_mii-exa-test-data-patient-13-labreport-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-test-data-patient-13-labreport-1</b></p><a name=\"mii-exa-test-data-patient-13-labreport-1\"> </a><a name=\"hcmii-exa-test-data-patient-13-labreport-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/DiagnosticReportLab\">MII PR Labor Laborbefund</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2><span title=\"Codes:{http://loinc.org 11502-2}\">Laboratory report</span> (<span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 LAB}, {http://loinc.org 26436-6}\">Laboratory studies (set)</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</td></tr><tr><td>Relevant Time</td><td>2023-11-14 10:30:00+0100</td></tr><tr><td>Reported</td><td>2023-11-20 14:00:00+0100</td></tr><tr><td>Performer</td><td> <a href=\"Organization-mii-exa-test-data-organization-labor-berlin.html\">Organization Labor Berlin – Charité Vivantes GmbH</a></td></tr><tr><td>Identifier</td><td> Filler Identifier/LDR_000013</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Reference Range</b></td><td><b>Flags</b></td><td><b>Note</b></td><td><b>Relevant Time</b></td><td><b>Reported</b></td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-13-labobs-protein.html\"><span title=\"Codes:{http://loinc.org 2890-2}\">Protein/Creatinine [Mass Ratio] in Urine</span></a></td><td>780 milligram per gram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/g = 'mg/g')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span>: &lt;150 milligram per gram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/g = 'mg/g')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></td><td><blockquote><div><p>Im Rahmen einer betriebsaerztlichen Untersuchung aufgefallen — der Anlass, der die zwoelfjaehrige diagnostische Odyssee beendet hat.</p>\n</div></blockquote></td><td/><td>2023-11-14 16:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-13-labobs-kreatinin.html\"><span title=\"Codes:{http://loinc.org 2160-0}\">Creatinine [Mass/volume] in Serum or Plasma</span></a></td><td>0.82 milligram per deciliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span>: 0.51 milligram per deciliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span> - 0.95 milligram per deciliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span> for <span title=\"Codes:{http://snomed.info/sct 248152002}\">Female (finding)</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></td><td><blockquote><div><p>Nierenfunktion noch normal — die Proteinurie ist hier das einzige Warnsignal.</p>\n</div></blockquote></td><td/><td>2023-11-14 16:00:00+0100</td></tr><tr><td><a href=\"Observation-mii-exa-test-data-patient-13-labobs-agalsidase.html\"><span title=\"Codes:{http://loinc.org 24049-9}\">Alpha galactosidase A [Enzymatic activity/mass] in Leukocytes</span></a></td><td>12.4 nanomol pro Stunde und Milligramm Protein<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codenmol/h/mg = 'nmol/h/mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span>: 30 nanomol pro Stunde und Milligramm Protein<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codenmol/h/mg = 'nmol/h/mg')</span> - 90 nanomol pro Stunde und Milligramm Protein<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codenmol/h/mg = 'nmol/h/mg')</span></td><td>Final, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation L}\">Low</span></td><td><blockquote><div><p>Bei heterozygoten Frauen kann die Enzymaktivitaet aufgrund der X-Inaktivierung auch normal ausfallen — ein normaler Wert schliesst Morbus Fabry bei Frauen nicht aus. Hier deutlich erniedrigt.</p>\n</div></blockquote></td><td>2023-11-20 09:00:00+0100</td><td/></tr></table><p>Proteinurie 780 mg/g Kreatinin bei normaler Nierenfunktion. Alpha-Galaktosidase-A-Aktivitaet in Leukozyten deutlich erniedrigt — Verdacht auf Morbus Fabry, genetische Abklaerung empfohlen.</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "FILL"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LDR_000013",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-13-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "LAB"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-1"
      },
      "effectiveDateTime" : "2023-11-14T10:30:00+01:00",
      "issued" : "2023-11-20T14:00:00+01:00",
      "performer" : [{
        "reference" : "Organization/mii-exa-test-data-organization-labor-berlin"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-test-data-patient-13-labobs-protein"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-13-labobs-kreatinin"
      },
      {
        "reference" : "Observation/mii-exa-test-data-patient-13-labobs-agalsidase"
      }],
      "conclusion" : "Proteinurie 780 mg/g Kreatinin bei normaler Nierenfunktion. Alpha-Galaktosidase-A-Aktivitaet in Leukozyten deutlich erniedrigt — Verdacht auf Morbus Fabry, genetische Abklaerung empfohlen."
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-test-data-patient-13-labreport-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-labobs-protein",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-labobs-protein",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-labobs-protein\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-labobs-protein</b></p><a name=\"mii-exa-test-data-patient-13-labobs-protein\"> </a><a name=\"hcmii-exa-test-data-patient-13-labobs-protein\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab\">MII PR Labor Laboruntersuchung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/LO_000051</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-13-labrequest-1.html\">ServiceRequest Protein/Creatinine [Mass Ratio] in Urine</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}, {http://loinc.org 26436-6}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 2890-2}\">Protein/Creatinine [Mass Ratio] in Urine</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Nephrologie; period = 2023-11-14 10:00:00+0100 --&gt; 2023-11-14 11:30:00+0100</a></p><p><b>effective</b>: 2023-11-14 10:30:00+0100</p><p><b>issued</b>: 2023-11-14 16:00:00+0100</p><p><b>value</b>: 780 milligram per gram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/g = 'mg/g')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>note</b>: </p><blockquote><div><p>Im Rahmen einer betriebsaerztlichen Untersuchung aufgefallen — der Anlass, der die zwoelfjaehrige diagnostische Odyssee beendet hat.</p>\n</div></blockquote><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>High</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>150 milligram per gram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/g = 'mg/g')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LO_000051",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-13-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "version" : "2.78",
          "code" : "2890-2",
          "display" : "Protein/Creatinine [Mass Ratio] in Urine"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-1"
      },
      "effectiveDateTime" : "2023-11-14T10:30:00+01:00",
      "issued" : "2023-11-14T16:00:00+01:00",
      "valueQuantity" : {
        "value" : 780,
        "unit" : "milligram per gram",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/g"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "note" : [{
        "text" : "Im Rahmen einer betriebsaerztlichen Untersuchung aufgefallen — der Anlass, der die zwoelfjaehrige diagnostische Odyssee beendet hat."
      }],
      "referenceRange" : [{
        "high" : {
          "value" : 150,
          "unit" : "milligram per gram",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/g"
        },
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
            "code" : "normal",
            "display" : "Normal Range"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-labobs-protein"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-labobs-kreatinin",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-labobs-kreatinin",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-labobs-kreatinin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-labobs-kreatinin</b></p><a name=\"mii-exa-test-data-patient-13-labobs-kreatinin\"> </a><a name=\"hcmii-exa-test-data-patient-13-labobs-kreatinin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab\">MII PR Labor Laboruntersuchung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/LO_000052</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-13-labrequest-1.html\">ServiceRequest Protein/Creatinine [Mass Ratio] in Urine</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}, {http://loinc.org 26436-6}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 2160-0}\">Creatinine [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Nephrologie; period = 2023-11-14 10:00:00+0100 --&gt; 2023-11-14 11:30:00+0100</a></p><p><b>effective</b>: 2023-11-14 10:30:00+0100</p><p><b>issued</b>: 2023-11-14 16:00:00+0100</p><p><b>value</b>: 0.82 milligram per deciliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>note</b>: </p><blockquote><div><p>Nierenfunktion noch normal — die Proteinurie ist hier das einzige Warnsignal.</p>\n</div></blockquote><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td><td><b>Type</b></td><td><b>AppliesTo</b></td></tr><tr><td style=\"display: none\">*</td><td>0.51 milligram per deciliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span></td><td>0.95 milligram per deciliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span></td><td><span title=\"Codes:{http://snomed.info/sct 248152002}\">Female (finding)</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LO_000052",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-13-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "version" : "2.78",
          "code" : "2160-0",
          "display" : "Creatinine [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-1"
      },
      "effectiveDateTime" : "2023-11-14T10:30:00+01:00",
      "issued" : "2023-11-14T16:00:00+01:00",
      "valueQuantity" : {
        "value" : 0.82,
        "unit" : "milligram per deciliter",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "note" : [{
        "text" : "Nierenfunktion noch normal — die Proteinurie ist hier das einzige Warnsignal."
      }],
      "referenceRange" : [{
        "low" : {
          "value" : 0.51,
          "unit" : "milligram per deciliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        },
        "high" : {
          "value" : 0.95,
          "unit" : "milligram per deciliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        },
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
            "code" : "normal",
            "display" : "Normal Range"
          }]
        },
        "appliesTo" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "248152002",
            "display" : "Female (finding)"
          }]
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-labobs-kreatinin"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-labobs-agalsidase",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-labobs-agalsidase",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-labobs-agalsidase\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-labobs-agalsidase</b></p><a name=\"mii-exa-test-data-patient-13-labobs-agalsidase\"> </a><a name=\"hcmii-exa-test-data-patient-13-labobs-agalsidase\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab\">MII PR Labor Laboruntersuchung</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Observation Instance Identifier/LO_000053</p><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-test-data-patient-13-labrequest-1.html\">ServiceRequest Protein/Creatinine [Mass Ratio] in Urine</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}, {http://loinc.org 26436-6}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 24049-9}\">Alpha galactosidase A [Enzymatic activity/mass] in Leukocytes</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Nephrologie; period = 2023-11-14 10:00:00+0100 --&gt; 2023-11-14 11:30:00+0100</a></p><p><b>effective</b>: 2023-11-20 09:00:00+0100</p><p><b>issued</b>: 2023-11-20 14:00:00+0100</p><p><b>value</b>: 12.4 nanomol pro Stunde und Milligramm Protein<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codenmol/h/mg = 'nmol/h/mg')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation L}\">Low</span></p><p><b>note</b>: </p><blockquote><div><p>Bei heterozygoten Frauen kann die Enzymaktivitaet aufgrund der X-Inaktivierung auch normal ausfallen — ein normaler Wert schliesst Morbus Fabry bei Frauen nicht aus. Hier deutlich erniedrigt.</p>\n</div></blockquote><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>30 nanomol pro Stunde und Milligramm Protein<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codenmol/h/mg = 'nmol/h/mg')</span></td><td>90 nanomol pro Stunde und Milligramm Protein<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codenmol/h/mg = 'nmol/h/mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/referencerange-meaning normal}\">Normal Range</span></td></tr></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "OBI"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/lab-results",
        "value" : "LO_000053",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          }
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-test-data-patient-13-labrequest-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        },
        {
          "system" : "http://loinc.org",
          "code" : "26436-6",
          "display" : "Laboratory studies (set)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "version" : "2.78",
          "code" : "24049-9",
          "display" : "Alpha galactosidase A [Enzymatic activity/mass] in Leukocytes"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-1"
      },
      "effectiveDateTime" : "2023-11-20T09:00:00+01:00",
      "issued" : "2023-11-20T14:00:00+01:00",
      "valueQuantity" : {
        "value" : 12.4,
        "unit" : "nanomol pro Stunde und Milligramm Protein",
        "system" : "http://unitsofmeasure.org",
        "code" : "nmol/h/mg"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "L",
          "display" : "Low"
        }]
      }],
      "note" : [{
        "text" : "Bei heterozygoten Frauen kann die Enzymaktivitaet aufgrund der X-Inaktivierung auch normal ausfallen — ein normaler Wert schliesst Morbus Fabry bei Frauen nicht aus. Hier deutlich erniedrigt."
      }],
      "referenceRange" : [{
        "low" : {
          "value" : 30,
          "unit" : "nanomol pro Stunde und Milligramm Protein",
          "system" : "http://unitsofmeasure.org",
          "code" : "nmol/h/mg"
        },
        "high" : {
          "value" : 90,
          "unit" : "nanomol pro Stunde und Milligramm Protein",
          "system" : "http://unitsofmeasure.org",
          "code" : "nmol/h/mg"
        },
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/referencerange-meaning",
            "code" : "normal",
            "display" : "Normal Range"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-labobs-agalsidase"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Medication/mii-exa-test-data-medication-agalsidase-beta",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "mii-exa-test-data-medication-agalsidase-beta",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_mii-exa-test-data-medication-agalsidase-beta\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication mii-exa-test-data-medication-agalsidase-beta</b></p><a name=\"mii-exa-test-data-medication-agalsidase-beta\"> </a><a name=\"hcmii-exa-test-data-medication-agalsidase-beta\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication\">MII PR Medikation Medication</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/atc A16AB04}\">Agalsidase beta 35 mg</span></p><p><b>form</b>: <span title=\"Codes:{http://standardterms.edqm.eu 50043000}\">Powder for concentrate for solution for infusion</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 424725004}\">Agalsidase beta</span></td><td>35 milligram<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span>/1 Powder for concentrate for solution for infusion<span style=\"background: LightGoldenRodYellow\"> (Details: standardterms.edqm.eu  code50043000 = 'Powder for concentrate for solution for infusion')</span></td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/atc",
          "version" : "2023",
          "code" : "A16AB04",
          "display" : "Agalsidase beta"
        }],
        "text" : "Agalsidase beta 35 mg"
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "50043000",
          "display" : "Powder for concentrate for solution for infusion"
        }]
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "424725004",
            "display" : "Agalsidase beta (substance)"
          }],
          "text" : "Agalsidase beta"
        },
        "strength" : {
          "numerator" : {
            "value" : 35,
            "unit" : "milligram",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "Powder for concentrate for solution for infusion",
            "system" : "http://standardterms.edqm.eu",
            "code" : "50043000"
          }
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Medication/mii-exa-test-data-medication-agalsidase-beta"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationRequest/mii-exa-test-data-patient-13-medrequest-1",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "mii-exa-test-data-patient-13-medrequest-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_mii-exa-test-data-patient-13-medrequest-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest mii-exa-test-data-patient-13-medrequest-1</b></p><a name=\"mii-exa-test-data-patient-13-medrequest-1\"> </a><a name=\"hcmii-exa-test-data-patient-13-medrequest-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest\">MII PR Medikation MedicationRequest</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/MedicationOrders</code>/MO_0000041</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>medication</b>: <a href=\"Medication-mii-exa-test-data-medication-agalsidase-beta.html\">Medication Agalsidase beta</a></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>authoredOn</b>: 2024-01-15 11:00:00+0100</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-patient-13-seltene-diagnose-genetisch.html\">Condition Fabry's disease</a></p><p><b>note</b>: </p><blockquote><div><p>Erste Infusion am 15.01.2024 unter stationaerer Ueberwachung wegen moeglicher Infusionsreaktionen; danach alle 14 Tage ambulant.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: Once per 14 days</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20045000}\">Intravenous use</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>62 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td></tr></table></blockquote><h3>Substitutions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Allowed[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>false</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/MedicationOrders",
        "value" : "MO_0000041"
      }],
      "status" : "active",
      "intent" : "order",
      "medicationReference" : {
        "reference" : "Medication/mii-exa-test-data-medication-agalsidase-beta"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "authoredOn" : "2024-01-15T11:00:00+01:00",
      "requester" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-patient-13-seltene-diagnose-genetisch"
      }],
      "note" : [{
        "text" : "Erste Infusion am 15.01.2024 unter stationaerer Ueberwachung wegen moeglicher Infusionsreaktionen; danach alle 14 Tage ambulant."
      }],
      "dosageInstruction" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2024-01-15"
            },
            "frequency" : 1,
            "period" : 14,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Intravenous use"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 62,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          }
        }]
      }],
      "substitution" : {
        "allowedBoolean" : false
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationRequest/mii-exa-test-data-patient-13-medrequest-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MedicationAdministration/mii-exa-test-data-patient-13-medadmin-1",
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "mii-exa-test-data-patient-13-medadmin-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationAdministration_mii-exa-test-data-patient-13-medadmin-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationAdministration mii-exa-test-data-patient-13-medadmin-1</b></p><a name=\"mii-exa-test-data-patient-13-medadmin-1\"> </a><a name=\"hcmii-exa-test-data-patient-13-medadmin-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration\">MII PR Medikation MedicationAdministration</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/MedicationAdministrations</code>/MA_0000041</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/medication-admin-category outpatient}\">Outpatient</span></p><p><b>medication</b>: <a href=\"Medication-mii-exa-test-data-medication-agalsidase-beta.html\">Medication Agalsidase beta</a></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>context</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>effective</b>: 2024-01-15 11:30:00+0100 --&gt; 2024-01-15 12:45:00+0100</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></td></tr></table><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-test-data-patient-13-seltene-diagnose-genetisch.html\">Condition Fabry's disease</a></p><p><b>request</b>: <a href=\"MedicationRequest-mii-exa-test-data-patient-13-medrequest-1.html\">MedicationRequest: identifier = https://www.charite.de/fhir/sid/MedicationOrders#MO_0000041; status = active; intent = order; medication[x] = -&gt;Medication Agalsidase beta; authoredOn = 2024-01-15 11:00:00+0100; note = Erste Infusion am 15.01.2024 unter stationaerer Ueberwachung wegen moeglicher Infusionsreaktionen; danach alle 14 Tage ambulant.</a></p><p><b>note</b>: </p><blockquote><div><p>Infusion ueber 75 Minuten mit einschleichender Rate, keine Infusionsreaktion.</p>\n</div></blockquote><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Route</b></td><td><b>Dose</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20045000}\">Intravenous use</span></td><td>62 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/MedicationAdministrations",
        "value" : "MA_0000041"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medication-admin-category",
          "code" : "outpatient"
        }]
      },
      "medicationReference" : {
        "reference" : "Medication/mii-exa-test-data-medication-agalsidase-beta"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "context" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "effectivePeriod" : {
        "start" : "2024-01-15T11:30:00+01:00",
        "end" : "2024-01-15T12:45:00+01:00"
      },
      "performer" : [{
        "actor" : {
          "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
        }
      }],
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-test-data-patient-13-seltene-diagnose-genetisch"
      }],
      "request" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-13-medrequest-1"
      },
      "note" : [{
        "text" : "Infusion ueber 75 Minuten mit einschleichender Rate, keine Infusionsreaktion."
      }],
      "dosage" : {
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Intravenous use"
          }]
        },
        "dose" : {
          "value" : 62,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        }
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "MedicationAdministration/mii-exa-test-data-patient-13-medadmin-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-charite",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-charite",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-charite\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-charite</b></p><a name=\"mii-exa-test-data-organization-charite\"> </a><a name=\"hcmii-exa-test-data-organization-charite\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Charité – Universitätsmedizin Berlin</p></div>"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Charité – Universitätsmedizin Berlin"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-charite"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-test-data-organization-labor-berlin",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-test-data-organization-labor-berlin",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mii-exa-test-data-organization-labor-berlin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-test-data-organization-labor-berlin</b></p><a name=\"mii-exa-test-data-organization-labor-berlin\"> </a><a name=\"hcmii-exa-test-data-organization-labor-berlin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Labor Berlin – Charité Vivantes GmbH</p></div>"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Labor Berlin – Charité Vivantes GmbH"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization/mii-exa-test-data-organization-labor-berlin"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Practitioner/mii-exa-test-data-practitioner-physician-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-test-data-practitioner-physician-1",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_mii-exa-test-data-practitioner-physician-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-test-data-practitioner-physician-1</b></p><a name=\"mii-exa-test-data-practitioner-physician-1\"> </a><a name=\"hcmii-exa-test-data-practitioner-physician-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>active</b>: true</p><p><b>name</b>: Rahel Hirsch </p></div>"
      },
      "active" : true,
      "name" : [{
        "family" : "Hirsch",
        "given" : ["Rahel"]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Practitioner/mii-exa-test-data-practitioner-physician-2",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-test-data-practitioner-physician-2",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_mii-exa-test-data-practitioner-physician-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-test-data-practitioner-physician-2</b></p><a name=\"mii-exa-test-data-practitioner-physician-2\"> </a><a name=\"hcmii-exa-test-data-practitioner-physician-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>active</b>: true</p><p><b>name</b>: Robert Koch (Official)</p></div>"
      },
      "active" : true,
      "name" : [{
        "use" : "official",
        "family" : "Koch",
        "given" : ["Robert"],
        "prefix" : ["Dr."]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-test-data-practitioner-physician-2"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-patient-13-symptom-akroparaesthesie",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-patient-13-symptom-akroparaesthesie",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-condition"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-patient-13-symptom-akroparaesthesie\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-patient-13-symptom-akroparaesthesie</b></p><a name=\"mii-exa-test-data-patient-13-symptom-akroparaesthesie\"> </a><a name=\"hcmii-exa-test-data-patient-13-symptom-akroparaesthesie\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-condition\">MII_PR_Symptom_Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2024-01-15</p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/symptom-condition</code>/SYMP-CON-0013-1</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>severity</b>: <span title=\"Codes:{http://snomed.info/sct 6736007}\">Moderate (severity modifier)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 91019004}, {http://fhir.de/CodeSystem/bfarm/icd-10-gm R20.2}\">Brennende Schmerzen und Missempfindungen an Händen und Füßen, belastungs- und hitzeabhängig</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 66019005}\">Limb structure</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>onset</b>: 2011 --&gt; (ongoing)</p><p><b>recordedDate</b>: 2024-01-15</p><p><b>note</b>: </p><blockquote><div><p>Ueber Jahre als Wachstumsschmerz bzw. funktionelle Beschwerden eingeordnet. Erst 2023 im Zusammenhang mit der Fabry-Diagnose als Akroparaesthesie erkannt.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2024-01-15"
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/symptom-condition",
        "value" : "SYMP-CON-0013-1"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "severity" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6736007",
          "display" : "Moderate (severity modifier)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "91019004",
          "display" : "Paresthesia"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "R20.2",
          "display" : "Parästhesie der Haut"
        }],
        "text" : "Brennende Schmerzen und Missempfindungen an Händen und Füßen, belastungs- und hitzeabhängig"
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "66019005",
          "display" : "Limb structure"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "onsetPeriod" : {
        "start" : "2011",
        "_start" : {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/lebensphase",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "263659003",
                "display" : "Adolescence (qualifier value)"
              }]
            }
          }]
        }
      },
      "recordedDate" : "2024-01-15",
      "note" : [{
        "text" : "Ueber Jahre als Wachstumsschmerz bzw. funktionelle Beschwerden eingeordnet. Erst 2023 im Zusammenhang mit der Fabry-Diagnose als Akroparaesthesie erkannt."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-patient-13-symptom-akroparaesthesie"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-patient-13-symptom-hypohidrose",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-patient-13-symptom-hypohidrose",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-condition"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-patient-13-symptom-hypohidrose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-patient-13-symptom-hypohidrose</b></p><a name=\"mii-exa-test-data-patient-13-symptom-hypohidrose\"> </a><a name=\"hcmii-exa-test-data-patient-13-symptom-hypohidrose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-condition\">MII_PR_Symptom_Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2024-01-15</p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/symptom-condition</code>/SYMP-CON-0013-2</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>severity</b>: <span title=\"Codes:{http://snomed.info/sct 255604002}\">Mild (qualifier value)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 45004005}, {http://fhir.de/CodeSystem/bfarm/icd-10-gm L74.4}\">Vermindertes Schwitzen mit ausgepraegter Hitzeintoleranz</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>onset</b>: 2014 --&gt; (ongoing)</p><p><b>recordedDate</b>: 2024-01-15</p><p><b>note</b>: </p><blockquote><div><p>Nie eigenstaendig aerztlich abgeklaert; von der Patientin selbst als Eigenheit beschrieben. Typisches Fruehsymptom des Morbus Fabry.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2024-01-15"
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/symptom-condition",
        "value" : "SYMP-CON-0013-2"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "severity" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "255604002",
          "display" : "Mild (qualifier value)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "45004005",
          "display" : "Hypohidrosis"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "L74.4",
          "display" : "Anhidrose"
        }],
        "text" : "Vermindertes Schwitzen mit ausgepraegter Hitzeintoleranz"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "onsetPeriod" : {
        "start" : "2014",
        "_start" : {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/lebensphase",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "263659003",
                "display" : "Adolescence (qualifier value)"
              }]
            }
          }]
        }
      },
      "recordedDate" : "2024-01-15",
      "note" : [{
        "text" : "Nie eigenstaendig aerztlich abgeklaert; von der Patientin selbst als Eigenheit beschrieben. Typisches Fruehsymptom des Morbus Fabry."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-patient-13-symptom-hypohidrose"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-patient-13-symptom-abdominal",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-patient-13-symptom-abdominal",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-condition"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-patient-13-symptom-abdominal\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-patient-13-symptom-abdominal</b></p><a name=\"mii-exa-test-data-patient-13-symptom-abdominal\"> </a><a name=\"hcmii-exa-test-data-patient-13-symptom-abdominal\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-condition\">MII_PR_Symptom_Condition</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2024-01-15</p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/symptom-condition</code>/SYMP-CON-0013-3</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>severity</b>: <span title=\"Codes:{http://snomed.info/sct 6736007}\">Moderate (severity modifier)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 21522001}, {http://fhir.de/CodeSystem/bfarm/icd-10-gm R10.4}\">Kolikartige Bauchschmerzen mit Diarrhoe, attackenartig</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 113345001}\">Abdominal structure</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>onset</b>: 2016 --&gt; 2019</p><p><b>recordedDate</b>: 2024-01-15</p><p><b>note</b>: </p><blockquote><div><p>Dreimalige gastroenterologische Abklaerung ohne wegweisenden Befund; als Reizdarmsyndrom gewertet. Retrospektiv Fabry-typische gastrointestinale Beteiligung.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2024-01-15"
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/symptom-condition",
        "value" : "SYMP-CON-0013-3"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "severity" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6736007",
          "display" : "Moderate (severity modifier)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "21522001",
          "display" : "Abdominal pain"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "R10.4",
          "display" : "Sonstige und nicht näher bezeichnete Bauchschmerzen"
        }],
        "text" : "Kolikartige Bauchschmerzen mit Diarrhoe, attackenartig"
      },
      "bodySite" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "113345001",
          "display" : "Abdominal structure"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "onsetPeriod" : {
        "start" : "2016",
        "end" : "2019"
      },
      "recordedDate" : "2024-01-15",
      "note" : [{
        "text" : "Dreimalige gastroenterologische Abklaerung ohne wegweisenden Befund; als Reizdarmsyndrom gewertet. Retrospektiv Fabry-typische gastrointestinale Beteiligung."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-patient-13-symptom-abdominal"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-symptom-obs-schmerz",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-symptom-obs-schmerz",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-observation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-symptom-obs-schmerz\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-symptom-obs-schmerz</b></p><a name=\"mii-exa-test-data-patient-13-symptom-obs-schmerz\"> </a><a name=\"hcmii-exa-test-data-patient-13-symptom-obs-schmerz\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-observation\">MII_PR_Symptom_Observation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Supporting info</b>: <a href=\"Condition-mii-exa-test-data-patient-13-symptom-akroparaesthesie.html\">Condition Paresthesia</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/symptom-observation</code>/SYMP-OBS-0013-1</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 72514-3}\">Pain severity - 0-10 verbal numeric rating [Score] - Reported</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>effective</b>: 2024-01-15</p><p><b>issued</b>: 2024-01-15 09:40:00+0100</p><p><b>value</b>: 7 {score}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{score} = '{score}')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 84100007}\">History taking</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 260864003}\">Frequency (attribute)</span></td><td>Krisenartige Schmerzattacken etwa zweimal monatlich, ausgeloest durch Hitze und koerperliche Belastung</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/workflow-supportingInfo",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-patient-13-symptom-akroparaesthesie"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/symptom-observation",
        "value" : "SYMP-OBS-0013-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "72514-3",
          "display" : "Pain severity - 0-10 verbal numeric rating [Score] - Reported"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "effectiveDateTime" : "2024-01-15",
      "issued" : "2024-01-15T09:40:00+01:00",
      "valueQuantity" : {
        "value" : 7,
        "unit" : "{score}",
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84100007",
          "display" : "History taking"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "260864003",
            "display" : "Frequency (attribute)"
          }]
        },
        "valueString" : "Krisenartige Schmerzattacken etwa zweimal monatlich, ausgeloest durch Hitze und koerperliche Belastung"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-symptom-obs-schmerz"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-symptom-obs-hitzeintoleranz",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-symptom-obs-hitzeintoleranz",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-observation"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-symptom-obs-hitzeintoleranz\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-symptom-obs-hitzeintoleranz</b></p><a name=\"mii-exa-test-data-patient-13-symptom-obs-hitzeintoleranz\"> </a><a name=\"hcmii-exa-test-data-patient-13-symptom-obs-hitzeintoleranz\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-symptom/StructureDefinition/finding-observation\">MII_PR_Symptom_Observation</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Supporting info</b>: <a href=\"Condition-mii-exa-test-data-patient-13-symptom-hypohidrose.html\">Condition Hypohidrosis</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/symptom-observation</code>/SYMP-OBS-0013-2</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 75325-1}\">Symptom</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>effective</b>: 2024-01-15</p><p><b>issued</b>: 2024-01-15 09:45:00+0100</p><p><b>value</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0002046}\">Ausgepraegte Hitzeintoleranz, Meidung von Sport und Sauna</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 84100007}\">History taking</span></p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/workflow-supportingInfo",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-patient-13-symptom-hypohidrose"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/symptom-observation",
        "value" : "SYMP-OBS-0013-2"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "75325-1",
          "display" : "Symptom"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "effectiveDateTime" : "2024-01-15",
      "issued" : "2024-01-15T09:45:00+01:00",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0002046",
          "display" : "Heat intolerance"
        }],
        "text" : "Ausgepraegte Hitzeintoleranz, Meidung von Sport und Sauna"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84100007",
          "display" : "History taking"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-symptom-obs-hitzeintoleranz"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-hpo-akroparaesthesie",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-hpo-akroparaesthesie",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-hpo-akroparaesthesie\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-hpo-akroparaesthesie</b></p><a name=\"mii-exa-test-data-patient-13-hpo-akroparaesthesie\"> </a><a name=\"hcmii-exa-test-data-patient-13-hpo-akroparaesthesie\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment\">MII Profile SE HPO Assessment</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0031006}\">Acroparesthesia</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>effective</b>: 2024-01-15</p><p><b>note</b>: </p><blockquote><div><p>Seit 2011 bestehend, siehe Symptom-Condition SYMP-CON-0013-1.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 84100007}\">History taking</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 260411009}\">Presence findings</span></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0031006",
          "display" : "Acroparesthesia"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "effectiveDateTime" : "2024-01-15",
      "note" : [{
        "text" : "Seit 2011 bestehend, siehe Symptom-Condition SYMP-CON-0013-1."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84100007",
          "display" : "History taking"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "260411009",
            "display" : "Presence findings"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA9633-4",
            "display" : "Present"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-hpo-akroparaesthesie"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-hpo-hypohidrose",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-hpo-hypohidrose",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-hpo-hypohidrose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-hpo-hypohidrose</b></p><a name=\"mii-exa-test-data-patient-13-hpo-hypohidrose\"> </a><a name=\"hcmii-exa-test-data-patient-13-hpo-hypohidrose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment\">MII Profile SE HPO Assessment</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0000966}\">Hypohidrosis</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>effective</b>: 2024-01-15</p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 84100007}\">History taking</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 260411009}\">Presence findings</span></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0000966",
          "display" : "Hypohidrosis"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "effectiveDateTime" : "2024-01-15",
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "84100007",
          "display" : "History taking"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "260411009",
            "display" : "Presence findings"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA9633-4",
            "display" : "Present"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-hpo-hypohidrose"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-hpo-proteinurie",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-hpo-proteinurie",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-hpo-proteinurie\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-hpo-proteinurie</b></p><a name=\"mii-exa-test-data-patient-13-hpo-proteinurie\"> </a><a name=\"hcmii-exa-test-data-patient-13-hpo-proteinurie\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment\">MII Profile SE HPO Assessment</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0000093}\">Proteinuria</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-1.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Nephrologie; period = 2023-11-14 10:00:00+0100 --&gt; 2023-11-14 11:30:00+0100</a></p><p><b>effective</b>: 2023-11-14</p><p><b>note</b>: </p><blockquote><div><p>Protein-Kreatinin-Ratio 780 mg/g im Spontanurin — Anlass der nephrologischen Vorstellung und damit Startpunkt der Diagnosefindung.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 27171005}\">Urinalysis</span></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-test-data-patient-13-labobs-protein.html\">Observation Protein/Creatinine [Mass Ratio] in Urine</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 260411009}\">Presence findings</span></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0000093",
          "display" : "Proteinuria"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-1"
      },
      "effectiveDateTime" : "2023-11-14",
      "note" : [{
        "text" : "Protein-Kreatinin-Ratio 780 mg/g im Spontanurin — Anlass der nephrologischen Vorstellung und damit Startpunkt der Diagnosefindung."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "27171005",
          "display" : "Urinalysis"
        }]
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-test-data-patient-13-labobs-protein"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "260411009",
            "display" : "Presence findings"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA9633-4",
            "display" : "Present"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-hpo-proteinurie"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-hpo-cornea",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-hpo-cornea",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-hpo-cornea\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-hpo-cornea</b></p><a name=\"mii-exa-test-data-patient-13-hpo-cornea\"> </a><a name=\"hcmii-exa-test-data-patient-13-hpo-cornea\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment\">MII Profile SE HPO Assessment</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0007957}\">Corneal opacity</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>effective</b>: 2023-12-04</p><p><b>note</b>: </p><blockquote><div><p>Cornea verticillata beidseits in der augenaerztlichen Spaltlampenuntersuchung — nahezu pathognomonisch fuer Morbus Fabry.</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 28726007}\">Corneal structure</span></p><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 55468007}\">Ocular slit lamp examination</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 260411009}\">Presence findings</span></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0007957",
          "display" : "Corneal opacity"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "effectiveDateTime" : "2023-12-04",
      "note" : [{
        "text" : "Cornea verticillata beidseits in der augenaerztlichen Spaltlampenuntersuchung — nahezu pathognomonisch fuer Morbus Fabry."
      }],
      "bodySite" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "28726007",
          "display" : "Corneal structure"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "55468007",
          "display" : "Ocular slit lamp examination"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "260411009",
            "display" : "Presence findings"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA9633-4",
            "display" : "Present"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-hpo-cornea"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-hpo-angiokeratom",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-hpo-angiokeratom",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-hpo-angiokeratom\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-hpo-angiokeratom</b></p><a name=\"mii-exa-test-data-patient-13-hpo-angiokeratom\"> </a><a name=\"hcmii-exa-test-data-patient-13-hpo-angiokeratom\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment\">MII Profile SE HPO Assessment</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0001014}\">Angiokeratoma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>effective</b>: 2024-01-15</p><p><b>note</b>: </p><blockquote><div><p>Keine Angiokeratome nachweisbar — bei heterozygoten Frauen haeufig fehlend. Der dokumentierte AUSSCHLUSS ist hier informativ, nicht das Fehlen der Ressource.</p>\n</div></blockquote><p><b>method</b>: <span title=\"Codes:{http://snomed.info/sct 5880005}\">Physical examination procedure</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 260411009}\">Presence findings</span></td><td><span title=\"Codes:{http://loinc.org LA9634-2}\">Absent</span></td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0001014",
          "display" : "Angiokeratoma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "effectiveDateTime" : "2024-01-15",
      "note" : [{
        "text" : "Keine Angiokeratome nachweisbar — bei heterozygoten Frauen haeufig fehlend. Der dokumentierte AUSSCHLUSS ist hier informativ, nicht das Fehlen der Ressource."
      }],
      "method" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "5880005",
          "display" : "Physical examination procedure"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "260411009",
            "display" : "Presence findings"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA9634-2",
            "display" : "Absent"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-hpo-angiokeratom"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-patient-13-seltene-diagnose-klinisch",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-patient-13-seltene-diagnose-klinisch",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-patient-13-seltene-diagnose-klinisch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-patient-13-seltene-diagnose-klinisch</b></p><a name=\"mii-exa-test-data-patient-13-seltene-diagnose-klinisch\"> </a><a name=\"hcmii-exa-test-data-patient-13-seltene-diagnose-klinisch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis\">MII PR SE Clinical Diagnosis</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2023-12-08</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category encounter-diagnosis}\">Encounter Diagnosis</span></p><p><b>severity</b>: <span title=\"Codes:{http://snomed.info/sct 6736007}\">Moderate (severity modifier)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 16652001}, {http://www.orpha.net 324}, {http://fhir.de/CodeSystem/bfarm/icd-10-gm E75.2}\">Morbus Fabry (Alpha-Galaktosidase-A-Mangel), heterozygot</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Sonstige Fachabteilung; period = 2023-12-08 09:00:00+0100 --&gt; 2023-12-08 10:45:00+0100</a></p><p><b>onset</b>: 22 years<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></p><p><b>recordedDate</b>: 2023-12-08</p><p><b>recorder</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>asserter</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-2.html\">Practitioner Robert Koch (official)</a></p><blockquote><p><b>evidence</b></p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0031006}\">Acroparesthesia</span></p><p><b>detail</b>: <a href=\"Observation-mii-exa-test-data-patient-13-hpo-akroparaesthesie.html\">Observation Acroparesthesia</a></p></blockquote><blockquote><p><b>evidence</b></p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0000966}\">Hypohidrosis</span></p><p><b>detail</b>: <a href=\"Observation-mii-exa-test-data-patient-13-hpo-hypohidrose.html\">Observation Hypohidrosis</a></p></blockquote><blockquote><p><b>evidence</b></p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0000093}\">Proteinuria</span></p><p><b>detail</b>: <a href=\"Observation-mii-exa-test-data-patient-13-hpo-proteinurie.html\">Observation Proteinuria</a></p></blockquote><blockquote><p><b>evidence</b></p><p><b>code</b>: <span title=\"Codes:{http://human-phenotype-ontology.org HP:0007957}\">Corneal opacity</span></p><p><b>detail</b>: <a href=\"Observation-mii-exa-test-data-patient-13-hpo-cornea.html\">Observation Corneal opacity</a></p></blockquote><p><b>note</b>: </p><blockquote><div><p>Diagnostische Latenz 12 Jahre (Erstsymptom 2011, Diagnose 2023-12-08). Ausloeser der Abklaerung war die Proteinurie, nicht die seit der Jugend bestehenden Schmerzattacken.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2023-12-08"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      }],
      "severity" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6736007",
          "display" : "Moderate (severity modifier)"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16652001",
          "display" : "Fabry's disease"
        },
        {
          "system" : "http://www.orpha.net",
          "code" : "324",
          "display" : "Fabry disease"
        },
        {
          "extension" : [{
            "url" : "http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit",
            "valueCoding" : {
              "system" : "https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_DIAGNOSESICHERHEIT",
              "code" : "G",
              "display" : "gesicherte Diagnose"
            }
          }],
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "E75.2",
          "display" : "Sonstige Sphingolipidosen"
        }],
        "text" : "Morbus Fabry (Alpha-Galaktosidase-A-Mangel), heterozygot"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-2"
      },
      "onsetAge" : {
        "value" : 22,
        "unit" : "years",
        "system" : "http://unitsofmeasure.org",
        "code" : "a"
      },
      "recordedDate" : "2023-12-08",
      "recorder" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "asserter" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-2"
      },
      "evidence" : [{
        "code" : [{
          "coding" : [{
            "system" : "http://human-phenotype-ontology.org",
            "code" : "HP:0031006",
            "display" : "Acroparesthesia"
          }]
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-test-data-patient-13-hpo-akroparaesthesie"
        }]
      },
      {
        "code" : [{
          "coding" : [{
            "system" : "http://human-phenotype-ontology.org",
            "code" : "HP:0000966",
            "display" : "Hypohidrosis"
          }]
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-test-data-patient-13-hpo-hypohidrose"
        }]
      },
      {
        "code" : [{
          "coding" : [{
            "system" : "http://human-phenotype-ontology.org",
            "code" : "HP:0000093",
            "display" : "Proteinuria"
          }]
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-test-data-patient-13-hpo-proteinurie"
        }]
      },
      {
        "code" : [{
          "coding" : [{
            "system" : "http://human-phenotype-ontology.org",
            "code" : "HP:0007957",
            "display" : "Corneal opacity"
          }]
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-test-data-patient-13-hpo-cornea"
        }]
      }],
      "note" : [{
        "text" : "Diagnostische Latenz 12 Jahre (Erstsymptom 2011, Diagnose 2023-12-08). Ausloeser der Abklaerung war die Proteinurie, nicht die seit der Jugend bestehenden Schmerzattacken."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-patient-13-seltene-diagnose-klinisch"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Condition/mii-exa-test-data-patient-13-seltene-diagnose-genetisch",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-test-data-patient-13-seltene-diagnose-genetisch",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_mii-exa-test-data-patient-13-seltene-diagnose-genetisch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-test-data-patient-13-seltene-diagnose-genetisch</b></p><a name=\"mii-exa-test-data-patient-13-seltene-diagnose-genetisch\"> </a><a name=\"hcmii-exa-test-data-patient-13-seltene-diagnose-genetisch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis\">MII PR SE Genetic Diagnosis</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>Condition Asserted Date</b>: 2023-12-08</p><p><b>Condition Related</b>: <a href=\"Condition-mii-exa-test-data-patient-13-seltene-diagnose-klinisch.html\">Condition Fabry's disease</a></p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 782964007}\">Genetic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 16652001}, {http://www.orpha.net 324}, {http://fhir.de/CodeSystem/bfarm/icd-10-gm E75.2}\">Morbus Fabry, molekulargenetisch gesichert (GLA, heterozygot)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Sonstige Fachabteilung; period = 2023-12-08 09:00:00+0100 --&gt; 2023-12-08 10:45:00+0100</a></p><p><b>recordedDate</b>: 2023-12-08</p><p><b>recorder</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-2.html\">Practitioner Robert Koch (official)</a></p><h3>Evidences</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Detail</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 106221001}\">Heterozygote pathogene Variante im GLA-Gen (Sanger-Sequenzierung)</span></td><td><a href=\"Observation-mii-exa-test-data-patient-13-molgen-variante.html\">Observation Genetic variant assessment</a></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Sanger-Sequenzierung des GLA-Gens: heterozygote pathogene Variante. X-chromosomaler Erbgang, daher Kaskadenscreening der Familie eingeleitet.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2023-12-08"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-related",
        "valueReference" : {
          "reference" : "Condition/mii-exa-test-data-patient-13-seltene-diagnose-klinisch"
        }
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "782964007",
          "display" : "Genetic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "16652001",
          "display" : "Fabry's disease"
        },
        {
          "system" : "http://www.orpha.net",
          "code" : "324",
          "display" : "Fabry disease"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "E75.2",
          "display" : "Sonstige Sphingolipidosen"
        }],
        "text" : "Morbus Fabry, molekulargenetisch gesichert (GLA, heterozygot)"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-2"
      },
      "recordedDate" : "2023-12-08",
      "recorder" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-2"
      },
      "evidence" : [{
        "code" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "106221001",
            "display" : "Genetic finding"
          }],
          "text" : "Heterozygote pathogene Variante im GLA-Gen (Sanger-Sequenzierung)"
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-test-data-patient-13-molgen-variante"
        }]
      }],
      "note" : [{
        "text" : "Sanger-Sequenzierung des GLA-Gens: heterozygote pathogene Variante. X-chromosomaler Erbgang, daher Kaskadenscreening der Familie eingeleitet."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Condition/mii-exa-test-data-patient-13-seltene-diagnose-genetisch"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Observation/mii-exa-test-data-patient-13-molgen-variante",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-test-data-patient-13-molgen-variante",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_mii-exa-test-data-patient-13-molgen-variante\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-test-data-patient-13-molgen-variante</b></p><a name=\"mii-exa-test-data-patient-13-molgen-variante\"> </a><a name=\"hcmii-exa-test-data-patient-13-molgen-variante\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-2.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Sonstige Fachabteilung; period = 2023-12-08 09:00:00+0100 --&gt; 2023-12-08 10:45:00+0100</a></p><p><b>effective</b>: 2023-12-04</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6576-8}\">Positive</span></p><p><b>note</b>: </p><blockquote><div><p>Sanger-Sequenzierung aller kodierenden Exons des GLA-Gens; heterozygote pathogene Variante nachgewiesen. Befund durch die Humangenetik freigegeben am 2023-12-08.</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:4296}\">GLA</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 53037-8}\">Genetic variation clinical significance [Imp]</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6668-3}\">Pathogenic</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-2"
      },
      "effectiveDateTime" : "2023-12-04",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        }]
      },
      "note" : [{
        "text" : "Sanger-Sequenzierung aller kodierenden Exons des GLA-Gens; heterozygote pathogene Variante nachgewiesen. Befund durch die Humangenetik freigegeben am 2023-12-08."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:4296",
            "display" : "GLA"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "53037-8",
            "display" : "Genetic variation clinical significance [Imp]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6668-3",
            "display" : "Pathogenic"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-test-data-patient-13-molgen-variante"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/FamilyMemberHistory/mii-exa-test-data-patient-13-familienanamnese-mutter",
    "resource" : {
      "resourceType" : "FamilyMemberHistory",
      "id" : "mii-exa-test-data-patient-13-familienanamnese-mutter",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"FamilyMemberHistory_mii-exa-test-data-patient-13-familienanamnese-mutter\"> </a><p class=\"res-header-id\"><b>Generated Narrative: FamilyMemberHistory mii-exa-test-data-patient-13-familienanamnese-mutter</b></p><a name=\"mii-exa-test-data-patient-13-familienanamnese-mutter\"> </a><a name=\"hcmii-exa-test-data-patient-13-familienanamnese-mutter\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese\">MII PR SE Familienanamnese</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX SE Von SE betroffen</b>: <span title=\"Codes:{http://snomed.info/sct 373066001}\">Yes</span></p><p><b>status</b>: Completed</p><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>date</b>: 2024-01-15</p><p><b>relationship</b>: <span title=\"Codes:{http://snomed.info/sct 65656005}\">Natural mother</span></p><p><b>sex</b>: <span title=\"Codes:{http://hl7.org/fhir/administrative-gender female}\">Female</span></p><p><b>born</b>: 1962</p><p><b>deceased</b>: false</p><p><b>note</b>: </p><blockquote><div><p>Nach der Diagnose der Indexpatientin im Kaskadenscreening ebenfalls als Traegerin identifiziert; klinisch bislang oligosymptomatisch.</p>\n</div></blockquote><h3>Conditions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>ContributedToDeath</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm E75.2}, {http://www.orpha.net 324}\">Sonstige Sphingolipidosen</span></td><td>false</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-von-se-betroffen",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "373066001",
            "display" : "Yes"
          }]
        }
      }],
      "status" : "completed",
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "date" : "2024-01-15",
      "relationship" : {
        "coding" : [{
          "extension" : [{
            "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mii-ex-molgen-verwandtschaftsgrad",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "125678001",
              "display" : "First degree blood relative (person)"
            }
          },
          {
            "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mii-ex-molgen-familiare-linie",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "72705000",
              "display" : "Mother (person)"
            }
          }],
          "system" : "http://snomed.info/sct",
          "code" : "65656005",
          "display" : "Natural mother"
        }]
      },
      "sex" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/administrative-gender",
          "code" : "female"
        }]
      },
      "bornDate" : "1962",
      "deceasedBoolean" : false,
      "note" : [{
        "text" : "Nach der Diagnose der Indexpatientin im Kaskadenscreening ebenfalls als Traegerin identifiziert; klinisch bislang oligosymptomatisch."
      }],
      "condition" : [{
        "code" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
            "version" : "2024",
            "code" : "E75.2",
            "display" : "Sonstige Sphingolipidosen"
          },
          {
            "system" : "http://www.orpha.net",
            "code" : "324",
            "display" : "Fabry disease"
          }]
        },
        "contributedToDeath" : false
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "FamilyMemberHistory/mii-exa-test-data-patient-13-familienanamnese-mutter"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/FamilyMemberHistory/mii-exa-test-data-patient-13-familienanamnese-onkel",
    "resource" : {
      "resourceType" : "FamilyMemberHistory",
      "id" : "mii-exa-test-data-patient-13-familienanamnese-onkel",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"FamilyMemberHistory_mii-exa-test-data-patient-13-familienanamnese-onkel\"> </a><p class=\"res-header-id\"><b>Generated Narrative: FamilyMemberHistory mii-exa-test-data-patient-13-familienanamnese-onkel</b></p><a name=\"mii-exa-test-data-patient-13-familienanamnese-onkel\"> </a><a name=\"hcmii-exa-test-data-patient-13-familienanamnese-onkel\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese\">MII PR SE Familienanamnese</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX SE Von SE betroffen</b>: <span title=\"Codes:{http://snomed.info/sct 373068000}\">Undetermined</span></p><p><b>status</b>: Completed</p><p><b>patient</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>date</b>: 2024-01-15</p><p><b>relationship</b>: <span title=\"Codes:{http://snomed.info/sct 38048003}\">Uncle</span></p><p><b>sex</b>: <span title=\"Codes:{http://hl7.org/fhir/administrative-gender male}\">Male</span></p><p><b>deceased</b>: 48 years<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></p><p><b>note</b>: </p><blockquote><div><p>Dialysepflichtige Niereninsuffizienz unklarer Genese, verstorben 2004. Keine genetische Abklaerung zu Lebzeiten — retrospektiv mit hoher Wahrscheinlichkeit Morbus Fabry.</p>\n</div></blockquote><h3>Conditions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>ContributedToDeath</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm N18.5}\">Chronische Nierenkrankheit, Stadium 5</span></td><td>true</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-von-se-betroffen",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "373068000",
            "display" : "Undetermined"
          }]
        }
      }],
      "status" : "completed",
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "date" : "2024-01-15",
      "relationship" : {
        "coding" : [{
          "extension" : [{
            "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mii-ex-molgen-verwandtschaftsgrad",
            "valueCoding" : {
              "system" : "http://snomed.info/sct",
              "code" : "699110007",
              "display" : "Second degree blood relative (person)"
            }
          }],
          "system" : "http://snomed.info/sct",
          "code" : "38048003",
          "display" : "Uncle"
        }]
      },
      "sex" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/administrative-gender",
          "code" : "male"
        }]
      },
      "deceasedAge" : {
        "value" : 48,
        "unit" : "years",
        "system" : "http://unitsofmeasure.org",
        "code" : "a"
      },
      "note" : [{
        "text" : "Dialysepflichtige Niereninsuffizienz unklarer Genese, verstorben 2004. Keine genetische Abklaerung zu Lebzeiten — retrospektiv mit hoher Wahrscheinlichkeit Morbus Fabry."
      }],
      "condition" : [{
        "code" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
            "version" : "2024",
            "code" : "N18.5",
            "display" : "Chronische Nierenkrankheit, Stadium 5"
          }]
        },
        "contributedToDeath" : true
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "FamilyMemberHistory/mii-exa-test-data-patient-13-familienanamnese-onkel"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/CarePlan/mii-exa-test-data-patient-13-seltene-therapieplan",
    "resource" : {
      "resourceType" : "CarePlan",
      "id" : "mii-exa-test-data-patient-13-seltene-therapieplan",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieplan"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_mii-exa-test-data-patient-13-seltene-therapieplan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: CarePlan mii-exa-test-data-patient-13-seltene-therapieplan</b></p><a name=\"mii-exa-test-data-patient-13-seltene-therapieplan\"> </a><a name=\"hcmii-exa-test-data-patient-13-seltene-therapieplan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieplan\">MII PR SE Therapieplan</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>subject</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-test-data-patient-13-encounter-3.html\">Encounter: identifier = Visit number; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Innere Medizin; period = 2024-01-15 09:00:00+0100 --&gt; 2024-01-15 13:00:00+0100</a></p><p><b>period</b>: 2024-01-15 --&gt; (ongoing)</p><p><b>created</b>: 2024-01-15</p><p><b>author</b>: <a href=\"Practitioner-mii-exa-test-data-practitioner-physician-1.html\">Practitioner Rahel Hirsch </a></p><p><b>addresses</b>: <a href=\"Condition-mii-exa-test-data-patient-13-seltene-diagnose-klinisch.html\">Condition Fabry's disease</a></p><h3>Activities</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"MedicationRequest-mii-exa-test-data-patient-13-medrequest-1.html\">MedicationRequest: identifier = https://www.charite.de/fhir/sid/MedicationOrders#MO_0000041; status = active; intent = order; medication[x] = -&gt;Medication Agalsidase beta; authoredOn = 2024-01-15 11:00:00+0100; note = Erste Infusion am 15.01.2024 unter stationaerer Ueberwachung wegen moeglicher Infusionsreaktionen; danach alle 14 Tage ambulant.</a></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Enzymersatztherapie mit Agalsidase beta alle zwei Wochen; nephrologische Verlaufskontrolle vierteljaehrlich; kardiologisches und neurologisches Screening jaehrlich.</p>\n</div></blockquote></div>"
      },
      "status" : "active",
      "intent" : "plan",
      "subject" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-test-data-patient-13-encounter-3"
      },
      "period" : {
        "start" : "2024-01-15"
      },
      "created" : "2024-01-15",
      "author" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "addresses" : [{
        "reference" : "Condition/mii-exa-test-data-patient-13-seltene-diagnose-klinisch"
      }],
      "activity" : [{
        "reference" : {
          "reference" : "MedicationRequest/mii-exa-test-data-patient-13-medrequest-1"
        }
      }],
      "note" : [{
        "text" : "Enzymersatztherapie mit Agalsidase beta alle zwei Wochen; nephrologische Verlaufskontrolle vierteljaehrlich; kardiologisches und neurologisches Screening jaehrlich."
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "CarePlan/mii-exa-test-data-patient-13-seltene-therapieplan"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ResearchSubject/mii-exa-test-data-patient-13-registerteilnahme",
    "resource" : {
      "resourceType" : "ResearchSubject",
      "id" : "mii-exa-test-data-patient-13-registerteilnahme",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-registerteilnahme"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ResearchSubject_mii-exa-test-data-patient-13-registerteilnahme\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchSubject mii-exa-test-data-patient-13-registerteilnahme</b></p><a name=\"mii-exa-test-data-patient-13-registerteilnahme\"> </a><a name=\"hcmii-exa-test-data-patient-13-registerteilnahme\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-registerteilnahme\">MII PR SE Registerteilnahme</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>MII EX SE Register</b>: <a href=\"Library-mii-exa-test-data-patient-13-register-katalog.html\">Fabry-Register Deutschland - Katalogeintrag</a></p><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/fabry-register-proband</code>/FR-DE-004217</p><p><b>status</b>: On-study</p><p><b>period</b>: 2024-02-05 --&gt; (ongoing)</p><p><b>study</b>: <a href=\"ResearchStudy-mii-exa-test-data-patient-13-register-study.html\">ResearchStudy Fabry-Register Deutschland</a></p><p><b>individual</b>: <a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></p><p><b>consent</b>: <a href=\"Consent-mii-exa-test-data-patient-13-register-consent.html\">mii-exa-test-data-patient-13-register-consent</a></p></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-register",
        "valueReference" : {
          "reference" : "Library/mii-exa-test-data-patient-13-register-katalog"
        }
      }],
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/fabry-register-proband",
        "value" : "FR-DE-004217"
      }],
      "status" : "on-study",
      "period" : {
        "start" : "2024-02-05"
      },
      "study" : {
        "reference" : "ResearchStudy/mii-exa-test-data-patient-13-register-study"
      },
      "individual" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "consent" : {
        "reference" : "Consent/mii-exa-test-data-patient-13-register-consent"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "ResearchSubject/mii-exa-test-data-patient-13-registerteilnahme"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Library/mii-exa-test-data-patient-13-register-katalog",
    "resource" : {
      "resourceType" : "Library",
      "id" : "mii-exa-test-data-patient-13-register-katalog",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Library_mii-exa-test-data-patient-13-register-katalog\"> </a><p><b style=\"color: maroon\">Exception parsing generated Narrative (see /tmp/liquid-0eabc921-30f4-4740-abd3-18277625ef27.html): unexpected non-end of element null::a  at line 110 column 50</b></p></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/fabry-register",
        "value" : "FABRY-REG-DE"
      }],
      "name" : "FabryRegistryDE",
      "title" : "Fabry-Register Deutschland - Katalogeintrag",
      "status" : "active",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/library-type",
          "code" : "asset-collection"
        }]
      },
      "relatedArtifact" : [{
        "type" : "documentation",
        "url" : "https://www.se-atlas.de/",
        "document" : {
          "url" : "https://www.se-atlas.de/"
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Library/mii-exa-test-data-patient-13-register-katalog"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ResearchStudy/mii-exa-test-data-patient-13-register-study",
    "resource" : {
      "resourceType" : "ResearchStudy",
      "id" : "mii-exa-test-data-patient-13-register-study",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ResearchStudy_mii-exa-test-data-patient-13-register-study\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchStudy mii-exa-test-data-patient-13-register-study</b></p><a name=\"mii-exa-test-data-patient-13-register-study\"> </a><a name=\"hcmii-exa-test-data-patient-13-register-study\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/sid/fabry-register</code>/FABRY-REG-DE</p><p><b>title</b>: Fabry-Register Deutschland</p><p><b>status</b>: Active</p><p><b>description</b>: </p><div><p>Krankheitsspezifisches Register zur Verlaufsbeobachtung von Patientinnen und Patienten mit Morbus Fabry unter Enzymersatztherapie.</p>\n</div></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/sid/fabry-register",
        "value" : "FABRY-REG-DE"
      }],
      "title" : "Fabry-Register Deutschland",
      "status" : "active",
      "description" : "Krankheitsspezifisches Register zur Verlaufsbeobachtung von Patientinnen und Patienten mit Morbus Fabry unter Enzymersatztherapie."
    },
    "request" : {
      "method" : "PUT",
      "url" : "ResearchStudy/mii-exa-test-data-patient-13-register-study"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Consent/mii-exa-test-data-patient-13-register-consent",
    "resource" : {
      "resourceType" : "Consent",
      "id" : "mii-exa-test-data-patient-13-register-consent",
      "meta" : {
        "source" : "https://www.charite.de/fhir/kds-testdata",
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_mii-exa-test-data-patient-13-register-consent\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent mii-exa-test-data-patient-13-register-consent</b></p><a name=\"mii-exa-test-data-patient-13-register-consent\"> </a><a name=\"hcmii-exa-test-data-patient-13-register-consent\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Information Source: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&amp;canonical=https://www.charite.de/fhir/kds-testdata\">https://www.charite.de/fhir/kds-testdata</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2>Participants</h2><table class=\"grid\"><tr><td><b>Role</b></td><td><b>Details</b></td></tr><tr><td title=\"Who the consent applies to\">Patient</td><td><a href=\"Patient-mii-exa-test-data-patient-13.html\">Miriam Kastner (official) Female, DoB: 1989-06-11 ( Medical record number)</a></td></tr></table><p>This consent is made under the regulation <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentpolicycodes cric}\">Common Rule Informed Consent</span> .</p><p>The subject has given their consent.</p></div>"
      },
      "status" : "active",
      "scope" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
          "code" : "research"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/consentcategorycodes",
          "code" : "research"
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-test-data-patient-13"
      },
      "dateTime" : "2024-02-05",
      "policyRule" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/consentpolicycodes",
          "code" : "cric"
        }]
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Consent/mii-exa-test-data-patient-13-register-consent"
    }
  }]
}

```
