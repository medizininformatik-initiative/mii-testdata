# Resource MII KDS Test Data



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "mii-kds-testdata",
  "language" : "en",
  "url" : "https://www.medizininformatik-initiative.de/fhir/testdata/ImplementationGuide/mii-kds-testdata",
  "version" : "2027.0.0-ballot",
  "name" : "MIIKDSTestData",
  "title" : "MII KDS Test Data",
  "status" : "draft",
  "date" : "2026-09-25T07:02:09+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "This project contains example MII KDS data for testing purposes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Deutschland"
    }]
  }],
  "packageId" : "mii-kds-testdata",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_complete",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/core/complete/ImplementationGuide/de.medizininformatikinitiative.kerndatensatz.complete",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.complete",
    "version" : "2027.0.0-ballot.19"
  },
  {
    "id" : "hl7_fhir_uv_sdc",
    "uri" : "http://hl7.org/fhir/uv/sdc/ImplementationGuide/hl7.fhir.uv.sdc",
    "packageId" : "hl7.fhir.uv.sdc",
    "version" : "4.0.0"
  },
  {
    "id" : "hl7_fhir_uv_xver_r5_r4",
    "uri" : "http://hl7.org/fhir/uv/xver/ImplementationGuide/hl7.fhir.uv.xver-r5.r4",
    "packageId" : "hl7.fhir.uv.xver-r5.r4",
    "version" : "0.1.0"
  },
  {
    "id" : "de_einwilligungsmanagement",
    "uri" : "http://fhir.org/packages/de.einwilligungsmanagement/ImplementationGuide/de.einwilligungsmanagement",
    "packageId" : "de.einwilligungsmanagement",
    "version" : "2.0.4"
  },
  {
    "id" : "de_gematik_isik",
    "uri" : "http://fhir.org/packages/de.gematik.isik/ImplementationGuide/de.gematik.isik",
    "packageId" : "de.gematik.isik",
    "version" : "6.0.0"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2019+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludexml"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/testdata/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-xml"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-xml-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2019+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludexml"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/testdata/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-xml"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-xml-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macroscopic-cylinder-count-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macroscopic-cylinder-count-01"
      },
      "name" : "Anzahl Zylinder Stanze 01",
      "description" : "Anzahl der Stanzzylinder in Specimen 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macroscopic-cylinder-count-03.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macroscopic-cylinder-count-03"
      },
      "name" : "Anzahl Zylinder Stanze 03",
      "description" : "Anzahl der Stanzzylinder in Specimen 03",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-asap.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-asap"
      },
      "name" : "Atypical Small Acinar Proliferation (ASAP) - Biopsy",
      "description" : "Presence of atypical small acinar proliferation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-1-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-1-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-5-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-5-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-6-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-6-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-9-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-9-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-10-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-10-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-2-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-2-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-3-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-3-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-4-list-aufnahmemedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-4-list-aufnahmemedikation"
      },
      "name" : "Aufnahmemedikation",
      "description" : "List: Aufnahmemedikation für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-patho-befund-bundle-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-patho-befund-bundle-1"
      },
      "name" : "Befunddokument Prostatabiopsie",
      "description" : "Dokument-Bundle: vollstaendiger Prostatabiopsie-Befundbericht (2 Stanzen) nach mii-pr-patho-bundle",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ResearchStudy"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ResearchStudy-mii-exa-test-data-studien-studie-1.html"
      }],
      "reference" : {
        "reference" : "ResearchStudy/mii-exa-test-data-studien-studie-1"
      },
      "name" : "Biomarker-basierte Verlaufsprognose endokriner Erkrankungen",
      "description" : "ResearchStudy: MII-BIOMARKER-2024 - Biomarker bei endokrinen Erkrankungen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-conclusion-grouper-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-conclusion-grouper-1"
      },
      "name" : "Diagnostic Conclusion Grouper - Biopsy",
      "description" : "Grouper for all diagnostic conclusion findings in biopsy specimens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-conclusion-grouper-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-conclusion-grouper-dar-1"
      },
      "name" : "Diagnostic Conclusion Grouper - Gesamttumorlaenge nicht ermittelbar",
      "description" : "Conclusion-Grouper mit Komponente ohne Wert: Gesamttumorlaenge wegen fragmentierter Stanze nicht ermittelbar (component.dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Library"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Library-mii-exa-test-data-studien-register-1.html"
      }],
      "reference" : {
        "reference" : "Library/mii-exa-test-data-studien-register-1"
      },
      "name" : "DRKS - Deutsches Register Klinischer Studien",
      "description" : "Library: DRKS - Deutsches Register Klinischer Studien",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-6-list-entlassmedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-6-list-entlassmedikation"
      },
      "name" : "Entlassmedikation",
      "description" : "List: Entlassmedikation für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-7-list-entlassmedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-7-list-entlassmedikation"
      },
      "name" : "Entlassmedikation",
      "description" : "List: Entlassmedikation für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-9-list-entlassmedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-9-list-entlassmedikation"
      },
      "name" : "Entlassmedikation",
      "description" : "List: Entlassmedikation für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-10-list-entlassmedikation.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-10-list-entlassmedikation"
      },
      "name" : "Entlassmedikation",
      "description" : "List: Entlassmedikation für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BodyStructure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BodyStructure-mii-exa-test-data-patho-body-structure-1.html"
      }],
      "reference" : {
        "reference" : "BodyStructure/mii-exa-test-data-patho-body-structure-1"
      },
      "name" : "Entnahmestelle Prostatastanze 01",
      "description" : "BodyStructure: rechte basale periphere Zone der Prostata",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Library"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Library-mii-exa-test-data-seltene-register-katalog-1.html"
      }],
      "reference" : {
        "reference" : "Library/mii-exa-test-data-seltene-register-katalog-1"
      },
      "name" : "ERN ReCONNET Registry - Katalogeintrag",
      "description" : "Library: Katalogeintrag ERN ReCONNET Register fuer seltene Bindegewebserkrankungen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ResearchStudy"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ResearchStudy-mii-exa-test-data-seltene-register-study-1.html"
      }],
      "reference" : {
        "reference" : "ResearchStudy/mii-exa-test-data-seltene-register-study-1"
      },
      "name" : "ERN ReCONNET Registry - Rare Connective Tissue and Musculoskeletal Diseases",
      "description" : "ResearchStudy: ERN ReCONNET Register fuer seltene Bindegewebserkrankungen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Substance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Substance-mii-exa-test-data-patho-substance-formalin-1.html"
      }],
      "reference" : {
        "reference" : "Substance/mii-exa-test-data-patho-substance-formalin-1"
      },
      "name" : "Formalin (Fixativ)",
      "description" : "Substance: neutral gepuffertes Formalin als Fixierungs-Additiv",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Media"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Media-mii-exa-test-data-patho-image-1.html"
      }],
      "reference" : {
        "reference" : "Media/mii-exa-test-data-patho-image-1"
      },
      "name" : "Fotodokumentation HE-Schnitt Stanze 01",
      "description" : "Attached Image: Fotodokumentation des HE-Schnitts der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patho-diagnose-gesichert-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patho-diagnose-gesichert-1"
      },
      "name" : "Gesicherte Prostatakarzinom-Diagnose nach Biopsie",
      "description" : "Gesicherte Diagnose eines Prostatakarzinoms nach 2-Stanzen-Biopsie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-grading-group-isup.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-grading-group-isup"
      },
      "name" : "Grading Group according to ISUP 2014/WHO 2016 - Biopsy",
      "description" : "Prostate cancer grade group according to ISUP 2014 and WHO 2016",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-gleason-grading-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-gleason-grading-01"
      },
      "name" : "Gradinggruppe ISUP Stanze 01",
      "description" : "Gradinggruppe nach ISUP 2014/WHO 2016 für Stanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-granulomatous-prostatitis.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-granulomatous-prostatitis"
      },
      "name" : "Granulomatous Prostatitis - Biopsy",
      "description" : "Presence of granulomatous prostatitis",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patho-specimen-01-slide.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patho-specimen-01-slide"
      },
      "name" : "HE-Schnitt Stanze 01",
      "description" : "Hämatoxylin-Eosin gefärbter Schnitt der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patho-specimen-03-slide.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patho-specimen-03-slide"
      },
      "name" : "HE-Schnitt Stanze 03",
      "description" : "Hämatoxylin-Eosin gefärbter Schnitt der Prostatastanze 03",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-high-grade-pin.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-high-grade-pin"
      },
      "name" : "High-grade Prostatic Intraepithelial Neoplasia - Biopsy",
      "description" : "Presence of high-grade prostatic intraepithelial neoplasia",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-histological-grade-who.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-histological-grade-who"
      },
      "name" : "Histological Differentiation Grade WHO - Biopsy",
      "description" : "Histological differentiation grade according to WHO",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-histological-type-icdo-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-histological-type-icdo-3"
      },
      "name" : "Histological Type ICD-O-3 - Biopsy",
      "description" : "Histological type according to ICD-O-3 classification",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-histo-typ-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-histo-typ-01"
      },
      "name" : "Histologischer Typ Stanze 01",
      "description" : "Histologischer Typ ICD-O-3 für Stanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-histo-typ-03.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-histo-typ-03"
      },
      "name" : "Histologischer Typ Stanze 03",
      "description" : "Histologischer Typ ICD-O-3 für Stanze 03",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-mii-exa-test-data-patho-composition-1.html"
      }],
      "reference" : {
        "reference" : "Composition/mii-exa-test-data-patho-composition-1"
      },
      "name" : "Histopathologischer Befundbericht - Prostatabiopsie",
      "description" : "Composition für den strukturierten Prostatabiopsie-Befundbericht (2 Stanzen: 01 positiv, 03 benigne)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-icdo-version.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-icdo-version"
      },
      "name" : "ICD-O Version - Biopsy",
      "description" : "Version of ICD-O classification used",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-p63-befund-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-p63-befund-1"
      },
      "name" : "Immunhistochemie p63 Stanze 01",
      "description" : "Zusätzliche Beobachtung: p63-Immunhistochemie der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-intraductal-carcinoma.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-intraductal-carcinoma"
      },
      "name" : "Intraductal Carcinoma - Biopsy",
      "description" : "Presence of intraductal carcinoma",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-intraop-grouper-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-intraop-grouper-1"
      },
      "name" : "Intraoperative Befunde Grouper",
      "description" : "Gruppierung der intraoperativen Beobachtungen (Schnellschnitt)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-intraop-grouper-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-intraop-grouper-dar-1"
      },
      "name" : "Intraoperative Befunde Grouper - Typisierung am Schnellschnitt offen",
      "description" : "Intraoperativ-Grouper mit Komponente ohne Wert: histologischer Typ am Schnellschnitt noch nicht klassifizierbar (component.dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-tnm-m-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-tnm-m-1"
      },
      "name" : "Klinisches M-Staging",
      "description" : "Klinische M-Kategorie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-tnm-n-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-tnm-n-1"
      },
      "name" : "Klinisches N-Staging",
      "description" : "Klinische N-Kategorie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-tnm-t-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-tnm-t-1"
      },
      "name" : "Klinisches T-Staging",
      "description" : "Klinische T-Kategorie nach Biopsie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-onko-liste-evidenz-1.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-onko-liste-evidenz-1"
      },
      "name" : "Liste der Evidenz zum Erstdiagnosezeitpunkt",
      "description" : "Onkologie Test - Liste Evidenz Erstdiagnose",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-lymphovascular-invasion.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-lymphovascular-invasion"
      },
      "name" : "Lymphovascular Invasion - Biopsy",
      "description" : "Lymphatic and vascular invasion in cancer specimen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macro-grouper-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macro-grouper-1"
      },
      "name" : "Makroskopische Befunde Grouper",
      "description" : "Gruppierung der makroskopischen Messungen beider Prostatastanzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macro-grouper-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macro-grouper-dar-1"
      },
      "name" : "Makroskopische Befunde Grouper - Laenge nicht messbar",
      "description" : "Makroskopie-Grouper mit Komponente ohne Wert: Zylinderlaenge am fragmentierten Material nicht messbar (component.dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macroscopic-length-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macroscopic-length-01"
      },
      "name" : "Makroskopische Länge Stanze 01",
      "description" : "Längenmessung der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macroscopic-length-03.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macroscopic-length-03"
      },
      "name" : "Makroskopische Länge Stanze 03",
      "description" : "Längenmessung der Prostatastanze 03",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-mii-exa-test-data-semistrukt-befundbericht.html"
      }],
      "reference" : {
        "reference" : "Composition/mii-exa-test-data-semistrukt-befundbericht"
      },
      "name" : "Mammographic Report",
      "description" : "Composition: semistrukturierter Befundbericht",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-1-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-1-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-2-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-2-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-3-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-3-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-4-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-4-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-5-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-5-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-6-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-6-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-7-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-7-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-8-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-8-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-9-list-stat-aufenthalt.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-9-list-stat-aufenthalt"
      },
      "name" : "Medikationsliste während stationärem Aufenthalt",
      "description" : "List: Medikationsliste während stationärem Aufenthalt für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-onkologie-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-onkologie-1"
      },
      "name" : "MII Onkologie Test Data Bundle",
      "description" : "Vollständiges Transaktionsbundle mit allen Onkologie-Testdaten für den Upload auf einen FHIR-Server",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-anforderung.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-anforderung"
      },
      "name" : "mii-exa-test-data-anforderung",
      "description" : "ServiceRequest: Anforderung MR",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-befundbericht.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-befundbericht"
      },
      "name" : "mii-exa-test-data-befundbericht",
      "description" : "DiagnosticReport: Befundbericht",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-befundungsprozedur.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-befundungsprozedur"
      },
      "name" : "mii-exa-test-data-befundungsprozedur",
      "description" : "Procedure: Befundungsprozedur",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-mii-exa-test-data-behandlungsempfehlung.html"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-test-data-behandlungsempfehlung"
      },
      "name" : "mii-exa-test-data-behandlungsempfehlung",
      "description" : "CarePlan: Behandlungsempfehlung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-bildgebung-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-bildgebung-diagnose-1"
      },
      "name" : "mii-exa-test-data-bildgebung-diagnose-1",
      "description" : "Bildgebung Diagnose - Lungentumor",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-bildgebung-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-bildgebung-encounter-1"
      },
      "name" : "mii-exa-test-data-bildgebung-encounter-1",
      "description" : "Bildgebung Test Encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Endpoint"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Endpoint-mii-exa-test-data-bildgebung-endpoint-1.html"
      }],
      "reference" : {
        "reference" : "Endpoint/mii-exa-test-data-bildgebung-endpoint-1"
      },
      "name" : "mii-exa-test-data-bildgebung-endpoint-1",
      "description" : "Endpoint: DICOM WADO-RS Endpunkt des PACS",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-bildgebung-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-bildgebung-labobs-1"
      },
      "name" : "mii-exa-test-data-bildgebung-labobs-1",
      "description" : "Bildgebung Lab - Tumorgröße",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-bildgebung-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-bildgebung-medrequest-1"
      },
      "name" : "mii-exa-test-data-bildgebung-medrequest-1",
      "description" : "Bildgebung MedRequest - Kontrastmittel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-bildgebung-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-bildgebung-patient-1"
      },
      "name" : "mii-exa-test-data-bildgebung-patient-1",
      "description" : "Bildgebung Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-bildgebungsprozedur.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-bildgebungsprozedur"
      },
      "name" : "mii-exa-test-data-bildgebungsprozedur",
      "description" : "Procedure: Bildgebungsprozedur",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ImagingStudy"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ImagingStudy-mii-exa-test-data-bildgebungsstudie.html"
      }],
      "reference" : {
        "reference" : "ImagingStudy/mii-exa-test-data-bildgebungsstudie"
      },
      "name" : "mii-exa-test-data-bildgebungsstudie",
      "description" : "ImagingStudy: MagneticResonance",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-test-data-biobank-crispr-protokoll-1.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-test-data-biobank-crispr-protokoll-1"
      },
      "name" : "mii-exa-test-data-biobank-crispr-protokoll-1",
      "description" : "DocumentReference: CRISPR Knockout-Protokoll fuer TP53 in Kolon-Tumor-Organoiden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-biobank-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-biobank-diagnose-1"
      },
      "name" : "mii-exa-test-data-biobank-diagnose-1",
      "description" : "Biobank Diagnose Patient 1: Kolonkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-biobank-diagnose-3.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-biobank-diagnose-3"
      },
      "name" : "mii-exa-test-data-biobank-diagnose-3",
      "description" : "Biobank Diagnose Patient 3: Kolonkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-biobank-dna-konzentration-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-biobank-dna-konzentration-1"
      },
      "name" : "mii-exa-test-data-biobank-dna-konzentration-1",
      "description" : "Observation: DNA-Konzentration der DNA-Probe von Biobank-Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-biobank-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-biobank-encounter-1"
      },
      "name" : "mii-exa-test-data-biobank-encounter-1",
      "description" : "Biobank Test Encounter (Probenentnahme)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-biobank-karyotyp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-biobank-karyotyp-1"
      },
      "name" : "mii-exa-test-data-biobank-karyotyp-1",
      "description" : "Observation: Karyotyp des Kolon-Organoids von Biobank-Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-test-data-biobank-kulturprotokoll-1.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-test-data-biobank-kulturprotokoll-1"
      },
      "name" : "mii-exa-test-data-biobank-kulturprotokoll-1",
      "description" : "DocumentReference: Kulturprotokoll fuer Kolon-Tumor-Organoide",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-biobank-morphologie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-biobank-morphologie-1"
      },
      "name" : "mii-exa-test-data-biobank-morphologie-1",
      "description" : "Observation: Zellmorphologie des Kolon-Organoids von Biobank-Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-biobank-organoid-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-biobank-organoid-1"
      },
      "name" : "mii-exa-test-data-biobank-organoid-1",
      "description" : "Specimen: Kolon-Tumor-Organoid, abgeleitet aus der Gewebeprobe von Biobank-Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-1"
      },
      "name" : "mii-exa-test-data-biobank-patient-1",
      "description" : "Biobank Test Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-2.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-2"
      },
      "name" : "mii-exa-test-data-biobank-patient-2",
      "description" : "Biobank Test Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-3.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-3"
      },
      "name" : "mii-exa-test-data-biobank-patient-3",
      "description" : "Biobank Test Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-4.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-4"
      },
      "name" : "mii-exa-test-data-biobank-patient-4",
      "description" : "Biobank Test Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-5.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-5"
      },
      "name" : "mii-exa-test-data-biobank-patient-5",
      "description" : "Biobank Test Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-6.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-6"
      },
      "name" : "mii-exa-test-data-biobank-patient-6",
      "description" : "Biobank Test Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-7.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-7"
      },
      "name" : "mii-exa-test-data-biobank-patient-7",
      "description" : "Biobank Test Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-8.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-8"
      },
      "name" : "mii-exa-test-data-biobank-patient-8",
      "description" : "Biobank Test Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-biobank-patient-9.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-biobank-patient-9"
      },
      "name" : "mii-exa-test-data-biobank-patient-9",
      "description" : "Biobank Test Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-biobank-proliferation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-biobank-proliferation-1"
      },
      "name" : "mii-exa-test-data-biobank-proliferation-1",
      "description" : "Observation: Proliferation des Kolon-Organoids von Biobank-Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-biobank-qualitaetspruefung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-biobank-qualitaetspruefung-1"
      },
      "name" : "mii-exa-test-data-biobank-qualitaetspruefung-1",
      "description" : "Observation: Qualitaetspruefung (Haemolyse-Screening) der Serumprobe von Biobank-Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-biobank-specimen-dna-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-biobank-specimen-dna-1"
      },
      "name" : "mii-exa-test-data-biobank-specimen-dna-1",
      "description" : "Specimen (Core): DNA-Probe, extrahiert aus dem EDTA-Blut von Biobank-Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-biobank-wachstumstyp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-biobank-wachstumstyp-1"
      },
      "name" : "mii-exa-test-data-biobank-wachstumstyp-1",
      "description" : "Observation: Wachstumstyp des Kolon-Organoids von Biobank-Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-bildgebung-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-bildgebung-1"
      },
      "name" : "mii-exa-test-data-bundle-bildgebung-1",
      "description" : "Bundle: Bildgebung Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-biobank-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-biobank-1"
      },
      "name" : "mii-exa-test-data-bundle-biobank-1",
      "description" : "Bundle: Biobank Testdaten",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-dokument-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-dokument-1"
      },
      "name" : "mii-exa-test-data-bundle-dokument-1",
      "description" : "Bundle: Dokument Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-icu-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-icu-1"
      },
      "name" : "mii-exa-test-data-bundle-icu-1",
      "description" : "Bundle: ICU Testdaten Patient-1 (Standort B). COVID-19-Aufnahme.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-isik-vitalparameter-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-isik-vitalparameter-1"
      },
      "name" : "mii-exa-test-data-bundle-isik-vitalparameter-1",
      "description" : "Bundle: ISiK 6.0.0 Observation-Testdaten - Vitalparameter (10 Profile), LebensZustand-Familie, Laboruntersuchungs-Familie, MII-ICU-Monitoring- und Koerpertemperatur-Familie (sd-mii-icu-*)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-kardiologie-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-kardiologie-1"
      },
      "name" : "mii-exa-test-data-bundle-kardiologie-1",
      "description" : "Bundle: Kardiologie Testdaten Patient-1 (KHK mit Z.n. Myokardinfarkt, Aortenklappenstenose, Herzinsuffizienz NYHA II, Z.n. embolischem zerebrovaskulaerem Ereignis, ICD-Implantation)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-lungenfunktion-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-lungenfunktion-1"
      },
      "name" : "mii-exa-test-data-bundle-lungenfunktion-1",
      "description" : "Bundle: Lungenfunktion Testdaten Patient-1 (Spirometrie, Bodyplethysmographie, Diffusionsmessung und Methacholin-Provokationstest bei V.a. Asthma bronchiale)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-mikrobio-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-mikrobio-1"
      },
      "name" : "mii-exa-test-data-bundle-mikrobio-1",
      "description" : "Bundle: Mikrobiologie Testdaten (Sepsis-Patient mit MRSA)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-molgen-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-molgen-1"
      },
      "name" : "mii-exa-test-data-bundle-molgen-1",
      "description" : "Bundle: Molekulargenetik Testdaten Patient-3 und Patient-4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-mtb-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-mtb-1"
      },
      "name" : "mii-exa-test-data-bundle-mtb-1",
      "description" : "Bundle: MTB Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-1"
      },
      "name" : "mii-exa-test-data-bundle-pat-1",
      "description" : "Bundle: Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-10.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-10"
      },
      "name" : "mii-exa-test-data-bundle-pat-10",
      "description" : "Bundle: Patient-10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-11.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-11"
      },
      "name" : "mii-exa-test-data-bundle-pat-11",
      "description" : "Bundle: Patient-11",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-2.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-2"
      },
      "name" : "mii-exa-test-data-bundle-pat-2",
      "description" : "Bundle: Patient-2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-3.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-3"
      },
      "name" : "mii-exa-test-data-bundle-pat-3",
      "description" : "Bundle: Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-4.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-4"
      },
      "name" : "mii-exa-test-data-bundle-pat-4",
      "description" : "Bundle: Patient-4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-5.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-5"
      },
      "name" : "mii-exa-test-data-bundle-pat-5",
      "description" : "Bundle: Patient-5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-6.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-6"
      },
      "name" : "mii-exa-test-data-bundle-pat-6",
      "description" : "Bundle: Patient-6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-7.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-7"
      },
      "name" : "mii-exa-test-data-bundle-pat-7",
      "description" : "Bundle: Patient-7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-8.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-8"
      },
      "name" : "mii-exa-test-data-bundle-pat-8",
      "description" : "Bundle: Patient-8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pat-9.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pat-9"
      },
      "name" : "mii-exa-test-data-bundle-pat-9",
      "description" : "Bundle: Patient-9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-patho-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-patho-1"
      },
      "name" : "mii-exa-test-data-bundle-patho-1",
      "description" : "Bundle: Pathologie Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-pro-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-pro-1"
      },
      "name" : "mii-exa-test-data-bundle-pro-1",
      "description" : "Bundle: PRO Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-seltene-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-seltene-1"
      },
      "name" : "mii-exa-test-data-bundle-seltene-1",
      "description" : "Bundle: Seltene Erkrankungen Testdaten Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-soziodemographie-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-soziodemographie-1"
      },
      "name" : "mii-exa-test-data-bundle-soziodemographie-1",
      "description" : "Bundle: Soziodemographie Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-studien-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-studien-1"
      },
      "name" : "mii-exa-test-data-bundle-studien-1",
      "description" : "Bundle: Studien Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-mii-exa-test-data-bundle-symptom-1.html"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-test-data-bundle-symptom-1"
      },
      "name" : "mii-exa-test-data-bundle-symptom-1",
      "description" : "Bundle: Symptom Testdaten Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-device-roche-cobas.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-device-roche-cobas"
      },
      "name" : "mii-exa-test-data-device-roche-cobas",
      "description" : "Device: Roche cobas",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-device-roche-cobas-c303.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-device-roche-cobas-c303"
      },
      "name" : "mii-exa-test-data-device-roche-cobas-c303",
      "description" : "Device: Roche cobas c 303",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-device-roche-cobas-e402.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-device-roche-cobas-e402"
      },
      "name" : "mii-exa-test-data-device-roche-cobas-e402",
      "description" : "Device: Roche cobas e 402",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DeviceMetric"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DeviceMetric-mii-exa-test-data-devicemetric-roche-cobas-c303-1.html"
      }],
      "reference" : {
        "reference" : "DeviceMetric/mii-exa-test-data-devicemetric-roche-cobas-c303-1"
      },
      "name" : "mii-exa-test-data-devicemetric-roche-cobas-c303-1",
      "description" : "DeviceMetric: Roche cobas c 303",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-dokument-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-dokument-diagnose-1"
      },
      "name" : "mii-exa-test-data-dokument-diagnose-1",
      "description" : "Condition: Pneumonie fuer Dokument-Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-dokument-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-dokument-encounter-1"
      },
      "name" : "mii-exa-test-data-dokument-encounter-1",
      "description" : "Dokument Test Encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-dokument-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-dokument-patient-1"
      },
      "name" : "mii-exa-test-data-dokument-patient-1",
      "description" : "Dokument Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-geraet.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-geraet"
      },
      "name" : "mii-exa-test-data-geraet",
      "description" : "Device: MRT-Gerät",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-icu-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-icu-diagnose-1"
      },
      "name" : "mii-exa-test-data-icu-diagnose-1",
      "description" : "Condition: COVID-19 (ICU-Aufnahmediagnose, Standort B) fuer ICU-Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-icu-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-icu-encounter-1"
      },
      "name" : "mii-exa-test-data-icu-encounter-1",
      "description" : "ICU Test Encounter (Standort B) - Aufnahme wegen COVID-19",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-icu-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-icu-patient-1"
      },
      "name" : "mii-exa-test-data-icu-patient-1",
      "description" : "ICU Test Patient (Standort B). Identisch mit Onko-Patient an Standort A (gemeinsame KVNR).",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-mii-exa-test-data-icu-practitioner-1.html"
      }],
      "reference" : {
        "reference" : "Practitioner/mii-exa-test-data-icu-practitioner-1"
      },
      "name" : "mii-exa-test-data-icu-practitioner-1",
      "description" : "ICU Practitioner: Intensivmedizinerin (Dokumentation der Scores und Prozeduren)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-alkoholabusus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-alkoholabusus-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-alkoholabusus-1",
      "description" : "ISiK AlkoholAbusus: verneint (Aufnahmeanamnese)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-atemfrequenz-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-atemfrequenz-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-atemfrequenz-1",
      "description" : "ISiK Atemfrequenz: 18/min",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-blutdruck-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-blutdruck-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-blutdruck-1",
      "description" : "ISiK Blutdruck systemisch arteriell: 132/84 mmHg, MAD 100 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-ekg-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-ekg-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-ekg-1",
      "description" : "ISiK EKG: Ruhe-EKG mit den Ableitungen I, II und III als SampledData-Kanaele (500 Hz)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-isik-vitalparameter-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-isik-vitalparameter-encounter-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-encounter-1",
      "description" : "ISiK Vitalparameter Test Encounter: stationaere Aufnahme zur Synkopenabklaerung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-entbindungstermin-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-entbindungstermin-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-entbindungstermin-1",
      "description" : "ISiK Erwarteter Entbindungstermin: 2026-11-20 (geschaetzt, technische Instanz)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-gcs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-gcs-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-gcs-1",
      "description" : "ISiK GCS: 12 Punkte (Augen 3, verbal 4, motorisch 5) nach Synkope",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-gewicht-percentil-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-gewicht-percentil-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-gewicht-percentil-1",
      "description" : "MII-ICU Koerpergewicht-Percentil (altersabhaengig): 45 %",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-groesse-percentil-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-groesse-percentil-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-groesse-percentil-1",
      "description" : "MII-ICU Koerpergroesse-Percentil (altersabhaengig): 40 %",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-herzfrequenz-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-herzfrequenz-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-herzfrequenz-1",
      "description" : "ISiK Herzfrequenz: 76/min",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-hzv-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-hzv-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-hzv-1",
      "description" : "MII-ICU Herzzeitvolumen: 4.8 L/min",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-icp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-icp-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-icp-1",
      "description" : "MII-ICU Intrakranieller Druck (ICP): 12 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-ideales-gewicht-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-ideales-gewicht-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-ideales-gewicht-1",
      "description" : "MII-ICU Ideales Koerpergewicht: 63 kg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-kerntemp-stirn-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-kerntemp-stirn-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-kerntemp-stirn-1",
      "description" : "MII-ICU Koerperkerntemperatur Stirn: 36.9 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-koerpergewicht-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-koerpergewicht-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-koerpergewicht-1",
      "description" : "ISiK Koerpergewicht: 78 kg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-koerpergroesse-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-koerpergroesse-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-koerpergroesse-1",
      "description" : "ISiK Koerpergroesse: 172 cm",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-koerperkerntemperatur-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-koerperkerntemperatur-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-koerperkerntemperatur-1",
      "description" : "ISiK Koerperkerntemperatur: 37.8 Grad Celsius (rektal)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-kopfumfang-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-kopfumfang-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-kopfumfang-1",
      "description" : "ISiK Kopfumfang: 56 cm",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-crp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-crp-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-crp-1",
      "description" : "ISiK Laboruntersuchung CRP: 4.2 mg/L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-generisch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-generisch-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-generisch-1",
      "description" : "ISiK Laboruntersuchung (generisch): Kalium im Serum 4.1 mmol/L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-gfr-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-gfr-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-gfr-1",
      "description" : "ISiK Laboruntersuchung GFR: 78 mL/min/1.73m2 (CKD-EPI 2021)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-hb-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-hb-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-hb-1",
      "description" : "ISiK Laboruntersuchung Haemoglobin: 13.2 g/dL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-kreatinin-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-kreatinin-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-kreatinin-1",
      "description" : "ISiK Laboruntersuchung Serumkreatinin: 0.9 mg/dL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-natrium-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-natrium-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-natrium-1",
      "description" : "ISiK Laboruntersuchung Serumnatrium: 141 mmol/L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-pct-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-pct-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-pct-1",
      "description" : "ISiK Laboruntersuchung Procalcitonin: 0.08 ng/mL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-thrombozyten-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-thrombozyten-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-thrombozyten-1",
      "description" : "ISiK Laboruntersuchung Thrombozyten: 265 x10^3/uL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-troponin-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-troponin-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-troponin-1",
      "description" : "ISiK Laboruntersuchung Troponin I: 0.02 ng/mL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-labor-tsh-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-labor-tsh-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-labor-tsh-1",
      "description" : "ISiK Laboruntersuchung TSH: 1.8 mIU/L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lap-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lap-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lap-1",
      "description" : "MII-ICU Linksatrialer Druck: 12/8 mmHg, Mittel 10 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lv-herzindex-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lv-herzindex-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lv-herzindex-1",
      "description" : "MII-ICU Linksventrikulaerer Herzindex: 2.9 L/min/m2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lv-hi-ind-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lv-hi-ind-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lv-hi-ind-1",
      "description" : "MII-ICU Herzindex durch Indikatorverduennung: 2.8 L/min/m2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lv-hzv-ind-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lv-hzv-ind-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lv-hzv-ind-1",
      "description" : "MII-ICU Herzzeitvolumen durch Indikatorverduennung: 4.9 L/min",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lv-schlagvolumen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lv-schlagvolumen-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lv-schlagvolumen-1",
      "description" : "MII-ICU Linksventrikulaeres Schlagvolumen: 70 mL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lv-sv-ind-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lv-sv-ind-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lv-sv-ind-1",
      "description" : "MII-ICU Schlagvolumen durch Indikatorverduennung: 68 mL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lv-svi-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lv-svi-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lv-svi-1",
      "description" : "MII-ICU Linksventrikulaerer Schlagvolumenindex: 37 mL/m2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lv-svi-ind-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lv-svi-ind-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lv-svi-ind-1",
      "description" : "MII-ICU Schlagvolumenindex durch Indikatorverduennung: 36 mL/m2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-lvp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-lvp-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-lvp-1",
      "description" : "MII-ICU Linksventrikulaerer Druck: 120/10 mmHg, Mittel 47 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-muv-generisch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-muv-generisch-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-muv-generisch-1",
      "description" : "MII-ICU Monitoring und Vitaldaten (generisch): Herzfrequenz 82/min",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-o2sat-art-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-o2sat-art-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-o2sat-art-1",
      "description" : "MII-ICU O2-Saettigung im arteriellen Blut (Pulsoxymetrie): 96 %",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-o2sat-postduktal-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-o2sat-postduktal-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-o2sat-postduktal-1",
      "description" : "MII-ICU O2-Saettigung postduktal (Pulsoxymetrie): 95 %",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-o2sat-praeduktal-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-o2sat-praeduktal-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-o2sat-praeduktal-1",
      "description" : "MII-ICU O2-Saettigung praeduktal (Pulsoxymetrie): 97 %",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-pap-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-pap-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-pap-1",
      "description" : "MII-ICU Pulmonalarterieller Blutdruck: 25/10 mmHg, Mittel 15 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-isik-vitalparameter-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-isik-vitalparameter-patient-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-patient-1",
      "description" : "ISiK Vitalparameter Test Patient: Viktoria Vogel (Synkope, Vitalparameter-Monitoring)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-puls-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-puls-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-puls-1",
      "description" : "MII-ICU Puls: 76/min (palpatorisch A. radialis)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-pulsatil-generisch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-pulsatil-generisch-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-pulsatil-generisch-1",
      "description" : "MII-ICU Sonstige pulsatile Druecke (generisch): systemisch-arteriell 128/76 mmHg, MAD 93 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-pvri-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-pvri-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-pvri-1",
      "description" : "MII-ICU Pulmonalvaskulaerer Widerstandsindex: 220 dyn.s/cm5/m2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-rap-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-rap-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-rap-1",
      "description" : "MII-ICU Rechtsatrialer Druck: 8/3 mmHg, Mittel 5 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-rvp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-rvp-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-rvp-1",
      "description" : "MII-ICU Rechtsventrikulaerer Druck: 25/4 mmHg, Mittel 14 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-sauerstoffsaettigung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-sauerstoffsaettigung-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-sauerstoffsaettigung-1",
      "description" : "ISiK Sauerstoffsaettigung arteriell: 96 % (pulsoxymetrisch)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-schwangerschaft-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-schwangerschaft-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-schwangerschaft-1",
      "description" : "ISiK Schwangerschaftsstatus: nicht schwanger (Aufnahmeanamnese)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-stillstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-stillstatus-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-stillstatus-1",
      "description" : "ISiK Stillstatus: stillt derzeit nicht (Aufnahmeanamnese)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-svri-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-svri-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-svri-1",
      "description" : "MII-ICU Systemischer vaskulaerer Widerstandsindex: 1900 dyn.s/cm5/m2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-achsel-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-achsel-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-achsel-1",
      "description" : "MII-ICU Koerpertemperatur axillaer: 36.6 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-atemwege-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-atemwege-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-atemwege-1",
      "description" : "MII-ICU Koerpertemperatur Atemwege: 36.7 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-blut-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-blut-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-blut-1",
      "description" : "MII-ICU Koerpertemperatur Blut: 37.3 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-brust-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-brust-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-brust-1",
      "description" : "MII-ICU Koerpertemperatur Brust: 36.4 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-bws-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-bws-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-bws-1",
      "description" : "MII-ICU Koerpertemperatur Brustwirbelsaeule: 36.9 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-gelenk-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-gelenk-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-gelenk-1",
      "description" : "MII-ICU Koerpertemperatur Gelenk: 35.8 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-generisch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-generisch-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-generisch-1",
      "description" : "MII-ICU Koerpertemperatur (generisch): 37.0 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-harnblase-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-harnblase-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-harnblase-1",
      "description" : "MII-ICU Koerpertemperatur Harnblase: 37.4 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-hws-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-hws-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-hws-1",
      "description" : "MII-ICU Koerpertemperatur Halswirbelsaeule: 36.8 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-kern-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-kern-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-kern-1",
      "description" : "MII-ICU Koerperkerntemperatur (Kern): 37.2 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-leiste-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-leiste-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-leiste-1",
      "description" : "MII-ICU Koerpertemperatur Leiste: 36.8 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-lws-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-lws-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-lws-1",
      "description" : "MII-ICU Koerpertemperatur Lendenwirbelsaeule: 36.9 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-myokard-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-myokard-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-myokard-1",
      "description" : "MII-ICU Koerpertemperatur Myokard: 37.0 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-nasal-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-nasal-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-nasal-1",
      "description" : "MII-ICU Koerpertemperatur nasal: 36.5 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-nasopharynx-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-nasopharynx-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-nasopharynx-1",
      "description" : "MII-ICU Koerpertemperatur Nasen-Rachen-Raum: 36.9 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-oesophagus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-oesophagus-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-oesophagus-1",
      "description" : "MII-ICU Koerpertemperatur oesophageal: 37.3 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-rektal-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-rektal-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-rektal-1",
      "description" : "MII-ICU Koerpertemperatur rektal: 37.6 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-stirn-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-stirn-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-stirn-1",
      "description" : "MII-ICU Koerpertemperatur Stirn: 36.3 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-sublingual-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-sublingual-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-sublingual-1",
      "description" : "MII-ICU Koerpertemperatur sublingual: 36.9 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-trommelfell-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-trommelfell-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-trommelfell-1",
      "description" : "MII-ICU Koerpertemperatur tympanal: 37.1 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-temp-vaginal-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-temp-vaginal-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-temp-vaginal-1",
      "description" : "MII-ICU Koerpertemperatur vaginal: 37.2 GradC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-wedge-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-wedge-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-wedge-1",
      "description" : "MII-ICU Pulmonalarterieller Wedge-Druck: 12 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-isik-vitalparameter-zvd-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-isik-vitalparameter-zvd-1"
      },
      "name" : "mii-exa-test-data-isik-vitalparameter-zvd-1",
      "description" : "MII-ICU Zentralvenoeser Blutdruck (ZVD): 8 mmHg",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-kardiologie-device-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-kardiologie-device-1"
      },
      "name" : "mii-exa-test-data-kardiologie-device-1",
      "description" : "Kardio Device: Implantierbarer Kardioverter-Defibrillator (ICD)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-kardiologie-deviceimplantation-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-kardiologie-deviceimplantation-1"
      },
      "name" : "mii-exa-test-data-kardiologie-deviceimplantation-1",
      "description" : "Kardio Kardiale Deviceimplantation: Implantation eines ICD",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DeviceMetric"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DeviceMetric-mii-exa-test-data-kardiologie-devicemetric-1.html"
      }],
      "reference" : {
        "reference" : "DeviceMetric/mii-exa-test-data-kardiologie-devicemetric-1"
      },
      "name" : "mii-exa-test-data-kardiologie-devicemetric-1",
      "description" : "Kardio DeviceMetric: NBG-Schrittmachermodus des ICD",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-kardiologie-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-kardiologie-diagnose-1"
      },
      "name" : "mii-exa-test-data-kardiologie-diagnose-1",
      "description" : "Kardio Diagnose: Akuter transmuraler Myokardinfarkt der Vorderwand",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-kardiologie-diagnose-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-kardiologie-diagnose-2"
      },
      "name" : "mii-exa-test-data-kardiologie-diagnose-2",
      "description" : "Kardio Diagnose: Hirninfarkt durch embolischen Verschluss zerebraler Arterien (eg-cv)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-kardiologie-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-kardiologie-encounter-1"
      },
      "name" : "mii-exa-test-data-kardiologie-encounter-1",
      "description" : "Kardiologie Test Encounter: stationaere Aufnahme wegen dekompensierter Herzinsuffizienz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-erstereignis-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-erstereignis-1"
      },
      "name" : "mii-exa-test-data-kardiologie-erstereignis-1",
      "description" : "Kardio Atherosklerotisches Erstereignis: KHK, Erstdiagnose 03/2020",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-geraeteprogrammierung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-geraeteprogrammierung-1"
      },
      "name" : "mii-exa-test-data-kardiologie-geraeteprogrammierung-1",
      "description" : "Kardio Geraeteprogrammierung: Brady Pacing Mode VVI",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-htx-nein-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-htx-nein-1"
      },
      "name" : "mii-exa-test-data-kardiologie-htx-nein-1",
      "description" : "Kardio Nein/Unbekannt: Herztransplantation - nein",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-kh-aufenthalte-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-kh-aufenthalte-1"
      },
      "name" : "mii-exa-test-data-kardiologie-kh-aufenthalte-1",
      "description" : "Kardio Anzahl KH-Aufenthalte wegen Herzinsuffizienz: 2 in den letzten 12 Monaten",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-kardiologie-klappenvitium-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-kardiologie-klappenvitium-1"
      },
      "name" : "mii-exa-test-data-kardiologie-klappenvitium-1",
      "description" : "Kardio Klappenvitium: hoehergradige Aortenklappenstenose",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-lvef-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-lvef-1"
      },
      "name" : "mii-exa-test-data-kardiologie-lvef-1",
      "description" : "Kardio LVEF: 38 % (reduzierte Ejektionsfraktion, HFrEF)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-mrs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-mrs-1"
      },
      "name" : "mii-exa-test-data-kardiologie-mrs-1",
      "description" : "Kardio Score mRS: 1 (keine relevante Beeintraechtigung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-nyha-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-nyha-1"
      },
      "name" : "mii-exa-test-data-kardiologie-nyha-1",
      "description" : "Kardio Score NYHA: Klasse II",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-kardiologie-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-kardiologie-patient-1"
      },
      "name" : "mii-exa-test-data-kardiologie-patient-1",
      "description" : "Kardiologie Test Patient: Karl Herzmann (KHK, Aortenklappenstenose, Herzinsuffizienz)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-kardiologie-rauchen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-kardiologie-rauchen-1"
      },
      "name" : "mii-exa-test-data-kardiologie-rauchen-1",
      "description" : "Kardio Raucherstatus: Ex-Raucher, 30 Packungsjahre",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "BodyStructure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "BodyStructure-mii-exa-test-data-koerperstruktur.html"
      }],
      "reference" : {
        "reference" : "BodyStructure/mii-exa-test-data-koerperstruktur"
      },
      "name" : "mii-exa-test-data-koerperstruktur",
      "description" : "BodyStructure: Körperstruktur",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-kontrastmittelgabe.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-kontrastmittelgabe"
      },
      "name" : "mii-exa-test-data-kontrastmittelgabe",
      "description" : "MedicationAdministration: kontrastmittelgabe",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-bf-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-bf-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-bf-1",
      "description" : "Lungenfunktion BF: Atemfrequenz 14/min",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-lungenfunktion-bodyplethysmografie-befund-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-lungenfunktion-bodyplethysmografie-befund-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-bodyplethysmografie-befund-1",
      "description" : "Lungenfunktion Bodyplethysmographie-Befund: erhoehter Atemwegswiderstand, leichte Ueberblaehung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-lungenfunktion-bodyplethysmographie-messung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-lungenfunktion-bodyplethysmographie-messung-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-bodyplethysmographie-messung-1",
      "description" : "Lungenfunktion Bodyplethysmographie-Messung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-co2-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-co2-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-co2-1",
      "description" : "Lungenfunktion CO2-Konzentration im Messraum: 0.05 %",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-lungenfunktion-diffusion-befund-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-lungenfunktion-diffusion-befund-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-diffusion-befund-1",
      "description" : "Lungenfunktion Diffusions-Befund: normale CO-Diffusionskapazitaet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-lungenfunktion-diffusion-messung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-lungenfunktion-diffusion-messung-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-diffusion-messung-1",
      "description" : "Lungenfunktion Diffusionsmessung (CO-Diffusionskapazitaet, Single-Breath)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-dlco-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-dlco-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-dlco-1",
      "description" : "Lungenfunktion DLCO: 7.20 mmol/(min.kPa) (92 % vom Soll)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-dlcoc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-dlcoc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-dlcoc-1",
      "description" : "Lungenfunktion DLCOc: 7.45 mmol/(min.kPa) (Hb-korrigiert)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-test-data-lungenfunktion-docref-rohdaten-1.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-test-data-lungenfunktion-docref-rohdaten-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-docref-rohdaten-1",
      "description" : "Lungenfunktion DocumentReference: Rohdaten der Messungen (Fluss-Volumen-Kurven)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-lungenfunktion-dosis-gabe-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-lungenfunktion-dosis-gabe-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-dosis-gabe-1",
      "description" : "Lungenfunktion Dosisgabe 1: 0.04 mg Methacholin inhalativ",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-lungenfunktion-dosis-gabe-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-lungenfunktion-dosis-gabe-2"
      },
      "name" : "mii-exa-test-data-lungenfunktion-dosis-gabe-2",
      "description" : "Lungenfunktion Dosisgabe 2: 0.30 mg Methacholin inhalativ",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-lungenfunktion-dosis-gabe-var-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-lungenfunktion-dosis-gabe-var-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-dosis-gabe-var-1",
      "description" : "Lungenfunktion Dosisgabe (Variante): medicationCodeableConcept 0.10 mg Methacholin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-dosis-kumuliert-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-dosis-kumuliert-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-dosis-kumuliert-1",
      "description" : "Lungenfunktion Dosis kumuliert: 0.34 mg Methacholin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-dosis-schwellwert-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-dosis-schwellwert-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-dosis-schwellwert-1",
      "description" : "Lungenfunktion Dosis-Schwellwert (PD20): 0.30 mg Methacholin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-lungenfunktion-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-lungenfunktion-encounter-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-encounter-1",
      "description" : "Lungenfunktion Test Encounter: ambulante Lungenfunktionsdiagnostik",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-fev-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-fev-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-fev-1",
      "description" : "Lungenfunktion FEV1: 2.10 L (74 % vom Soll)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-fev-fvc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-fev-fvc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-fev-fvc-1",
      "description" : "Lungenfunktion FEV1/FVC: 67.7 % (leichte Obstruktion)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-fev-prov-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-fev-prov-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-fev-prov-1",
      "description" : "Lungenfunktion FEV1 (Provokation, Baseline): 2.10 L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-fev-prov-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-fev-prov-2"
      },
      "name" : "mii-exa-test-data-lungenfunktion-fev-prov-2",
      "description" : "Lungenfunktion FEV1 (Provokation, nach Methacholin): 1.55 L (-26 %)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-frc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-frc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-frc-1",
      "description" : "Lungenfunktion FRC: 3.40 L (bodyplethysmographisch)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-frc-prov-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-frc-prov-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-frc-prov-1",
      "description" : "Lungenfunktion FRC (Provokation, nach Methacholin): 3.60 L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-fvc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-fvc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-fvc-1",
      "description" : "Lungenfunktion FVC: 3.10 L (86 % vom Soll)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-gewicht-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-gewicht-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-gewicht-1",
      "description" : "Lungenfunktion Koerpergewicht: 68 (Einheit 'ug' durch Profil-Pattern vorgegeben, fachlich 'kg')",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-hb-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-hb-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-hb-1",
      "description" : "Lungenfunktion Hb: 13.8 g/dL",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-ic-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-ic-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-ic-1",
      "description" : "Lungenfunktion IC: 2.40 L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-irv-erv-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-irv-erv-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-irv-erv-1",
      "description" : "Lungenfunktion ERV: 0.90 L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-kco-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-kco-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-kco-1",
      "description" : "Lungenfunktion KCO: 1.45 mmol/(min.kPa.L) (95 % vom Soll)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-kcoc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-kcoc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-kcoc-1",
      "description" : "Lungenfunktion KCOc: 1.50 mmol/(min.kPa.L) (Hb-korrigiert)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-luftfeuchtigkeit-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-luftfeuchtigkeit-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-luftfeuchtigkeit-1",
      "description" : "Lungenfunktion Luftfeuchtigkeit im Messraum: 45 %",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-lufttemperatur-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-lufttemperatur-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-lufttemperatur-1",
      "description" : "Lungenfunktion Lufttemperatur im Messraum: 21.5 Cel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-mef-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-mef-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-mef-1",
      "description" : "Lungenfunktion MEF50: 1.90 L/s (deutlich reduziert)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-lungenfunktion-methacholine-1.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-lungenfunktion-methacholine-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-methacholine-1",
      "description" : "Lungenfunktion Medication: Methacholin-Provokationsloesung (Provokit 0,33%)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-lungenfunktion-methacholine-anordnung-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-lungenfunktion-methacholine-anordnung-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-methacholine-anordnung-1",
      "description" : "Lungenfunktion MedicationRequest: Anordnung Methacholin-Provokationsprotokoll",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-lungenfunktion-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-lungenfunktion-patient-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-patient-1",
      "description" : "Lungenfunktion Test Patient: Luise Atemwald (V.a. Asthma bronchiale)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-pef-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-pef-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-pef-1",
      "description" : "Lungenfunktion PEF: 5.20 L/s (75 % vom Soll)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-pef-prov-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-pef-prov-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-pef-prov-1",
      "description" : "Lungenfunktion PEF (Provokation, nach Methacholin): 4.10 L/s",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-lungenfunktion-provokationstest-befund-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-lungenfunktion-provokationstest-befund-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-provokationstest-befund-1",
      "description" : "Lungenfunktion Provokationstest-Befund: positiver Methacholin-Provokationstest",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-lungenfunktion-provokationstest-messung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-lungenfunktion-provokationstest-messung-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-provokationstest-messung-1",
      "description" : "Lungenfunktion Provokationstest-Messung (Methacholin-Provokation)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-r-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-r-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-r-1",
      "description" : "Lungenfunktion R_tot: 0.42 kPa/(L/s) (erhoeht)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-r-prov-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-r-prov-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-r-prov-1",
      "description" : "Lungenfunktion R_tot (Provokation, nach Methacholin): 0.55 kPa/(L/s)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-rv-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-rv-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-rv-1",
      "description" : "Lungenfunktion RV: 2.60 L (130 % vom Soll, Ueberblaehung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-rv-tlc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-rv-tlc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-rv-tlc-1",
      "description" : "Lungenfunktion RV/TLC: 44 % (erhoeht)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-sg-total-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-sg-total-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-sg-total-1",
      "description" : "Lungenfunktion sG_tot: 0.74 /kPa.s (erniedrigt)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-lungenfunktion-spirometrie-befund-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-lungenfunktion-spirometrie-befund-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-spirometrie-befund-1",
      "description" : "Lungenfunktion Spirometrie-Befund: leichte obstruktive Ventilationsstoerung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-lungenfunktion-spirometrie-messung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-lungenfunktion-spirometrie-messung-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-spirometrie-messung-1",
      "description" : "Lungenfunktion Spirometrie-Messung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-sr-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-sr-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-sr-1",
      "description" : "Lungenfunktion sR_tot: 1.35 kPa.s (erhoeht)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-sr-eff-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-sr-eff-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-sr-eff-1",
      "description" : "Lungenfunktion sR_eff: 1.10 kPa.s (leicht erhoeht)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-sr-prov-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-sr-prov-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-sr-prov-1",
      "description" : "Lungenfunktion sR_tot (Provokation, nach Methacholin): 1.80 kPa.s",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-tlc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-tlc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-tlc-1",
      "description" : "Lungenfunktion TLC: 5.90 L (107 % vom Soll)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-mii-exa-test-data-lungenfunktion-umgebung-1.html"
      }],
      "reference" : {
        "reference" : "Location/mii-exa-test-data-lungenfunktion-umgebung-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-umgebung-1",
      "description" : "Lungenfunktion Umgebung: Lungenfunktionslabor (Raum innerhalb eines Gebaeudes)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-lungenfunktion-untersuchung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-lungenfunktion-untersuchung-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-untersuchung-1",
      "description" : "Lungenfunktion Procedure: komplette Lungenfunktionsdiagnostik (Gesamtuntersuchung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-va-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-va-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-va-1",
      "description" : "Lungenfunktion VA: 4.95 L",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-lungenfunktion-vc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-lungenfunktion-vc-1"
      },
      "name" : "mii-exa-test-data-lungenfunktion-vc-1",
      "description" : "Lungenfunktion VC: 3.30 L (89 % vom Soll)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-5-fluorouracil.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-5-fluorouracil"
      },
      "name" : "mii-exa-test-data-medication-5-fluorouracil",
      "description" : "Medication: 5-Fluorouracil",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-amoxicillin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-amoxicillin"
      },
      "name" : "mii-exa-test-data-medication-amoxicillin",
      "description" : "Medication: Amoxicillin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-amoxicillin-clavulansaeure.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-amoxicillin-clavulansaeure"
      },
      "name" : "mii-exa-test-data-medication-amoxicillin-clavulansaeure",
      "description" : "Medication: Amoxicillin und Clavulansäure",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-ass-100.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-ass-100"
      },
      "name" : "mii-exa-test-data-medication-ass-100",
      "description" : "Medication: ASS 100",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-atorvastatin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-atorvastatin"
      },
      "name" : "mii-exa-test-data-medication-atorvastatin",
      "description" : "Medication: Atorvastatin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-carboplatin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-carboplatin"
      },
      "name" : "mii-exa-test-data-medication-carboplatin",
      "description" : "Medication: Carboplatin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-cisplatin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-cisplatin"
      },
      "name" : "mii-exa-test-data-medication-cisplatin",
      "description" : "Medication: Cisplatin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-clarithromycin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-clarithromycin"
      },
      "name" : "mii-exa-test-data-medication-clarithromycin",
      "description" : "Medication: Clarithromycin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-dalbavancin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-dalbavancin"
      },
      "name" : "mii-exa-test-data-medication-dalbavancin",
      "description" : "Medication: Dalbavancin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-ethinylestradiol-levonorgestrel.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-ethinylestradiol-levonorgestrel"
      },
      "name" : "mii-exa-test-data-medication-ethinylestradiol-levonorgestrel",
      "description" : "Medication: Ethinylestradiol und Levonorgestrel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-glucoseloesung.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-glucoseloesung"
      },
      "name" : "mii-exa-test-data-medication-glucoseloesung",
      "description" : "Medication: Glucoselösung 5%",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-heparin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-heparin"
      },
      "name" : "mii-exa-test-data-medication-heparin",
      "description" : "Medication: Heparin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-ibuprofen.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-ibuprofen"
      },
      "name" : "mii-exa-test-data-medication-ibuprofen",
      "description" : "Medication: Ibuprofen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-leuprorelin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-leuprorelin"
      },
      "name" : "mii-exa-test-data-medication-leuprorelin",
      "description" : "Medication: Leuprorelin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-metamizol.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-metamizol"
      },
      "name" : "mii-exa-test-data-medication-metamizol",
      "description" : "Medication: Metamizol",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-metoprolol.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-metoprolol"
      },
      "name" : "mii-exa-test-data-medication-metoprolol",
      "description" : "Medication: Metoprolol",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-morphin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-morphin"
      },
      "name" : "mii-exa-test-data-medication-morphin",
      "description" : "Medication: Morphin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-omeprazol.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-omeprazol"
      },
      "name" : "mii-exa-test-data-medication-omeprazol",
      "description" : "Medication: Omeprazol",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-oxaliplatin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-oxaliplatin"
      },
      "name" : "mii-exa-test-data-medication-oxaliplatin",
      "description" : "Medication: Oxaliplatin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-paclitaxel.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-paclitaxel"
      },
      "name" : "mii-exa-test-data-medication-paclitaxel",
      "description" : "Medication: Paclitaxel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-pantoprazol.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-pantoprazol"
      },
      "name" : "mii-exa-test-data-medication-pantoprazol",
      "description" : "Medication: Pantoprazol",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-paracetamol.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-paracetamol"
      },
      "name" : "mii-exa-test-data-medication-paracetamol",
      "description" : "Medication: Paracetamol",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-propofol.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-propofol"
      },
      "name" : "mii-exa-test-data-medication-propofol",
      "description" : "Medication: Propofol",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-rezeptur-doxorubicin.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-rezeptur-doxorubicin"
      },
      "name" : "mii-exa-test-data-medication-rezeptur-doxorubicin",
      "description" : "Medication: Rezeptur Doxorubicin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-salbutamol.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-salbutamol"
      },
      "name" : "mii-exa-test-data-medication-salbutamol",
      "description" : "Medication: Salbutamol",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-sumatriptan.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-sumatriptan"
      },
      "name" : "mii-exa-test-data-medication-sumatriptan",
      "description" : "Medication: Sumatriptan",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Medication-mii-exa-test-data-medication-topiramat.html"
      }],
      "reference" : {
        "reference" : "Medication/mii-exa-test-data-medication-topiramat"
      },
      "name" : "mii-exa-test-data-medication-topiramat",
      "description" : "Medication: Topiramat",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-allgemeine-bestimmung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-allgemeine-bestimmung-1"
      },
      "name" : "mii-exa-test-data-mikrobio-allgemeine-bestimmung-1",
      "description" : "Mikrobio: Allgemeine Bestimmung — Bakterien-Nachweis",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-allgemeine-bestimmung-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-allgemeine-bestimmung-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-allgemeine-bestimmung-alt-1",
      "description" : "Mikrobio: allgemeine-bestimmung — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-allgemeine-bestimmung-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-allgemeine-bestimmung-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-allgemeine-bestimmung-dar-1",
      "description" : "Mikrobio: allgemeine-bestimmung — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-allgemeine-kultur-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-allgemeine-kultur-1"
      },
      "name" : "mii-exa-test-data-mikrobio-allgemeine-kultur-1",
      "description" : "Mikrobio: Allgemeine Kultur (Blutkultur) — positiv",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-allgemeine-kultur-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-allgemeine-kultur-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-allgemeine-kultur-alt-1",
      "description" : "Mikrobio: allgemeine-kultur — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-allgemeine-kultur-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-allgemeine-kultur-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-allgemeine-kultur-dar-1",
      "description" : "Mikrobio: Allgemeine Kultur — Ergebnis fehlt (Probe abgelaufen)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-antigen-antikoerper-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-antigen-antikoerper-1"
      },
      "name" : "mii-exa-test-data-mikrobio-antigen-antikoerper-1",
      "description" : "Mikrobio: Antikörper-Titer (IgG) quantitativ",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-antigen-antikoerper-quantitativ-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-antigen-antikoerper-quantitativ-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-antigen-antikoerper-quantitativ-alt-1",
      "description" : "Mikrobio: antigen-antikoerper-quantitativ — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-antigen-antikoerper-quantitativ-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-antigen-antikoerper-quantitativ-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-antigen-antikoerper-quantitativ-dar-1",
      "description" : "Mikrobio: antigen-antikoerper-quantitativ — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-aviditaet-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-aviditaet-1"
      },
      "name" : "mii-exa-test-data-mikrobio-aviditaet-1",
      "description" : "Mikrobio: Avidität IgG niedrig (frische Infektion)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-aviditaet-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-aviditaet-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-aviditaet-alt-1",
      "description" : "Mikrobio: aviditaet — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-aviditaet-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-aviditaet-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-aviditaet-dar-1",
      "description" : "Mikrobio: aviditaet — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-bartlett-score-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-bartlett-score-1"
      },
      "name" : "mii-exa-test-data-mikrobio-bartlett-score-1",
      "description" : "Mikrobio: Bartlett-Score (verwertbar)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-bartlett-score-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-bartlett-score-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-bartlett-score-alt-1",
      "description" : "Mikrobio: bartlett-score — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-bartlett-score-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-bartlett-score-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-bartlett-score-dar-1",
      "description" : "Mikrobio: bartlett-score — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-ct-wert-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-ct-wert-1"
      },
      "name" : "mii-exa-test-data-mikrobio-ct-wert-1",
      "description" : "Mikrobio: CT-Wert PCR (21.3)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-ct-wert-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-ct-wert-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-ct-wert-alt-1",
      "description" : "Mikrobio: ct-wert — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-ct-wert-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-ct-wert-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-ct-wert-dar-1",
      "description" : "Mikrobio: ct-wert — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-mikrobio-device-bactec-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-bactec-1"
      },
      "name" : "mii-exa-test-data-mikrobio-device-bactec-1",
      "description" : "Mikrobio Lab Analyzer: Blutkultur-Automat (Inkubation und Wachstumsdetektion)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-mikrobio-device-immunoassay-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-immunoassay-1"
      },
      "name" : "mii-exa-test-data-mikrobio-device-immunoassay-1",
      "description" : "Mikrobio Lab Analyzer: Immunoassay-Analyzer (Serologie)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-mikrobio-device-maldi-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-maldi-1"
      },
      "name" : "mii-exa-test-data-mikrobio-device-maldi-1",
      "description" : "Mikrobio Lab Analyzer: MALDI-TOF Massenspektrometer (Erreger-Identifikation)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-mikrobio-device-mikroskop-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-mikroskop-1"
      },
      "name" : "mii-exa-test-data-mikrobio-device-mikroskop-1",
      "description" : "Mikrobio Lab Analyzer: Lichtmikroskop (Gram-/Spezialfaerbungen, Scores)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-mikrobio-device-pcr-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-pcr-1"
      },
      "name" : "mii-exa-test-data-mikrobio-device-pcr-1",
      "description" : "Mikrobio Lab Analyzer: Real-time-PCR-Cycler (molekulare Diagnostik)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-mikrobio-device-vitek-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-mikrobio-device-vitek-1"
      },
      "name" : "mii-exa-test-data-mikrobio-device-vitek-1",
      "description" : "Mikrobio Lab Analyzer: Antibiogramm-Automat (MHK-Bestimmung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-mikrobio-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-mikrobio-diagnose-1"
      },
      "name" : "mii-exa-test-data-mikrobio-diagnose-1",
      "description" : "Condition: Sepsis durch MRSA fuer Mikrobio-Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-mikrobio-diagnostic-report-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-mikrobio-diagnostic-report-1"
      },
      "name" : "mii-exa-test-data-mikrobio-diagnostic-report-1",
      "description" : "Mikrobio Diagnostic Report: Blutkultur + Antibiogramm + MRSA-Befund",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-empfindlichkeit-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-empfindlichkeit-1"
      },
      "name" : "mii-exa-test-data-mikrobio-empfindlichkeit-1",
      "description" : "Mikrobio: Empfindlichkeit Vancomycin (MHK 1 mg/L, S)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-empfindlichkeit-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-empfindlichkeit-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-empfindlichkeit-alt-1",
      "description" : "Mikrobio: empfindlichkeit — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-empfindlichkeit-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-empfindlichkeit-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-empfindlichkeit-dar-1",
      "description" : "Mikrobio: empfindlichkeit — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-empfindlichkeit-sir-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-empfindlichkeit-sir-1"
      },
      "name" : "mii-exa-test-data-mikrobio-empfindlichkeit-sir-1",
      "description" : "Mikrobio: empfindlichkeit — SIR-Ergebnis als valueCodeableConcept (EUCAST)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-mikrobio-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-mikrobio-encounter-1"
      },
      "name" : "mii-exa-test-data-mikrobio-encounter-1",
      "description" : "Mikrobio Test Encounter: Stationärer Sepsis-Aufenthalt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-keimzahl-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-keimzahl-1"
      },
      "name" : "mii-exa-test-data-mikrobio-keimzahl-1",
      "description" : "Mikrobio: Keimzahl Urinkultur (E. coli, signifikant)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-keimzahl-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-keimzahl-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-keimzahl-alt-1",
      "description" : "Mikrobio: keimzahl — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-keimzahl-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-keimzahl-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-keimzahl-dar-1",
      "description" : "Mikrobio: keimzahl — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-mikroskopie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-mikroskopie-1"
      },
      "name" : "mii-exa-test-data-mikrobio-mikroskopie-1",
      "description" : "Mikrobio: Mikroskopie — Gram-positive Kokken in Haufen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-mikroskopie-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-mikroskopie-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-mikroskopie-alt-1",
      "description" : "Mikrobio: mikroskopie — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-mikroskopie-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-mikroskopie-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-mikroskopie-dar-1",
      "description" : "Mikrobio: mikroskopie — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-molekulare-pathogenlast-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-molekulare-pathogenlast-1"
      },
      "name" : "mii-exa-test-data-mikrobio-molekulare-pathogenlast-1",
      "description" : "Mikrobio: Molekulare Pathogenlast (350.000 Copies/mL)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-molekulare-pathogenlast-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-molekulare-pathogenlast-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-molekulare-pathogenlast-alt-1",
      "description" : "Mikrobio: molekulare-pathogenlast — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-molekulare-pathogenlast-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-molekulare-pathogenlast-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-molekulare-pathogenlast-dar-1",
      "description" : "Mikrobio: molekulare-pathogenlast — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-mrgn-klasse-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-mrgn-klasse-1"
      },
      "name" : "mii-exa-test-data-mikrobio-mrgn-klasse-1",
      "description" : "Mikrobio: MRGN-Klasse 3MRGN (E. coli)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-mrgn-klasse-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-mrgn-klasse-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-mrgn-klasse-alt-1",
      "description" : "Mikrobio: mrgn-klasse — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-mrgn-klasse-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-mrgn-klasse-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-mrgn-klasse-dar-1",
      "description" : "Mikrobio: mrgn-klasse — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-nugent-score-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-nugent-score-1"
      },
      "name" : "mii-exa-test-data-mikrobio-nugent-score-1",
      "description" : "Mikrobio: Nugent-Score (7 — bakterielle Vaginose)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-nugent-score-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-nugent-score-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-nugent-score-alt-1",
      "description" : "Mikrobio: nugent-score — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-nugent-score-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-nugent-score-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-nugent-score-dar-1",
      "description" : "Mikrobio: nugent-score — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-mii-exa-test-data-mikrobio-organization-lab-1.html"
      }],
      "reference" : {
        "reference" : "Organization/mii-exa-test-data-mikrobio-organization-lab-1"
      },
      "name" : "mii-exa-test-data-mikrobio-organization-lab-1",
      "description" : "Mikrobio Lab Organization: Mikrobiologisches Labor Charité",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-mikrobio-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-mikrobio-patient-1"
      },
      "name" : "mii-exa-test-data-mikrobio-patient-1",
      "description" : "Mikrobio Test Patient: Sepsis-Fall",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-mikrobio-probe-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-mikrobio-probe-1"
      },
      "name" : "mii-exa-test-data-mikrobio-probe-1",
      "description" : "Mikrobio Probe: Sputum (fuer spezifische Mikroskopie auf saeurefeste Staebchen)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-mikrobio-probe-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-mikrobio-probe-2"
      },
      "name" : "mii-exa-test-data-mikrobio-probe-2",
      "description" : "Mikrobio Probe: intraoperative Kolon-Gewebeprobe zur Erregerdiagnostik",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-resistenz-mech-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-resistenz-mech-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-resistenz-mech-alt-1",
      "description" : "Mikrobio: resistenzmechanismen-determinanten — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-resistenz-mech-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-resistenz-mech-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-resistenz-mech-dar-1",
      "description" : "Mikrobio: resistenzmechanismen-determinanten — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-resistenzkategorie-status-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-resistenzkategorie-status-1"
      },
      "name" : "mii-exa-test-data-mikrobio-resistenzkategorie-status-1",
      "description" : "Mikrobio: Resistenzkategorie-Status — MRSA-Status positiv",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-resistenzkategorie-status-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-resistenzkategorie-status-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-resistenzkategorie-status-alt-1",
      "description" : "Mikrobio: resistenzkategorie-status — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-resistenzkategorie-status-neg-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-resistenzkategorie-status-neg-1"
      },
      "name" : "mii-exa-test-data-mikrobio-resistenzkategorie-status-neg-1",
      "description" : "Mikrobio: resistenzkategorie-status — negatives Ergebnis (MRSA nicht nachgewiesen)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-resistenzmechanismen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-resistenzmechanismen-1"
      },
      "name" : "mii-exa-test-data-mikrobio-resistenzmechanismen-1",
      "description" : "Mikrobio: Resistenzmechanismus mecA nachgewiesen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-mikrobio-servicerequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-mikrobio-servicerequest-1"
      },
      "name" : "mii-exa-test-data-mikrobio-servicerequest-1",
      "description" : "Mikrobio Auftrag: Blutkultur + Erregerdiagnostik",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-mikrobio-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-mikrobio-specimen-1"
      },
      "name" : "mii-exa-test-data-mikrobio-specimen-1",
      "description" : "Mikrobio Specimen: Blutkultur aerob",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-mikrobio-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-mikrobio-specimen-2"
      },
      "name" : "mii-exa-test-data-mikrobio-specimen-2",
      "description" : "Mikrobio Specimen: Mittelstrahlurin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-spezifische-bestimmung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-spezifische-bestimmung-1"
      },
      "name" : "mii-exa-test-data-mikrobio-spezifische-bestimmung-1",
      "description" : "Mikrobio: Spezifische Bestimmung — S. aureus identifiziert",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-spezifische-bestimmung-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-spezifische-bestimmung-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-spezifische-bestimmung-alt-1",
      "description" : "Mikrobio: spezifische-bestimmung — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-spezifische-bestimmung-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-spezifische-bestimmung-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-spezifische-bestimmung-dar-1",
      "description" : "Mikrobio: spezifische-bestimmung — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-spezifische-mikroskopie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-spezifische-mikroskopie-1"
      },
      "name" : "mii-exa-test-data-mikrobio-spezifische-mikroskopie-1",
      "description" : "Mikrobio: Spezifische Mikroskopie — saeurefeste Staebchen im Sputum nachgewiesen (Kinyoun, 2+)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-spezifische-mikroskopie-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-spezifische-mikroskopie-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-spezifische-mikroskopie-dar-1",
      "description" : "Mikrobio: spezifische-mikroskopie — Material nicht ausreichend, Ausstrich nicht beurteilbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-titer-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-titer-1"
      },
      "name" : "mii-exa-test-data-mikrobio-titer-1",
      "description" : "Mikrobio: Antikörper-Titer (1:128)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-titer-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-titer-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-titer-alt-1",
      "description" : "Mikrobio: titer — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-titer-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-titer-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-titer-dar-1",
      "description" : "Mikrobio: titer — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-virulenzfaktor-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-virulenzfaktor-1"
      },
      "name" : "mii-exa-test-data-mikrobio-virulenzfaktor-1",
      "description" : "Mikrobio: Virulenzfaktor PVL nicht nachgewiesen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-virulenzfaktor-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-virulenzfaktor-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-virulenzfaktor-alt-1",
      "description" : "Mikrobio: virulenzfaktor — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-virulenzfaktor-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-virulenzfaktor-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-virulenzfaktor-dar-1",
      "description" : "Mikrobio: virulenzfaktor — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-voraus-empf-alt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-voraus-empf-alt-1"
      },
      "name" : "mii-exa-test-data-mikrobio-voraus-empf-alt-1",
      "description" : "Mikrobio: voraussichtliche-empfindlichkeit — Alt-Variante zur MS-Coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-voraus-empf-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-voraus-empf-dar-1"
      },
      "name" : "mii-exa-test-data-mikrobio-voraus-empf-dar-1",
      "description" : "Mikrobio: voraussichtliche-empfindlichkeit — Probe nicht auswertbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mikrobio-voraussichtliche-empfindlichkeit-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mikrobio-voraussichtliche-empfindlichkeit-1"
      },
      "name" : "mii-exa-test-data-mikrobio-voraussichtliche-empfindlichkeit-1",
      "description" : "Mikrobio: Voraussichtliche Empfindlichkeit Methicillin (R via mecA)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-molgen-device-sequencer.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-molgen-device-sequencer"
      },
      "name" : "mii-exa-test-data-molgen-device-sequencer",
      "description" : "Device: Sequencer used for BRAF mutation analysis",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-molgen-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-molgen-diagnose-1"
      },
      "name" : "mii-exa-test-data-molgen-diagnose-1",
      "description" : "Molgen Diagnose - Erbliches Tumorsyndrom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-molgen-diagnose-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-molgen-diagnose-2"
      },
      "name" : "mii-exa-test-data-molgen-diagnose-2",
      "description" : "Molgen Diagnose - NSCLC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-molgen-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-molgen-encounter-1"
      },
      "name" : "mii-exa-test-data-molgen-encounter-1",
      "description" : "Molgen Test Encounter 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-molgen-encounter-2.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-molgen-encounter-2"
      },
      "name" : "mii-exa-test-data-molgen-encounter-2",
      "description" : "Molgen Test Encounter 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-molgen-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-molgen-patient-1"
      },
      "name" : "mii-exa-test-data-molgen-patient-1",
      "description" : "Molgen Test Patient 1 (Erbliche Tumorerkrankung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-molgen-patient-2.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-molgen-patient-2"
      },
      "name" : "mii-exa-test-data-molgen-patient-2",
      "description" : "Molgen Test Patient 2 (NSCLC)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-molgen-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-molgen-specimen-1"
      },
      "name" : "mii-exa-test-data-molgen-specimen-1",
      "description" : "Molgen Specimen 1 - Blutprobe Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-molgen-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-molgen-specimen-2"
      },
      "name" : "mii-exa-test-data-molgen-specimen-2",
      "description" : "Molgen Specimen 2 - Tumorgewebe Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-molgen-specimen-3.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-molgen-specimen-3"
      },
      "name" : "mii-exa-test-data-molgen-specimen-3",
      "description" : "Molgen Specimen 3 - Blutprobe Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-mtb-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-mtb-encounter-1"
      },
      "name" : "mii-exa-test-data-mtb-encounter-1",
      "description" : "MTB Test Encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-labobs-ecog-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-labobs-ecog-1"
      },
      "name" : "mii-exa-test-data-mtb-labobs-ecog-1",
      "description" : "MTB ECOG Performance Status",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-labobs-vorbefund-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-labobs-vorbefund-1"
      },
      "name" : "mii-exa-test-data-mtb-labobs-vorbefund-1",
      "description" : "MTB Vorbefund Lab",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-mtb-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-mtb-patient-1"
      },
      "name" : "mii-exa-test-data-mtb-patient-1",
      "description" : "MTB Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-mtb-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-mtb-specimen-1"
      },
      "name" : "mii-exa-test-data-mtb-specimen-1",
      "description" : "MTB Tumorgewebe",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1"
      },
      "name" : "mii-exa-test-data-onko-anzahl-befallene-lymphknoten-1",
      "description" : "Onkologie Test - Anzahl befallene Lymphknoten",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1"
      },
      "name" : "mii-exa-test-data-onko-anzahl-befallene-sentinel-lymphknoten-1",
      "description" : "Onkologie Test - Anzahl befallene Sentinel-Lymphknoten",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1"
      },
      "name" : "mii-exa-test-data-onko-anzahl-untersuchte-lymphknoten-1",
      "description" : "Onkologie Test - Anzahl untersuchte Lymphknoten",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1"
      },
      "name" : "mii-exa-test-data-onko-anzahl-untersuchte-sentinel-lymphknoten-1",
      "description" : "Onkologie Test - Anzahl untersuchte Sentinel-Lymphknoten",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-asa-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-asa-1"
      },
      "name" : "mii-exa-test-data-onko-asa-1",
      "description" : "Onkologie Test ASA - II",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-onko-befund-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-onko-befund-1"
      },
      "name" : "mii-exa-test-data-onko-befund-1",
      "description" : "Onkologie Test Befund - Pathologiebericht",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1"
      },
      "name" : "mii-exa-test-data-onko-bestrahlung-nuklearmedizin-1",
      "description" : "Onkologie Test Nuklearmedizinische Bestrahlung - Radiojod-Therapie Schilddrüse",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-onko-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-1"
      },
      "name" : "mii-exa-test-data-onko-diagnose-1",
      "description" : "Onkologie Test Diagnose - Ovarialkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-onko-diagnose-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-2"
      },
      "name" : "mii-exa-test-data-onko-diagnose-2",
      "description" : "Onkologie Diagnose-Variante - abgeschlossen, onsetAge mit Lebensphase-Beginn und abatementDateTime",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-onko-diagnose-3.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-onko-diagnose-3"
      },
      "name" : "mii-exa-test-data-onko-diagnose-3",
      "description" : "Onkologie Diagnose-Variante - abgeschlossen mit abatementAge",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-ecog-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-ecog-1"
      },
      "name" : "mii-exa-test-data-onko-ecog-1",
      "description" : "Onkologie Test ECOG - 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-onko-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-onko-encounter-1"
      },
      "name" : "mii-exa-test-data-onko-encounter-1",
      "description" : "Onkologie Test Encounter - Inpatient oncology encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-fernmetastasen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-fernmetastasen-1"
      },
      "name" : "mii-exa-test-data-onko-fernmetastasen-1",
      "description" : "Onkologie Test Fernmetastasen - Leber",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-figo-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-figo-1"
      },
      "name" : "mii-exa-test-data-onko-figo-1",
      "description" : "Onkologie Test Weitere Klassifikationen - FIGO IVB",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-onko-fruehere-tumorerkrankung-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-onko-fruehere-tumorerkrankung-1"
      },
      "name" : "mii-exa-test-data-onko-fruehere-tumorerkrankung-1",
      "description" : "Onkologie Test - Frühere Tumorerkrankung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-genetische-variante-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-genetische-variante-1"
      },
      "name" : "mii-exa-test-data-onko-genetische-variante-1",
      "description" : "Onkologie Test Genetische Variante - BRCA1 Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-genetische-variante-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-genetische-variante-2"
      },
      "name" : "mii-exa-test-data-onko-genetische-variante-2",
      "description" : "Onkologie Test Genetische Variante - KRAS Wildtyp",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-grading-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-grading-1"
      },
      "name" : "mii-exa-test-data-onko-grading-1",
      "description" : "Onkologie Test Grading - G3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-histologie-icdo3-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-histologie-icdo3-1"
      },
      "name" : "mii-exa-test-data-onko-histologie-icdo3-1",
      "description" : "Onkologie Test Histologie ICD-O-3 - Seröses Adenokarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-karnofsky-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-karnofsky-1"
      },
      "name" : "mii-exa-test-data-onko-karnofsky-1",
      "description" : "Onkologie Test Karnofsky - 80%",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-krk-abstand-aboral-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-krk-abstand-aboral-1"
      },
      "name" : "mii-exa-test-data-onko-krk-abstand-aboral-1",
      "description" : "Onkologie Test KRK Abstand Resektionsrand aboral",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-krk-abstand-anokutan-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-krk-abstand-anokutan-1"
      },
      "name" : "mii-exa-test-data-onko-krk-abstand-anokutan-1",
      "description" : "Onkologie Test KRK Abstand Tumor zur Anokutanlinie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-krk-abstand-crm-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-krk-abstand-crm-1"
      },
      "name" : "mii-exa-test-data-onko-krk-abstand-crm-1",
      "description" : "Onkologie Test KRK Abstand circumferentielle Resektionsebene (CRM)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-krk-abstand-mesorektal-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-krk-abstand-mesorektal-1"
      },
      "name" : "mii-exa-test-data-onko-krk-abstand-mesorektal-1",
      "description" : "Onkologie Test KRK MRT Abstand zur mesorektalen Faszie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1"
      },
      "name" : "mii-exa-test-data-onko-krk-anastomoseninsuffizienz-1",
      "description" : "Onkologie Test KRK Anastomoseninsuffizienz - Keine",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-krk-operation-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-krk-operation-1"
      },
      "name" : "mii-exa-test-data-onko-krk-operation-1",
      "description" : "Onkologie Test KRK Operation - Anteriore Resektion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-onko-krk-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-onko-krk-specimen-1"
      },
      "name" : "mii-exa-test-data-onko-krk-specimen-1",
      "description" : "Onkologie Test KRK Specimen - Rektumresektat",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-krk-stoma-markierung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-krk-stoma-markierung-1"
      },
      "name" : "mii-exa-test-data-onko-krk-stoma-markierung-1",
      "description" : "Onkologie Test KRK Stoma Markierung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-mamma-her2neu-status-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-mamma-her2neu-status-1"
      },
      "name" : "mii-exa-test-data-onko-mamma-her2neu-status-1",
      "description" : "Onkologie Test Mamma Her2neu Status - Negativ",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-mamma-her2neu-status-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-mamma-her2neu-status-2"
      },
      "name" : "mii-exa-test-data-onko-mamma-her2neu-status-2",
      "description" : "Onkologie Test Mamma Her2neu Status - Positiv (3+)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-mamma-menopause-status-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-mamma-menopause-status-1"
      },
      "name" : "mii-exa-test-data-onko-mamma-menopause-status-1",
      "description" : "Onkologie Test Mamma Menopausenstatus - Prämenopausal",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-mamma-operation-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-mamma-operation-1"
      },
      "name" : "mii-exa-test-data-onko-mamma-operation-1",
      "description" : "Onkologie Test Mamma Operation - Brusterhaltende Therapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-mamma-praeop-markierung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-mamma-praeop-markierung-1"
      },
      "name" : "mii-exa-test-data-onko-mamma-praeop-markierung-1",
      "description" : "Onkologie Test Mamma Präoperative Markierung - Drahtmarkierung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1"
      },
      "name" : "mii-exa-test-data-onko-mamma-rezeptorstatus-estrogen-1",
      "description" : "Onkologie Test Mamma Östrogenrezeptorstatus - Positiv",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1"
      },
      "name" : "mii-exa-test-data-onko-mamma-rezeptorstatus-progesteron-1",
      "description" : "Onkologie Test Mamma Progesteronrezeptorstatus - Positiv",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-mamma-sozialdienst-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-mamma-sozialdienst-1"
      },
      "name" : "mii-exa-test-data-onko-mamma-sozialdienst-1",
      "description" : "Onkologie Test Mamma Sozialdienst - Psychosoziale Beratung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-onko-medikation-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-onko-medikation-1"
      },
      "name" : "mii-exa-test-data-onko-medikation-1",
      "description" : "Onkologie Test Medikation - Paclitaxel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-onko-medikation-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-onko-medikation-2"
      },
      "name" : "mii-exa-test-data-onko-medikation-2",
      "description" : "Onkologie Test Medikation - Carboplatin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-onko-medikation-3.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-onko-medikation-3"
      },
      "name" : "mii-exa-test-data-onko-medikation-3",
      "description" : "Onkologie Test Medikation - Niraparib (PARP-Inhibitor)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-breslow-tiefe-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-breslow-tiefe-1"
      },
      "name" : "mii-exa-test-data-onko-melanom-breslow-tiefe-1",
      "description" : "Onkologie Test Melanom Breslow Tiefe",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-breslow-tiefe-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-breslow-tiefe-2"
      },
      "name" : "mii-exa-test-data-onko-melanom-breslow-tiefe-2",
      "description" : "Onkologie Test Melanom Breslow Tiefe - Nicht bestimmbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-melanom-exzision-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-melanom-exzision-1"
      },
      "name" : "mii-exa-test-data-onko-melanom-exzision-1",
      "description" : "Onkologie Test Melanom Exzision - Oberarm",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-ldh-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-ldh-1"
      },
      "name" : "mii-exa-test-data-onko-melanom-ldh-1",
      "description" : "Onkologie Test Melanom LDH - Normal",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-ldh-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-ldh-2"
      },
      "name" : "mii-exa-test-data-onko-melanom-ldh-2",
      "description" : "Onkologie Test Melanom LDH - Erhöht",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-sicherheitsabstand-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-sicherheitsabstand-1"
      },
      "name" : "mii-exa-test-data-onko-melanom-sicherheitsabstand-1",
      "description" : "Onkologie Test Melanom Sicherheitsabstand",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-sicherheitsabstand-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-sicherheitsabstand-2"
      },
      "name" : "mii-exa-test-data-onko-melanom-sicherheitsabstand-2",
      "description" : "Onkologie Test Melanom Sicherheitsabstand - Nicht bestimmbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-ulzeration-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-ulzeration-1"
      },
      "name" : "mii-exa-test-data-onko-melanom-ulzeration-1",
      "description" : "Onkologie Test Melanom Ulzeration - Vorhanden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-ulzeration-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-ulzeration-2"
      },
      "name" : "mii-exa-test-data-onko-melanom-ulzeration-2",
      "description" : "Onkologie Test Melanom Ulzeration - Nicht vorhanden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-melanom-ulzeration-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-melanom-ulzeration-dar-1"
      },
      "name" : "mii-exa-test-data-onko-melanom-ulzeration-dar-1",
      "description" : "Onkologie Test Melanom Ulzeration - nicht beurteilbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AdverseEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AdverseEvent-mii-exa-test-data-onko-nebenwirkung-1.html"
      }],
      "reference" : {
        "reference" : "AdverseEvent/mii-exa-test-data-onko-nebenwirkung-1"
      },
      "name" : "mii-exa-test-data-onko-nebenwirkung-1",
      "description" : "Onkologie Test Nebenwirkung - Fatigue nach Chemotherapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AdverseEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AdverseEvent-mii-exa-test-data-onko-nebenwirkung-2.html"
      }],
      "reference" : {
        "reference" : "AdverseEvent/mii-exa-test-data-onko-nebenwirkung-2"
      },
      "name" : "mii-exa-test-data-onko-nebenwirkung-2",
      "description" : "Onkologie Test Nebenwirkung - Polyneuropathie nach Strahlentherapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-operation-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-operation-1"
      },
      "name" : "mii-exa-test-data-onko-operation-1",
      "description" : "Onkologie Test Operation - Debulking Ovarialkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-onko-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-onko-patient-1"
      },
      "name" : "mii-exa-test-data-onko-patient-1",
      "description" : "Onkologie Test Patient - Synthetic patient for comprehensive oncology testing",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-anzahl-stanzen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-anzahl-stanzen-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-anzahl-stanzen-1",
      "description" : "Onkologie Test Prostata Anzahl Stanzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-ca-befall-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-ca-befall-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-ca-befall-1",
      "description" : "Onkologie Test Prostata Ca-Befall stärkstbefallene Stanze",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-gleason-gesamt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-gleason-gesamt-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-gleason-gesamt-1",
      "description" : "Onkologie Test Prostata Gleason-Score gesamt - Gleason 7 (3+4)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-gleason-grade-group-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-gleason-grade-group-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-gleason-grade-group-1",
      "description" : "Onkologie Test Prostata Gleason Grade Group 2 (3+4=7)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-gleason-primary-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-gleason-primary-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-gleason-primary-1",
      "description" : "Onkologie Test Prostata Gleason Primary Pattern (3)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-gleason-secondary-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-gleason-secondary-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-gleason-secondary-1",
      "description" : "Onkologie Test Prostata Gleason Secondary Pattern (4)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-komplikation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-komplikation-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-komplikation-1",
      "description" : "Onkologie Test Prostata OP Komplikation - Clavien-Dindo IIIa",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-positive-stanzen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-positive-stanzen-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-positive-stanzen-1",
      "description" : "Onkologie Test Prostata Anzahl Positiver Stanzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-prostata-psa-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-prostata-psa-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-psa-1",
      "description" : "Onkologie Test Prostata PSA bei Diagnose",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-prostata-surgery-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-prostata-surgery-1"
      },
      "name" : "mii-exa-test-data-onko-prostata-surgery-1",
      "description" : "Onkologie Test Prostata OP - Radikale Prostatektomie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-residualstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-residualstatus-1"
      },
      "name" : "mii-exa-test-data-onko-residualstatus-1",
      "description" : "Onkologie Test Residualstatus - R0",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-onko-sequencer-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-onko-sequencer-1"
      },
      "name" : "mii-exa-test-data-onko-sequencer-1",
      "description" : "Onkologie Test Device - NGS-Sequenzierer",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-onko-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-onko-specimen-1"
      },
      "name" : "mii-exa-test-data-onko-specimen-1",
      "description" : "Onkologie Test Specimen - Tumorresektat",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-strahlentherapie-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-strahlentherapie-1"
      },
      "name" : "mii-exa-test-data-onko-strahlentherapie-1",
      "description" : "Onkologie Test Strahlentherapie - Adjuvante Bestrahlung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-strahlentherapie-bestrahlung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-strahlentherapie-bestrahlung-1"
      },
      "name" : "mii-exa-test-data-onko-strahlentherapie-bestrahlung-1",
      "description" : "Onkologie Test Strahlentherapie Bestrahlung - mit allen Dosisangaben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-studienteilnahme-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-studienteilnahme-1"
      },
      "name" : "mii-exa-test-data-onko-studienteilnahme-1",
      "description" : "Onkologie Test Studienteilnahme - Patient nimmt an Studie teil",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-studienteilnahme-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-studienteilnahme-2"
      },
      "name" : "mii-exa-test-data-onko-studienteilnahme-2",
      "description" : "Onkologie Test Studienteilnahme - Keine Studienteilnahme",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-onko-systemische-therapie-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-onko-systemische-therapie-1"
      },
      "name" : "mii-exa-test-data-onko-systemische-therapie-1",
      "description" : "Onkologie Test Systemische Therapie - Neoadjuvante Chemotherapie CarboTax",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RequestGroup-mii-exa-test-data-onko-therapieempfehlung-kombi-1.html"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-test-data-onko-therapieempfehlung-kombi-1"
      },
      "name" : "mii-exa-test-data-onko-therapieempfehlung-kombi-1",
      "description" : "Onkologie Test Therapieempfehlung Kombinationstherapie - CarboTax Schema",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-medikation-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-1"
      },
      "name" : "mii-exa-test-data-onko-therapieempfehlung-medikation-1",
      "description" : "Onkologie Test Therapieempfehlung Medikation - Carboplatin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-medikation-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-medikation-2"
      },
      "name" : "mii-exa-test-data-onko-therapieempfehlung-medikation-2",
      "description" : "Onkologie Test Therapieempfehlung Medikation - Paclitaxel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-onko-therapieempfehlung-niraparib.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-onko-therapieempfehlung-niraparib"
      },
      "name" : "mii-exa-test-data-onko-therapieempfehlung-niraparib",
      "description" : "Onkologie Test Therapieempfehlung Medikation - Niraparib",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-onko-therapieempfehlung-op-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-onko-therapieempfehlung-op-1"
      },
      "name" : "mii-exa-test-data-onko-therapieempfehlung-op-1",
      "description" : "Onkologie Test Therapieempfehlung Operation - Debulking",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RequestGroup-mii-exa-test-data-onko-therapieempfehlung-parp-1.html"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-test-data-onko-therapieempfehlung-parp-1"
      },
      "name" : "mii-exa-test-data-onko-therapieempfehlung-parp-1",
      "description" : "Onkologie Test Therapieempfehlung - PARP-Inhibitor Erhaltung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-a-symbol-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-a-symbol-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-a-symbol-1",
      "description" : "Onkologie Test TNM a-Symbol - keine Autopsie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-klassifikation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-klassifikation-1",
      "description" : "Onkologie Test TNM Klassifikation - ypT3c pN1 M1b, Stadium IVB",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-klassifikation-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-2"
      },
      "name" : "mii-exa-test-data-onko-tnm-klassifikation-2",
      "description" : "Onkologie Test TNM Klassifikation klinisch - ycT2(m) rcN0 ycM0, Stadium IB",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-klassifikation-synthetisiert-1",
      "description" : "Onkologie Test TNM synthetisiert - aus klinischer (IB) und pathologischer (IVB) Klassifikation, Gesamt-Stadium IVB",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-l-kategorie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-l-kategorie-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-l-kategorie-1",
      "description" : "Onkologie Test TNM L-Kategorie - L1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-m-kategorie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-m-kategorie-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-m-kategorie-1",
      "description" : "Onkologie Test TNM M-Kategorie - pM1b",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-m-kategorie-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-m-kategorie-2"
      },
      "name" : "mii-exa-test-data-onko-tnm-m-kategorie-2",
      "description" : "Onkologie Test TNM M-Kategorie klinisch - ycM0",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-m-symbol-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-m-symbol-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-m-symbol-1",
      "description" : "Onkologie Test TNM m-Symbol - multiple Primärtumoren",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-n-kategorie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-n-kategorie-1",
      "description" : "Onkologie Test TNM N-Kategorie - pN1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-n-kategorie-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-2"
      },
      "name" : "mii-exa-test-data-onko-tnm-n-kategorie-2",
      "description" : "Onkologie Test TNM N-Kategorie klinisch - rcN0 (Rezidiv-Staging)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-n-kategorie-sn-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-n-kategorie-sn-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-n-kategorie-sn-1",
      "description" : "Onkologie Test TNM N-Kategorie - pN0(i-)(sn) Sentinel Node",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-pn-kategorie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-pn-kategorie-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-pn-kategorie-1",
      "description" : "Onkologie Test TNM Pn-Kategorie - Pn0",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-r-symbol-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-r-symbol-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-r-symbol-1",
      "description" : "Onkologie Test TNM r-Symbol - kein Rezidiv",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-s-kategorie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-s-kategorie-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-s-kategorie-1",
      "description" : "Onkologie Test TNM S-Kategorie - S1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-t-kategorie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-t-kategorie-1",
      "description" : "Onkologie Test TNM T-Kategorie - pT3c",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-t-kategorie-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-2"
      },
      "name" : "mii-exa-test-data-onko-tnm-t-kategorie-2",
      "description" : "Onkologie Test TNM T-Kategorie klinisch - ycT2(m), nach neoadjuvanter Therapie, multiple Tumoren",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-t-kategorie-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-t-kategorie-3"
      },
      "name" : "mii-exa-test-data-onko-tnm-t-kategorie-3",
      "description" : "Onkologie Test TNM T-Kategorie - aT3 (Autopsiebefund)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-v-kategorie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-v-kategorie-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-v-kategorie-1",
      "description" : "Onkologie Test TNM V-Kategorie - V0",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tnm-y-symbol-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tnm-y-symbol-1"
      },
      "name" : "mii-exa-test-data-onko-tnm-y-symbol-1",
      "description" : "Onkologie Test TNM y-Symbol - Zustand nach neoadjuvanter Therapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tod-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tod-1"
      },
      "name" : "mii-exa-test-data-onko-tod-1",
      "description" : "Onkologie Test Tod - Verstorben an Tumorerkrankung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tod-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tod-2"
      },
      "name" : "mii-exa-test-data-onko-tod-2",
      "description" : "Onkologie Test Tod - Todesursache unbekannt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tumorgroesse-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tumorgroesse-1"
      },
      "name" : "mii-exa-test-data-onko-tumorgroesse-1",
      "description" : "Onkologie Test Tumorgröße - 22mm",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-mii-exa-test-data-onko-tumorkonferenz-1.html"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-1"
      },
      "name" : "mii-exa-test-data-onko-tumorkonferenz-1",
      "description" : "Onkologie Test Tumorkonferenz - Prätherapeutisch mit OP + Chemo Empfehlung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-mii-exa-test-data-onko-tumorkonferenz-2.html"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-2"
      },
      "name" : "mii-exa-test-data-onko-tumorkonferenz-2",
      "description" : "Onkologie Test Tumorkonferenz - Postoperativ mit Therapieabweichung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-mii-exa-test-data-onko-tumorkonferenz-molekular-1.html"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-test-data-onko-tumorkonferenz-molekular-1"
      },
      "name" : "mii-exa-test-data-onko-tumorkonferenz-molekular-1",
      "description" : "Onkologie Test Molekulares Tumorboard - mit erweiterter Therapieempfehlung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tumormarker-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tumormarker-1"
      },
      "name" : "mii-exa-test-data-onko-tumormarker-1",
      "description" : "Onkologie Test Tumormarker - CA-125 erhöht (356 U/mL)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tumormarker-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tumormarker-2"
      },
      "name" : "mii-exa-test-data-onko-tumormarker-2",
      "description" : "Onkologie Test Tumormarker - semiquantitatives Ergebnis (valueCodeableConcept)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tumormarker-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tumormarker-3"
      },
      "name" : "mii-exa-test-data-onko-tumormarker-3",
      "description" : "Onkologie Test Tumormarker - Bereichsangabe (valueRange)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tumormarker-4.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tumormarker-4"
      },
      "name" : "mii-exa-test-data-onko-tumormarker-4",
      "description" : "Onkologie Test Tumormarker - Verhaeltnisangabe (valueRatio)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-tumormarker-5.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-tumormarker-5"
      },
      "name" : "mii-exa-test-data-onko-tumormarker-5",
      "description" : "Onkologie Test Tumormarker - nicht bestimmbar (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-verlauf-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-verlauf-1"
      },
      "name" : "mii-exa-test-data-onko-verlauf-1",
      "description" : "Onkologie Test Verlauf - Vollremission nach Therapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-onko-verlauf-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-onko-verlauf-2"
      },
      "name" : "mii-exa-test-data-onko-verlauf-2",
      "description" : "Onkologie Test Verlauf - Teilremission mit Lymphknotenprogress",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-mii-exa-test-data-organization-biobank-charite.html"
      }],
      "reference" : {
        "reference" : "Organization/mii-exa-test-data-organization-biobank-charite"
      },
      "name" : "mii-exa-test-data-organization-biobank-charite",
      "description" : "Organization: Zentrale Biobank der Charité",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-mii-exa-test-data-organization-charite.html"
      }],
      "reference" : {
        "reference" : "Organization/mii-exa-test-data-organization-charite"
      },
      "name" : "mii-exa-test-data-organization-charite",
      "description" : "Organization: Charité – Universitätsmedizin Berlin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-mii-exa-test-data-organization-labor-berlin.html"
      }],
      "reference" : {
        "reference" : "Organization/mii-exa-test-data-organization-labor-berlin"
      },
      "name" : "mii-exa-test-data-organization-labor-berlin",
      "description" : "Organization: Labor Berlin – Charité Vivantes GmbH",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-pat1-pro-p29-pain-int-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-pat1-pro-p29-pain-int-tscore"
      },
      "name" : "mii-exa-test-data-pat1-pro-p29-pain-int-tscore",
      "description" : "PRO Observation: PROMIS-29 Pain Interference T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-pat1-pro-p29-phys-fn-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-pat1-pro-p29-phys-fn-tscore"
      },
      "name" : "mii-exa-test-data-pat1-pro-p29-phys-fn-tscore",
      "description" : "PRO Observation: PROMIS-29 Physical Function T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-pat1-pro-p29-sleep-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-pat1-pro-p29-sleep-tscore"
      },
      "name" : "mii-exa-test-data-pat1-pro-p29-sleep-tscore",
      "description" : "PRO Observation: PROMIS-29 Sleep Disturbance T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patho-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patho-encounter-1"
      },
      "name" : "mii-exa-test-data-patho-encounter-1",
      "description" : "Patho Test Encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-mii-exa-test-data-patho-organization-1.html"
      }],
      "reference" : {
        "reference" : "Organization/mii-exa-test-data-patho-organization-1"
      },
      "name" : "mii-exa-test-data-patho-organization-1",
      "description" : "Pathologisches Institut (Testdaten)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patho-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patho-patient-1"
      },
      "name" : "mii-exa-test-data-patho-patient-1",
      "description" : "Patho Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-mii-exa-test-data-patho-practitioner-1.html"
      }],
      "reference" : {
        "reference" : "Practitioner/mii-exa-test-data-patho-practitioner-1"
      },
      "name" : "mii-exa-test-data-patho-practitioner-1",
      "description" : "Pathologe (Testdaten)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-mii-exa-test-data-patho-practitioner-2.html"
      }],
      "reference" : {
        "reference" : "Practitioner/mii-exa-test-data-patho-practitioner-2"
      },
      "name" : "mii-exa-test-data-patho-practitioner-2",
      "description" : "Urologe / Einsender (Testdaten)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-1"
      },
      "name" : "mii-exa-test-data-patient-1",
      "description" : "Patient: Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AllergyIntolerance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AllergyIntolerance-mii-exa-test-data-patient-1-allergie-1.html"
      }],
      "reference" : {
        "reference" : "AllergyIntolerance/mii-exa-test-data-patient-1-allergie-1"
      },
      "name" : "mii-exa-test-data-patient-1-allergie-1",
      "description" : "AllergyIntolerance: Penicillin-Allergie (Urtikaria, moderat) fuer Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-1-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-1-consent-1"
      },
      "name" : "mii-exa-test-data-patient-1-consent-1",
      "description" : "Consent: Einwilligung für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-test-data-patient-1-consent-docref-1.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-test-data-patient-1-consent-docref-1"
      },
      "name" : "mii-exa-test-data-patient-1-consent-docref-1",
      "description" : "DocumentReference: Gescannter, unterschriebener Einwilligungsbogen zu Consent von Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-mii-exa-test-data-patient-1-consent-provenance-1.html"
      }],
      "reference" : {
        "reference" : "Provenance/mii-exa-test-data-patient-1-consent-provenance-1"
      },
      "name" : "mii-exa-test-data-patient-1-consent-provenance-1",
      "description" : "Provenance: Herkunft der Einwilligung von Patient 1 (aus gescanntem Einwilligungsbogen)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-test-data-patient-1-consent-qr-1.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-test-data-patient-1-consent-qr-1"
      },
      "name" : "mii-exa-test-data-patient-1-consent-qr-1",
      "description" : "QuestionnaireResponse: Erfassung des Einwilligungsbogens zu Consent von Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-1-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-1-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-1-diagnose-1",
      "description" : "Condition: Masern mit Otitis für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-1-diagnose-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-1-diagnose-2"
      },
      "name" : "mii-exa-test-data-patient-1-diagnose-2",
      "description" : "Condition: Otitis media bei anderenorts klassifizierten Viruskrankheiten für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-test-data-patient-1-dokument-1.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-test-data-patient-1-dokument-1"
      },
      "name" : "mii-exa-test-data-patient-1-dokument-1",
      "description" : "DocumentReference: Entlassbrief Innere Medizin - alle MS-Elemente",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-test-data-patient-1-dokument-2.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-test-data-patient-1-dokument-2"
      },
      "name" : "mii-exa-test-data-patient-1-dokument-2",
      "description" : "DocumentReference: Befundbericht Radiologie (URL-Verweis) - alle MS-Elemente",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-1-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-1-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-1-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-1-encounter-2.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-1-encounter-2"
      },
      "name" : "mii-exa-test-data-patient-1-encounter-2",
      "description" : "Encounter: Versorgungsstellenkontakt Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-fluess-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Fluessigkeit Gesamt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-galle-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Gallenfluessigkeit",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-gallengang-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Gallengang",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-magen-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Magensonde",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-opdrain-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Opdrainage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-pankreas-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Pankreasdrainage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-stuhl-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Stuhlgang",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-urin-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Urin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ausf-wunde-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Wunddrainage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-blutverlust-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Blutverlust",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-drainage-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-drainage-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-drainage-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Ausfuhr Drainage Generisch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-enteral-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Einfuhr Enterale Fluessigkeit",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-fluess-1",
      "description" : "ICU Observation: SD MII ICU Bilanz Einfuhr Fluessigkeit Gesamt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Einfuhr Muttermilch (technische Abdeckung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-mumi-abgep-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Einfuhr Abgepumpte Muttermilch (technische Abdeckung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-oral-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Einfuhr Oraler Fluessigkeit",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-oral-fluess-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Einfuhr Orale Fluessigkeit",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-saeugling-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Einfuhr Saeuglingsnahrung (technische Abdeckung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-einf-spendermilch-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Einfuhr Spendermilch (technische Abdeckung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ges-ausf-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Gesamte Ausfuhr",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-ges-einf-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Gesamte Einfuhr",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-haemofiltr-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Abnahme Haemofiltration Einzelmesswerte",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-status-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-status-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-status-1",
      "description" : "ICU Observation: MII PR ICU Bilanz (generisch) - Fluessigkeitsbilanz-Status",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-bilanz-tages-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-bilanz-tages-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-bilanz-tages-1",
      "description" : "ICU Observation: MII PR ICU Bilanz Gesamte Tages Bilanz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-patient-1-icu-device-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-device-1",
      "description" : "ICU Device: Beatmungsgeraet Draeger Evita V500",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-patient-1-icu-device-ecmo-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-ecmo-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-device-ecmo-1",
      "description" : "ICU Device: VV-ECMO-Konsole (Getinge Cardiohelp)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-patient-1-icu-device-monitor-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-monitor-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-device-monitor-1",
      "description" : "ICU Device: Patientenmonitor (Multiparameter, Bett 3)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-patient-1-icu-device-pdms-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-patient-1-icu-device-pdms-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-device-pdms-1",
      "description" : "ICU Device: Patientendaten-Management-System (Fluessigkeitsbilanzierung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-art-druck-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-art-druck-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-art-druck-1",
      "description" : "ICU Observation: MII PR ICU Arterieller Druck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-blutfl-cardio-1",
      "description" : "ICU Observation: MII PR ICU Blutfluss Cardiovasculaeres Geraet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-blutfl-extra-1",
      "description" : "ICU Observation: MII PR ICU Blutfluss Extrakorporaler Gasaustausch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-blutfl-idx-1",
      "description" : "ICU Observation: MII PR ICU Blutflussindex Extrakorporaler Gasaustausch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-dauer-extra-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-dauer-extra-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-dauer-extra-1",
      "description" : "ICU Observation: MII PR ICU Dauer Extrakorporaler Gasaustausch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-dauer-haemo-1",
      "description" : "ICU Observation: MII ICU Dauer Haemodialysesitzung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DeviceMetric"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DeviceMetric-mii-exa-test-data-patient-1-icu-ect-dm-param-1.html"
      }],
      "reference" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-ect-dm-param-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-dm-param-1",
      "description" : "ICU DeviceMetric: Eingestellte Gemessene Parameter Extrakorporale Verfahren",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-1-icu-ect-extrakorp-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-ect-extrakorp-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-extrakorp-1",
      "description" : "ICU Procedure: MII PR ICU Extrakorporales Verfahren",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-gasfluss-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-gasfluss-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-gasfluss-1",
      "description" : "ICU Observation: MII PR ICU Gasfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-haemo-blutfl-1",
      "description" : "ICU Observation: MII PR ICU Haemodialyse Blutfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-kalzium-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-kalzium-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-kalzium-1",
      "description" : "ICU Observation: MII PR ICU Ionisiertes Kalzium Nierenersatzverfahren",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-param-generisch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-param-generisch-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-param-generisch-1",
      "description" : "ICU Observation: MII PR ICU Parameter von Extrakorporalen Verfahren (generisch) - Sweep-Gasfluss abends",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-substituatfl-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-substituatfl-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-substituatfl-1",
      "description" : "ICU Observation: MII PR ICU Substituatfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-substituatvol-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-substituatvol-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-substituatvol-1",
      "description" : "ICU Observation: MII PR ICU Substituatvolumen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-ect-ven-druck-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-ect-ven-druck-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-ect-ven-druck-1",
      "description" : "ICU Observation: MII PR ICU Venous Pressure",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-event-o2-partial-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-event-o2-partial-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-event-o2-partial-1",
      "description" : "ICU Observation: MII PR ICU Exspiratorischer Sauerstoffpartialdruck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-event-o2-partial-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Exspiratorischer Sauerstoffpartialdruck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-atemfreq-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-atemfreq-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-atemfreq-1",
      "description" : "ICU Observation: MII PR ICU Atemfrequenz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-blutdruck-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-blutdruck-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-blutdruck-1",
      "description" : "ICU Observation: MII PR ICU Arterieller Blutdruck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-blutdruck-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Arterieller Blutdruck beim Wechsel des Druckaufnehmers nicht verfuegbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-gewicht-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-gewicht-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-gewicht-1",
      "description" : "ICU Observation: MII PR ICU Koerpergewicht",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-gewicht-var-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-gewicht-var-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-gewicht-var-1",
      "description" : "ICU Observation: Koerpergewicht (effectivePeriod-Variante)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-groesse-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-groesse-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-groesse-1",
      "description" : "ICU Observation: MII PR ICU Koerpergroesse",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-groesse-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-groesse-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-groesse-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Koerpergroesse bei beatmeter Patientin nicht messbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-groesse-var-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-groesse-var-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-groesse-var-1",
      "description" : "ICU Observation: Koerpergroesse (effectivePeriod-Variante)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-herzfreq-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-herzfreq-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-herzfreq-1",
      "description" : "ICU Observation: MII SD ICU Herzfrequenz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-herzfreq-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Herzfrequenz waehrend Transport nicht abgeleitet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-kopfumfang-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-kopfumfang-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-kopfumfang-1",
      "description" : "ICU Observation: MII PR ICU Kopfumfang",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-kopfumfang-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Kopfumfang nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-laenge-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-laenge-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-laenge-1",
      "description" : "ICU Observation: MII PR ICU Koerperlaenge (liegend, 168 cm bei Aufnahme)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-laenge-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-laenge-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-laenge-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Koerperlaenge in Bauchlage nicht messbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-muv-laenge-var-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-muv-laenge-var-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-muv-laenge-var-1",
      "description" : "ICU Observation: Koerperlaenge liegend (effectivePeriod-Variante)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-befund-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-befund-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-befund-1",
      "description" : "ICU Pupillenbefund: Grouper mit 9 Einzelbefunden (Anisokorie)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-befund-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-befund-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-befund-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): Grouper - Pupillen bei Lidoedem nicht beurteilbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-form-li-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-form-li-1",
      "description" : "ICU Pupillenbefund: Pupillenform links rund",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-form-li-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): Pupillenform links nicht beurteilbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-form-re-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-form-re-1",
      "description" : "ICU Pupillenbefund: Pupillenform rechts rund",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-form-re-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): Pupillenform rechts nicht beurteilbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-li-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-groesse-li-1",
      "description" : "ICU Pupillenbefund: Pupillengroesse links 5 mm (Anisokorie)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-groesse-li-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): Pupillengroesse links nicht messbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-re-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-groesse-re-1",
      "description" : "ICU Pupillenbefund: Pupillengroesse rechts 3 mm",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-groesse-re-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): Pupillengroesse rechts nicht messbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-1",
      "description" : "ICU Pupillenbefund: direkte Lichtreaktion links traege",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-li-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): direkte Lichtreaktion links nicht pruefbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-1",
      "description" : "ICU Pupillenbefund: direkte Lichtreaktion rechts prompt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-dir-re-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): direkte Lichtreaktion rechts nicht pruefbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-1",
      "description" : "ICU Pupillenbefund: indirekte (konsensuelle) Lichtreaktion links traege",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-li-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): indirekte Lichtreaktion links nicht pruefbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-1",
      "description" : "ICU Pupillenbefund: indirekte (konsensuelle) Lichtreaktion rechts prompt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-licht-ind-re-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): indirekte Lichtreaktion rechts nicht pruefbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-symmetrie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-symmetrie-1",
      "description" : "ICU Pupillenbefund: Pupillensymmetrie - Anisokorie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-pupille-symmetrie-dar-1",
      "description" : "ICU Pupillenbefund (dataAbsentReason): Pupillensymmetrie nicht beurteilbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-cam-icu-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-cam-icu-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-cam-icu-1",
      "description" : "ICU Score: CAM-ICU positiv (Feature 1-3 vorhanden, Feature 4 nicht beurteilt positiv)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-fpsr-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-fpsr-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-fpsr-1",
      "description" : "ICU Score: Faces Pain Scale - Revised 6/10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-fpsr-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-fpsr-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-fpsr-dar-1",
      "description" : "ICU Score (dataAbsentReason): FPS-R 4/10, NRS-Gegenprobe nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-gcs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-gcs-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-gcs-1",
      "description" : "ICU Score: Glasgow Coma Scale 8 (E2 V2 M4) unter Sedierung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-gcs-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-gcs-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-gcs-dar-1",
      "description" : "ICU Score (dataAbsentReason): GCS 6T - verbale Reaktion bei intubierter Patientin nicht beurteilbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-icdsc-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-icdsc-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-icdsc-1",
      "description" : "ICU Score: ICDSC 6 (Delir-Schwelle ueberschritten)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-nrs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-nrs-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-nrs-1",
      "description" : "ICU Score: Numerische Ratingskala Schmerz 4/10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-nrs-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-nrs-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-nrs-dar-1",
      "description" : "ICU Score: Numerische Ratingskala nicht erhebbar (Sedierung, dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-rass-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-rass-1",
      "description" : "ICU Score: RASS -3 (moderate Sedierung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-rass-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-rass-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-rass-dar-1",
      "description" : "ICU Score (dataAbsentReason): RASS unter Muskelrelaxierung nicht beurteilbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-sofa-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-sofa-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-sofa-1",
      "description" : "ICU Score: SOFA 9 (Respiration 3, Gerinnung 1, Leber 0, Kreislauf 1, ZNS 3, Niere 1)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-vas-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-vas-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-vas-1",
      "description" : "ICU Score: Visuelle Analogskala Schmerz 45 mm",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-vas-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-vas-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-vas-dar-1",
      "description" : "ICU Score (dataAbsentReason): Visuelle Analogskala unter Analgosedierung nicht erhebbar",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-wbf-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-wbf-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-wbf-1",
      "description" : "ICU Score: Wong-Baker FACES Schmerzskala 6/10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-zopa-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-zopa-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-zopa-1",
      "description" : "ICU Score: ZOPA - Schmerzverhalten vorhanden (sedierte Patientin)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-score-zopa-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-score-zopa-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-score-zopa-dar-1",
      "description" : "ICU Score (dataAbsentReason): ZOPA erhoben, NRS-Selbsteinschaetzung nicht moeglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-1",
      "description" : "ICU Observation: MII PR ICU Atemwegsdruck Bei Mittlerem Expiratorischem Gasfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-atemdr-mitt-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Atemwegsdruck bei mittlerem expiratorischem Gasfluss - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-atemdr-null-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-null-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-atemdr-null-1",
      "description" : "ICU Observation: MII PR ICU Atemwegsdruck Bei Null Expiratorischem Gasfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-atemdr-null-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Atemwegsdruck bei Null-Gasfluss (exspiratorisch) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-1-icu-vent-beatmung-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-1-icu-vent-beatmung-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-beatmung-1",
      "description" : "ICU Procedure: MII PR ICU Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-compliance-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-compliance-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-compliance-1",
      "description" : "ICU Observation: dynamische-kompliance",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-compliance-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-compliance-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-compliance-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Dynamische Kompliance - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DeviceMetric"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DeviceMetric-mii-exa-test-data-patient-1-icu-vent-dm-param-1.html"
      }],
      "reference" : {
        "reference" : "DeviceMetric/mii-exa-test-data-patient-1-icu-vent-dm-param-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-dm-param-1",
      "description" : "ICU DeviceMetric: Eingestellte Gemessene Parameter Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-dp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-dp-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-dp-1",
      "description" : "ICU Observation: MII PR ICU Druckdifferenz Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-dp-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-dp-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-dp-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Druckdifferenz der Beatmung - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-etco2-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-etco2-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-etco2-1",
      "description" : "ICU Observation: MII PR ICU Endexpiratorischer Kohlendioxidpartialdruck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-etco2-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-etco2-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-etco2-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Endexspiratorischer Kohlendioxidpartialdruck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-exp-flow-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-exp-flow-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-exp-flow-1",
      "description" : "ICU Observation: MII PR ICU Exspiratorischer Gasfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-exp-flow-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Exspiratorischer Gasfluss - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-fio2-eingest-1",
      "description" : "ICU Observation: inspiratorische-sauerstofffraktion-eingestellt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-fio2-gem-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-fio2-gem-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-fio2-gem-1",
      "description" : "ICU Observation: MIIm PR ICU Inspiratorische Sauerstofffraktion Gemessen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-fio2-gem-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Inspiratorische Sauerstofffraktion (gemessen) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-freq-mech-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-mech-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-freq-mech-1",
      "description" : "ICU Observation: MII PR ICU Mechanische Atemfrequenz Beatmet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-freq-mech-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Mechanische Atemfrequenz - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-freq-spont-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-1",
      "description" : "ICU Observation: MII PR ICU Spontane Atemfrequenz Beatmet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Spontane Atemfrequenz (beatmet) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-1",
      "description" : "ICU Observation: MII PR ICU Spontane Mechanische Atemfrequenz Beatmet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-freq-spont-mech-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Spontane und mechanische Atemfrequenz (beatmet) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-horowitz-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-horowitz-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-horowitz-1",
      "description" : "ICU Observation: MII PR ICU Horowitz In Arteriellem Blut",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-horowitz-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Horowitz-Index in arteriellem Blut - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-ie-ratio-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-ie-ratio-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-ie-ratio-1",
      "description" : "ICU Observation: MII PR ICU Zeitverhaeltnis Ein Ausatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-ie-ratio-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Zeitverhaeltnis Ein-/Ausatmung (I:E) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-insp-flow-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-1",
      "description" : "ICU Observation: MII PR ICU Inspiratorischer Gasfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Inspiratorischer Gasfluss - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-set-1",
      "description" : "ICU Observation: MII PR ICU Eingestellter Inspiratorischer Gasfluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-insp-flow-set-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Eingestellter inspiratorischer Gasfluss - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-map-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-map-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-map-1",
      "description" : "ICU Observation: MII PR ICU Mittlerer Beatmungsdruck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-map-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-map-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-map-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Mittlerer Beatmungsdruck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-mv-masch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-mv-masch-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-mv-masch-1",
      "description" : "ICU Observation: MII PR ICU Beatmungsvolumen Pro Minute Maschineller Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-mv-masch-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Beatmungsvolumen pro Minute (maschinelle Beatmung) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-param-generisch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-param-generisch-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-param-generisch-1",
      "description" : "ICU Observation: MII PR ICU Parameter von Beatmung (generisch) - inspiratorisches Minutenvolumen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-param-generisch-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Parameter von Beatmung (generisch, inspiratorisches Minutenvolumen) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-peep-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-peep-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-peep-1",
      "description" : "ICU Observation: MII PR ICU Positiv Endexpiratorischer Druck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-peep-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-peep-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-peep-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Positiv-endexspiratorischer Druck (PEEP) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pip-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pip-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pip-1",
      "description" : "ICU Observation: MII PR ICU Maximaler Beatmungsdruck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pip-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pip-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pip-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Maximaler Beatmungsdruck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pmax-insp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmax-insp-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pmax-insp-1",
      "description" : "ICU Observation: MII PR ICU Maximaler Inspiratorischer Beatmungsdruck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pmax-insp-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Maximaler inspiratorischer Beatmungsdruck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pmean-insp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmean-insp-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pmean-insp-1",
      "description" : "ICU Observation: MII PR ICU Mittlerer Inspiratorischer Beatmungsdruck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pmean-insp-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Mittlerer inspiratorischer Beatmungsdruck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pplat-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pplat-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pplat-1",
      "description" : "ICU Observation: MII PR ICU Plateau-Beatmungsdruck (lungenprotektiv unter ECMO)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-pplat-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-pplat-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-pplat-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Plateau-Beatmungsdruck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-ps-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-ps-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-ps-1",
      "description" : "ICU Observation: MII PR ICU Unterstuezungsdruck Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-ps-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-ps-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-ps-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Unterstuetzungsdruck der Beatmung - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-te-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-te-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-te-1",
      "description" : "ICU Observation: MII PR ICU Einstellung Ausatmungszeit Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-te-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-te-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-te-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Einstellung Ausatmungszeit - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-ti-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-ti-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-ti-1",
      "description" : "ICU Observation: MII PR ICU Einstellung Einatmungszeit Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-ti-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-ti-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-ti-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Einstellung Einatmungszeit - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-beat-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-beat-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-beat-1",
      "description" : "ICU Observation: MII PR ICU Atemzugvolumen Waehrend Beatmung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-beat-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Atemzugvolumen waehrend Beatmung - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-einst-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-einst-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-einst-1",
      "description" : "ICU Observation: MII PR ICU Atemzugvolumen Einstellung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-einst-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Atemzugvolumen (Einstellung) - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-spont-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-1",
      "description" : "ICU Observation: MII PR ICU Spontanes Atemzugvolumen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Spontanes Atemzugvolumen - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-1",
      "description" : "ICU Observation: MII PR ICU Spontanes Plus Mechanisches Atemzugvolumen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-vt-spont-mech-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Spontanes und mechanisches Atemzugvolumen - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-zeit-hoch-1",
      "description" : "ICU Observation: MII ICU Beatmungszeit Hohem Druck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-zeit-hoch-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Beatmungszeit bei hohem Druck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-1",
      "description" : "ICU Observation: MII PR ICU Beatmungszeit Niedrigem Druck",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1"
      },
      "name" : "mii-exa-test-data-patient-1-icu-vent-zeit-niedrig-dar-1",
      "description" : "ICU Observation (dataAbsentReason): Beatmungszeit bei niedrigem Druck - waehrend Diskonnektion nicht erhoben",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-2",
      "description" : "Observation: Erythrozyten im Blut für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-3",
      "description" : "Observation: Hämatokrit im Blut für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-4.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-4"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-4",
      "description" : "Observation: Thrombozyten im Blut für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-5.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-5"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-5",
      "description" : "Observation: Thrombozyten im Blut für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-6.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-6"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-6",
      "description" : "Observation: Hämoglobin im Blut für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-7.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-7"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-7",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-8.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-8"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-8",
      "description" : "Observation: Nitrit im Urin negativ für Patient 1 (valueCodeableConcept-Variante)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-labobs-9.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-labobs-9"
      },
      "name" : "mii-exa-test-data-patient-1-labobs-9",
      "description" : "Observation: Troponin T unter Nachweisgrenze für Patient 1 (comparator-Variante)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-1-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-1-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-1-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-1-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-1-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-1-labrequest-1",
      "description" : "ServiceRequest: Kleines Blutbild für Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-1-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-1-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-1-medadmin-1",
      "description" : "MedicationAdministration: Dalbavancin 1500 mg als 30-minütige Infusion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-1-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-1-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-1-medadmin-2",
      "description" : "MedicationAdministration: Abgebrochen - Dalbavancin 1500 mg als 30-minütige Infusion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-1-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-1-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-1-medrequest-1",
      "description" : "MedicationRequest: Dalbavancin 1500 mg IV als 30-minütige Infusion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-1-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-1-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-1-medrequest-2",
      "description" : "MedicationRequest: Dalbavancin 1500 mg IV als 30-minütige Infusion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-1-medrequest-3.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-1-medrequest-3"
      },
      "name" : "mii-exa-test-data-patient-1-medrequest-3",
      "description" : "MedicationRequest: Propofol 6.5 mg/min IV via Perfusor",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-1-medrequest-4.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-1-medrequest-4"
      },
      "name" : "mii-exa-test-data-patient-1-medrequest-4",
      "description" : "MedicationRequest: Propofol 6.5 mg/min IV via Perfusor",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-1-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-1-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-1-medstatement-1",
      "description" : "MedicationStatement: ASS 100 mg 1x täglich mittags eine Tablette oral",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-1-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-1-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-1-medstatement-2",
      "description" : "MedicationStatement: Dalbavancin 1500 mg als 30-minütige Infusion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-1-medstatement-3.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-1-medstatement-3"
      },
      "name" : "mii-exa-test-data-patient-1-medstatement-3",
      "description" : "MedicationStatement: Propofol 5 mg/min intravenös",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-1-patho-active-problems-1.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-1-patho-active-problems-1"
      },
      "name" : "mii-exa-test-data-patient-1-patho-active-problems-1",
      "description" : "Patho Active Problems List: Prostataerkrankungen bei Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-patient-1-patho-hopi-1.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-patient-1-patho-hopi-1"
      },
      "name" : "mii-exa-test-data-patient-1-patho-hopi-1",
      "description" : "Patho History of Present Illness: Klinische Anamnese bei Prostata-Stanzbiopsie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-1-patho-problem-list-item-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-1-patho-problem-list-item-1"
      },
      "name" : "mii-exa-test-data-patient-1-patho-problem-list-item-1",
      "description" : "Patho Problem List Item: PSA-Erhöhung bei V.a. Prostatakarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-bdi-ii-score.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-bdi-ii-score"
      },
      "name" : "mii-exa-test-data-patient-1-pro-bdi-ii-score",
      "description" : "PRO Observation: BDI-II Total Score for Patient 1 (mild depression, score 12)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-eq5d5l-index.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-eq5d5l-index"
      },
      "name" : "mii-exa-test-data-patient-1-pro-eq5d5l-index",
      "description" : "PRO Observation: EQ-5D-5L Index Value for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-eq5d5l-profile.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-eq5d5l-profile"
      },
      "name" : "mii-exa-test-data-patient-1-pro-eq5d5l-profile",
      "description" : "PRO Observation: EQ-5D-5L Profile String for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-eq5d5l-vas.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-eq5d5l-vas"
      },
      "name" : "mii-exa-test-data-patient-1-pro-eq5d5l-vas",
      "description" : "PRO Observation: EQ-5D-5L VAS Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-test-data-patient-1-pro-phq15-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-test-data-patient-1-pro-phq15-response"
      },
      "name" : "mii-exa-test-data-patient-1-pro-phq15-response",
      "description" : "PRO QuestionnaireResponse: PHQ-15 for Patient 1 (medium somatic symptom severity, score 12)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-phq15-score.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-phq15-score"
      },
      "name" : "mii-exa-test-data-patient-1-pro-phq15-score",
      "description" : "PRO Observation: PHQ-15 Total Score for Patient 1 (medium somatic symptom severity, score 12)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-phq9-obs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-phq9-obs-1"
      },
      "name" : "mii-exa-test-data-patient-1-pro-phq9-obs-1",
      "description" : "PRO Observation: PHQ-9 Score (spezifisches Profil) for Patient 1 (mild depression, score 8)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-test-data-patient-1-pro-phq9-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-test-data-patient-1-pro-phq9-response"
      },
      "name" : "mii-exa-test-data-patient-1-pro-phq9-response",
      "description" : "PRO QuestionnaireResponse: PHQ-9 for Patient 1 (mild depression, score 8)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-phq9-score.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-phq9-score"
      },
      "name" : "mii-exa-test-data-patient-1-pro-phq9-score",
      "description" : "PRO Observation: PHQ-9 Score for Patient 1 (mild depression, score 8)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis-cogfn-sf4a-raw-score.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis-cogfn-sf4a-raw-score"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis-cogfn-sf4a-raw-score",
      "description" : "PRO Observation: PROMIS Cognitive Function SF4a Raw Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis-cogfn-sf4a-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis-cogfn-sf4a-tscore"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis-cogfn-sf4a-tscore",
      "description" : "PRO Observation: PROMIS Cognitive Function SF4a T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis-dep-sf4a-raw-score.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis-dep-sf4a-raw-score"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis-dep-sf4a-raw-score",
      "description" : "PRO Observation: PROMIS Depression SF4a Raw Score for Patient 1 (mild, raw score 7)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-test-data-patient-1-pro-promis-dep-sf4a-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-test-data-patient-1-pro-promis-dep-sf4a-response"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis-dep-sf4a-response",
      "description" : "PRO QuestionnaireResponse: PROMIS Depression SF4a for Patient 1 (mild, raw score 7)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis-dep-sf4a-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis-dep-sf4a-tscore"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis-dep-sf4a-tscore",
      "description" : "PRO Observation: PROMIS Depression T-Score for Patient 1 (mild, T-score 52.7)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis29-anxiety-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis29-anxiety-tscore"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis29-anxiety-tscore",
      "description" : "PRO Observation: PROMIS-29 Anxiety T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis29-depression-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis29-depression-tscore"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis29-depression-tscore",
      "description" : "PRO Observation: PROMIS-29 Depression T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis29-fatigue-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis29-fatigue-tscore"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis29-fatigue-tscore",
      "description" : "PRO Observation: PROMIS-29 Fatigue T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis29-pain-intensity.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis29-pain-intensity"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis29-pain-intensity",
      "description" : "PRO Observation: PROMIS-29 Pain Intensity for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-test-data-patient-1-pro-promis29-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-test-data-patient-1-pro-promis29-response"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis29-response",
      "description" : "PRO QuestionnaireResponse: PROMIS-29 (Auszug Angst/Depression) for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-promis29-social-function-tscore.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-promis29-social-function-tscore"
      },
      "name" : "mii-exa-test-data-patient-1-pro-promis29-social-function-tscore",
      "description" : "PRO Observation: PROMIS-29 Social Function T-Score for Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-test-data-patient-1-pro-whodas12-response.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-test-data-patient-1-pro-whodas12-response"
      },
      "name" : "mii-exa-test-data-patient-1-pro-whodas12-response",
      "description" : "PRO QuestionnaireResponse: WHODAS 2.0 12-Item for Patient 1 (mild disability, simple sum 12)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-pro-whodas12-score.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-pro-whodas12-score"
      },
      "name" : "mii-exa-test-data-patient-1-pro-whodas12-score",
      "description" : "PRO Observation: WHODAS 2.0 12-Item Simple Sum Score for Patient 1 (mild disability, sum 12)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-1-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-1-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-1-prozedur-1",
      "description" : "Procedure: Exzision und Resektion an Lunge für Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-1-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-1-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-1-prozedur-2",
      "description" : "Procedure: Gabe von Dalbavancin für Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-1-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-1-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-1-specimen-1",
      "description" : "Specimen: EDTA-Blut für Klinische Chemie und Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Substance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Substance-mii-exa-test-data-patient-1-substance-1.html"
      }],
      "reference" : {
        "reference" : "Substance/mii-exa-test-data-patient-1-substance-1"
      },
      "name" : "mii-exa-test-data-patient-1-substance-1",
      "description" : "Substance: Edetic acid",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-1-todesursache-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-1-todesursache-1"
      },
      "name" : "mii-exa-test-data-patient-1-todesursache-1",
      "description" : "Observation: Todesursache für Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-1-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-1-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-1-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-10.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-10"
      },
      "name" : "mii-exa-test-data-patient-10",
      "description" : "Patient: Patient-10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-10-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-10-consent-1"
      },
      "name" : "mii-exa-test-data-patient-10-consent-1",
      "description" : "Consent: Einwilligung für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-10-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-10-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-10-diagnose-1",
      "description" : "Condition: Chronische ischämische Herzkrankheit für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-10-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-10-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-10-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-10-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-10-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-10-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-10-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-10-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-10-labobs-2",
      "description" : "Observation: Hämoglobin im Blut für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-10-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-10-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-10-labobs-3",
      "description" : "Observation: Kreatinin im Serum für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-10-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-10-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-10-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-10-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-10-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-10-labrequest-1",
      "description" : "ServiceRequest: Basisstoffwechsel für Patient 10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-10-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-10-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-10-medadmin-1",
      "description" : "MedicationAdministration: Sumatriptan 50mg oral bei Migräne",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-10-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-10-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-10-medadmin-2",
      "description" : "MedicationAdministration: Topiramat 50mg oral zur Prophylaxe",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-10-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-10-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-10-medrequest-1",
      "description" : "MedicationRequest: Sumatriptan 50mg bei Migräne-Attacke",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-10-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-10-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-10-medrequest-2",
      "description" : "MedicationRequest: Topiramat 50mg 2x täglich zur Prophylaxe",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-10-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-10-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-10-medstatement-1",
      "description" : "MedicationStatement: Sumatriptan 50mg bei Migräne-Attacke",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-10-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-10-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-10-medstatement-2",
      "description" : "MedicationStatement: Topiramat 50mg 2x täglich zur Prophylaxe",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-10-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-10-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-10-prozedur-1",
      "description" : "Procedure: Computertomographie des Schädels bei Migräne für Patient-10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-10-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-10-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-10-prozedur-2",
      "description" : "Procedure: Migräne-Prophylaxe mit Topiramat für Patient-10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-10-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-10-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-10-specimen-1",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-10-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-10-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-10-specimen-2",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-10-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-10-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-10-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-10",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-11.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-11"
      },
      "name" : "mii-exa-test-data-patient-11",
      "description" : "Patient: Patient-11",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-2.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-2"
      },
      "name" : "mii-exa-test-data-patient-2",
      "description" : "Patient: Patient-2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-2-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-2-consent-1"
      },
      "name" : "mii-exa-test-data-patient-2-consent-1",
      "description" : "Consent: Einwilligung für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-2-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-2-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-2-diagnose-1",
      "description" : "Condition: Bösartige Neubildung des Lungenoberlappens für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-2-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-2-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-2-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-2-encounter-2.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-2-encounter-2"
      },
      "name" : "mii-exa-test-data-patient-2-encounter-2",
      "description" : "Encounter: Abteilungskontakt Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-2-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-2-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-2-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-2-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-2-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-2-labobs-2",
      "description" : "Observation: Erythrozyten im Blut für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-2-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-2-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-2-labobs-3",
      "description" : "Observation: Hämoglobin im Blut für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-2-labobs-4.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-2-labobs-4"
      },
      "name" : "mii-exa-test-data-patient-2-labobs-4",
      "description" : "Observation: Thrombozyten im Blut für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-2-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-2-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-2-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-2-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-2-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-2-labrequest-1",
      "description" : "ServiceRequest: Vollständiges Blutbild für Patient 2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-2-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-2-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-2-medadmin-1",
      "description" : "MedicationAdministration: Morphin 10 mg oral bei Schmerzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-2-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-2-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-2-medadmin-2",
      "description" : "MedicationAdministration: Carboplatin 450 mg IV über 1 Stunde",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-2-medadmin-3.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-2-medadmin-3"
      },
      "name" : "mii-exa-test-data-patient-2-medadmin-3",
      "description" : "MedicationAdministration: Paclitaxel 175 mg IV über 3 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-2-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-2-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-2-medrequest-1",
      "description" : "MedicationRequest: Morphin 10mg oral alle 6 Stunden bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-2-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-2-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-2-medrequest-2",
      "description" : "MedicationRequest: Carboplatin 450mg IV über 1 Stunde",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-2-medrequest-3.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-2-medrequest-3"
      },
      "name" : "mii-exa-test-data-patient-2-medrequest-3",
      "description" : "MedicationRequest: Paclitaxel 175mg IV über 3 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-2-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-2-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-2-medstatement-1",
      "description" : "MedicationStatement: Morphin 10mg alle 6 Stunden bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-2-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-2-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-2-medstatement-2",
      "description" : "MedicationStatement: Carboplatin 450mg IV über 1 Stunde",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-2-medstatement-3.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-2-medstatement-3"
      },
      "name" : "mii-exa-test-data-patient-2-medstatement-3",
      "description" : "MedicationStatement: Paclitaxel 175mg IV über 3 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-2-medstatement-4.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-2-medstatement-4"
      },
      "name" : "mii-exa-test-data-patient-2-medstatement-4",
      "description" : "MedicationStatement: Erythrozyten 150-300 mL/h intravenös",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-2-medstatement-5.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-2-medstatement-5"
      },
      "name" : "mii-exa-test-data-patient-2-medstatement-5",
      "description" : "MedicationStatement: Erythrozyten 150 mL/h intravenös",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-2-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-2-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-2-prozedur-1",
      "description" : "Procedure: Thorakotomie mit Lobektomie des rechten Oberlappens für Patient-2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-2-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-2-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-2-prozedur-2",
      "description" : "Procedure: Postoperative Intensivüberwachung für Patient-2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-2-prozedur-3.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-2-prozedur-3"
      },
      "name" : "mii-exa-test-data-patient-2-prozedur-3",
      "description" : "Procedure: Transfusion von Erythrozytenkonzentrat für Patient-2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-2-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-2-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-2-specimen-1",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-2-todesursache-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-2-todesursache-1"
      },
      "name" : "mii-exa-test-data-patient-2-todesursache-1",
      "description" : "Observation: Todesursache für Patient-2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-2-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-2-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-2-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-2",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-3.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-3"
      },
      "name" : "mii-exa-test-data-patient-3",
      "description" : "Patient: Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-3-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-3-consent-1"
      },
      "name" : "mii-exa-test-data-patient-3-consent-1",
      "description" : "Consent: Einwilligung für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-3-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-3-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-3-diagnose-1",
      "description" : "Condition: Bösartige anorektale Neubildung für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-3-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-3-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-3-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-3-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-3-labobs-2",
      "description" : "Observation: Alkalische Phosphatase im Serum für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-3-labobs-3",
      "description" : "Observation: Bilirubin im Serum für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-3-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-3-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-3-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-3-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-3-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-3-labrequest-1",
      "description" : "ServiceRequest: Vollständiges Blutbild für Patient 3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-3-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-3-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-3-medadmin-1",
      "description" : "MedicationAdministration: Metamizol 500 mg oral bei Schmerzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-3-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-3-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-3-medadmin-2",
      "description" : "MedicationAdministration: 5-FU 1000 mg IV über 46 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-3-medadmin-3.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-3-medadmin-3"
      },
      "name" : "mii-exa-test-data-patient-3-medadmin-3",
      "description" : "MedicationAdministration: Oxaliplatin 85mg IV über 2 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-3-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-3-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-3-medrequest-1",
      "description" : "MedicationRequest: Metamizol 500-1000 mg oral bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-3-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-3-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-3-medrequest-2",
      "description" : "MedicationRequest: 5-FU 1000mg/m² IV über 46 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-3-medrequest-3.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-3-medrequest-3"
      },
      "name" : "mii-exa-test-data-patient-3-medrequest-3",
      "description" : "MedicationRequest: Oxaliplatin 85mg/m² IV über 2 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-3-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-3-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-3-medstatement-1",
      "description" : "MedicationStatement: Metamizol 500-1000 mg oral bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-3-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-3-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-3-medstatement-2",
      "description" : "MedicationStatement: Fluorouracil 1000mg/m² IV über 46 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-3-medstatement-3.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-3-medstatement-3"
      },
      "name" : "mii-exa-test-data-patient-3-medstatement-3",
      "description" : "MedicationStatement: Oxaliplatin 85mg/m² IV über 2 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-3-medstatement-4.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-3-medstatement-4"
      },
      "name" : "mii-exa-test-data-patient-3-medstatement-4",
      "description" : "MedicationStatement: Doxorubicin 50mg/m² IV über 1 Stunde",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-3-molgen-anforderung-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-3-molgen-anforderung-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-anforderung-1",
      "description" : "ServiceRequest: Anforderung genetischer Test fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-3-molgen-anforderung-2.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-3-molgen-anforderung-2"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-anforderung-2",
      "description" : "ServiceRequest: Anforderung NGS-Panel bei NSCLC Stadium IV gemaess S3-Leitlinie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-3-molgen-befundbericht-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-3-molgen-befundbericht-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-befundbericht-1",
      "description" : "DiagnosticReport: Molekulargenetischer Befundbericht mit BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-biomarker-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-biomarker-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-biomarker-1",
      "description" : "Observation: Molekularer Biomarker (PD-L1 TPS) fuer Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-diagnostische-implikation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-diagnostische-implikation-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-diagnostische-implikation-1",
      "description" : "Observation: Diagnostische Implikation fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "FamilyMemberHistory"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "FamilyMemberHistory-mii-exa-test-data-patient-3-molgen-family-member-history-1.html"
      }],
      "reference" : {
        "reference" : "FamilyMemberHistory/mii-exa-test-data-patient-3-molgen-family-member-history-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-family-member-history-1",
      "description" : "FamilyMemberHistory: Familienanamnese fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-mii-exa-test-data-patient-3-molgen-folgemassnahme-1.html"
      }],
      "reference" : {
        "reference" : "Task/mii-exa-test-data-patient-3-molgen-folgemassnahme-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-folgemassnahme-1",
      "description" : "Task: Empfohlene Folgemassnahme fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-3-molgen-genomic-study-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-3-molgen-genomic-study-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-genomic-study-1",
      "description" : "Procedure: Genomic Study BRAF-Analyse bei kolorektalem Adenokarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-3-molgen-genomic-study-analysis-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-3-molgen-genomic-study-analysis-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-genomic-study-analysis-1",
      "description" : "Procedure: Genomic Study Analysis BRAF Exon 15 mittels NGS",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-genotyp-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-genotyp-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-genotyp-1",
      "description" : "Observation: Genotyp fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-mii-exa-test-data-patient-3-molgen-medikationsempfehlung-1.html"
      }],
      "reference" : {
        "reference" : "Task/mii-exa-test-data-patient-3-molgen-medikationsempfehlung-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-medikationsempfehlung-1",
      "description" : "Task: Medikationsempfehlung fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-molekulare-konsequenz-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-molekulare-konsequenz-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-molekulare-konsequenz-1",
      "description" : "Observation: Molekulare Konsequenz der BRAF V600E Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-msi-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-msi-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-msi-1",
      "description" : "Observation: Mikrosatelliteninstabilitaet fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-mutationslast-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-mutationslast-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-mutationslast-1",
      "description" : "Observation: Mutationslast (TMB) fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RiskAssessment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RiskAssessment-mii-exa-test-data-patient-3-molgen-polygener-risiko-score-1.html"
      }],
      "reference" : {
        "reference" : "RiskAssessment/mii-exa-test-data-patient-3-molgen-polygener-risiko-score-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-polygener-risiko-score-1",
      "description" : "RiskAssessment: Polygener Risiko Score fuer kolorektales Karzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-therapeutische-implikation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-therapeutische-implikation-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-therapeutische-implikation-1",
      "description" : "Observation: Therapeutische Implikation fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-therapeutische-implikation-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-therapeutische-implikation-2"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-therapeutische-implikation-2",
      "description" : "Observation: Therapeutische Implikation fuer EGFR L858R bei NSCLC Stadium IV",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-therapeutische-implikation-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-therapeutische-implikation-3"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-therapeutische-implikation-3",
      "description" : "Observation: Therapeutische Implikation fuer EGFR Exon-20-Insertion bei NSCLC - Amivantamab",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-variante-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-variante-1"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-variante-1",
      "description" : "Observation: Genetische Variante fuer BRAF-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-variante-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-variante-2"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-variante-2",
      "description" : "Observation: Genetische Variante EGFR L858R bei NSCLC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-molgen-variante-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-molgen-variante-3"
      },
      "name" : "mii-exa-test-data-patient-3-molgen-variante-3",
      "description" : "Observation: Genetische Variante EGFR Exon-20-Insertion p.Ala767_Val769dup bei NSCLC",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-3-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-3-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-3-prozedur-1",
      "description" : "Procedure: Rektoskopie mit Biopsieentnahme für Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-3-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-3-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-3-prozedur-2",
      "description" : "Procedure: Tiefe anteriore Rektumresektion für Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-3-prozedur-3.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-3-prozedur-3"
      },
      "name" : "mii-exa-test-data-patient-3-prozedur-3",
      "description" : "Procedure: Chemotherapie für Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-blutgruppe-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-blutgruppe-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-blutgruppe-1",
      "description" : "Blutgruppe Observation: A Rh(D) positive - all MS elements, both code and value slices",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-bmi-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-bmi-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-bmi-1",
      "description" : "BMI Observation - all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-3-seltene-clinical-diagnosis-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-3-seltene-clinical-diagnosis-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-clinical-diagnosis-1",
      "description" : "Clinical Diagnosis: Marfan syndrome - maximum MS element coverage",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-3-seltene-clinical-diagnosis-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-3-seltene-clinical-diagnosis-2"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-clinical-diagnosis-2",
      "description" : "Clinical Diagnosis: Ectopia lentis bei Marfan-Syndrom, nach Lensektomie behoben (abatementAge-Variante)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-mii-exa-test-data-patient-3-seltene-clinical-impression-1.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/mii-exa-test-data-patient-3-seltene-clinical-impression-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-clinical-impression-1",
      "description" : "ClinicalImpression: Rare disease assessment - all MS elements populated",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-consanguinity-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-consanguinity-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-consanguinity-1",
      "description" : "Consanguinity Observation: keine Blutsverwandtschaft der Eltern (Marfan-Syndrom, autosomal-dominant)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "FamilyMemberHistory"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "FamilyMemberHistory-mii-exa-test-data-patient-3-seltene-familienanamnese-1.html"
      }],
      "reference" : {
        "reference" : "FamilyMemberHistory/mii-exa-test-data-patient-3-seltene-familienanamnese-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-familienanamnese-1",
      "description" : "Familienanamnese: Mother with Marfan syndrome - all MS elements including penetrance, mondo, deceased",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "FamilyMemberHistory"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "FamilyMemberHistory-mii-exa-test-data-patient-3-seltene-familienanamnese-2.html"
      }],
      "reference" : {
        "reference" : "FamilyMemberHistory/mii-exa-test-data-patient-3-seltene-familienanamnese-2"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-familienanamnese-2",
      "description" : "Familienanamnese: Father not affected - tests vonSEBetroffen=No, deceasedAge",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "FamilyMemberHistory"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "FamilyMemberHistory-mii-exa-test-data-patient-3-seltene-familienanamnese-3.html"
      }],
      "reference" : {
        "reference" : "FamilyMemberHistory/mii-exa-test-data-patient-3-seltene-familienanamnese-3"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-familienanamnese-3",
      "description" : "Familienanamnese: Bruder, bisher nicht betroffen - tests age[x], date, reasonCode, reasonReference",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-geburtsgewicht-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-geburtsgewicht-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-geburtsgewicht-1",
      "description" : "Geburtsgewicht Observation - retrospektive Angabe zur Geburt (technische Schicht)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-geburtslaenge-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-geburtslaenge-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-geburtslaenge-1",
      "description" : "Geburtslaenge Observation - retrospektive Angabe zur Geburt (technische Schicht)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-3-seltene-genetic-diagnosis-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-3-seltene-genetic-diagnosis-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-genetic-diagnosis-1",
      "description" : "Genetic Diagnosis: Marfan syndrome (FBN1 variant) - maximum MS element coverage including penetrance",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-3-seltene-genetic-diagnosis-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-3-seltene-genetic-diagnosis-2"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-genetic-diagnosis-2",
      "description" : "Genetic Diagnosis: Transienter neonataler Diabetes mellitus (6q24), im Saeuglingsalter remittiert (abatement-Variante)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-gestationsalter-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-gestationsalter-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-gestationsalter-1",
      "description" : "Gestationsalter Observation - retrospektive Angabe zur Geburt (technische Schicht)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-hpo-assessment-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-hpo-assessment-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-hpo-assessment-1",
      "description" : "HPO Assessment: Aortic root aneurysm (Present) - all optional fields populated",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-hpo-assessment-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-hpo-assessment-2"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-hpo-assessment-2",
      "description" : "HPO Assessment: Arachnodactyly (Absent) - excluded phenotype",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-hpo-assessment-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-hpo-assessment-3"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-hpo-assessment-3",
      "description" : "HPO Assessment: Ectopia lentis (Present, Moderate severity, with change status interpretation)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-hpo-assessment-4.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-hpo-assessment-4"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-hpo-assessment-4",
      "description" : "HPO Assessment: Tall stature (Present, effectivePeriod) - tests effectivePeriod slice",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-hueftumfang-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-hueftumfang-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-hueftumfang-1",
      "description" : "Hueftumfang Observation - all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-icf-assessment-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-icf-assessment-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-icf-assessment-1",
      "description" : "ICF-Assessment Observation: b730 Funktionen der Muskelkraft mit Ausmass der Schaedigung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-kopfumfang-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-kopfumfang-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-kopfumfang-1",
      "description" : "Kopfumfang Observation - all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ResearchSubject"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ResearchSubject-mii-exa-test-data-patient-3-seltene-registerteilnahme-1.html"
      }],
      "reference" : {
        "reference" : "ResearchSubject/mii-exa-test-data-patient-3-seltene-registerteilnahme-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-registerteilnahme-1",
      "description" : "Registerteilnahme: Einschluss in das ERN ReCONNET Register (Marfan-Syndrom)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-3-seltene-studieneinschluss-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-3-seltene-studieneinschluss-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-studieneinschluss-1",
      "description" : "Studieneinschluss Anfrage: Clinical trial referral - all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-3-seltene-symptom-condition-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-3-seltene-symptom-condition-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-symptom-condition-1",
      "description" : "Symptom Condition: Tall stature - all 4 code slices (HPO, SNOMED, ICD-10-GM, MONDO), all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-3-seltene-symptom-condition-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-3-seltene-symptom-condition-2"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-symptom-condition-2",
      "description" : "Symptom Condition: Aortic root dilatation - tests onsetDateTime/abatementDateTime slices",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-seltene-taillenumfang-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-seltene-taillenumfang-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-taillenumfang-1",
      "description" : "Taillenumfang Observation - all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-3-seltene-therapie-durchgefuehrt-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-3-seltene-therapie-durchgefuehrt-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-therapie-durchgefuehrt-1",
      "description" : "Therapie durchgefuehrt: Pharmakotherapie (Losartan) - tests performedPeriod, code.display",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-3-seltene-therapie-durchgefuehrt-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-3-seltene-therapie-durchgefuehrt-2"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-therapie-durchgefuehrt-2",
      "description" : "Therapie durchgefuehrt: Sonstiges (Physiotherapie) - tests performedDateTime slice",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RequestGroup-mii-exa-test-data-patient-3-seltene-therapie-kombination-1.html"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-test-data-patient-3-seltene-therapie-kombination-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-therapie-kombination-1",
      "description" : "Therapieempfehlung Kombination: Combined therapy for Marfan - all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-3-seltene-therapie-nicht-med-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-3-seltene-therapie-nicht-med-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-therapie-nicht-med-1",
      "description" : "Therapieempfehlung nicht-medikamentoes: Annual cardiac screening - all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-3-seltene-therapieempfehlung-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-3-seltene-therapieempfehlung-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-therapieempfehlung-1",
      "description" : "Therapieempfehlung: Losartan for Marfan - all MS elements including extensions",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-mii-exa-test-data-patient-3-seltene-therapieplan-1.html"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-test-data-patient-3-seltene-therapieplan-1"
      },
      "name" : "mii-exa-test-data-patient-3-seltene-therapieplan-1",
      "description" : "Therapieplan: Marfan syndrome care plan - all activity slices and MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-3-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-3-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-3-specimen-1",
      "description" : "Specimen: Gewebeprobe aus dem Kolon",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-3-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-3-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-3-specimen-2",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-3-specimen-3.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-3-specimen-3"
      },
      "name" : "mii-exa-test-data-patient-3-specimen-3",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-3-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-3-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-3-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-3",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-4.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-4"
      },
      "name" : "mii-exa-test-data-patient-4",
      "description" : "Patient: Patient-4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-4-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-4-consent-1"
      },
      "name" : "mii-exa-test-data-patient-4-consent-1",
      "description" : "Consent: Einwilligung für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-4-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-4-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-4-diagnose-1",
      "description" : "Condition: Bösartige Neubildung des Magens nicht näher bezeichnet für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-4-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-4-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-4-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-4-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-4-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-4-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-4-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-4-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-4-labobs-2",
      "description" : "Observation: Kreatinin im Serum für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-4-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-4-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-4-labobs-3",
      "description" : "Observation: Cholesterin im Serum für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-4-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-4-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-4-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-4-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-4-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-4-labrequest-1",
      "description" : "ServiceRequest: Basisstoffwechsel für Patient 4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-4-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-4-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-4-medadmin-1",
      "description" : "MedicationAdministration: Cisplatin 75mg IV über 2 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-4-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-4-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-4-medadmin-2",
      "description" : "MedicationAdministration: Omeprazol 20mg oral morgens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-4-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-4-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-4-medrequest-1",
      "description" : "MedicationRequest: Cisplatin 75mg/m² IV über 2 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-4-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-4-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-4-medrequest-2",
      "description" : "MedicationRequest: Omeprazol 20mg 1x täglich morgens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-4-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-4-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-4-medstatement-1",
      "description" : "MedicationStatement: Cisplatin 75mg/m² IV über 2 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-4-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-4-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-4-medstatement-2",
      "description" : "MedicationStatement: Omeprazol 20mg 1x täglich morgens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-4-molgen-anforderung-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-4-molgen-anforderung-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-anforderung-1",
      "description" : "ServiceRequest: Anforderung molekulargenetische Stufendiagnostik",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-4-molgen-befundbericht-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-4-molgen-befundbericht-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-befundbericht-1",
      "description" : "DiagnosticReport: Molekulargenetischer Befundbericht Magenkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-4-molgen-diagnostische-implikation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-4-molgen-diagnostische-implikation-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-diagnostische-implikation-1",
      "description" : "Observation: Diagnostische Implikation fuer Magenkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "FamilyMemberHistory"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "FamilyMemberHistory-mii-exa-test-data-patient-4-molgen-family-member-history-1.html"
      }],
      "reference" : {
        "reference" : "FamilyMemberHistory/mii-exa-test-data-patient-4-molgen-family-member-history-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-family-member-history-1",
      "description" : "FamilyMemberHistory: Familienanamnese fuer Magenkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-4-molgen-genomic-study-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-4-molgen-genomic-study-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-genomic-study-1",
      "description" : "Procedure: Genomic Study Stufendiagnostik Magenkarzinom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-4-molgen-genomic-study-analysis-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-4-molgen-genomic-study-analysis-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-genomic-study-analysis-1",
      "description" : "Procedure: Genomic Study Analysis Stufendiagnostik Magenkarzinom-Panel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-4-molgen-molekulare-konsequenz-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-4-molgen-molekulare-konsequenz-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-molekulare-konsequenz-1",
      "description" : "Observation: Molekulare Konsequenz der CTNNA1 Frameshift-Deletion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-4-molgen-variante-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-4-molgen-variante-1"
      },
      "name" : "mii-exa-test-data-patient-4-molgen-variante-1",
      "description" : "Observation: Genetische Variante fuer CTNNA1-Mutation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-4-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-4-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-4-prozedur-1",
      "description" : "Procedure: Ösophagogastroduodenoskopie mit Biopsie-Entnahme für Patient-4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-4-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-4-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-4-prozedur-2",
      "description" : "Procedure: Partielle Gastrektomie für Patient-4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-4-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-4-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-4-specimen-1",
      "description" : "Specimen: EDTA-Blut für Klinische Chemie und Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-4-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-4-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-4-specimen-2",
      "description" : "Specimen: EDTA-Blut für Klinische Chemie und Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-4-specimen-3.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-4-specimen-3"
      },
      "name" : "mii-exa-test-data-patient-4-specimen-3",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-4-specimen-4.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-4-specimen-4"
      },
      "name" : "mii-exa-test-data-patient-4-specimen-4",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-4-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-4-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-4-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-4",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-5.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-5"
      },
      "name" : "mii-exa-test-data-patient-5",
      "description" : "Patient: Patient-5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-5-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-5-consent-1"
      },
      "name" : "mii-exa-test-data-patient-5-consent-1",
      "description" : "Consent: Einwilligung für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-5-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-5-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-5-diagnose-1",
      "description" : "Condition: Endometriose des Ovars für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-5-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-5-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-5-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-5-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-5-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-5-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-5-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-5-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-5-labobs-2",
      "description" : "Observation: Hämoglobin im Blut für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-5-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-5-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-5-labobs-3",
      "description" : "Observation: Fasting glucose im Serum für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-5-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-5-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-5-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-5-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-5-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-5-labrequest-1",
      "description" : "ServiceRequest: Kleines Blutbild und Basisstoffwechsel für Patient 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-5-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-5-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-5-medadmin-1",
      "description" : "MedicationAdministration: Leuprorelin 3,75mg s.c.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-5-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-5-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-5-medadmin-2",
      "description" : "MedicationAdministration: Ibuprofen 400mg oral bei Schmerzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-5-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-5-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-5-medrequest-1",
      "description" : "MedicationRequest: Leuprorelin 3,75mg s.c. alle 4 Wochen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-5-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-5-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-5-medrequest-2",
      "description" : "MedicationRequest: Ibuprofen 400mg bis zu 3x täglich bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-5-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-5-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-5-medstatement-1",
      "description" : "MedicationStatement: Leuprorelin 3,75mg s.c. alle 4 Wochen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-5-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-5-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-5-medstatement-2",
      "description" : "MedicationStatement: Ibuprofen 400mg bis zu 3x täglich bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-5-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-5-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-5-prozedur-1",
      "description" : "Procedure: Diagnostische Laparoskopie zur Endometriose-Abklärung für Patient-5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-5-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-5-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-5-prozedur-2",
      "description" : "Procedure: Laparoskopische Exzision von Endometriose für Patient-5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-5-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-5-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-5-specimen-1",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-5-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-5-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-5-specimen-2",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-5-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-5-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-5-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-6.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-6"
      },
      "name" : "mii-exa-test-data-patient-6",
      "description" : "Patient: Patient-6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-6-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-6-consent-1"
      },
      "name" : "mii-exa-test-data-patient-6-consent-1",
      "description" : "Consent: Einwilligung für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-6-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-6-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-6-diagnose-1",
      "description" : "Condition: Chronische Gastritis, nicht näher bezeichnet für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-6-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-6-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-6-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-6-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-6-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-6-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-6-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-6-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-6-labobs-2",
      "description" : "Observation: Alanine aminotransferase im Serum für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-6-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-6-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-6-labobs-3",
      "description" : "Observation: Aspartate aminotransferase im Serum für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-6-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-6-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-6-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-6-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-6-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-6-labrequest-1",
      "description" : "ServiceRequest: Leberfunktionstest für Patient 6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-6-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-6-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-6-medadmin-1",
      "description" : "MedicationAdministration: Pantoprazol 40mg oral morgens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-6-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-6-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-6-medadmin-2",
      "description" : "MedicationAdministration: Amoxicillin 500mg oral",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-6-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-6-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-6-medrequest-1",
      "description" : "MedicationRequest: Pantoprazol 40mg 1x täglich morgens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-6-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-6-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-6-medrequest-2",
      "description" : "MedicationRequest: Amoxicillin 500mg 3x täglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-6-medrequest-3.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-6-medrequest-3"
      },
      "name" : "mii-exa-test-data-patient-6-medrequest-3",
      "description" : "MedicationRequest: Clarithromycin 250mg 2x täglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-6-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-6-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-6-medstatement-1",
      "description" : "MedicationStatement: Pantoprazol 40mg 1x täglich morgens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-6-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-6-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-6-medstatement-2",
      "description" : "MedicationStatement: Amoxicillin 500mg 3x täglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-6-medstatement-3.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-6-medstatement-3"
      },
      "name" : "mii-exa-test-data-patient-6-medstatement-3",
      "description" : "MedicationStatement: Clarithromycin 250mg 2x täglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-6-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-6-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-6-prozedur-1",
      "description" : "Procedure: Ösophagogastroduodenoskopie bei Gastritis für Patient-6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-6-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-6-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-6-prozedur-2",
      "description" : "Procedure: Atemtest auf Helicobacter pylori für Patient-6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-6-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-6-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-6-specimen-1",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-6-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-6-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-6-specimen-2",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-6-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-6-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-6-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-6",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-7.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-7"
      },
      "name" : "mii-exa-test-data-patient-7",
      "description" : "Patient: Patient-7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-7-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-7-consent-1"
      },
      "name" : "mii-exa-test-data-patient-7-consent-1",
      "description" : "Consent: Einwilligung für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-7-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-7-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-7-diagnose-1",
      "description" : "Condition: Bösartige Neubildung des Magens nicht näher bezeichnet für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-7-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-7-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-7-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-7-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-7-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-7-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-7-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-7-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-7-labobs-2",
      "description" : "Observation: Hämoglobin im Blut für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-7-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-7-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-7-labobs-3",
      "description" : "Observation: C-reactives Protein im Serum für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-7-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-7-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-7-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-7-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-7-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-7-labrequest-1",
      "description" : "ServiceRequest: Kleines Blutbild und Entzündungsmarker für Patient 7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-7-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-7-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-7-medadmin-1",
      "description" : "MedicationAdministration: Amoxicillin/Clavulansäure 1,2g IV",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-7-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-7-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-7-medadmin-2",
      "description" : "MedicationAdministration: Salbutamol 200μg inhalativ",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-7-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-7-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-7-medrequest-1",
      "description" : "MedicationRequest: Amoxicillin/Clavulansäure 1,2g IV alle 8 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-7-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-7-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-7-medrequest-2",
      "description" : "MedicationRequest: Salbutamol 2 Hubs inhalativ bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-7-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-7-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-7-medstatement-1",
      "description" : "MedicationStatement: Amoxicillin/Clavulansäure 1,2g IV alle 8 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-7-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-7-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-7-medstatement-2",
      "description" : "MedicationStatement: Salbutamol 2 Hubs inhalativ bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-7-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-7-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-7-prozedur-1",
      "description" : "Procedure: Flexible Bronchoskopie mit bronchoalveolärer Lavage für Patient-7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-7-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-7-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-7-prozedur-2",
      "description" : "Procedure: Intravenöse Antibiotikatherapie für Patient-7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-7-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-7-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-7-specimen-1",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-7-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-7-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-7-specimen-2",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-7-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-7-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-7-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-7",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-8.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-8"
      },
      "name" : "mii-exa-test-data-patient-8",
      "description" : "Patient: Patient-8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-8-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-8-consent-1"
      },
      "name" : "mii-exa-test-data-patient-8-consent-1",
      "description" : "Consent: Einwilligung für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-8-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-8-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-8-diagnose-1",
      "description" : "Condition: Akute Bronchitis für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-8-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-8-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-8-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-8-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-8-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-8-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-8-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-8-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-8-labobs-2",
      "description" : "Observation: Troponin T im Serum für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-8-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-8-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-8-labobs-3",
      "description" : "Observation: Kreatin-Kinase MB im Serum für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-8-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-8-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-8-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-8-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-8-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-8-labrequest-1",
      "description" : "ServiceRequest: Herzmarker-Panel für Patient 8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-8-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-8-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-8-medadmin-1",
      "description" : "MedicationAdministration: Heparin 5000 IE s.c.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-8-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-8-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-8-medadmin-2",
      "description" : "MedicationAdministration: Metoprolol 50mg oral",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-8-medadmin-3.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-8-medadmin-3"
      },
      "name" : "mii-exa-test-data-patient-8-medadmin-3",
      "description" : "MedicationAdministration: Atorvastatin 80mg oral zur Nacht",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-8-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-8-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-8-medrequest-1",
      "description" : "MedicationRequest: Heparin 5000 IE s.c. alle 12 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-8-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-8-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-8-medrequest-2",
      "description" : "MedicationRequest: Metoprolol 25mg morgens, 50mg abends (2 dosageInstructions, gleiche Einheit mg)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-8-medrequest-3.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-8-medrequest-3"
      },
      "name" : "mii-exa-test-data-patient-8-medrequest-3",
      "description" : "MedicationRequest: Atorvastatin 40mg 1x täglich abends",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-8-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-8-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-8-medstatement-1",
      "description" : "MedicationStatement: Heparin 5000 IE s.c. alle 12 Stunden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-8-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-8-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-8-medstatement-2",
      "description" : "MedicationStatement: Metoprolol 50mg 2x täglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-8-medstatement-3.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-8-medstatement-3"
      },
      "name" : "mii-exa-test-data-patient-8-medstatement-3",
      "description" : "MedicationStatement: Atorvastatin 40mg 1x täglich abends",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-8-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-8-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-8-prozedur-1",
      "description" : "Procedure: Koronarangiographie bei Myokardinfarkt für Patient-8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-8-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-8-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-8-prozedur-2",
      "description" : "Procedure: Perkutane Koronarangioplastie mit Stent-Implantation für Patient-8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-8-prozedur-3.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-8-prozedur-3"
      },
      "name" : "mii-exa-test-data-patient-8-prozedur-3",
      "description" : "Procedure: Kardiopulmonale Reanimation bei Myokardinfarkt für Patient-8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-8-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-8-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-8-specimen-1",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-8-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-8-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-8-specimen-2",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-8-todesursache-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-8-todesursache-1"
      },
      "name" : "mii-exa-test-data-patient-8-todesursache-1",
      "description" : "Observation: Todesursache für Patient-8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-8-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-8-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-8-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-9.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-9"
      },
      "name" : "mii-exa-test-data-patient-9",
      "description" : "Patient: Patient-9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-patient-9-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-patient-9-consent-1"
      },
      "name" : "mii-exa-test-data-patient-9-consent-1",
      "description" : "Consent: Einwilligung für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patient-9-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patient-9-diagnose-1"
      },
      "name" : "mii-exa-test-data-patient-9-diagnose-1",
      "description" : "Condition: Chronische ischämische Herzkrankheit für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-patient-9-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-patient-9-encounter-1"
      },
      "name" : "mii-exa-test-data-patient-9-encounter-1",
      "description" : "Encounter: Einrichtungskontakt Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-9-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-9-labobs-1"
      },
      "name" : "mii-exa-test-data-patient-9-labobs-1",
      "description" : "Observation: Leukozyten im Blut für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-9-labobs-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-9-labobs-2"
      },
      "name" : "mii-exa-test-data-patient-9-labobs-2",
      "description" : "Observation: Hämoglobin im Blut für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-9-labobs-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-9-labobs-3"
      },
      "name" : "mii-exa-test-data-patient-9-labobs-3",
      "description" : "Observation: Estradiol im Serum für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patient-9-labreport-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patient-9-labreport-1"
      },
      "name" : "mii-exa-test-data-patient-9-labreport-1",
      "description" : "DiagnosticReport: Laborbericht für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patient-9-labrequest-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patient-9-labrequest-1"
      },
      "name" : "mii-exa-test-data-patient-9-labrequest-1",
      "description" : "ServiceRequest: Hormonpanel für Patient 9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-9-medadmin-1.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-9-medadmin-1"
      },
      "name" : "mii-exa-test-data-patient-9-medadmin-1",
      "description" : "MedicationAdministration: Verhütungspille 1 Tablette oral",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationAdministration"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationAdministration-mii-exa-test-data-patient-9-medadmin-2.html"
      }],
      "reference" : {
        "reference" : "MedicationAdministration/mii-exa-test-data-patient-9-medadmin-2"
      },
      "name" : "mii-exa-test-data-patient-9-medadmin-2",
      "description" : "MedicationAdministration: Paracetamol 400mg oral bei Schmerzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-9-medrequest-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-9-medrequest-1"
      },
      "name" : "mii-exa-test-data-patient-9-medrequest-1",
      "description" : "MedicationRequest: Verhütungspille 1 Tablette täglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-patient-9-medrequest-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-patient-9-medrequest-2"
      },
      "name" : "mii-exa-test-data-patient-9-medrequest-2",
      "description" : "MedicationRequest: Paracetamol 500mg bis zu 4x täglich bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-9-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-9-medstatement-1"
      },
      "name" : "mii-exa-test-data-patient-9-medstatement-1",
      "description" : "MedicationStatement: Verhütungspille 1 Tablette täglich",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-patient-9-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-patient-9-medstatement-2"
      },
      "name" : "mii-exa-test-data-patient-9-medstatement-2",
      "description" : "MedicationStatement: Paracetamol 500mg bei Bedarf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-9-prozedur-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-9-prozedur-1"
      },
      "name" : "mii-exa-test-data-patient-9-prozedur-1",
      "description" : "Procedure: Diagnostische Laparoskopie bei Ovarialzyste für Patient-9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-patient-9-prozedur-2.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-patient-9-prozedur-2"
      },
      "name" : "mii-exa-test-data-patient-9-prozedur-2",
      "description" : "Procedure: Laparoskopische Zystektomie bei Ovarialzyste für Patient-9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-9-specimen-1.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-9-specimen-1"
      },
      "name" : "mii-exa-test-data-patient-9-specimen-1",
      "description" : "Specimen: EDTA-Blut für Hämatologie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patient-9-specimen-2.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patient-9-specimen-2"
      },
      "name" : "mii-exa-test-data-patient-9-specimen-2",
      "description" : "Specimen: Serum für Klinische Chemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patient-9-vitalstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patient-9-vitalstatus-1"
      },
      "name" : "mii-exa-test-data-patient-9-vitalstatus-1",
      "description" : "Observation: Vitalstatus für Patient-9",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-patient-pseudonym-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-patient-pseudonym-1"
      },
      "name" : "mii-exa-test-data-patient-pseudonym-1",
      "description" : "Patient (pseudonymisiert): eigenstaendiger Testpatient nur mit Pseudonym, ohne identifizierende Daten",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-mii-exa-test-data-practitioner-physician-1.html"
      }],
      "reference" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-1"
      },
      "name" : "mii-exa-test-data-practitioner-physician-1",
      "description" : "Practitioner: Dr. Rahel Hirsch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-mii-exa-test-data-practitioner-physician-2.html"
      }],
      "reference" : {
        "reference" : "Practitioner/mii-exa-test-data-practitioner-physician-2"
      },
      "name" : "mii-exa-test-data-practitioner-physician-2",
      "description" : "Practitioner: Dr. Robert Koch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-mii-exa-test-data-practitioner-role-physician-1.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/mii-exa-test-data-practitioner-role-physician-1"
      },
      "name" : "mii-exa-test-data-practitioner-role-physician-1",
      "description" : "PractitionerRole: Physician",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-pro-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-pro-diagnose-1"
      },
      "name" : "mii-exa-test-data-pro-diagnose-1",
      "description" : "Condition: Mittelgradige depressive Episode fuer PRO-Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-pro-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-pro-encounter-1"
      },
      "name" : "mii-exa-test-data-pro-encounter-1",
      "description" : "PRO Test Encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-pro-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-pro-patient-1"
      },
      "name" : "mii-exa-test-data-pro-patient-1",
      "description" : "PRO Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-radiologische-beobachtung.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-radiologische-beobachtung"
      },
      "name" : "mii-exa-test-data-radiologische-beobachtung",
      "description" : "Observation: Radiologische Beobachtung",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-radiologische-beobachtung-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-radiologische-beobachtung-2"
      },
      "name" : "mii-exa-test-data-radiologische-beobachtung-2",
      "description" : "Observation: Radiologische Beobachtung (Architekturstoerung: nein, valueCodeableConcept)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-radiologische-beobachtung-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-radiologische-beobachtung-3"
      },
      "name" : "mii-exa-test-data-radiologische-beobachtung-3",
      "description" : "Observation: Radiologische Beobachtung (Herddurchmesser 8 mm, valueQuantity)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-radiologische-messung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-radiologische-messung-1"
      },
      "name" : "mii-exa-test-data-radiologische-messung-1",
      "description" : "Observation: Radiologische Messung (Durchmesser des Herdbefunds, 4.2 mm)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-seltene-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-seltene-encounter-1"
      },
      "name" : "mii-exa-test-data-seltene-encounter-1",
      "description" : "Seltene Erkrankungen Test Encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-seltene-labobs-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-seltene-labobs-1"
      },
      "name" : "mii-exa-test-data-seltene-labobs-1",
      "description" : "Seltene Lab Observation - Enzymaktivitaet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-seltene-molgen-befundbericht-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-seltene-molgen-befundbericht-1"
      },
      "name" : "mii-exa-test-data-seltene-molgen-befundbericht-1",
      "description" : "Seltene Molgen Befundbericht Stub",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-seltene-molgen-variante-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-seltene-molgen-variante-1"
      },
      "name" : "mii-exa-test-data-seltene-molgen-variante-1",
      "description" : "Seltene Molgen Variante Stub",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-seltene-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-seltene-patient-1"
      },
      "name" : "mii-exa-test-data-seltene-patient-1",
      "description" : "Seltene Erkrankungen Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-seltene-register-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-seltene-register-consent-1"
      },
      "name" : "mii-exa-test-data-seltene-register-consent-1",
      "description" : "Consent: Einwilligung in die Teilnahme am ERN ReCONNET Register",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-ausbildung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-ausbildung-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-ausbildung-1",
      "description" : "Soziodemographie: Berufsausbildung Lehre",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-berufliche-stellung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-berufliche-stellung-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-berufliche-stellung-1",
      "description" : "Soziodemographie: Berufliche Stellung Angestellte (lang-Slice)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-berufliche-stellung-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-berufliche-stellung-2"
      },
      "name" : "mii-exa-test-data-soziodemographie-berufliche-stellung-2",
      "description" : "Soziodemographie: Berufliche Stellung Angestellte (minimal-Slice)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-beschaeftigungsstatus-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-beschaeftigungsstatus-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-beschaeftigungsstatus-1",
      "description" : "Soziodemographie: Beschaeftigungsstatus Rentnerin (lang-Slice)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-beschaeftigungsstatus-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-beschaeftigungsstatus-2"
      },
      "name" : "mii-exa-test-data-soziodemographie-beschaeftigungsstatus-2",
      "description" : "Soziodemographie: Beschaeftigungsstatus Rente (minimal-Slice)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-betreuungssituation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-betreuungssituation-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-betreuungssituation-1",
      "description" : "Soziodemographie: Betreuung auf Anfrage (Hausnotruf)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-datenerhebung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-datenerhebung-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-datenerhebung-1",
      "description" : "Soziodemographie: Datenerhebung per Selbstauskunft mit allen Einzel-Observations",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-einkommen-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-einkommen-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-einkommen-1",
      "description" : "Soziodemographie: Haushaltsnettoeinkommen 2.000 bis unter 3.000 Euro",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-geburtsland-mutter-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-geburtsland-mutter-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-geburtsland-mutter-1",
      "description" : "Soziodemographie: Geburtsland der Mutter (Polen)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-geburtsland-vater-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-geburtsland-vater-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-geburtsland-vater-1",
      "description" : "Soziodemographie: Geburtsland des Vaters (Deutschland)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-haushaltsgroesse-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-haushaltsgroesse-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-haushaltsgroesse-1",
      "description" : "Soziodemographie: Haushaltsgroesse 2 Personen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-partnerschaft-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-partnerschaft-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-partnerschaft-1",
      "description" : "Soziodemographie: Aktuelle Partnerschaft vorhanden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-soziodemographie-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-soziodemographie-patient-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-patient-1",
      "description" : "Soziodemographie Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-schulabschluss-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-schulabschluss-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-schulabschluss-1",
      "description" : "Soziodemographie: Realschulabschluss",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-schuljahre-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-schuljahre-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-schuljahre-1",
      "description" : "Soziodemographie: 10 Schuljahre",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-schwerbehindertenausweis-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-schwerbehindertenausweis-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-schwerbehindertenausweis-1",
      "description" : "Soziodemographie: Schwerbehindertenausweis mit GdB 60 und Merkzeichen G",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-schwerbehindertenausweis-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-schwerbehindertenausweis-2"
      },
      "name" : "mii-exa-test-data-soziodemographie-schwerbehindertenausweis-2",
      "description" : "Soziodemographie: kein Schwerbehindertenausweis vorhanden (Nein-Zweig sba-1)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-schwerbehindertenausweis-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-schwerbehindertenausweis-3"
      },
      "name" : "mii-exa-test-data-soziodemographie-schwerbehindertenausweis-3",
      "description" : "Soziodemographie: Schwerbehindertenausweis erfragt, keine Angabe (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-soziooekonomische-faktoren-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-soziooekonomische-faktoren-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-soziooekonomische-faktoren-1",
      "description" : "Soziodemographie: Soziooekonomischer Faktor (generisch)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-soziodemographie-vertrauensperson-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-soziodemographie-vertrauensperson-1"
      },
      "name" : "mii-exa-test-data-soziodemographie-vertrauensperson-1",
      "description" : "Soziodemographie: Vertrauensperson vorhanden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-studie-einschluss-anfrage-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-studie-einschluss-anfrage-1"
      },
      "name" : "mii-exa-test-data-studie-einschluss-anfrage-1",
      "description" : "ServiceRequest: Studieneinschluss-Anfrage für Patient-1 in MII-BIOMARKER-2024",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-mii-exa-test-data-studien-consent-1.html"
      }],
      "reference" : {
        "reference" : "Consent/mii-exa-test-data-studien-consent-1"
      },
      "name" : "mii-exa-test-data-studien-consent-1",
      "description" : "Consent: Einwilligung in die Teilnahme an MII-BIOMARKER-2024",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-studien-diagnose-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-studien-diagnose-1"
      },
      "name" : "mii-exa-test-data-studien-diagnose-1",
      "description" : "Condition: Diabetes mellitus Typ 2 fuer Studien-Patient 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-test-data-studien-dokument-1.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-test-data-studien-dokument-1"
      },
      "name" : "mii-exa-test-data-studien-dokument-1",
      "description" : "DocumentReference: Studienprotokoll MII-BIOMARKER-2024",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-studien-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-studien-encounter-1"
      },
      "name" : "mii-exa-test-data-studien-encounter-1",
      "description" : "Studien Test Encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Group"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Group-mii-exa-test-data-studien-group-1.html"
      }],
      "reference" : {
        "reference" : "Group/mii-exa-test-data-studien-group-1"
      },
      "name" : "mii-exa-test-data-studien-group-1",
      "description" : "Group: Eligibility-Population der Studie MII-BIOMARKER-2024",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "EvidenceVariable"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "EvidenceVariable-mii-exa-test-data-studien-kriterium-1.html"
      }],
      "reference" : {
        "reference" : "EvidenceVariable/mii-exa-test-data-studien-kriterium-1"
      },
      "name" : "mii-exa-test-data-studien-kriterium-1",
      "description" : "EvidenceVariable: Ein-/Ausschlusskriterien der Studie MII-BIOMARKER-2024",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-studien-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-studien-patient-1"
      },
      "name" : "mii-exa-test-data-studien-patient-1",
      "description" : "Studien Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ResearchSubject"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ResearchSubject-mii-exa-test-data-studien-proband-1.html"
      }],
      "reference" : {
        "reference" : "ResearchSubject/mii-exa-test-data-studien-proband-1"
      },
      "name" : "mii-exa-test-data-studien-proband-1",
      "description" : "ResearchSubject: Proband Felix Proband in MII-BIOMARKER-2024",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-symptom-condition-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-symptom-condition-1"
      },
      "name" : "mii-exa-test-data-symptom-condition-1",
      "description" : "Symptom Condition: Chronische Spannungskopfschmerzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-symptom-condition-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-symptom-condition-2"
      },
      "name" : "mii-exa-test-data-symptom-condition-2",
      "description" : "Symptom Condition: Chronische Herzinsuffizienz, NYHA-Klasse II",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-symptom-device-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-symptom-device-1"
      },
      "name" : "mii-exa-test-data-symptom-device-1",
      "description" : "Symptom Test Device: digitales Symptomtagebuch (ePRO-App)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-mii-exa-test-data-symptom-encounter-1.html"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-test-data-symptom-encounter-1"
      },
      "name" : "mii-exa-test-data-symptom-encounter-1",
      "description" : "Symptom Test Encounter (ambulante Abklaerung)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-symptom-observation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-symptom-observation-1"
      },
      "name" : "mii-exa-test-data-symptom-observation-1",
      "description" : "Symptom Observation: Kopfschmerz mit Begleitsymptom und Schmerzintensitaet",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-symptom-observation-2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-symptom-observation-2"
      },
      "name" : "mii-exa-test-data-symptom-observation-2",
      "description" : "Symptom Observation: Schmerzintensitaet NRS aus dem Kopfschmerztagebuch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-symptom-observation-3.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-symptom-observation-3"
      },
      "name" : "mii-exa-test-data-symptom-observation-3",
      "description" : "Symptom Observation: Belastungsdyspnoe bei chronischer Herzinsuffizienz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-symptom-observation-4.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-symptom-observation-4"
      },
      "name" : "mii-exa-test-data-symptom-observation-4",
      "description" : "Symptom Observation: Schwindel erfragt, keine verwertbare Angabe (dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-mii-exa-test-data-symptom-patient-1.html"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-test-data-symptom-patient-1"
      },
      "name" : "mii-exa-test-data-symptom-patient-1",
      "description" : "Symptom Test Patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-test-data-symptom-questionnaireresponse-1.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-test-data-symptom-questionnaireresponse-1"
      },
      "name" : "mii-exa-test-data-symptom-questionnaireresponse-1",
      "description" : "Symptom Test QuestionnaireResponse: Kopfschmerztagebuch",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-micro-grouper-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-micro-grouper-1"
      },
      "name" : "Mikroskopische Befunde Grouper",
      "description" : "Gruppierung der mikroskopischen Befunde beider Prostatastanzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-micro-grouper-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-micro-grouper-dar-1"
      },
      "name" : "Mikroskopische Befunde Grouper - perineurale Infiltration nicht beurteilbar",
      "description" : "Mikroskopie-Grouper mit Komponente ohne Wert: perineurale Infiltration am vorliegenden Schnitt nicht beurteilbar (component.dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-morph-text-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-morph-text-01"
      },
      "name" : "Morphologie Freitext Stanze 01",
      "description" : "Morphologie Freitext für Stanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-morph-text-03.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-morph-text-03"
      },
      "name" : "Morphologie Freitext Stanze 03",
      "description" : "Morphologie Freitext für Stanze 03",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-morphology-free-text.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-morphology-free-text"
      },
      "name" : "Morphology Free Text Description - Biopsy",
      "description" : "Free text description of tumor morphology",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Claim"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Claim-mii-exa-test-data-mtb-antrag-kostenuebernahme-1.html"
      }],
      "reference" : {
        "reference" : "Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-1"
      },
      "name" : "MTB Antrag Kostenuebernahme",
      "description" : "Test instance for cost coverage application with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Claim"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Claim-mii-exa-test-data-mtb-antrag-kostenuebernahme-2.html"
      }],
      "reference" : {
        "reference" : "Claim/mii-exa-test-data-mtb-antrag-kostenuebernahme-2"
      },
      "name" : "MTB Antrag Kostenuebernahme (Erstantrag)",
      "description" : "Minimaler Erstantrag als Ziel der related.claim-Referenz des Folgeantrags",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClaimResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClaimResponse-mii-exa-test-data-mtb-antwort-kostenuebernahme-1.html"
      }],
      "reference" : {
        "reference" : "ClaimResponse/mii-exa-test-data-mtb-antwort-kostenuebernahme-1"
      },
      "name" : "MTB Antwort Kostenuebernahme",
      "description" : "Test instance for cost coverage response with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-mii-exa-test-data-mtb-behandlungsepisode-1.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/mii-exa-test-data-mtb-behandlungsepisode-1"
      },
      "name" : "MTB Behandlungsepisode",
      "description" : "Test instance for MTB treatment episode with all MS slices populated",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-biomarker-her2-status-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-biomarker-her2-status-1"
      },
      "name" : "MTB Biomarker HER2 Status",
      "description" : "Test instance for HER2 biomarker status",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-mtb-biopsie-auftrag-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-mtb-biopsie-auftrag-1"
      },
      "name" : "MTB Biopsie Auftrag",
      "description" : "Test instance for biopsy order",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-brcaness-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-brcaness-1"
      },
      "name" : "MTB BRCAness",
      "description" : "Test instance for BRCAness assessment",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-consent-given-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-consent-given-1"
      },
      "name" : "MTB Consent Given",
      "description" : "Test instance for MTB consent/patient education confirmation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-copy-number-variant-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-copy-number-variant-1"
      },
      "name" : "MTB Copy Number Variant - ERBB2",
      "description" : "Test instance for CNV (ERBB2 amplification) with all MS component slices",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-mtb-diagnose-primaertumor-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-1"
      },
      "name" : "MTB Diagnose Primaertumor",
      "description" : "Test instance for MTB primary tumor diagnosis with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-mtb-diagnose-primaertumor-3.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-3"
      },
      "name" : "MTB Diagnose Primaertumor (Variante abatementAge)",
      "description" : "Minimal-Variante fuer die MS-Choice-Alternative abatementAge",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-mtb-diagnose-primaertumor-2.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-mtb-diagnose-primaertumor-2"
      },
      "name" : "MTB Diagnose Primaertumor (Variante abatementDateTime)",
      "description" : "Minimal-Variante fuer die MS-Choice-Alternativen abatementDateTime und onsetAge",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-diagnostische-implikation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-diagnostische-implikation-1"
      },
      "name" : "MTB Diagnostische Implikation",
      "description" : "Test instance for diagnostic implication of EGFR variant",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-dna-fusion-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-dna-fusion-1"
      },
      "name" : "MTB DNA Fusion - EML4-ALK",
      "description" : "Test instance for DNA fusion variant (EML4-ALK)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-einfache-variante-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-einfache-variante-1"
      },
      "name" : "MTB Einfache Variante - EGFR",
      "description" : "Test instance for simple variant (EGFR L858R) with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-mii-exa-test-data-mtb-evidenz-liste-1.html"
      }],
      "reference" : {
        "reference" : "List/mii-exa-test-data-mtb-evidenz-liste-1"
      },
      "name" : "MTB Evidenz-Liste Erstdiagnose",
      "description" : "Liste der Evidenz-Befunde zur Erstdiagnose des Primaertumors",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-mii-exa-test-data-mtb-follow-up-1.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/mii-exa-test-data-mtb-follow-up-1"
      },
      "name" : "MTB Follow-Up",
      "description" : "Test instance for MTB follow-up clinical impression with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-mtb-genomic-study-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-mtb-genomic-study-1"
      },
      "name" : "MTB Genomic Study",
      "description" : "Test instance for MTB genomic study procedure",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-mtb-genomic-study-analysis-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-mtb-genomic-study-analysis-1"
      },
      "name" : "MTB Genomic Study Analysis",
      "description" : "Test instance for MTB genomic study analysis with method and change types",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-test-data-mtb-device-sequencer-1.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-test-data-mtb-device-sequencer-1"
      },
      "name" : "MTB Genomic Study Device (Sequencer)",
      "description" : "Device: NGS-Sequenzierer (Illumina NovaSeq 6000) des MTB-NGS-Workflows",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-mtb-histologie-evaluation-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-mtb-histologie-evaluation-1"
      },
      "name" : "MTB Histologie Evaluation Auftrag",
      "description" : "Test instance for histology evaluation order",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-hrd-score-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-hrd-score-1"
      },
      "name" : "MTB HRD Score",
      "description" : "Test instance for homologous recombination deficiency score with sub-scores",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-mtb-humangenetische-beratung-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-mtb-humangenetische-beratung-1"
      },
      "name" : "MTB Humangenetische Beratung Auftrag",
      "description" : "Test instance for human genetics counseling order",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-ihc-mmr-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-ihc-mmr-1"
      },
      "name" : "MTB IHC MMR",
      "description" : "Test instance for mismatch repair protein immunohistochemistry",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-ihc-msi-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-ihc-msi-1"
      },
      "name" : "MTB IHC MSI",
      "description" : "Test instance for MSI by immunohistochemistry",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-ihc-phosphorylation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-ihc-phosphorylation-1"
      },
      "name" : "MTB IHC Phosphorylation",
      "description" : "Test instance for phosphorylation immunohistochemistry",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-immunohistochemistry-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-immunohistochemistry-1"
      },
      "name" : "MTB Immunohistochemistry - PD-L1",
      "description" : "Test instance for immunohistochemistry observation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-immunohistochemistry-her2-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-immunohistochemistry-her2-1"
      },
      "name" : "MTB Immunohistochemistry HER2",
      "description" : "Test instance for HER2 immunohistochemistry",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-immunohistochemistry-pdl1-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-immunohistochemistry-pdl1-1"
      },
      "name" : "MTB Immunohistochemistry PD-L1",
      "description" : "Test instance for PD-L1 immunohistochemistry with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-insituhybridization-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-insituhybridization-1"
      },
      "name" : "MTB In Situ Hybridization",
      "description" : "Test instance for in situ hybridization biomarker",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-insituhybridization-her2-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-insituhybridization-her2-1"
      },
      "name" : "MTB In Situ Hybridization HER2",
      "description" : "Test instance for HER2 FISH with all component slices",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-mikrosatelliteninstabilitaet-1"
      },
      "name" : "MTB Mikrosatelliteninstabilitaet (MSI)",
      "description" : "Test instance for microsatellite instability",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-mtb-molecular-pathology-report-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-mtb-molecular-pathology-report-1"
      },
      "name" : "MTB Molecular Pathology Report",
      "description" : "Test instance for molecular pathology report",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-molekularer-biomarker-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-molekularer-biomarker-1"
      },
      "name" : "MTB Molekularer Biomarker",
      "description" : "Test instance for molecular biomarker base profile",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-mutationslast-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-mutationslast-1"
      },
      "name" : "MTB Mutationslast (TMB)",
      "description" : "Test instance for tumor mutational burden",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-mtb-ngs-bericht-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-mtb-ngs-bericht-1"
      },
      "name" : "MTB NGS Bericht",
      "description" : "Test instance for NGS report with all result slices populated",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-oncotree-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-oncotree-1"
      },
      "name" : "MTB Oncotree Classification",
      "description" : "Test instance for Oncotree tumor classification",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DeviceDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DeviceDefinition-mii-exa-test-data-mtb-panel-devicedef-1.html"
      }],
      "reference" : {
        "reference" : "DeviceDefinition/mii-exa-test-data-mtb-panel-devicedef-1"
      },
      "name" : "MTB Panel DeviceDefinition (TSO 500)",
      "description" : "DeviceDefinition: NGS-Gen-Panel TruSight Oncology 500 des MTB-NGS-Workflows",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-ploidie-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-ploidie-1"
      },
      "name" : "MTB Ploidie",
      "description" : "Test instance for ploidy assessment",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-response-befund-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-response-befund-1"
      },
      "name" : "MTB Response Befund",
      "description" : "Test instance for MTB response assessment with RECIST method",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-rna-fusion-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-rna-fusion-1"
      },
      "name" : "MTB RNA Fusion - BCR-ABL1",
      "description" : "Test instance for RNA fusion variant (BCR-ABL1)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-rna-seq-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-rna-seq-1"
      },
      "name" : "MTB RNA Seq",
      "description" : "Test instance for RNA sequencing observation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ResearchStudy"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ResearchStudy-mii-exa-test-data-mtb-studie-1.html"
      }],
      "reference" : {
        "reference" : "ResearchStudy/mii-exa-test-data-mtb-studie-1"
      },
      "name" : "MTB Studie",
      "description" : "Test instance for MTB research study",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ResearchStudy"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ResearchStudy-mii-exa-test-data-mtb-studie-2.html"
      }],
      "reference" : {
        "reference" : "ResearchStudy/mii-exa-test-data-mtb-studie-2"
      },
      "name" : "MTB Studie (Dachstudie)",
      "description" : "Minimales Studien-Stub als Ziel der partOf-Referenz der MTB-Studie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Group"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Group-mii-exa-test-data-mtb-studie-group-1.html"
      }],
      "reference" : {
        "reference" : "Group/mii-exa-test-data-mtb-studie-group-1"
      },
      "name" : "MTB Studien-Eligibility-Gruppe",
      "description" : "Eligibility-Population der MTB-Studie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-mtb-studieneinschluss-anfrage-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-mtb-studieneinschluss-anfrage-1"
      },
      "name" : "MTB Studieneinschluss Anfrage",
      "description" : "Test instance for study enrollment request with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-mtb-studieneinschluss-anfrage-2.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-mtb-studieneinschluss-anfrage-2"
      },
      "name" : "MTB Studieneinschluss Anfrage (abgelehnt)",
      "description" : "Test instance for a rejected study enrollment request (statusReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Library"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Library-mii-exa-test-data-mtb-studien-register-1.html"
      }],
      "reference" : {
        "reference" : "Library/mii-exa-test-data-mtb-studien-register-1"
      },
      "name" : "MTB Studienregister",
      "description" : "Studienregister-Eintrag (ClinicalTrials.gov) der MTB-Studie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-mtb-systemische-therapie-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-therapie-1"
      },
      "name" : "MTB Systemische Therapie",
      "description" : "Test instance for MTB systemic therapy procedure",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-mtb-systemische-therapie-medstatement-1.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-1"
      },
      "name" : "MTB Systemische Therapie MedicationStatement",
      "description" : "Test instance for MTB systemic therapy medication statement",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-test-data-mtb-systemische-vortherapie-1.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-test-data-mtb-systemische-vortherapie-1"
      },
      "name" : "MTB Systemische Vortherapie",
      "description" : "Test instance for prior systemic therapy",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-mtb-systemische-therapie-medstatement-2.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-2"
      },
      "name" : "MTB Systemtherapie MedicationStatement (Variante asNeededCodeableConcept)",
      "description" : "Minimal-Variante fuer die MS-Choice-Alternativen asNeededCodeableConcept, boundsDuration und timing.when",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-mii-exa-test-data-mtb-systemische-therapie-medstatement-3.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-test-data-mtb-systemische-therapie-medstatement-3"
      },
      "name" : "MTB Systemtherapie MedicationStatement (Variante boundsRange)",
      "description" : "Minimal-Variante fuer die MS-Choice-Alternative timing.repeat.boundsRange",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-therapeutische-implikation-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-therapeutische-implikation-1"
      },
      "name" : "MTB Therapeutische Implikation",
      "description" : "Test instance for therapeutic implication with evidence grading",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-1.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-1"
      },
      "name" : "MTB Therapieempfehlung - Osimertinib",
      "description" : "Test instance for therapy recommendation with priority, evidence, and publication",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-2.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-2"
      },
      "name" : "MTB Therapieempfehlung - Sotorasib",
      "description" : "Test instance for second therapy recommendation (part of combination)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-test-data-mtb-therapieempfehlung-3.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-test-data-mtb-therapieempfehlung-3"
      },
      "name" : "MTB Therapieempfehlung - Trametinib",
      "description" : "Test instance for third therapy recommendation (part of combination)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RequestGroup-mii-exa-test-data-mtb-therapieempfehlung-kombination-1.html"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-test-data-mtb-therapieempfehlung-kombination-1"
      },
      "name" : "MTB Therapieempfehlung Kombination",
      "description" : "Test instance for combination therapy recommendation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-mii-exa-test-data-mtb-therapieplan-1.html"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-test-data-mtb-therapieplan-1"
      },
      "name" : "MTB Therapieplan",
      "description" : "Test instance for MTB therapy plan with all activity slices",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-tumorausbreitung-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-tumorausbreitung-1"
      },
      "name" : "MTB Tumorausbreitung",
      "description" : "Test instance for tumor spread assessment with all MS elements",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-tumorzellgehalt-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-tumorzellgehalt-1"
      },
      "name" : "MTB Tumorzellgehalt",
      "description" : "Test instance for tumor cell content measurement",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-mtb-who-grad-tumor-zns-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-mtb-who-grad-tumor-zns-1"
      },
      "name" : "MTB WHO Grad Tumor ZNS",
      "description" : "Test instance for WHO CNS tumor grading",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-positive-cores-left.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-positive-cores-left"
      },
      "name" : "Number of Positive Cores Left Side - Biopsy",
      "description" : "Number of tissue cores positive for carcinoma on the left side",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-positive-cores-right.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-positive-cores-right"
      },
      "name" : "Number of Positive Cores Right Side - Biopsy",
      "description" : "Number of tissue cores positive for carcinoma on the right side",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patho-specimen-01-block.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patho-specimen-01-block"
      },
      "name" : "Paraffinblock Stanze 01",
      "description" : "Paraffineinbettung der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patho-specimen-03-block.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patho-specimen-03-block"
      },
      "name" : "Paraffinblock Stanze 03",
      "description" : "Paraffineinbettung der Prostatastanze 03",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ImagingStudy"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ImagingStudy-mii-exa-test-data-patho-imaging-study-1.html"
      }],
      "reference" : {
        "reference" : "ImagingStudy/mii-exa-test-data-patho-imaging-study-1"
      },
      "name" : "Patho Whole-Slide-Imaging Studie",
      "description" : "Whole-Slide-Imaging (DICOM) des HE-Schnitts der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-mii-exa-test-data-patho-report-1.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-test-data-patho-report-1"
      },
      "name" : "Pathologiebericht Prostatastanzen",
      "description" : "Pathologiebericht für die 2-Stanzen-Prostatabiopsie (Stanze 01 positiv, Stanze 03 benigne)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-percentage-gleason-45.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-percentage-gleason-45"
      },
      "name" : "Percentage of Gleason Pattern 4/5 - Biopsy",
      "description" : "Percentage of tumor area with Gleason pattern 4 and 5",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-percentage-tumor-total.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-percentage-tumor-total"
      },
      "name" : "Percentage Tumor Content Total - Biopsy",
      "description" : "Total percentage of tumor in all positive tissue cores",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-perineural-infiltration.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-perineural-infiltration"
      },
      "name" : "Perineural Infiltration - Biopsy",
      "description" : "Presence of perineural invasion in cancer specimen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-periprostatatic-fat-invasion.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-periprostatatic-fat-invasion"
      },
      "name" : "Periprostatic Fat Invasion - Biopsy",
      "description" : "Tumor invasion into periprostatic connective and adipose tissue (typically not assessable in biopsy)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-primary-gleason-pattern.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-primary-gleason-pattern"
      },
      "name" : "Primary Gleason Pattern (Epstein 2005) - Biopsy",
      "description" : "Primary Gleason pattern according to Epstein 2005",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-primaer-gleason-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-primaer-gleason-01"
      },
      "name" : "Primäres Gleason Muster Stanze 01",
      "description" : "Primäres Gleason Muster für Stanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-test-data-patho-request-1.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-test-data-patho-request-1"
      },
      "name" : "Prostatabiopsie Anforderung (2 Stanzen)",
      "description" : "Anforderung für die 2-Stanzen-Prostatabiopsie (Testdaten-Szenario)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patho-specimen-01-part.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patho-specimen-01-part"
      },
      "name" : "Prostatastanze 01 - Rechts lateral basal",
      "description" : "Tru-cut Biopsie aus der rechten lateralen Basis (periphere Zone)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-mii-exa-test-data-patho-specimen-03-part.html"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-test-data-patho-specimen-03-part"
      },
      "name" : "Prostatastanze 03 - Rechts lateral apikal",
      "description" : "Tru-cut Biopsie aus der rechten lateralen Apex (periphere Zone)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-tumoranteil-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-tumoranteil-01"
      },
      "name" : "Prozentualer Tumoranteil Stanze 01",
      "description" : "Prozentualer Tumoranteil für Stanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-psa-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-psa-1"
      },
      "name" : "PSA vor Biopsie",
      "description" : "PSA-Wert vor der Prostatastanzenentnahme",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-ratio-positive-cores.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-ratio-positive-cores"
      },
      "name" : "Ratio of Positive to Total Cores - Biopsy",
      "description" : "Ratio of positive cores to all examined cores",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-intraop-befund-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-intraop-befund-1"
      },
      "name" : "Schnellschnitt-Befund Stanze 01",
      "description" : "Intraoperative Beobachtung (Schnellschnitt): Nachweis eines azinären Adenokarzinoms in Stanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-secondary-gleason-pattern.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-secondary-gleason-pattern"
      },
      "name" : "Secondary Gleason Pattern (Epstein 2005) - Biopsy",
      "description" : "Secondary Gleason pattern according to Epstein 2005",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macroscopic-laterality-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macroscopic-laterality-01"
      },
      "name" : "Seitenangabe Stanze 01",
      "description" : "Lateralitätsangabe der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-macroscopic-laterality-03.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-macroscopic-laterality-03"
      },
      "name" : "Seitenangabe Stanze 03",
      "description" : "Lateralitätsangabe der Prostatastanze 03",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-sekundaer-gleason-01.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-sekundaer-gleason-01"
      },
      "name" : "Sekundäres Gleason Muster Stanze 01",
      "description" : "Sekundäres Gleason Muster für Stanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-seminal-vesicle-invasion.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-seminal-vesicle-invasion"
      },
      "name" : "Seminal Vesicle Invasion - Biopsy",
      "description" : "Tumor invasion into seminal vesicles (typically not assessable in biopsy)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-gleason-score-total.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-gleason-score-total"
      },
      "name" : "Total Gleason Score - Biopsy",
      "description" : "Total Gleason score in biopsy specimens",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-tumor-length-total.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-tumor-length-total"
      },
      "name" : "Total Tumor Length in mm - Biopsy",
      "description" : "Total linear length of carcinoma in millimeters",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Media"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Media-mii-exa-test-data-patho-image-2.html"
      }],
      "reference" : {
        "reference" : "Media/mii-exa-test-data-patho-image-2"
      },
      "name" : "Uebersichtsaufnahme HE-Schnitt Stanze 01",
      "description" : "Attached Image: Uebersichtsaufnahme (geringe Vergroesserung) des HE-Schnitts der Prostatastanze 01",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-test-data-patho-diagnose-verdacht-1.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-test-data-patho-diagnose-verdacht-1"
      },
      "name" : "Verdachtsdiagnose Prostatakarzinom vor Biopsie",
      "description" : "Verdacht auf Prostatakarzinom basierend auf erhöhtem PSA und auffälligem MRT-Befund",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Composition-mii-exa-test-data-patho-composition-0.html"
      }],
      "reference" : {
        "reference" : "Composition/mii-exa-test-data-patho-composition-0"
      },
      "name" : "Vorlaeufiger Befundbericht Prostatabiopsie",
      "description" : "Vorlaeufige Composition (Schnellschnitt-Vorabmitteilung), ersetzt durch die finale Composition",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-zusatz-grouper-dar-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-zusatz-grouper-dar-1"
      },
      "name" : "Zusaetzliche Beobachtungen Grouper - Immunhistochemie nicht durchgefuehrt",
      "description" : "Zusatzbefund-Grouper mit Komponente ohne Wert: weiterfuehrende Immunhistochemie am erschoepften Block nicht durchgefuehrt (component.dataAbsentReason)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-test-data-patho-zusatz-grouper-1.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-test-data-patho-zusatz-grouper-1"
      },
      "name" : "Zusätzliche Beobachtungen Grouper",
      "description" : "Gruppierung der zusätzlichen Beobachtungen (Immunhistochemie)",
      "exampleBoolean" : true
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "nutzung.html"
        }],
        "nameUrl" : "nutzung.html",
        "title" : "Nutzung",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "testabdeckung.html"
        }],
        "nameUrl" : "testabdeckung.html",
        "title" : "Testabdeckung",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/predefined-resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
