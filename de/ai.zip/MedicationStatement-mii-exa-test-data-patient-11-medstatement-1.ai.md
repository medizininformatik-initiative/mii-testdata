# mii-exa-test-data-patient-11-medstatement-1 - MII KDS Test Data v2027.0.0-ballot.rc2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-exa-test-data-patient-11-medstatement-1**

## Beispiel MedicationStatement: mii-exa-test-data-patient-11-medstatement-1

-------

**German**

-------

Information Source: [https://www.charite.de/fhir/kds-testdata](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&canonical=https://www.charite.de/fhir/kds-testdata)

Profile: [MII PR Medikation MedicationStatement](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&canonical=https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement)

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html)

**identifier**: `https://www.charite.de/fhir/sid/MedicationStatements`/MS_0000021

**basedOn**: [MedicationRequest: identifier = https://www.charite.de/fhir/sid/MedicationOrders#MO_0000021; status = active; intent = order; medication[x] = ->Medication Valsartan und Sacubitril; authoredOn = 2025-01-28 09:40:00+0100; note = Auftitration auf 97/103 mg nach vier Wochen bei stabilem Blutdruck vorgesehen.](MedicationRequest-mii-exa-test-data-patient-11-medrequest-1.md)

**status**: Active

**category**: ambulanter Kontakt

**medication**: [Medication Valsartan und Sacubitril](Medication-mii-exa-test-data-medication-sacubitril-valsartan.md)

**subject**: [Ingrid Margarete Hallermann (official) Female, DoB: 1959-11-08 ( Krankenaktennummer (use: usual, ))](Patient-mii-exa-test-data-patient-11.md)

**context**: [Encounter: identifier = Fallnummer; status = finished; class = ambulatory (ActCode#AMB); type = Einrichtungskontakt,Untersuchung und Behandlung; serviceType = Kardiologie; period = 2025-02-10 09:00:00+0100 --> 2025-02-10 11:30:00+0100](Encounter-mii-exa-test-data-patient-11-encounter-2.md)

**effective**: 2025-01-28 --> (ongoing)

**dateAsserted**: 2025-02-10

**informationSource**: [Ingrid Margarete Hallermann (official) Female, DoB: 1959-11-08 ( Krankenaktennummer (use: usual, ))](Patient-mii-exa-test-data-patient-11.md)

**reasonReference**: [Condition Heart failure](Condition-mii-exa-test-data-patient-11-diagnose-1.md)

**note**: 

> 

Patientin berichtet regelmäßige Einnahme; keine symptomatische Hypotonie.


> **dosage****sequence**: 1**timing**: 2 per 1 day**route**: Oral use

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 1 Tablet (Details: standardterms.edqm.eu code10219000 = 'Tablette') |




## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "mii-exa-test-data-patient-11-medstatement-1",
  "meta" : {
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "identifier" : [{
    "system" : "https://www.charite.de/fhir/sid/MedicationStatements",
    "value" : "MS_0000021"
  }],
  "basedOn" : [{
    "reference" : "MedicationRequest/mii-exa-test-data-patient-11-medrequest-1"
  }],
  "status" : "active",
  "category" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/medication-statement-category",
      "code" : "outpatient"
    },
    {
      "system" : "http://ihe-d.de/CodeSystems/FallkontextBeiDokumentenerstellung",
      "code" : "E100",
      "display" : "ambulanter Kontakt"
    }]
  },
  "medicationReference" : {
    "reference" : "Medication/mii-exa-test-data-medication-sacubitril-valsartan"
  },
  "subject" : {
    "reference" : "Patient/mii-exa-test-data-patient-11"
  },
  "context" : {
    "reference" : "Encounter/mii-exa-test-data-patient-11-encounter-2"
  },
  "effectivePeriod" : {
    "start" : "2025-01-28"
  },
  "dateAsserted" : "2025-02-10",
  "informationSource" : {
    "reference" : "Patient/mii-exa-test-data-patient-11"
  },
  "reasonReference" : [{
    "reference" : "Condition/mii-exa-test-data-patient-11-diagnose-1"
  }],
  "note" : [{
    "text" : "Patientin berichtet regelmäßige Einnahme; keine symptomatische Hypotonie."
  }],
  "dosage" : [{
    "sequence" : 1,
    "timing" : {
      "repeat" : {
        "frequency" : 2,
        "period" : 1,
        "periodUnit" : "d"
      }
    },
    "route" : {
      "coding" : [{
        "system" : "http://standardterms.edqm.eu",
        "code" : "20053000",
        "display" : "Oral use"
      }]
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 1,
        "unit" : "Tablet",
        "system" : "http://standardterms.edqm.eu",
        "code" : "10219000"
      }
    }]
  }]
}

```
