# Histopathologischer Befundbericht - Prostatabiopsie - MII KDS Test Data v2027.0.0-ballot.rc2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Histopathologischer Befundbericht - Prostatabiopsie**

## Beispiel Composition: Histopathologischer Befundbericht - Prostatabiopsie

-------

**German**

-------

Last updated: 2024-01-20 16:00:00+0100; 

Information Source: [https://www.charite.de/fhir/kds-testdata](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&canonical=https://www.charite.de/fhir/kds-testdata)

Profile: [MII PR Patho Composition](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.complete@2027.0.0-ballot.19&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-composition)

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html)

**Document DiagnosticReport Reference**: [Diagnostic Report for 'Pathology synoptic report' for '->Klaus Gewebeprobe Male, DoB: 1963-06-30 ( https://www.charite.de/fhir/sid/patientenidentifikation#PATH-TEST-001)'](DiagnosticReport-mii-exa-test-data-patho-report-1.md)

**Composition Version Number**: 1

**identifier**: Accession ID/E_24_001

**status**: Final

**type**: Histopathologischer Befundbericht

**category**: Befundbericht

**encounter**: [Encounter: status = finished; class = inpatient encounter (ActCode#IMP); period = 2024-01-10 --> 2024-02-20](Encounter-mii-exa-test-data-patho-encounter-1.md)

**date**: 2024-01-20 15:30:00+0100

**author**: [Institut für Pathologie](Organization-mii-exa-test-data-patho-organization-1.md)

**title**: Histopathologischer Befundbericht - Prostatabiopsie

> **attester****mode**: Legal**party**: [Organization Institut für Pathologie, Charité - Universitätsmedizin Berlin](Organization-mii-exa-test-data-patho-organization-1.md)

> **attester****mode**: Professional**party**: [Practitioner Paula Schnittbild ](Practitioner-mii-exa-test-data-patho-practitioner-1.md)

**custodian**: [Organization Institut für Pathologie, Charité - Universitätsmedizin Berlin](Organization-mii-exa-test-data-patho-organization-1.md)

### RelatesTos

| | | |
| :--- | :--- | :--- |
| - | **Code** | **Target[x]** |
| * | Replaces | [Composition Vorlaeufiger Befundbericht - Prostatabiopsie](Composition-mii-exa-test-data-patho-composition-0.md) |

### Events

| | | |
| :--- | :--- | :--- |
| - | **Period** | **Detail** |
| * | 2024-01-15 --> 2024-01-20 | [ServiceRequest Prostate Pathology biopsy report](ServiceRequest-mii-exa-test-data-patho-request-1.md) |



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "mii-exa-test-data-patho-composition-1",
  "meta" : {
    "lastUpdated" : "2024-01-20T16:00:00+01:00",
    "source" : "https://www.charite.de/fhir/kds-testdata",
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-composition"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "extension" : [{
    "url" : "http://hl7.eu/fhir/extensions/StructureDefinition/composition-diagnosticReportReference",
    "valueReference" : {
      "reference" : "DiagnosticReport/mii-exa-test-data-patho-report-1"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/composition-clinicaldocument-versionNumber",
    "valueString" : "1"
  }],
  "identifier" : {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "ACSN",
        "display" : "Accession ID"
      }]
    },
    "system" : "https://www.charite.de/fhir/sid/patho/befundbericht",
    "value" : "E_24_001"
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "11526-1",
      "display" : "Pathology study"
    },
    {
      "system" : "http://ihe-d.de/CodeSystems/IHEXDStypeCode",
      "code" : "PATH"
    },
    {
      "system" : "http://snomed.info/sct",
      "code" : "721967005",
      "display" : "Tissue pathology biopsy report"
    }],
    "text" : "Histopathologischer Befundbericht"
  },
  "category" : [{
    "coding" : [{
      "system" : "http://ihe-d.de/CodeSystems/IHEXDSclassCode",
      "code" : "BEF"
    }]
  }],
  "subject" : {
    "reference" : "Patient/mii-exa-test-data-patho-patient-1"
  },
  "encounter" : {
    "reference" : "Encounter/mii-exa-test-data-patho-encounter-1"
  },
  "date" : "2024-01-20T15:30:00+01:00",
  "author" : [{
    "reference" : "Organization/mii-exa-test-data-patho-organization-1",
    "display" : "Institut für Pathologie"
  }],
  "title" : "Histopathologischer Befundbericht - Prostatabiopsie",
  "attester" : [{
    "mode" : "legal",
    "party" : {
      "reference" : "Organization/mii-exa-test-data-patho-organization-1"
    }
  },
  {
    "mode" : "professional",
    "party" : {
      "reference" : "Practitioner/mii-exa-test-data-patho-practitioner-1"
    }
  }],
  "custodian" : {
    "reference" : "Organization/mii-exa-test-data-patho-organization-1"
  },
  "relatesTo" : [{
    "code" : "replaces",
    "targetReference" : {
      "reference" : "Composition/mii-exa-test-data-patho-composition-0"
    }
  }],
  "event" : [{
    "period" : {
      "start" : "2024-01-15",
      "end" : "2024-01-20"
    },
    "detail" : [{
      "reference" : "ServiceRequest/mii-exa-test-data-patho-request-1"
    }]
  }],
  "section" : [{
    "title" : "Pathologiebefundbericht",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "60567-5",
        "display" : "Comprehensive pathology report panel"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Klinische Angaben</h3><p>Erhöhter PSA-Wert (12,8 ng/ml). V.a. Prostatakarzinom. Bitte histologische Abklärung. Stanzbiopsie der rechten Prostata (2 Stanzen).</p><p>Der vollständige strukturierte Befund gliedert sich in die Sektionen Makroskopie, Mikroskopie, Intraoperative Beobachtung, Diagnostische Schlussfolgerung und Zusätzliche Beobachtungen.</p></div>"
    },
    "entry" : [{
      "reference" : "DiagnosticReport/mii-exa-test-data-patho-report-1"
    }],
    "section" : [{
      "title" : "Vorläufige Mitteilung",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Vorabmitteilung des Schnellschnittergebnisses am 2024-01-15.</p></div>"
      }
    }]
  },
  {
    "title" : "Makroskopie",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "22634-0",
        "display" : "Pathology report gross observation Narrative"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Makroskopische Messungen beider Prostatastanzen, je 1 Zylinder pro Specimen.</p><table><thead><tr><th>Stanze</th><th>Lokalisation</th><th>Stanzenlänge (cm)</th></tr></thead><tbody><tr><td>01</td><td>Rechts lateral basal</td><td>1.8</td></tr><tr><td>03</td><td>Rechts lateral apikal</td><td>1.5</td></tr></tbody></table></div>"
    },
    "entry" : [{
      "reference" : "Observation/mii-exa-test-data-patho-macro-grouper-1"
    }],
    "section" : [{
      "title" : "Makroskopie Stanze 01",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Stanze 01: 1 Zylinder, 1,8 cm, rechts lateral basal.</p></div>"
      }
    }]
  },
  {
    "title" : "Mikroskopie",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "22635-7",
        "display" : "Pathology report microscopic observation Narrative Other stain"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Adenokarzinom in Stanze 01 nachgewiesen: azinäres Adenokarzinom, Gleason-Score 3+4=7, ISUP-Gradgruppe 2, Tumoranteil 40%. Stanze 03 benigne (fibröse und glatte Muskulatur mit vereinzelten benignen Prostatadrüsen, keine Atypien).</p></div>"
    },
    "entry" : [{
      "reference" : "Observation/mii-exa-test-data-patho-micro-grouper-1"
    }],
    "section" : [{
      "title" : "Mikroskopie Stanze 01",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Stanze 01: azinäres Adenokarzinom, Gleason 3+4=7.</p></div>"
      }
    }]
  },
  {
    "title" : "Intraoperative Beobachtung",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "83321-0",
        "display" : "Pathology report intraoperative observation in Specimen Document"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Schnellschnitt Stanze 01: Nachweis eines azinären Adenokarzinoms; endgültige Gradierung am Paraffinmaterial.</p></div>"
    },
    "entry" : [{
      "reference" : "Observation/mii-exa-test-data-patho-intraop-grouper-1"
    }],
    "section" : [{
      "title" : "Schnellschnitt Stanze 01",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Schnellschnitt: Nachweis eines azinären Adenokarzinoms.</p></div>"
      }
    }]
  },
  {
    "title" : "Diagnostische Schlussfolgerung",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "22637-3",
        "display" : "Pathology report final diagnosis Narrative"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>1 von 2 Stanzen tumorbefallen (Stanze 01, rechts lateral basal). Prozentualer Tumoranteil 40%, Tumorlänge gesamt 7,2 mm. Perineurale Infiltration nachgewiesen. Infiltration des periprostatischen Fettgewebes, Samenblaseninfiltration, lymphovaskuläre Invasion, intraduktales Karzinom, ASAP, High-grade-PIN und granulomatöse Prostatitis nicht nachgewiesen.</p><p><b>Diagnose:</b> Azinäres Adenokarzinom der Prostata (ICD-O 8140/3), Gleason-Score 3+4=7, ISUP-Gradgruppe 2.</p></div>"
    },
    "entry" : [{
      "reference" : "Observation/mii-exa-test-data-patho-conclusion-grouper-1"
    }],
    "section" : [{
      "title" : "Diagnose",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Azinäres Adenokarzinom der Prostata (ICD-O 8140/3), ISUP-Gradgruppe 2.</p></div>"
      }
    }]
  },
  {
    "title" : "Zusätzliche Beobachtungen",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "100969-5",
        "display" : "Pathology report additional specified observation in Specimen Narrative"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Immunhistochemie: Die Tumorzellen sind negativ für p63.</p></div>"
    },
    "entry" : [{
      "reference" : "Observation/mii-exa-test-data-patho-zusatz-grouper-1"
    }],
    "section" : [{
      "title" : "Immunhistochemie",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Immunhistochemie: Tumorzellen negativ für p63.</p></div>"
      }
    }]
  }]
}

```
